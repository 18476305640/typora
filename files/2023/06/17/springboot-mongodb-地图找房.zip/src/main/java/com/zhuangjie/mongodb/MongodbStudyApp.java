package com.zhuangjie.mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MongodbStudyApp {
    public static void main(String[] args) {
        SpringApplication.run(MongodbStudyApp.class,args);
    }
}
