package com.zhuangjie.docker.mapper;


import com.zhuangjie.docker.entities.User;
import tk.mybatis.mapper.common.Mapper;
public interface UserMapper extends Mapper<User> {
}
