const {app, BrowserWindow,ipcMain} = require('electron')
const path = require('path')
const fs = require('fs')

app.on('ready', () => {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        autoHideMenuBar: true,
        webPreferences: {
            preload: path.join(__dirname, './preload.js')
        }
    })
    win.loadFile('pages/index/index.html')
    
    ipcMain.handle('write-file', (event, text) => {
        // 写入到文件
        return new Promise((resolve, reject) => {
            fs.writeFile('D://writeData.text', text, (err) => resolve(err == null) )
        })
    })
    ipcMain.handle('read-file', (event) => {
        return new Promise((resolve, reject) => {
            fs.readFile('D://writeData.text', 'utf-8', (err, data) => {
                if (err !== null) reject(err)
                resolve(data)
            })
        })
    })
})

console.log('Hello from main.js')