window.addEventListener('load', function() {
    const input = document.querySelector("#input");
    document.querySelector("#write").onclick = async function() {
        if(await preloadProvide.writeFile(input.value)) {
            alert('完成写入')
        }else {
            alert('写入失败')
        }
    }
    document.querySelector("#read").addEventListener('click',async () => {
        alert(await preloadProvide.readFile());
    });
});
