const {contextBridge, ipcRenderer} = require('electron');
contextBridge.exposeInMainWorld('preloadProvide', {
  writeFile: (text)=>{
     return ipcRenderer.invoke('write-file', text);
  },
  readFile: ()=>{
    return ipcRenderer.invoke('read-file');
  }
});