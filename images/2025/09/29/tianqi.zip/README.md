# 天气查询系统

一个使用Java开发的天气查询系统，支持查询国内城市的天气信息。本项目将原有的国外天气API替换为国内的和风天气API，提供更稳定、更准确的国内天气数据。

## 功能特点

- 支持通过城市名称查询实时天气信息
- 提供未来3天的天气预报
- 当API调用失败时自动返回模拟数据
- 响应式设计，适配不同设备
- 支持热门城市快速查询

## 技术栈

- Java Servlet
- JSP
- Tailwind CSS
- 和风天气API

## 如何使用

### 1. 获取和风天气API密钥

1. 访问[和风天气开放平台](https://dev.qweather.com/)
2. 注册账号并登录
3. 创建应用并获取API密钥

### 2. 配置API密钥

将获取到的API密钥替换到`WeatherService.java`文件中的`API_KEY`常量：

```java
// 和风天气API密钥 (请替换为您自己的API密钥)
private static final String API_KEY = "your_qweather_api_key_here";
```

### 3. 部署项目

将项目部署到支持Java EE的Web服务器（如Tomcat）上。

### 4. 访问系统

启动服务器后，通过浏览器访问：`http://localhost:8080/weather-service`

## API说明

本项目使用了和风天气的以下API：

1. **城市搜索API**：根据城市名称获取城市ID
   - URL: `https://geoapi.qweather.com/v2/city/lookup`

2. **实时天气API**：获取指定城市的实时天气数据
   - URL: `https://devapi.qweather.com/v7/weather/now`

3. **3天预报API**：获取指定城市未来3天的天气预报
   - URL: `https://devapi.qweather.com/v7/weather/3d`

详细的API文档请参考[和风天气开发文档](https://dev.qweather.com/docs/)。

## 项目结构

```
weather-service/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       ├── weather/
│   │   │       │   ├── model/
│   │   │       │   │   ├── WeatherInfo.java
│   │   │       │   │   └── WeatherForecast.java
│   │   │       │   ├── service/
│   │   │       │   │   └──── WeatherService.java
│   │   │       │   └── servlet/
│   │   │       │       └── WeatherServlet.java
│   │   └── webapp/
│   │       ├── index.jsp
│   │       ├── result.jsp
│   │       └── WEB.xml
│   └── README.md
```

## 注意事项

1. 免费版API有调用次数限制，请合理使用
2. 如果需要更高的调用频率或更多功能，请考虑升级到付费版API
3. API密钥是敏感信息，请妥善保管，不要在公开代码中泄露

## 许可证

MIT
