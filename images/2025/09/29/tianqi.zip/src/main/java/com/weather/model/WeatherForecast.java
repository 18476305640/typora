package com.weather.model;

public class WeatherForecast {
    private String date;
    private String dayOfWeek;
    private String weather;
    private String description;
    private String icon;
    private String maxTemperature;
    private String minTemperature;
    private String humidity;
    private String windSpeed;
    
    // Getters and Setters
    public String getDate() {
        return date;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public String getDayOfWeek() {
        return dayOfWeek;
    }
    
    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }
    
    public String getWeather() {
        return weather;
    }
    
    public void setWeather(String weather) {
        this.weather = weather;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getIcon() {
        return icon;
    }
    
    public void setIcon(String icon) {
        this.icon = icon;
    }
    
    public String getMaxTemperature() {
        return maxTemperature;
    }
    
    public void setMaxTemperature(String maxTemperature) {
        this.maxTemperature = maxTemperature;
    }
    
    public String getMinTemperature() {
        return minTemperature;
    }
    
    public void setMinTemperature(String minTemperature) {
        this.minTemperature = minTemperature;
    }
    
    public String getHumidity() {
        return humidity;
    }
    
    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }
    
    public String getWindSpeed() {
        return windSpeed;
    }
    
    public void setWindSpeed(String windSpeed) {
        this.windSpeed = windSpeed;
    }
}
