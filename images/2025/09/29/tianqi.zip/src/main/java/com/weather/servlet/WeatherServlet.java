package com.weather.servlet;

import com.weather.model.WeatherInfo;
import com.weather.model.WeatherForecast;
import com.weather.service.WeatherService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class WeatherServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        WeatherService weatherService = new WeatherService();
        String city = request.getParameter("city");

        if (city == null || city.trim().isEmpty()) {
            request.setAttribute("error", "请输入城市名称");
            request.getRequestDispatcher("result.jsp").forward(request, response);
            return;
        }

        try {
            WeatherInfo weatherInfo = weatherService.getWeatherByCity(city);
            List<WeatherForecast> forecasts = weatherService.getWeatherForecast(city);

            request.setAttribute("weatherInfo", weatherInfo);
            request.setAttribute("forecasts", forecasts);
        } catch (Exception e) {
            request.setAttribute("error", "查询天气失败: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("result.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
