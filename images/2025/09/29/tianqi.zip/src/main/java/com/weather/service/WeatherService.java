package com.weather.service;

import com.weather.model.WeatherInfo;
import com.weather.model.WeatherForecast;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class WeatherService {

    private static final String BASE_URL_7D = "https://apis.kit9.cn/api/seven_days_weather/api.php?city=%s";
    private static final String BASE_URL_REALTIME = "https://apis.kit9.cn/api/weather/api.php?city=%s";

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 获取实时天气信息（包含当前温度）
     * @param cityName 城市名称
     * @return WeatherInfo
     * @throws IOException 网络请求异常
     */
    public WeatherInfo getWeatherByCity(String cityName) throws IOException {
        String url = String.format(BASE_URL_REALTIME, cityName);

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(url);
            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                String jsonResponse = EntityUtils.toString(response.getEntity(), "UTF-8");
                System.out.println("实时天气信息 jsonResponse: " + jsonResponse);
                if (response.getStatusLine().getStatusCode() == 200) {
                    return parseRealtimeWeather(jsonResponse, cityName);
                } else {
                    return getMockWeatherData(cityName);
                }
            }
        } catch (Exception e) {
            return getMockWeatherData(cityName);
        }
    }

    /**
     * 解析实时天气
     */
    private WeatherInfo parseRealtimeWeather(String jsonResponse, String cityName) throws IOException {
        JsonNode root = objectMapper.readTree(jsonResponse);
        if (root.path("code").asInt() != 200) {
            return getMockWeatherData(cityName);
        }

        JsonNode data = root.path("data");
        WeatherInfo info = new WeatherInfo();

        info.setCity(cityName);
        info.setTemperature(data.path("temperature").asText());   // 1/5°
        info.setWeather(data.path("weather").asText());
        info.setDescription(data.path("weather").asText());
        info.setHumidity(data.path("humidity").asText() + "%");
        info.setWindSpeed(data.path("wind_direction").asText() + " " + data.path("wind_scale").asText() + "级");


        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        info.setUpdateTime(sdf.format(new Date()));

        return info;
    }

    /**
     * 获取未来7日天气预报
     */
    public List<WeatherForecast> getWeatherForecast(String cityName) throws IOException {
        String url = String.format(BASE_URL_7D, cityName);

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(url);
            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                String jsonResponse = EntityUtils.toString(response.getEntity(), "UTF-8");
                System.out.println("7日天气 jsonResponse: " + jsonResponse);
                if (response.getStatusLine().getStatusCode() == 200) {
                    return parseForecastResponse(jsonResponse);
                } else {
                    return getMockForecastData(cityName);
                }
            }
        } catch (Exception e) {
            return getMockForecastData(cityName);
        }
    }

    /**
     * 解析7天天气预报
     */
    private List<WeatherForecast> parseForecastResponse(String jsonResponse) throws IOException {
        JsonNode root = objectMapper.readTree(jsonResponse);
        List<WeatherForecast> forecasts = new ArrayList<>();

        if (root.path("code").asInt() != 200) {
            return forecasts;
        }

        JsonNode data = root.path("data");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.CHINESE);

        for (JsonNode day : data) {
            WeatherForecast forecast = new WeatherForecast();
            String dateStr = day.path("date").asText();
            forecast.setDate(dateStr);

            try {
                Date date = dateFormat.parse(dateStr);
                forecast.setDayOfWeek(dayFormat.format(date));
            } catch (Exception e) {
                forecast.setDayOfWeek("");
            }

            forecast.setWeather(day.path("weather").asText());
            forecast.setDescription(day.path("weather").asText());
            forecast.setIcon("");

            forecast.setMaxTemperature(day.path("high").asText() + "°C");
            forecast.setMinTemperature(day.path("low").asText() + "°C");
            forecast.setHumidity("-");
            forecast.setWindSpeed(day.path("wind_direction").asText() + " " + day.path("wind_scale").asText() + "级");

            forecasts.add(forecast);
        }

        return forecasts;
    }

    /**
     * 模拟今日天气数据
     */
    private WeatherInfo getMockWeatherData(String cityName) {
        System.out.println("error: 无法请求今日天气数据，使用模拟数据！！！");
        WeatherInfo info = new WeatherInfo();
        info.setCity(cityName);
        info.setTemperature("20/10°");
        info.setWeather("晴");
        info.setDescription("晴朗");
        info.setHumidity("50%");
        info.setWindSpeed("西风 2级");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        info.setUpdateTime(sdf.format(new Date()));

        return info;
    }

    /**
     * 模拟7天天气数据
     */
    private List<WeatherForecast> getMockForecastData(String cityName) {
        System.err.println("无法获取城市天气信息，使用模拟天气数据!!");
        List<WeatherForecast> forecasts = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.CHINESE);

        for (int i = 0; i < 7; i++) {
            WeatherForecast forecast = new WeatherForecast();
            Date date = calendar.getTime();
            forecast.setDate(dateFormat.format(date));
            forecast.setDayOfWeek(dayFormat.format(date));

            forecast.setWeather("晴");
            forecast.setDescription("晴朗");
            forecast.setIcon("");
            forecast.setMaxTemperature((20 + i) + "°C");
            forecast.setMinTemperature((10 + i) + "°C");
            forecast.setHumidity("50%");
            forecast.setWindSpeed("西风 2级");

            forecasts.add(forecast);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        return forecasts;
    }
}
