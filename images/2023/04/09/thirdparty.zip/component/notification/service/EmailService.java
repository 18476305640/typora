package com.zhuangjie.gulimall.thirdparty.component.notification.service;

public interface EmailService extends MessageService {
}
