package com.zhuangjie.gulimall.thirdparty.component.notification.service;

public interface SmsService extends MessageService {
}
