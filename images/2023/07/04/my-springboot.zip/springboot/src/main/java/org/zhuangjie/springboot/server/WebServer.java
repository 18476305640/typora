package org.zhuangjie.springboot.server;

import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

public interface WebServer {

    public void start(AnnotationConfigWebApplicationContext applicationContext);

}

