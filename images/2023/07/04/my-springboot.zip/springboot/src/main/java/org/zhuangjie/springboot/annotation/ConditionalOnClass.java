package org.zhuangjie.springboot.annotation;

import org.springframework.context.annotation.Conditional;
import org.zhuangjie.springboot.server.WebServerConditionalOnClass;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Conditional(WebServerConditionalOnClass.class)
public @interface ConditionalOnClass {
    String value() default "";
}
