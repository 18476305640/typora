package org.zhuangjie.springboot;

import org.springframework.context.annotation.DeferredImportSelector;
import org.springframework.core.type.AnnotationMetadata;

public class AutoConfigurationImportSelector implements DeferredImportSelector {
    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        // 这里应该负责扫描所有jar下 META-INF/spring.factories ，得到要自动配置的className
        return new String[]{"org.zhuangjie.springboot.autoconfigure.WebServerAutoConfiguration"};
    }
}
