package org.zhuangjie.springboot;

import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.zhuangjie.springboot.server.WebServer;

import java.util.Collection;
import java.util.Map;

public class SpringApplication {

    public static void run(Class clazz,String[] args){
        AnnotationConfigWebApplicationContext applicationContext = new AnnotationConfigWebApplicationContext();
        applicationContext.register(clazz);
        applicationContext.refresh();

        WebServer webServer = getWebServer(applicationContext);
        webServer.start(applicationContext);
    }

    private static WebServer getWebServer(AnnotationConfigWebApplicationContext applicationContext) {
        Map<String, WebServer> webServerMap = applicationContext.getBeansOfType(WebServer.class);
        Collection<WebServer> webServerBeans = webServerMap.values();
        if (webServerBeans.size() == 0) {
            throw new NullPointerException("没有可启动的WebServer!");
        }
        if (webServerBeans.size() > 1) {
            throw new RuntimeException("WebServer存在多个！");
        }
        return webServerBeans.stream().findFirst().get();
    }



}