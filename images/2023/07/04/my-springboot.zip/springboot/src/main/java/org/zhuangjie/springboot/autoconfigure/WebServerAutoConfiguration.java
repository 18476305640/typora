package org.zhuangjie.springboot.autoconfigure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.zhuangjie.springboot.annotation.ConditionalOnClass;
import org.zhuangjie.springboot.server.JettyWebServer;
import org.zhuangjie.springboot.server.TomcatWebServer;

@Configuration
public class WebServerAutoConfiguration {
    @Bean
    @ConditionalOnClass("org.apache.catalina.startup.Tomcat")
    public TomcatWebServer tomcatWebServer() {
        return new TomcatWebServer();
    }

    @Bean
    @ConditionalOnClass("org.eclipse.jetty.server.Server")
    public JettyWebServer jettyWebServer() {
        return new JettyWebServer();
    }

}
