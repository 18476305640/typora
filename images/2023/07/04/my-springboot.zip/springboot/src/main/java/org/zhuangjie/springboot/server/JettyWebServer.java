package org.zhuangjie.springboot.server;

import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

public class JettyWebServer implements WebServer{

    @Override
    public void start(AnnotationConfigWebApplicationContext applicationContext) {
        System.out.println("启动Jetty");
    }
}