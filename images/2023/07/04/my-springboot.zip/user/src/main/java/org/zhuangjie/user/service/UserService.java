package org.zhuangjie.user.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    public String test() {
        return "Hello,world~";
    }
}
