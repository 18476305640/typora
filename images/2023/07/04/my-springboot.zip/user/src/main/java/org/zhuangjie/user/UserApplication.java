package org.zhuangjie.user;

import org.springframework.context.annotation.Import;
import org.zhuangjie.springboot.SpringApplication;
import org.zhuangjie.springboot.annotation.SpringBootApplication;
import org.zhuangjie.springboot.autoconfigure.WebServerAutoConfiguration;

@SpringBootApplication
public class UserApplication {
    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class,args);
    }
}