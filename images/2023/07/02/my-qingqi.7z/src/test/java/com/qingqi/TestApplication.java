package com.qingqi;


import cn.hutool.core.util.StrUtil;
import com.qingqi.controller.RouteController;
import com.qingqi.service.BaiduService;
import com.qingqi.vo.RunParamVo;
import io.jsonwebtoken.Jwt;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
public class TestApplication {

    @Autowired
    private BaiduService baiduService;

    String routeId = "64a0d26ecfc3b37eb27847be";
    String points = "116.361869,39.945919|116.362516,39.938395|116.379404,39.938838|116.378469,39.946417|116.378469,39.946417";
    @Test
    public void test() {
        Arrays.stream(StrUtil.split(points, "|")).forEach(point->{
            String[] ll = point.split(",");
            Boolean state = baiduService.uploadLocation(routeId, new RunParamVo(Double.valueOf(ll[0]), Double.valueOf(ll[1]), Double.valueOf(12.5)));
            System.out.println( Double.valueOf(ll[0])+","+ Double.valueOf(ll[1])+"result： "+state);
            try {
                Thread.sleep(6000);
            }catch (Exception e) {}
        });
    }
    @Autowired
    private RouteController routeController;
    @Test
    public void  test2() {
        routeController.updateRoute("64a0d26ecfc3b37eb27847be","哈哈，骑了一会");
    }

}
