package com.qingqi.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.NumberUtil;
import com.mongodb.client.result.UpdateResult;
import com.qingqi.pojo.Route;
import com.qingqi.pojo.RunRoute;
import com.qingqi.pojo.User;
import com.qingqi.utils.UserThreadLocal;
import com.qingqi.vo.ErrorResult;
import com.qingqi.vo.NearRouteVo;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.geo.Metrics;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.NearQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class RouteService {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private BaiduService baiduService;

    @Autowired
    private RouteInfoService routeInfoService;

    @Autowired
    private UserService userService;


    /**
     * 创建路线
     *
     * @return
     */
    public String createRoute() {
        Route route = new Route();
        route.setId(ObjectId.get());
        route.setUserId(UserThreadLocal.get());
        route.setStatus(1);
        route.setIsShare(false); //默认不投稿
        route.setStartTime(System.currentTimeMillis());

        //将数据保存到MongoDB
        this.mongoTemplate.save(route);

        String routeId = route.getId().toString();
        //百度地图鹰眼服务中创建Entity
        Boolean bool = this.baiduService.createEntity(routeId);
        if (bool) {
            //成功
            return routeId;
        }

        //失败
        return null;
    }


    /**
     * 删除路线
     *
     * @param routeId 路线id
     * @return
     */
    public Boolean deleteRoute(String routeId) {
        //删除MongoDB中的数据
        Query query = this.createQuery(routeId);
        boolean result = this.mongoTemplate.remove(query, Route.class).getDeletedCount() == 1;
        if (result) {
            //删除百度鹰眼服务中的实体
            if (this.baiduService.deleteEntity(routeId)) {
                return true;
            }
        }
        return false;
    }
    /**
     * 构造查询对象，设置了2个条件，其中userId是确保只删除自己的数据
     *
     * @param routeId
     * @return
     */
    private Query createQuery(String routeId) {
        return Query.query(Criteria.where("id").is(new ObjectId(routeId))
                .and("userId").is(UserThreadLocal.get()));
    }

    /**
     * 更新路线（结束运动）
     *
     * @param routeId 路线id
     * @param title   路线标题
     * @return
     */
    public Object updateRoute(String routeId, String title) {
        //判断路线是否已经结束，如果已经结束就不能再次结束
        Route route = this.queryRouteById(routeId);
        if (null == route) {
            return ErrorResult.builder()
                    .errCode("500").errMessage("结束运动失败，路线不存在.").build();
        }

        if (route.getStatus() == 0) {
            return ErrorResult.builder()
                    .errCode("501").errMessage("结束运动失败，该路线已经结束.").build();
        }

        //更新路线数据
        Update update = Update.update("title", title)
                .set("status", 0)
                .set("endTime", System.currentTimeMillis());

        UpdateResult updateResult = this.mongoTemplate.updateFirst(this.createQuery(routeId), update, Route.class);
        if (updateResult.getModifiedCount() == 1) {
            //查询百度地图鹰眼服务中的路线轨迹点，更新到路线数据中，异步的操作
            this.routeInfoService.updateRouteInfo(routeId, UserThreadLocal.get());

            //结束沿着路线骑行的关系
            Update runRouteUpdate = Update.update("status", 0)
                    .set("updated", System.currentTimeMillis());
            //条件
            Query runRouteQuery = Query.query(Criteria.where("routeId").is(routeId)
                    .and("userId").is(UserThreadLocal.get())
                    .and("status").is(1));
            UpdateResult runRouteUpdateResult = this.mongoTemplate.updateFirst(runRouteQuery, runRouteUpdate, RunRoute.class);

            //更新成功
            return runRouteUpdateResult.getModifiedCount() == 1;
        }

        return ErrorResult.builder()
                .errCode("502").errMessage("结束运动失败.").build();
    }



    /**
     * 根据主键查询路线对象
     *
     * @param routeId
     * @return
     */
    public Route queryRouteById(String routeId) {
        return this.mongoTemplate.findById(new ObjectId(routeId), Route.class);
    }

    /**
     * 投稿路线 修改isShare为true
     *
     * @param routeId 路线id
     * @return
     */
    public Boolean shareRoute(String routeId) {
        Update update = Update.update("isShare", true);
        Query query = this.createQuery(routeId);

        UpdateResult updateResult = this.mongoTemplate.updateFirst(query, update, Route.class);
        return updateResult.getModifiedCount() == 1;
    }


    /**
     * 查询附近的路线
     *
     * @param longitude 当前用户所在位置的经度
     * @param latitude  当前用户所在位置的纬度
     * @param distance  查询的距离，单位：km，默认10km
     * @return
     */
    public Object queryNearRoute(Double longitude, Double latitude, Double distance) {

        //构造查询，附近搜索数据，条件：路线已经结束并且已经分享
        NearQuery nearQuery = NearQuery.near(longitude, latitude, Metrics.KILOMETERS)
                .maxDistance(distance)
                .query(Query.query(Criteria.where("isShare").is(true).and("status").is(0)));

        //geo的查询
        GeoResults<Route> geoResults = this.mongoTemplate.geoNear(nearQuery, Route.class);
        if (CollUtil.isEmpty(geoResults.getContent())) {
            //没有数据
            return Collections.emptyList();
        }
        return geoResults.getContent().stream()
                .map(result -> {
                    Route route = result.getContent();
                    //数据拷贝
                    NearRouteVo nearRouteVo = BeanUtil.toBeanIgnoreError(route, NearRouteVo.class);
                    nearRouteVo.setLongitude(route.getLocation().getX());
                    nearRouteVo.setLatitude(route.getLocation().getY());
                    nearRouteVo.setRange(NumberUtil.round(result.getDistance().getValue(), 2).doubleValue());//路线与我的距离
                    return nearRouteVo;
                }).collect(Collectors.toList());
    }


    /**
     * 路线同行的人
     *
     * @param routeId 路线id
     * @return
     */
    public Object queryRouteNearUser(String routeId) {
        //查询正在该路线骑行的人，最多查询9个
        PageRequest pageRequest = PageRequest.of(0, 9, Sort.by(Sort.Order.desc("created")));
        Query query = Query.query(Criteria.where("runRouteId").is(routeId)
                .and("status").is(1)).with(pageRequest);
        List<RunRoute> runRouteList = this.mongoTemplate.find(query, RunRoute.class);
        if (CollUtil.isEmpty(runRouteList)) {
            //没有查询到数据
            return MapUtil.builder().put("count", 0)
                    .put("records", Collections.EMPTY_LIST).build();
        }

        //查询用户数据
        List<Object> userIdList = CollUtil.getFieldValues(runRouteList, "userId");
        Map<Long, User> userMap = this.userService.queryUserMap(userIdList);

        //构造响应结果数据
        List<Map<Object, Object>> resultList = runRouteList.stream().map(runRoute -> {
            User user = userMap.get(runRoute.getUserId());
            return MapUtil.builder()
                    .put("userId", runRoute.getUserId())
                    .put("logo", user.getLogo())
                    .put("nickName", user.getNickName()).build();
        }).collect(Collectors.toList());

        //查询数量
        Query countQuery = Query.query(Criteria.where("runRouteId").is(routeId)
                .and("status").is(1));
        long count = this.mongoTemplate.count(countQuery, RunRoute.class);

        return MapUtil.builder().put("count", count)
                .put("records", resultList).build();
    }






}
