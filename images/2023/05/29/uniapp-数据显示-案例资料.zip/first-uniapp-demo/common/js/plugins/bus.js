// eventBus.js

// 创建事件总线对象
const eventBus = {
  events: {},
  emit(event, data) {
    // 检查事件是否存在
    if (!this.events[event]) {
      return;
    }
    // 触发事件的所有回调函数
    this.events[event].forEach(callback => {
      callback(data);
    });
  },
  on(event, callback) {
    // 检查事件是否已存在，如果不存在则创建一个空数组来存储回调函数
    if (!this.events[event]) {
      this.events[event] = [];
    }
    // 将回调函数添加到事件的回调函数数组中
    this.events[event].push(callback);
  }
};

// 导出事件总线对象
export default eventBus;
