<template>
	<view class="uni-list">
		<block v-for="(value,index) in listData" :key="index">
			<view class="uni-list-cell">
				<view class="uni-media-list">
					<image class="uni-media-list-logo" :src="'http://localhost/image/'+value.coverImage"></image>
					<view class="uni-media-list-body">
						<view class="uni-media-list-text-top">{{value.title}}</view>
						<view class="uni-media-list-text-bottom">
							<text>{{value.author}}</text>
							<text>{{value.releaseDate}}</text>
						</view>
					</view>
				</view>
			</view>
		</block>
		<uni-load-more :status="status" :icon-size="16" :content-text="contentText"></uni-load-more>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				queryParam: {
					pageNum: 1,
					pageSize: 10
				},
				totalPage: 0,
				listData: [],
				status: 'more',
				contentText: {
					contentdown: '上拉加载更多',
					contentrefresh: '加载中',
					contentnomore: '没有更多'
				}
			}
		},
		onLoad() {
			this.getList();
		},
		onPullDownRefresh() {
			this.listData = []
			this.pageNum = 1
			this.getList()
		},
		onReachBottom() {
			console.log("下拉触底")
			console.log("下拉触底")
			if (this.queryParam.pageNum >= this.totalPage) {
				console.log("没有下一页数据");
				this.status = "noMore"
			} else {
				console.log("有下一页数据");
				this.queryParam.pageNum++;
				this.getList();
			}
		},
		methods: {
			getList: function() {
				uni.request({
					url: 'http://localhost/news/list',
					method: 'POST',
					data: this.queryParam,
					success: data => {
						let result = data.data;
						if (result.code == 200) {
							this.listData = [...this.listData, ...result.newsList];
							this.totalPage = result.totalPage;
						}
						uni.stopPullDownRefresh()
					},
					fail: (data, code) => {
						console.log("fail:" + JSON.stringify(data))
						uni.stopPullDownRefresh();
					}

				})
			}
		}
	}
</script>

<style lang="scss">
	.uni-list {
		background-color: #FFFFFF;
		position: relative;
		width: 100%;
		display: flex;
		flex-direction: column;

		.uni-list-cell {
			position: relative;
			display: flex;
			flex-direction: row;
			justify-content: space-between;
			align-items: center;

			.uni-media-list {
				padding: 22rpx 30rpx;
				box-sizing: border-box;
				display: flex;
				width: 100%;
				flex-direction: row;

				.uni-media-list-logo {
					width: 5.625rem;
					height: 4.375rem;
					margin-right: 0.625rem;
				}

				.uni-media-list-body {
					height: auto;
					display: flex;
					flex: 1;
					flex-direction: column;
					justify-content: space-around;
					align-items: flex-start;
					overflow: hidden;

					.uni-media-list-text-top {
						height: 2.3125rem;
						font-size: 0.875rem;
						overflow: hidden;
						width: 100%;
						line-height: 1.125rem;
					}

					.uni-media-list-text-bottom {
						display: flex;
						flex-direction: row;
						justify-content: space-between;
						width: 100%;
						line-height: 0.9375rem;
						font-size: 0.8125rem;
						color: #8f8f94;
					}

				}
			}
		}

		.uni-list-cell::after {
			position: absolute;
			z-index: 3;
			right: 0;
			bottom: 0;
			left: 0.9375rem;
			height: 1px;
			content: '';
			transform: scaleY(.5);
			background-color: #c8c7cc;
		}

	}
</style>