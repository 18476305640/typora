package com.java1234.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 新闻实体
 * @author java1234_小锋 （公众号：java1234）
 * @site www.java1234.vip
 * @company 南通小锋网络科技有限公司
 */
@TableName(value = "t_news")
@Data
public class News implements Serializable {

    /**
     * 编号
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 标题
     */
    @TableField(value = "title")
    private String title;

    /**
     * 作者
     */
    @TableField(value = "author")
    private String author;

    /**
     * 发布日期
     */
    @JsonSerialize(using=CustomDateTimeSerializer.class)
    @TableField(value = "releaseDate")
    @JsonFormat(pattern ="yyyy-MM-dd HH:mm:ss")
    private Date releaseDate;

    /**
     * 封面图片
     */
    @TableField(value = "coverImage")
    private String coverImage;

    /**
     * 新闻内容
     */
    @TableField(value = "content")
    private String content;


}
