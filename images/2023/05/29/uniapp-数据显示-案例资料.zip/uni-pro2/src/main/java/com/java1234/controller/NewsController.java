package com.java1234.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.java1234.entity.News;
import com.java1234.entity.PageBean;
import com.java1234.entity.R;
import com.java1234.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 新闻Controller控制器
 * @author java1234_小锋 （公众号：java1234）
 * @site www.java1234.vip
 * @company 南通小锋网络科技有限公司
 */
@RestController
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private NewsService newsService;

    /**
     * 测试
     * @return
     */
    @GetMapping("/test")
    public R test(){
        return R.ok("测试");
    }

    /**
     * 查询新闻信息
     * @return
     */
    @PostMapping("/list")
    public R list(@RequestBody PageBean pageBean) throws InterruptedException {
        Thread.sleep(1000);
        Page<News> pageResult = newsService.page(new Page<>(pageBean.getPageNum(), pageBean.getPageSize()));
        Map<String,Object> resultMap=new HashMap<>();
        resultMap.put("newsList",pageResult.getRecords());
        resultMap.put("totalPage",pageResult.getPages());
        return R.ok(resultMap);
    }
}
