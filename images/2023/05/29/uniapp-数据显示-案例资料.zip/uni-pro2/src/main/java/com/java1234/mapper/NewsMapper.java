package com.java1234.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.java1234.entity.News;

/**
 * 新闻Mapper接口
 */
public interface NewsMapper extends BaseMapper<News> {
}
