package com.java1234.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.java1234.entity.News;

/**
 * 新闻Service接口
 */
public interface NewsService extends IService<News> {
}
