package com.java1234.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.java1234.entity.News;
import com.java1234.mapper.NewsMapper;
import com.java1234.service.NewsService;
import org.springframework.stereotype.Service;

/**
 * 新闻Service实现类
 * @author java1234_小锋 （公众号：java1234）
 * @site www.java1234.vip
 * @company 南通小锋网络科技有限公司
 */
@Service
public class NewsServiceImpl extends ServiceImpl<NewsMapper, News> implements NewsService {


}
