package com.zhuangjie.recursion;

public class MaxSubArray {
    public static void main(String[] args) {
        System.out.println(maxSubArrayS(new int[]{-2, 1, -3, 4, -1, 2, 1, -5, 4}));
    }
    static int maxSubArray(int[] nums) {
        if (nums == null || nums.length == 0) return 0;
        int[] dp = new int[nums.length];
        int max = dp[0] = nums[0];
        for (int i = 1; i < nums.length; i++) {
            if (dp[i - 1] > 0) {
                dp[i] = dp[i - 1] + nums[i];
            }else {
                dp[i] = nums[i];
            }
            max = Math.max(max,dp[i]);
        }
        return max;
    }
    static int maxSubArrayS(int[] nums) {
        if (nums == null || nums.length == 0) return 0;
        int dp = nums[0];
        int max = dp;
        for (int i = 1; i < nums.length; i++) {
            if (dp > 0) {
                dp = dp + nums[i];
            }else {
                dp = nums[i];
            }
            max = Math.max(max,dp);
        }
        return max;
    }
}
