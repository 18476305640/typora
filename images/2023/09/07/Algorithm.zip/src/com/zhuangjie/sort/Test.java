package com.zhuangjie.sort;

import com.zhuangjie.sort.utils.IntegerUtils;

public class Test {
    public static void main(String[] args) {
//        Integer[] array = IntegerUtils.headTailAscOrder(0, 10000, 10000);
        Integer[] array = {2,4,8,8,8,12,24,14,5,5};
//        BubbleSort<Integer> bubbleSort = new BubbleSort();
//        System.out.println(IntegerUtils.isAscOrder(array));
//        bubbleSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(bubbleSort.array));
//        System.out.println(bubbleSort);
//
//        BubbleSort<Integer> bubbleSort2 = new BubbleSort(true);
//        System.out.println(IntegerUtils.isAscOrder(array));
//        bubbleSort2.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(bubbleSort2.array));
//        System.out.println(bubbleSort2);
//
//        SelectionSort<Integer> selectSort = new SelectionSort<>();
//        System.out.println(IntegerUtils.isAscOrder(array));
//        selectSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(selectSort.array));
//        System.out.println(selectSort);
//
//        HeapSort<Integer> heapSort = new HeapSort<>();
//        System.out.println(IntegerUtils.isAscOrder(array));
//        heapSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(heapSort.array));
//        System.out.println(heapSort);
//
//        InsertionSort<Integer> insertionSort = new InsertionSort<>();
//        System.out.println(IntegerUtils.isAscOrder(array));
////        IntegerUtils.println(array);
//        insertionSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(insertionSort.array));
////        IntegerUtils.println(insertionSort.array);
//        System.out.println(insertionSort);
//
//        MergeSort<Integer> mergeSort = new MergeSort<>();
//        System.out.println(IntegerUtils.isAscOrder(array));
////        IntegerUtils.println(array);
//        mergeSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(mergeSort.array));
////        IntegerUtils.println(mergeSort.array);
//        System.out.println(mergeSort);
//
//        QuickSort<Integer> quickSort = new QuickSort<>();
//        System.out.println(IntegerUtils.isAscOrder(array));
////        IntegerUtils.println(array);
//        quickSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(quickSort.array));
////        IntegerUtils.println(quickSort.array);
//        System.out.println(quickSort);
//
//        ShellSort<Integer> shellSort = new ShellSort<>();
//        System.out.println(IntegerUtils.isAscOrder(array));
//        IntegerUtils.println(array);
//        shellSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(shellSort.array));
//        IntegerUtils.println(shellSort.array);
//        System.out.println(shellSort);
//
//        CountingSort countingSort = new CountingSort();
//        System.out.println(IntegerUtils.isAscOrder(array));
//        IntegerUtils.println(array);
//        countingSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(countingSort.array));
//        IntegerUtils.println(countingSort.array);
//        System.out.println(countingSort);

//        CountingSort countingSort = new CountingSort();
//        System.out.println(IntegerUtils.isAscOrder(array));
//        IntegerUtils.println(array);
//        countingSort.sort(IntegerUtils.copy(array));
//        System.out.println(IntegerUtils.isAscOrder(countingSort.array));
//        IntegerUtils.println(countingSort.array);
//        System.out.println(countingSort);

        RadixSort radixSort = new RadixSort();
        System.out.println(IntegerUtils.isAscOrder(array));
        IntegerUtils.println(array);
        radixSort.sort(IntegerUtils.copy(array));
        System.out.println(IntegerUtils.isAscOrder(radixSort.array));
        IntegerUtils.println(radixSort.array);
        System.out.println(radixSort);





    }
}
