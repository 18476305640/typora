package com.zhuangjie.sort;

/**
 * 排序
 *
 * @author zhuangjie
 * @date 2023/08/11
 */
public abstract class Sort<T extends Comparable<T>> {
    protected T[] array;
    /**
     * 比较数
     */
    private int cmpCount;
    /**
     * 交换数
     */
    private int swapCount;
    /**
     * 算法排序耗时
     */
    protected long time;
    public void sort(T[] array) {
        if (array == null || array.length < 2) return;
        this.array = array;
        long begin = System.currentTimeMillis();
        sort();
        time = System.currentTimeMillis() - begin;
    }

    /**
     * 比较
     *
     * @param v1 v1
     * @param v2 v2
     * @return int
     */
    protected int compare(T v1, T v2) {
        cmpCount++;
        return v1.compareTo(v2);
    }
    protected abstract void sort();

    /**
     * 根据索引交换
     *
     * @param i1 i1
     * @param i2 i2
     */
    protected void swap(int i1, int i2) {
        swapCount++;
        T tmp = array[i1];
        array[i1] = array[i2];
        array[i2] = tmp;
    }

    @Override
    public String toString() {
        String timeStr = "耗时：" + (time / 1000.0) + "s(" + time + "ms)";
        String compareCountStr = "比较：" + cmpCount;
        String swapCountStr = "交换：" + swapCount;
        return "【" + getClass().getSimpleName() + "】\n"
                + timeStr + " \t"
                + compareCountStr + "\t "
                + swapCountStr + "\n"
                + "------------------------------------------------------------------";
    }
}
