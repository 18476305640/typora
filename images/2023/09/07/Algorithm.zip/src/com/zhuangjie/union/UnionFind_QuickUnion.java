package com.zhuangjie.union;

public class UnionFind_QuickUnion extends UnionFind{
    public UnionFind_QuickUnion(int capacity) {
        super(capacity);
    }

    @Override
    public int find(int v) {
        rangeCheck(v);
        int parent;
        while ((parent = parents[v]) != v) {
            v = parent;
        }
        return parent;
    }

    @Override
    public void union(int v1, int v2) {
        int p1 = find(v1);
        int p2 = find(v2);
        if (p1 != p2) parents[p1] = p2;
    }
}
