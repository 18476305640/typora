package com.zhuangjie.sort;

/**
 * 计数排序
 *
 * @author zhuangjie
 * @date 2023/08/17
 */
public class CountingSort extends Sort<Integer> {

    @Override
    protected void sort() {
//        sort0(); // 未优化版本-不稳定排序
        sort1(); // 优化版本-稳定排序优化空间
    }

    private void sort1() {
        // 找出最值
        int max = array[0];
        int min = array[0];
        for (Integer element : array) {
            if (element > max) max = element;
            if (element < min) min = element;
        }
        // 开辟内存空间，存储次数
        int[] counts = new int[max - min + 1]; //  min:2 max:3 ， 3-2=1还需要再加1还是要创建counts数组的长度
        for (Integer value : array) {
            counts[value - min]++; // 如果value是最小位，那这应该是0位置，所以value-min
        }
        // 累加次数
        for (int i = 1; i < counts.length; i++) {
            counts[i] += counts[i - 1];
        }
        // 从后往前遍历元素，将它放到有序数组中的合适位置
        int[] newArray = new int[array.length]; // 它将是最终排好序的数组
        for (int i = array.length-1; i >= 0; i--) { // 从后往前遍历元素
            // “array[i] - min” 是找元素“array[i]”在counts上对应的索引
            // “counts[array[i] - min]]” 自然是找在counts的值，即累加值。
            // “--counts[array[i] - min]]” 是在有序数组中的索引。注意是相同元素最后一个元素的在有序数组newArray中的索引
            newArray[--counts[array[i] - min]] = array[i];
        }
        // 将最终有序的数组newArray索引映射放到array上
        for (int i = 0; i < newArray.length; i++) {
            array[i] = newArray[i];
        }
    }

    private void sort0() {
        // 找出最大值
        int max = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i] > max) {
                max = array[i];
            }
        }
        // 构建数组,统计元素（作为counts的索引）的次数（索引对应的值）
        int[] counts = new int[max + 1];
        for (int i = 0; i < array.length; i++) {
            counts[array[i]]++;
        }
        // 遍历counts数组，由该数组的索引与value（次数），输出有序定稿array
        int index = 0;
        for (int i = 0; i < counts.length; i++) {
            while (counts[i]-- > 0) {
                array[index++] = i;
            }
        }
    }
}
