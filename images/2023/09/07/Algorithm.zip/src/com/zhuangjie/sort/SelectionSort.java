package com.zhuangjie.sort;

/**
 * 选择排序
 *
 * @author zhuangjie
 * @date 2023/08/16
 */
public class SelectionSort<T extends Comparable<T>> extends Sort<T>{
    @Override
    protected void sort() {
        int arrayLength = array.length;
        for (int end = arrayLength-1; end >= 0; end--) {
            int maxIndex = 0;
            for (int i = 1; i <= end; i++) {
                if (compare(array[i],array[maxIndex]) > 0) {
                    maxIndex = i;
                }
            }
            swap(maxIndex,end);
        }
    }
}
