package com.zhuangjie.graph.test;

import com.zhuangjie.graph.ListGraph;

/**
 * 测试
 *
 * @author zhuangjie
 * @date 2023/08/22
 */
public class OldTest {
    public static void main(String[] args) {
        test();
    }
    static void test() {
        ListGraph<String, Integer> graph = new ListGraph<>();
//		graph.addEdge("V0", "V1");
//		graph.addEdge("V1", "V0");
//
//		graph.addEdge("V0", "V2");
//		graph.addEdge("V2", "V0");
//
//		graph.addEdge("V0", "V3");
//		graph.addEdge("V3", "V0");
//
//		graph.addEdge("V1", "V2");
//		graph.addEdge("V2", "V1");
//
//		graph.addEdge("V2", "V3");
//		graph.addEdge("V3", "V2");
//
//		graph.print();

        graph.addEdge("V1", "V0", 9);
        graph.addEdge("V1", "V2", 3);
        graph.addEdge("V2", "V0", 2);
        graph.addEdge("V2", "V3", 5);
        graph.addEdge("V3", "V4", 1);
        graph.addEdge("V0", "V4", 6);

//        graph.removeEdge("V0", "V4");
//        graph.removeVertex("V0");

        System.out.println(graph.mst());
    }
}
