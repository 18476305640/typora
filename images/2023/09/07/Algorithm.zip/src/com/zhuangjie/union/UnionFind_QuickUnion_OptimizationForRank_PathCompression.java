package com.zhuangjie.union;

/**
 * 基于QuickUnion的Rank优化的再路径压缩优化
 *
 * @author zhuangjie
 * @date 2023/08/20
 */
public class UnionFind_QuickUnion_OptimizationForRank_PathCompression extends UnionFind_QuickUnion_OptimizationForRank{

    public UnionFind_QuickUnion_OptimizationForRank_PathCompression(int capacity) {
        super(capacity);
    }

    @Override
    public int find(int v) {
        rangeCheck(v);
        int parent = parents[v];
        if (parent != v) {
            parents[v] = find(parent);
        }
        return parents[v];
    }


}
