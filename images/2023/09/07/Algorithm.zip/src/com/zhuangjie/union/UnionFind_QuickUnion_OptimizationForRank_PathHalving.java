package com.zhuangjie.union;

/**
 * 基于QuickUnion的Rank优化的再"路径减半"优化
 *
 * @author zhuangjie
 * @date 2023/08/20
 */
public class UnionFind_QuickUnion_OptimizationForRank_PathHalving extends UnionFind_QuickUnion_OptimizationForRank{

    public UnionFind_QuickUnion_OptimizationForRank_PathHalving(int capacity) {
        super(capacity);
    }

    @Override
    public int find(int v) {
        rangeCheck(v);
        int parent;
        while ((parent = parents[v]) != v) {
            v = (parents[v] = parents[parent]);
        }
        return parent;
    }
}
