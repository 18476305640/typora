package com.zhuangjie.sort;

/**
 * 归并排序
 *
 * @author zhuangjie
 * @date 2023/08/13
 */
public class MergeSort<T extends Comparable<T>> extends Sort<T>  {
    T[] leftArray;

    @Override
    protected void sort() {
        // 将一个数组切半，多的放在右边，计算：floor(（(endIndex +1) - beginIndex）/2 )
        leftArray = (T[]) new Comparable[array.length >> 1];
        sort(0,array.length);

    }

    private void sort(int begin, int end) {
        if (end - begin < 2) return; // 当要分的元素只有一个时不能再分 0 1 2 这样再分，如果是0 1 这样就不能再分了因为1是不分括的
        int mid = (begin + end) >> 1;
        sort(begin,mid); //[begin,mid)
        sort(mid,end); // [mid,end)
        merge(begin,mid,end);
    }

    private void merge(int begin, int mid, int end) {
        int li = 0,le = mid - begin; // 左边数组(基于leftArray), 且le指向数组右外面
        int ri = mid,re = end; //  re指向数组右外面
        int ai = begin; // ai表示待填入的索引
        // 拷贝左边数组到leftArray中
        for(int i = li; i < le; i++) {
            leftArray[i] = array[begin + i];
        }
        // 合并
        while (li < le) {
            if (ri < re && compare(array[ri],leftArray[li]) < 0) {
                array[ai++] = array[ri++];
            }else {
                array[ai++] = leftArray[li++];
            }
        }
    }
}
