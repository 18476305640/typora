package com.zhuangjie.recursion;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Pirate {
    public static void main(String[] args) {
        int[] weights = {3, 5, 4, 10, 7, 14, 2, 11};
        Arrays.sort(weights);
        int capacity = 30; // 最大容量
        int weight = 0, count = 0;
        for (int i = 0; i < weights.length && weight < capacity; i++) {
            int current = weights[i];
            int newWeight = weight + current;
            if (newWeight > capacity) break;
            weight = newWeight;
            count++;
            System.out.println(current);
        }
        System.out.println("总重量："+weight+",总数量："+count);
    }
}
