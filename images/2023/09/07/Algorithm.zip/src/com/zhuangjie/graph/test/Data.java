package com.zhuangjie.graph.test;

import com.zhuangjie.graph.Graph;

public class Data {
    static Graph.WeightManager<Double> weightManager = new Graph.WeightManager<Double>() {
        public int compare(Double w1, Double w2) {
            return w1.compareTo(w2);
        }

        public Double add(Double w1, Double w2) {
            return w1 + w2;
        }

        @Override
        public Double zero() {
            return 0.0;
        }
    };
    public static final Object[][] NEGATIVE_WEIGHT1 = {
            {"A", "B", 10}, {"A", "D", 30},{"A", "E", 100},
            {"D", "C", 20}, {"D", "E", 60}, {"B", "C", 50},
            {"C", "E", 10}
    };

    public static final Object[][] MST_01 = {
            {0, 2, 2}, {0, 4, 7},
            {1, 2, 3}, {1, 5, 1}, {1, 6, 7},
            {2, 4, 4}, {2, 5, 3}, {2, 6, 6},
            {3, 7, 9},
            {4, 6, 8},
            {5, 6, 4}, {5, 7, 5}
    };

}