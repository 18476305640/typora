package com.zhuangjie.recursion;

public class Test {
    public static void main(String[] args) {
        int targetIndex = search(new int[]{4,7,8,9,12},9);
        System.out.println(targetIndex);
    }

    private static int search(int[] array, int target) {
        if (array == null || array.length == 0) return -1;
        int begin = 0,end = array.length - 1;
        int compareCount = 0;
        while (begin <= end) {
            int mid = begin;
            if (begin != end) {
                mid = (begin + end) >> 1;
            }
            compareCount++;
            if (array[mid] == target) {
                return compareCount;
            }else if (array[mid] > target) {
                end = mid - 1;
            }else {
                begin = mid + 1;
            }
        }
        return -1;
    }
}
