package com.zhuangjie.recursion;


public class CoinChange {
    public static void main(String[] args) {
        System.out.println(coin(new Integer[]{25, 20, 5, 1}, 41));
    }

    private static int coin(Integer[] faces, int money) {
        // 参数合法性检验
        if (faces.length == 0 && money > 0) {
            throw new RuntimeException("参数错误，兑换失败！");
        }
        // 计算过的，将存放着这里 dp[money] = minCount
        int[] dp = new int[money+1];
        // 小于money的面值face，设置初始化值，当后面要求的money是K，而面值里面又刚好有，就让其得到minCount取值1
        for (Integer face : faces) {
            if (face > money) break;
            dp[face] = 1;
        }
        // 开始递归方法
        return coin(faces,money,dp);
    }

    private static int coin(Integer[] faces, int money, int[] dp) {
        // 递归基（递归的结束条件）
        if(money < 1) return Integer.MAX_VALUE;
        // 每种都尝试选-取小值
        if (dp[money] == 0) {
            int minCount = Integer.MAX_VALUE;
            for (Integer face : faces) {
                minCount = Math.min(minCount, coin(faces,money - face,dp) );
            }
            dp[money] = minCount+1;
        }
        return dp[money];
    }
}
