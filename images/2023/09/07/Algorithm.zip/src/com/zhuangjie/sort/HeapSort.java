package com.zhuangjie.sort;

/**
 * 堆排序
 *
 * @author zhuangjie
 * @date 2023/08/12
 */
public class HeapSort<T extends Comparable<T>> extends Sort<T>{
    private int heapSize = 0;
    @Override
    public void sort(T[] array) {
        long begin = System.currentTimeMillis();
        // 原地建堆
        this.array = array;
        this.heapSize = array.length;
        for (int i = (heapSize >> 1) -1; i >= 0; i-- ) {
            siftDown(i);
        }
        // 排序堆排序方法（算法）对堆数组进行排序
        sort();
        time = System.currentTimeMillis() - begin;
    }



    @Override
    protected void sort() {
        // 根据堆特性将堆的数组转有序
        while (heapSize > 1) {
            // 首元素（最佳）与堆尾元素交换，交换完后heapSize--
            swap(--heapSize,0);
            siftDown(0);
        }
    }

    private void siftDown(int index) {
        T element = array[index];
        int half = heapSize >> 1;
        while (index < half) { // index必须是非叶子节点
            // 默认是左边跟父节点比
            int childIndex = (index << 1) + 1;
            T child = array[childIndex];

            int rightIndex = childIndex + 1;
            // 右子节点比左子节点大
            if (rightIndex < heapSize &&
                    compare(array[rightIndex], child) > 0) {
                child = array[childIndex = rightIndex];
            }

            // 大于等于子节点
            if (compare(element, child) >= 0) break;

            array[index] = child;
            index = childIndex;
        }
        array[index] = element;
    }
}
