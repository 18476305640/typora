package com.zhuangjie.union;

/**
 * 并查集-QuickUnion-优化尺寸
 *
 * @author zhuangjie
 * @date 2023/08/20
 */
public class UnionFind_QuickUnion_OptimizationForSize extends UnionFind_QuickUnion{
    private int[] sizes;
    public UnionFind_QuickUnion_OptimizationForSize(int capacity) {
        super(capacity);
        // 刚开始有capacity棵树，每棵只是自己一个节点，即size都是1
        sizes = new int[capacity];
        for (int i = 0; i < sizes.length; i++) {
            sizes[i] = 1;
        }
    }

    @Override
    public void union(int v1, int v2) {
        int p1 = find(v1);
        int p2 = find(v2);
        if (p1 == p2) return;
        int size1 = sizes[v1];
        int size2 = sizes[v2];
        if (size1 > size2) {
            // p1嫁接到p2下面
            parents[p1] = p2;
            sizes[p2] += size2;
        }else {
            // p2嫁接到p1下面
            parents[p2] = p1;
            sizes[p1] += size1;
        }
    }
}
