package com.zhuangjie.union;

/**
 * 并查集-快查法
 *
 * @author zhuangjie
 * @date 2023/08/20
 */
public class UnionFind_QuickFind extends UnionFind{

    public UnionFind_QuickFind(int capacity) {
        super(capacity);
    }

    @Override
    public int find(int v) {
        rangeCheck(v);
        return parents[v];
    }

    /**
     * 将v1所在集合的所有元素都嫁接到v2的父节点上
     * v1    v2   union(v1,v2)
     *  0    4	      4
     * 1 2   3     0 1 2 3
     */
    @Override
    public void union(int v1, int v2) {
        int parent = parents[v1];
        for (int i = 0; i < parents.length; i++) {
            if (parents[i] == parent) {
                parents[i] = parents[v2];
            }
        }

    }
}
