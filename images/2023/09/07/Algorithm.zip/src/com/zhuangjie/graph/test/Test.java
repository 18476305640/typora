package com.zhuangjie.graph.test;

import com.zhuangjie.graph.Graph;
import com.zhuangjie.graph.ListGraph;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Test {

    public static void main(String[] args) {
        testSp();
    }


    static void testSp() {
        Graph<Object, Double> graph = GraphGenerator.directedGraph(Data.NEGATIVE_WEIGHT1);
        Map<Object, Map<Object, Graph.PathInfo<Object, Double>>> objectMapMap = graph.shortestPath();
        for (Map.Entry<Object, Map<Object, Graph.PathInfo<Object, Double>>> objectMapEntry : objectMapMap.entrySet()) {
            System.out.println(objectMapEntry.getKey()+"----");
            Map<Object, Graph.PathInfo<Object, Double>> valueMap = objectMapEntry.getValue();
            if (valueMap == null) continue;
            for (Map.Entry<Object, Graph.PathInfo<Object, Double>> objectPathInfoEntry : valueMap.entrySet()) {
                System.out.println(objectPathInfoEntry.getKey()+":"+objectPathInfoEntry.getValue());
            }
        }
    }


    static void test() {
        ListGraph<String, Integer> graph = new ListGraph<>();
//		graph.addEdge("V0", "V1");
//		graph.addEdge("V1", "V0");
//
//		graph.addEdge("V0", "V2");
//		graph.addEdge("V2", "V0");
//
//		graph.addEdge("V0", "V3");
//		graph.addEdge("V3", "V0");
//
//		graph.addEdge("V1", "V2");
//		graph.addEdge("V2", "V1");
//
//		graph.addEdge("V2", "V3");
//		graph.addEdge("V3", "V2");
//
//		graph.print();

        graph.addEdge("V1", "V0", 9);
        graph.addEdge("V1", "V2", 3);
        graph.addEdge("V2", "V0", 2);
        graph.addEdge("V2", "V3", 5);
        graph.addEdge("V3", "V4", 1);
        graph.addEdge("V0", "V4", 6);

        graph.removeEdge("V0", "V4");
        graph.removeVertex("V0");

        graph.print();
    }
}
