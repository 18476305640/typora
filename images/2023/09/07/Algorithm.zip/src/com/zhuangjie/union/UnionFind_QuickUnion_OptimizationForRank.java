package com.zhuangjie.union;

/**
 * 并查集-QuickUnion-优化尺寸
 *
 * @author zhuangjie
 * @date 2023/08/20
 */
public class UnionFind_QuickUnion_OptimizationForRank extends UnionFind_QuickUnion{
    private int[] ranks;
    public UnionFind_QuickUnion_OptimizationForRank(int capacity) {
        super(capacity);
        // 刚开始有capacity棵树，每棵只是自己一个节点，即height或rank都是1
        ranks = new int[capacity];
        for (int i = 0; i < ranks.length; i++) {
            ranks[i] = 1;
        }
    }

    @Override
    public void union(int v1, int v2) {
        int p1 = find(v1);
        int p2 = find(v2);
        if (p1 == p2) return;
        int rank1 = ranks[v1];
        int rank2 = ranks[v2];
        if (rank1 < rank2) {
            // p1嫁接到p2下面
            parents[p1] = p2;
        }else {
            // rank1 < rank2 或 rank1 == rank2 ，都让p2嫁接到p1下面
            parents[p2] = p1;
            // 如果是rank1 == rank2的情况，合并后的树根节点需要+1
            if (rank1 == rank2) ranks[p1]++;
        }
    }
}
