package com.zhuangjie.sort;

/**
 * 快速排序
 *
 * @author zhuangjie
 * @date 2023/08/16
 */
public class QuickSort<T extends Comparable<T>>  extends Sort<T>{
    @Override
    protected void sort() {
        sort(0,array.length);
    }

    private void sort(int begin, int end) {
        if (end - begin < 2) return; // 至少有两个元素，最小元素的情况示例： [0（begin） ，1]，2（end）
        int mid = pivotIndex(begin,end); // 进行快排，操作完一次，需要返回begin==end的值作为mid
        sort(begin,mid); // [begin.mid)
        sort(mid + 1,end); // [mid + 1,end), mid位置已经确定或说该元素已经完成排序
    }

    private int pivotIndex(int begin, int end) {
        swap(begin, begin + (int)Math.random()*(end - begin)); // 随便从[begin,end)中选取一个作为中心轴。选出来的中心轴需要与begin进行值交换
        T pivot = array[begin]; // 备份出中心轴的值
        end--; // end表示右边将要与中心轴比较的位置或将被占用的位置，刚开始是array.length，需要指向最后一个元素，所以需要end--
        while (begin < end) {
            while (begin < end) {
                if (compare(pivot,array[end]) > 0) { // 当右边与中心轴比较时，如果右边要比较的值比中心轴值还小，要就要放在begin位置上
                    array[begin++] = array[end]; // 此时的begin表示将被占用，被占用后就需要向前一位，++后表示将要与中心轴比较
                    break; // 比较方向由右边转到左边与中心轴比较
                }else {
                    end--; // 如果右边的值比中心轴值大，右边比较的值需要忽略,end向前走一位转为与end-1比较。
                }
            }
            // 左边与中心轴 同上 右边与中心轴
            while (begin < end) {
                if (compare(pivot,array[begin]) < 0) {
                    array[end--] = array[begin];
                    break;
                }else {
                    begin++;
                }
            }
        }
        // 中心轴值位置确定是begin或end，将备份的中心轴值“放下来”
        array[begin] = pivot;
        // 返回begin == end的值,返回作为mid
        return begin;
    }


}
