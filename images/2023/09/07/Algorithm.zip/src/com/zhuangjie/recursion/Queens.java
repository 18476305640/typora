package com.zhuangjie.recursion;

public class Queens {
    /**
     * 存放着每个皇后的位置
     *  索引（row）: 0 1 2
     *  值（col）:   2 1 0
     *
     *  cols[row] == col 表示第row列已经放置了皇后在col行
     */
    int[] cols;
    // 一共有多少种合理的摆法
    int ways = 0;

    void placeQueens(int n) {
        if (n < 1) return;
        cols = new int[n];
        place(0);
        System.out.println(n+"皇后，一共有"+ways+"种摆法");
    }


    /**
     * 判断第row行第col列是否可以摆放皇后
     */
    private boolean isValid(int row,int col) {
        for (int i = 0; i < row; i++) {
            // 会看0~row列已经放置的皇后它们的行(col)是否是col，如果是，那说明已经放置了
            if (cols[i] == col) return false;
            // 到这里说明[0~i]列在col行没有皇后，且[0,i)斜线上也没有皇后。 但还需要判断该位置（row,col）是否在i列的皇后斜线上。
            int preRow = i;
            int preCol = cols[preRow];
            // ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/09/03/1693747570797.png)
            if (Math.abs(col - preCol) == (row - preRow)) return false;
        }
        return true;
    }

    /**
     * 从第 row 行开始摆放皇后
     */
    private void place(int row) {
        // 如果当前行是从左到右已经到了最后一行（row），那就说明出现了一种`row-1皇后`的排法，所以要ways++，然后结束。往上尝试其它排法。
        if (row == cols.length) {
            ways++;
            show();
            return;
        }
        // 继续往右摆放
        for (int col = 0; col < cols.length; col++) {
            if (! isValid(row,col)) continue;
            cols[row] = col;
            place(row + 1);
        }

    }

    void show() {
        for (int row = 0; row < cols.length; row++) {
            for (int col = 0; col < cols.length; col++) {
                if (cols[row] == col) { // 摆放了皇后
                    System.out.print("1 ");
                } else {
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }
        System.out.println("--------------------------");
    }

    
}
