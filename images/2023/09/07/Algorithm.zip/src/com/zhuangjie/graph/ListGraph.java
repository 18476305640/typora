package com.zhuangjie.graph;

import com.zhuangjie.graph.other.MinHeap;
import com.zhuangjie.graph.other.UnionFind;

import java.util.*;

/**
 * 邻接表实现图
 */
public class ListGraph<V, E> extends Graph<V, E> {

    public ListGraph() {
    }

    public ListGraph(WeightManager<E> weightManager) {
        super(weightManager);
    }

    /**
     * 边的比较器（通过权重比较）
     */
    private Comparator<Edge<V, E>> edgeComparator = (Edge<V, E> e1, Edge<V, E> e2) -> weightManager.compare(e1.weight, e2.weight);
    /**
     * 所有顶点在这里，可根据顶点的value值找到顶点
     */
    private Map<V, Vertex<V, E>> vertices = new HashMap<>();

    /**
     * 所有边放在这里
     */
    private Set<Edge<V, E>> edges = new HashSet<>();

    /**
     * 边
     */
    private static class Edge<V, E> {
        Vertex<V, E> from; // 出发点
        Vertex<V, E> to; // 到达点
        E weight;    // 权值

        public Edge(Vertex<V, E> from, Vertex<V, E> to) {
            this.from = from;
            this.to = to;
        }

        public Edge(Vertex<V, E> from, Vertex<V, E> to, E weight) {
            this(from, to);
            this.weight = weight;
        }

        @Override
        public boolean equals(Object obj) {
            Edge<V, E> edge = (Edge<V, E>) obj;
            return Objects.equals(from, edge.from) && Objects.equals(to, edge.to);
        }

        @Override
        public int hashCode() {
            return from.hashCode() * 31 + to.hashCode();
        }

        @Override
        public String toString() {
            return "Edge [from=" + from + ", to=" + to + ", weight=" + weight + "]";
        }

        /**
         * 由Edge转EdgeInfo
         *
         * @return
         */
        public EdgeInfo<V, E> info() {
            return new EdgeInfo<>(from.value, to.value, weight);
        }

    }

    /**
     * 顶点
     */
    private static class Vertex<V, E> {
        V value;
        Set<Edge<V, E>> inEdges = new HashSet<>(); // 进来的边
        Set<Edge<V, E>> outEdges = new HashSet<>(); // 出去的边

        public Vertex(V value) {
            this.value = value;
        }

        @Override
        public boolean equals(Object obj) {
            return Objects.equals(value, ((Vertex<V, E>) obj).value);
        }

        @Override
        public int hashCode() {
            return value == null ? 0 : value.hashCode();
        }

        @Override
        public String toString() {
            return value == null ? "null" : value.toString();
        }

    }


    @Override
    public int edgesSize() {
        return edges.size();
    }

    @Override
    public int verticesSize() {
        return vertices.size();
    }

    @Override
    public void addVertex(V v) {
        if (vertices.containsValue(v)) return;
        vertices.put(v, new Vertex<>(v));
    }

    @Override
    public void addEdge(V from, V to) {
        addEdge(from, to, null);
    }

    @Override
    public void addEdge(V from, V to, E weight) {
        // 根据传入的参数from找到出发点,如果不存在则创建
        Vertex<V, E> fromVertex = vertices.get(from);
        if (fromVertex == null) {
            fromVertex = new Vertex<>(from);
            vertices.put(from, fromVertex);
        }
        // 根据传入的参数to找到终点,如果不存在则创建
        Vertex<V, E> toVertex = vertices.get(to);
        if (toVertex == null) {
            toVertex = new Vertex<>(to);
            vertices.put(to, toVertex);
        }
        // 根据出发点与终点,创建边
        Edge<V, E> edge = new Edge<>(fromVertex, toVertex, weight);
        // 删除（删除的edge可能与当前的edge不同，结合下面的添加中相当于覆盖了）
        fromVertex.outEdges.remove(edge);
        toVertex.inEdges.remove(edge);
        edges.remove(edge);
        // 添加
        fromVertex.outEdges.add(edge);
        toVertex.inEdges.add(edge);
        edges.add(edge);
    }

    /**
     * 删除顶点
     *
     * @param v v
     */
    @Override
    public void removeVertex(V v) {
        Vertex<V, E> vertex = vertices.remove(v);
        if (vertex == null) return;
        Iterator<Edge<V, E>> inIterator = vertex.inEdges.iterator();
        while (inIterator.hasNext()) {
            Edge<V, E> inEdge = inIterator.next();
            inEdge.from.outEdges.remove(inEdge);
            edges.remove(inEdge);
        }

        Iterator<Edge<V, E>> outIterator = vertex.outEdges.iterator();
        while (outIterator.hasNext()) {
            Edge<V, E> outEdge = outIterator.next();
            outEdge.to.inEdges.remove(outEdge);
            edges.remove(outEdge);
        }
    }

    /**
     * 删除边
     *
     * @param from 从
     * @param to   来
     */
    @Override
    public void removeEdge(V from, V to) {
        // 找到from的顶点value获取Vertex，如果找不到则不需要删除
        Vertex<V, E> fromVertex = vertices.get(from);
        if (fromVertex == null) return;
        // 找到to的顶点value获取Vertex，如果找不到则不需要删除
        Vertex<V, E> toVertex = vertices.get(to);
        if (toVertex == null) return;
        // 组装获取对应的Edge
        Edge<V, E> edge = new Edge<>(fromVertex, toVertex);
        // 获取edge删除from、to顶点对应的关联与删除edges中的edge
        if (fromVertex.outEdges.remove(edge)) {
            toVertex.inEdges.remove(edge);
            edges.remove(edge);
        }
    }

    @Override
    public void bfs(V begin, VertexVisitor<V> visitor) {
        if (visitor == null) return;
        Vertex<V, E> beginVertex = vertices.get(begin);
        if (beginVertex == null) return;


        // 存放已经访问过的节点
        Set<Vertex<V, E>> visitedVertices = new HashSet<>();
        Queue<Vertex<V, E>> queue = new LinkedList<>();
        queue.offer(beginVertex);  // 将第一个节点放入队列中以驱动
        visitedVertices.add(beginVertex); // 入队就要加入visitedVertices
        while (!queue.isEmpty()) {
            Vertex<V, E> vertex = queue.poll();
            if (visitor.visit(vertex.value)) return; // 给序，将返回false暂停遍历
            for (Edge<V, E> outEdge : vertex.outEdges) {
                if (visitedVertices.contains(outEdge.to)) continue;
                queue.offer(outEdge.to);
                visitedVertices.add(outEdge.to); // 入队就要加入visitedVertices
            }
        }

    }

    @Override
    public void dfs(V begin, VertexVisitor<V> visitor) {
        // 必要性检查
        if (visitor == null) return;
        Vertex<V, E> beginVertex = vertices.get(begin);
        if (beginVertex == null) return;

        Set<Vertex<V, E>> visitedVertices = new HashSet<>();
        // 三步曲：入栈-记录到visitedVertices-遍历
        Stack<Vertex<V, E>> stack = new Stack<>();
        stack.add(beginVertex);
        visitedVertices.add(beginVertex);
        if (visitor.visit(beginVertex.value)) return;
        while (!stack.isEmpty()) {
            Vertex<V, E> vertex = stack.pop();
            for (Edge<V, E> outEdge : vertex.outEdges) {
                if (visitedVertices.contains(outEdge.to)) continue;
                // 如果有下个顶点，那当前遍历的vertex和选中的子顶点都要入队，且对选中的子顶点记录到visitedVertices
                stack.add(vertex);
                stack.add(outEdge.to);
                visitedVertices.add(outEdge.to);
                if (visitor.visit(outEdge.to.value)) return;
                break; // 结束，下一轮由当前outEdgew作为新的vertex
            }
        }


    }


//    /**
//     * 递归实现深度优先搜索DFS
//     */
//    abstract class VertexVisitorForRecursion<V> implements VertexVisitor<V>{
//        boolean stop = false;
//    }
//    @Override
//    public void dfs(V begin, VertexVisitor<V> visitor) {
//        // 必要性检查
//        if (visitor == null) return;
//        Vertex<V, E> beginVertex = vertices.get(begin);
//        if (beginVertex == null) return;
//        // 已经遍历的节点将放在下面的Set中
//        Set<Vertex<V, E>> visitedVertices = new HashSet<>();
//        // 开始递归，传入必要参数（下面的第二个参数是将原始的）VertexVisitor进行封闭VertexVisitor的子类（抽象类）VertexVisitorForRecursion，多了一个stop变量
//        dfsRecursive(beginVertex, new VertexVisitorForRecursion<V>() {
//            @Override
//            public boolean visit(V v) {
//                return visitor.visit(v);
//            }
//        }, visitedVertices);
//    }
//
//    private void dfsRecursive(Vertex<V, E> vertex, VertexVisitorForRecursion<V> visitor,Set<Vertex<V, E>> visitedVertices) {
//        if (visitedVertices.contains(vertex) || visitor.stop || (visitor.stop = visitor.visit(vertex.value)) ) return;
//
//        visitedVertices.add(vertex);
//
//        for (Edge<V, E> edge : vertex.outEdges) {
//            // 如果前面的已经是退出（visitor.stop为true）了，那栈底的函数也应该退出
//            if (visitor.stop) return;
//            // 如果已经遍历过了，那就跳过该顶点
//            if (visitedVertices.contains(edge.to)) continue;
//            dfsRecursive(edge.to, visitor, visitedVertices);
//        }
//    }


    /**
     * 拓扑排序（注意操作不能影响结构）
     */
    @Override
    public List<V> topologicalSort() {
        List<V> list = new ArrayList<>(); // 排序结果
        LinkedList<Vertex<V, E>> query = new LinkedList<>(); // 等待处理的顶点（边还没有去掉）
        HashMap<Vertex<V, E>, Integer> ins = new HashMap<>(); // 记录顶点的入度

        for (Vertex<V, E> vertex : vertices.values()) {
            int inDegree = vertex.inEdges.size(); // vertex的入度
            if (inDegree == 0) {
                // 入度为0
                query.push(vertex);
            } else {
                // 入度不为0
                ins.put(vertex, inDegree);
            }
        }
        while (!query.isEmpty()) {
            Vertex<V, E> vertex = query.poll();
            list.add(vertex.value); // 将弹出要处理（度为0的顶点）加入结果中
            // 处理弹出的顶点剩下要处理的
            for (Edge<V, E> outEdge : vertex.outEdges) {
                Vertex<V, E> toVertex = outEdge.to;
                int toInDegree = ins.get(toVertex) - 1;
                if (toInDegree == 0) {
                    query.push(toVertex);
                    ins.remove(toVertex); // 这个不要也可以
                } else {
                    ins.put(toVertex, toInDegree);
                }
            }
        }
        return list;
    }




    @Override
    public Map<V, PathInfo<V, E>> shortestPath(V begin) {
        // return dijkstra();
        return bellmanFord(begin);
    }

    @Override
    public Map<V, Map<V, PathInfo<V, E>>> shortestPath() {
        HashMap<V, Map<V, PathInfo<V, E>>> paths = new HashMap<>();
        // 遍历所有多，可以得到任何两点中from-to的两点，先初始化
        for (Edge<V, E> edge : edges) {
            Map<V, PathInfo<V, E>> map = paths.get(edge.from.value);
            if (map == null) map = new HashMap<>();
            PathInfo<V, E> pathInfo = new PathInfo<>(edge.weight);
            pathInfo.getEdgeInfos().add(edge.info());
            map.put(edge.to.value,pathInfo);
            paths.put(edge.from.value,map);
        }
        if (paths.isEmpty()) return null;
        Set<V> vs = vertices.keySet();
        /**
         * for：
         * 1       2
         *   2       1
         *    3       3
         *结果：
         * 2:1:3   1:2:3
         * 2:2:3   2:2:3
         * 2:3:3   3:2:3
         */
        for (V v2 : vs) {
            for (V v1 : vs) {
                for (V v3 : vs) {
                    // // v1 -> v2
                    if (v1.equals(v2) || v2.equals(v3) || v1.equals(v3)) continue;
                    PathInfo<V, E> path12 = paths.get(v1) == null?null:paths.get(v1).get(v2);
                    if (path12 == null) break;
                    // v2 -> v3
                    PathInfo<V, E> path23 = paths.get(v2) == null?null:paths.get(v2).get(v3);
                    if (path23 == null) continue;
                    // v1 -> v3
                    PathInfo<V, E> path13 = paths.get(v1) == null?null:paths.get(v1).get(v3);
                    // 如果新的组合更短更新
                    E newV13Weight = weightManager.add(path12.getWeight(), path23.getWeight());
                    if (path13 == null || weightManager.compare(newV13Weight,path13.getWeight()) < 0 ) {
                        if (path13  == null) {
                            path13 = new PathInfo<>();
                            paths.get(v1).put(v3,path13);
                        }else {
                            path13.getEdgeInfos().clear();
                        }
                        path13.setWeight(newV13Weight);
                        path13.getEdgeInfos().addAll(path12.getEdgeInfos());
                        path13.getEdgeInfos().addAll(path23.getEdgeInfos());
                    }
                }
            }
        }
        return paths;

    }

    private Map<V, PathInfo<V, E>> bellmanFord(V begin) {
        Vertex<V, E> beginVertex = vertices.get(begin);
        if(beginVertex == null || vertices.size() < 2) return null;
        Map<V, PathInfo<V, E>> selectedPaths = new HashMap<>();
        int count = vertices.size() - 1;
        for (int i = 0; i < count; i++) {
            for (Edge<V, E> edge : edges) {
                PathInfo<V, E> fromPathInfo = selectedPaths.get(edge.from.value);
                // 如果fromPathInfo为空，且不是begin-跳过
                if (fromPathInfo == null && ! begin.equals( edge.from.value ) ) continue;
                // 如果fromPathInfo不为空，且是begin，更新无意义-跳过
                if ( fromPathInfo != null && begin.equals( edge.from.value ) ) continue;
                // 松驰操作（必须要过滤掉不能松驰的）
                relax(fromPathInfo,edge,selectedPaths);
            }
        }
        // 检测负权环, 前面已经松弛了V-1次,这里如果松弛第 V 次仍然可以成功, 说明有负权环
        for (Edge<V, E> edge : edges) {
            PathInfo<V, E> fromPathInfo = selectedPaths.get(edge.from.value);
            // 松驰操作（必须要过滤掉不能松驰的）
            if (relax(fromPathInfo,edge,selectedPaths)) {
                System.out.println("有负权环, 不存在最短路径");
                return null;
            }
        }
        return selectedPaths;
    }

    /**
     * 松驰操作
     *
     * @param fromPathInfo  从路径信息
     * @param edge          边缘
     * @param selectedPaths 选择路径
     */
    private boolean relax(PathInfo<V, E> fromPathInfo, Edge<V, E> edge, Map<V, PathInfo<V, E>> selectedPaths) {
        // 要更新的点
        PathInfo<V, E> toPathInfo = selectedPaths.get(edge.to.value);
        // 到时候如果fromPathInfo还是为null，那肯定是begin，设置基本数据，准备操作
        if (fromPathInfo == null) fromPathInfo = new PathInfo<>(weightManager.zero());
        E newToWeight = weightManager.add(fromPathInfo.getWeight(), edge.weight);
        if ( toPathInfo == null || weightManager.compare(newToWeight,toPathInfo.getWeight() ) < 0) {
            if (toPathInfo == null) toPathInfo = new PathInfo<>();
            // 更新PathInfo-weight
            toPathInfo.setWeight(newToWeight);
            // 更新PathInfo-EdgeInfos
            toPathInfo.getEdgeInfos().clear();
            toPathInfo.getEdgeInfos().addAll(fromPathInfo.getEdgeInfos());
            toPathInfo.getEdgeInfos().add(edge.info());
            // 更新
            selectedPaths.put(edge.to.value,toPathInfo);
            return true;
        }
        return false;
    }


//    @Override
//    public Map<V, PathInfo<V, E>> dijkstra(V begin) {
//        Vertex<V, E> beginVertex = vertices.get(begin);
//        if(beginVertex == null || vertices.size() < 2) return null;
//
//        Map<V, PathInfo<V, E>> selectedPaths = new HashMap<>();
//        Map<Vertex<V, E>, PathInfo<V, E>> paths = new HashMap<>();
//        paths.put(beginVertex,new PathInfo<>(weightManager.zero()));
//        while ( ! paths.isEmpty() ) {
//            Map.Entry<Vertex<V, E>, PathInfo<V, E>> minEntry  = removeMinPath(paths);
//            if (minEntry == null) break;
//            // 最近的顶点
//            Vertex<V, E> nearestVertex = minEntry.getKey();
//            selectedPaths.put(minEntry.getKey().value, minEntry.getValue());
//            // 进行松驰
//            for (Edge<V, E> outEdge : nearestVertex.outEdges) {
//                if (selectedPaths.containsKey(outEdge.to) || beginVertex.equals(outEdge.to) ) continue;
//                relax(selectedPaths,paths,outEdge);
//            }
//
//        }
//        // 删除掉begin到begin的最短路径（因为这是无意义的）
//        selectedPaths.remove(begin);
//        return selectedPaths;
//    }
//
//    /**
//     * 松驰操作
//     * @param paths
//     * @param outEdge
//     */
//    private void relax(Map<V, PathInfo<V, E>> selectedPaths,Map<Vertex<V, E>, PathInfo<V, E>> paths, Edge<V, E> outEdge) {
//        PathInfo<V, E> minPathInfo = selectedPaths.get(outEdge.from.value);
//        PathInfo<V, E> oldPathInfo = paths.get(outEdge.to);
//        E newWeight = weightManager.add(minPathInfo.getWeight() ,outEdge.weight);
//        if ( oldPathInfo == null  || weightManager.compare(newWeight,oldPathInfo.getWeight()) < 0) {
//            if (oldPathInfo == null ) oldPathInfo = new PathInfo<>();
//            // 更新PathInfo-weight
//            oldPathInfo.setWeight(newWeight);
//            // 更新PathInfo-edgeInfos
//            oldPathInfo.getEdgeInfos().clear();
//            oldPathInfo.getEdgeInfos().addAll(minPathInfo.getEdgeInfos());
//            oldPathInfo.getEdgeInfos().add(outEdge.info());
//            // 添加到paths中
//            paths.put(outEdge.to,oldPathInfo);
//        }
//    }

//    /**
//     * 从paths中取出一个最小的路径出来
//     */
//    private Map.Entry<Vertex<V, E>, PathInfo<V, E>> removeMinPath(Map<Vertex<V, E>, PathInfo<V, E>> paths) {
//        Map.Entry<Vertex<V, E>, PathInfo<V, E>> minEntry = null;
//        Iterator<Map.Entry<Vertex<V, E>, PathInfo<V, E>>> iterator = paths.entrySet().iterator();
//        while (iterator.hasNext()) {
//            Map.Entry<Vertex<V, E>, PathInfo<V, E>> entry = iterator.next();
//            if (minEntry == null || weightManager.compare(entry.getValue().getWeight(), minEntry.getValue().getWeight()) < 0) {
//                minEntry = entry;
//            }
//        }
//        // 删除掉paths中选中的entry（最终的minEntry）
//        paths.remove(minEntry.getKey());
//        // 返回minEntry
//        return minEntry;
//    }

    /**
     * 最小生成数
     */
    @Override
    public Set<EdgeInfo<V, E>> mst() {
        // return prim();
        return kruskal();
    }

    /**
     * 最小生成树-普里姆算法
     *
     * @return
     */
    private Set<EdgeInfo<V, E>> prim() {
        Iterator<Vertex<V, E>> verticesIterator = vertices.values().iterator();
        if (!verticesIterator.hasNext()) return null; // 如果没有顶点，那直接返回null
        // 选择一个顶点开始
        Vertex<V, E> vertex = verticesIterator.next();
        // 已经选择的顶点
        Set<Vertex<V, E>> addedVertex = new HashSet<>();
        addedVertex.add(vertex);
        // 将要返回的结果集合
        Set<EdgeInfo<V, E>> edgeInfos = new HashSet<>();
        // 选择的顶点的边放在最小堆中，以选择最小边
        MinHeap<Edge<V, E>> edgeMinHeap = new MinHeap<>(vertex.outEdges, edgeComparator);
        while (!edgeMinHeap.isEmpty() && addedVertex.size() < vertices.size()) {
            // 选择已选择的顶点放出的最小边
            Edge<V, E> edge = edgeMinHeap.remove();
            // 如果上面说的最小边to顶点也是已选择的边，那是“内边”跳过本次选择的最小边
            if (addedVertex.contains(edge.to)) continue;
            // 将to顶点纳入已选择的顶点
            addedVertex.add(edge.to);
            // 将上面说的最小边放到结果集合中
            edgeInfos.add(edge.info());
            // 将to顶点放出的边放到最小堆中
            edgeMinHeap.addAll(edge.to.outEdges);
        }
        // 返回结果集合
        return edgeInfos;
    }

    /**
     * 最小生成树-克鲁斯卡尔算法
     *
     * @return {@link Set}<{@link EdgeInfo}<{@link V},{@link    } {@link E}>>
     */
    private Set<EdgeInfo<V, E>> kruskal() {
        int vertexSize = vertices.size(); // 顶点数
        int edgeSize = vertexSize - 1;  // 生成树的边数 （顶点数-1）
        if (vertexSize == 0) return null; // 空的图
        MinHeap<Edge<V, E>> edgeMinHeap = new MinHeap<>(edges, edgeComparator); // 堆，将所有的边放在最小堆中
        UnionFind<Vertex<V, E>> uf = new UnionFind<>(); //
        vertices.values().forEach(vertex -> uf.makeSet(vertex)); // 将所有顶点初始化到并查集中，将其中每个元素设置为单独的集合
        Set<EdgeInfo<V, E>> edgeInfos = new HashSet<>(); // 结果集合
        while (!edgeMinHeap.isEmpty() && edgeInfos.size() < edgeSize) {
            Edge<V, E> edge = edgeMinHeap.remove(); // 取出最小边
            if (uf.isSame(edge.from, edge.to)) continue; // 如果该边的form与to在同一个集合中就跳过
            edgeInfos.add(edge.info()); // 将未在集合中的to放到结果集中
            uf.union(edge.from, edge.to); // 将两个集合合并
        }
        return edgeInfos;
    }

    /**
     * 打印图的信息
     */
    public void print() {
        System.out.println("\n[顶点]-------------------");
        vertices.forEach((V v, Vertex<V, E> vertex) -> {
            System.out.println("[ " + v + " ]");
            System.out.print("out:");
            System.out.println(vertex.outEdges);
            System.out.print("in:");
            System.out.println(vertex.inEdges);
        });
        System.out.println("\n[边]-------------------");
        edges.forEach((Edge<V, E> edge) -> {
            System.out.println(edge);
        });
    }


}
