package com.zhuangjie.sort;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 希尔排序
 *
 * @author zhuangjie
 * @date 2023/08/16
 */
public class ShellSort<T extends Comparable<T>> extends Sort<T>  {

    @Override
    protected void sort() {
        List<Integer> stepSequence = shellStpSequence();
        for (Integer step : stepSequence) {
            sort(step);
        }
    }

    private void sort(Integer step) {
        // step:值表示行元素个数
        // col: 表示当前排序列
        for (Integer col = 0; col < step; col++) {
            // begin是要插入有序序列
            for (int begin = col + step; begin < array.length; begin += step) {
                // 使用比较并交换方式的插入排序
                int cur = begin;
                while (cur > col && compare(array[cur],array[cur - step]) < 0) {
                    swap(cur,cur - step);
                    cur -= step;
                }
                // 使用比较并移动方式的插入排序
//                T v = array[begin];
//                int cur = begin;
//                while ( cur > col && compare(v,array[cur - step]) < 0) {
//                    array[cur] = array[cur - step];
//                    cur -= step;
//                }
//                array[cur] = v;
            }
        }
    }

    /**
     * 希尔本人提出的步长序列
     */
    private List<Integer> shellStpSequence() {
        List<Integer> stepSequence = new ArrayList<>();
        int step = array.length;
        while ((step>>=1) > 0) {
            stepSequence.add(step);
        }
        return stepSequence;
    }


    /**
     * 目前效率最高的步长序列
     */
    private List<Integer> sedgewickStepSequence() {
        List<Integer> stepSequence = new LinkedList<>();
        int k = 0, step = 0;
        while (true) {
            if (k % 2 == 0) {
                int pow = (int) Math.pow(2, k >> 1);
                step = 1 + 9 * (pow * pow - pow);
            } else {
                int pow1 = (int) Math.pow(2, (k - 1) >> 1);
                int pow2 = (int) Math.pow(2, (k + 1) >> 1);
                step = 1 + 8 * pow1 * pow2 - 6 * pow2;
            }
            if (step >= array.length) break;
            stepSequence.add(0, step);
            k++;
        }
        return stepSequence;
    }
}
