package com.zhuangjie.sort;

/**
 * 插入排序
 *
 * @author zhuangjie
 * @date 2023/08/16
 */
public class InsertionSort<T extends Comparable<T>> extends Sort<T>{
    @Override
    protected void sort() {
//        int arrayLength = array.length;
//        for (int end = 1; end < arrayLength;end++) {
//            // end位置通过交换向前移动到合适的位置
//            for (int i = end - 1; i >= 0; i--) {
//                if (compare(array[i],array[i+1]) <= 0) break;
//                swap(i,i+1);
//            }
//        }

//        for (int begin = 1; begin < array.length;begin++) {
//            T v = array[begin]; // 待插入的值
//            int cut = begin; // 待v下来的位置
//            // 确定出cut的值（比v大的，都向后移一位）
//            while (cut >= 1 && compare(array[cut-1],v) > 0) {
//                // 头部有序数据中比待插入元素大的，都朝尾部方向挪动1个位置。
//                array[cut] = array[cut-1];
//                // 每次挪动意味着cut-- （向前一位）
//                cut--;
//            }
//            // 确定了要插入的位置cut，且经过挪动，空出了cut的位置
//            array[cut] = v;
//        }

        for (int i = 1; i < array.length; i++) {
            insert(i,search(i));
        }



    }

    /**
     * 将source-1到target都右移一位，然后将source上的值放到target位置上
     *
     * @param source 源
     * @param target 目标
     */
    public void insert(int source,int target) {
        T v = array[source];
        for (int i = source; i > target; i--) {
            array[i] = array[i-1];
        }
        array[target] = v;
    }

    /**
     * 数组index位置是要插入左边有序数组中，返回的是要插入的位置（也有可能是传入的index）
     *
     * @param index 指数
     * @return int
     */
    public int search(int index) {
        int begin = 0;
        int end = index;
        while (begin < end) {
            int mid = (begin + end) >> 1;
            if (compare(array[index] ,array[mid]) < 0) {
                end = mid;
            }else {
                begin = mid + 1;
            }
        }
        return end;
    }
}
