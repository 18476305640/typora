package com.zhuangjie.sort;

public class BubbleSort<T extends Comparable<T>> extends Sort<T>{
    /**
     * 是否优化
     */
    private boolean isOptimize = false;

    public BubbleSort(boolean isOptimize) {
        this.isOptimize = isOptimize;
    }
    public BubbleSort() {
    }

    @Override
    protected void sort() {
        if (isOptimize) {
            optimizeSort();
        }else {
            baseSort();
        }
    }

    /**
     * 基本的排序
     */
    private void baseSort() {
        int arrayLength = array.length;
        for (int end = arrayLength-1; end >= 1; end--) {
            for (int i = 1; i <= end; i++) {
                if (compare(array[i-1],array[i]) > 0) {
                    swap(i-1,i);
                }
            }
        }
    }

    /**
     * 优化的冒泡排序
     */
    private void optimizeSort() {
        int arrayLength = array.length;
        for (int end = arrayLength-1; end >= 1; end--) {
            // end的最小值
            int sortedIndex = 1;
            for (int i = 1; i <= end; i++) {
                if (compare(array[i-1],array[i]) > 0) {
                    swap(i-1,i);
                    sortedIndex = i;
                }
            }
            end = sortedIndex;
        }
    }

}
