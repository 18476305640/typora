// yapi mock 接口地址
// export const baseUrl = "https://mock-java.itheima.net/mock/3051";

// 本地地址
export const baseUrl = "http://127.0.0.1:6688";
