export default {
  navigationBarTitleText: "保存运动",
  navigationStyle: "custom", //隐藏系统自带导航
};
