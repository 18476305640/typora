export default {
  navigationBarTitleText: "轻骑",
};
