export default {
  navigationBarTitleText: "轻骑",
  navigationStyle: "custom", //隐藏系统自带导航
};
