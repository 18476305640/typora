package com.zhuangjie.baiduapi;

import com.zhuangjie.baiduapi.utils.HttpUtils;
import org.junit.Test;

import java.util.HashMap;

public class _1_IP转大致位置 {
    @Test
    public void test01() throws Exception {
        // https://api.map.baidu.com/location/ip?ak=您的AK&ip=您的IP&coor=bd09ll
        HashMap<String, String> query = new HashMap<>();
        query.put("ak","wEvXfD0TnUyg1bHTLQDjqAMvxvqFN6HV");
        query.put("ip",""); // 如果不指定或为空将使用发来请求的IP进行定位。
        query.put("coor","bd09ll");
        HttpUtils.Response process = new HttpUtils.Builder("https://api.map.baidu.com")
                .path("/location/ip")
                .querys(query)
                .get().process();
        String body = process.getBody();
        System.out.println(body);

    }
}
