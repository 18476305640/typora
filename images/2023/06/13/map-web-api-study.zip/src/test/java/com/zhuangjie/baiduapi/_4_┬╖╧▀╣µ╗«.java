package com.zhuangjie.baiduapi;

import com.zhuangjie.baiduapi.utils.HttpUtils;
import org.junit.Test;

import java.util.HashMap;

public class _4_路线规划 {
    @Test
    public void test01() throws Exception {
        // https://api.map.baidu.com/directionlite/v1/driving?origin=40.01116,116.339303&destination=39.936404,116.452562&ak=您的AK
        HashMap<String, String> query = new HashMap<>();
        query.put("ak","oSA25UWA8NGECm85yw2uPxFvKdGPHTr6");
        query.put("origin","40.01116,116.339303");
        query.put("destination","39.998877,116.316833");
        query.put("coord_type","bd09ll");
        HttpUtils.Response process = new HttpUtils.Builder("https://api.map.baidu.com")
                .path("/directionlite/v1/driving")
                .querys(query)
                .get().process();
        String body = process.getBody();
        System.out.println(body);

    }
}
