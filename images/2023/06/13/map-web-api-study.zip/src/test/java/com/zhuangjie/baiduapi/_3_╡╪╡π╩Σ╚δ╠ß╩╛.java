package com.zhuangjie.baiduapi;

import com.zhuangjie.baiduapi.utils.HttpUtils;
import org.junit.Test;

import java.util.HashMap;

public class _3_地点输入提示 {
    @Test
    public void test01() throws Exception {
        // https://api.map.baidu.com/place/v2/suggestion?query=天安门&region=北京&city_limit=true&output=json&ak=你的ak //GET请求
        HashMap<String, String> query = new HashMap<>();
        query.put("ak","oSA25UWA8NGECm85yw2uPxFvKdGPHTr6");
        query.put("query","北京大");
        query.put("region","北京市");
        query.put("city_limit","true");
        query.put("output","json");
        HttpUtils.Response process = new HttpUtils.Builder("https://api.map.baidu.com")
                .path("/place/v2/suggestion")
                .querys(query)
                .get().process();
        String body = process.getBody();
        System.out.println(body);

    }
}
