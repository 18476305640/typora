package com.zhuangjie.baiduapi;

import com.zhuangjie.baiduapi.utils.HttpUtils;
import org.junit.Test;

import java.util.HashMap;

public class _2_IP定位服务 {
    @Test
    public void test01() throws Exception {
        // https://api.map.baidu.com/geoconv/v1/?coords=114.21892734521,29.575429778924&from=1&to=5&ak=你的密钥
        HashMap<String, String> query = new HashMap<>();
        query.put("ak","wEvXfD0TnUyg1bHTLQDjqAMvxvqFN6HV");
        query.put("coords","112.457556,23.088262");
        query.put("from","1");
        query.put("to","5");
        HttpUtils.Response process = new HttpUtils.Builder("https://api.map.baidu.com")
                .path("/geoconv/v1/")
                .querys(query)
                .get().process();
        String body = process.getBody();
        System.out.println(body);
    }
}
