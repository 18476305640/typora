package com.zhuangjie.baiduapi.utils;

import lombok.Data;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
class StringUtils {
    public static boolean isNotBlank(String str) {
        return str != null && ! str.isEmpty();
    }
    public static boolean isBlank(String str) {
        return ! isNotBlank(str);
    }

}

public class HttpUtils {
    private final String host;
    private final String path;
    private final Map<String, String> headers;
    private final Map<String, String> querys;
    private final String body;
    private final byte[] byteBody;


    @Data
    public static class Response {
        private Integer status;
        private Header[] headers;
        private String body;
    }

    public static class RawResponse {
        private HttpResponse httpResponse;

        public RawResponse(HttpResponse httpResponse) {
            this.httpResponse = httpResponse;
        }

        public HttpResponse raw() {
            return this.httpResponse;
        }

        public Response process(String charset) throws IOException {
            if (httpResponse == null) {
                throw new IllegalArgumentException("在将RawResponse(持有HttpResponse)加工为Response时出现，原因是最原始的HttpResponse对象为空。");
            }
            Response response = new Response();
            response.setStatus(httpResponse.getStatusLine().getStatusCode());
            response.setHeaders(httpResponse.getAllHeaders());
            response.setBody(EntityUtils.toString(httpResponse.getEntity(), charset));
            return response;
        }

        public Response process() throws IOException {
            return process("UTF-8");
        }
    }

    private HttpUtils(Builder builder) {
        this.host = builder.host;
        this.path = builder.path;
        this.headers = builder.headers;
        this.querys = builder.querys;
        this.body = builder.body;
        this.byteBody = builder.byteBody;
    }

    public HttpResponse execute(String method) throws Exception {
        HttpClient httpClient = wrapClient(host);

        switch (method) {
            case "GET":
                return executeGet(httpClient);
            case "POST":
                return executePost(httpClient);
            case "PUT":
                return executePut(httpClient);
            case "DELETE":
                return executeDelete(httpClient);
            default:
                throw new IllegalArgumentException("Invalid HTTP method: " + method);
        }
    }

    private HttpResponse executeGet(HttpClient httpClient) throws Exception {
        HttpGet request = new HttpGet(buildUrl(host, path, querys));
        for (Map.Entry<String, String> e : headers.entrySet()) {
            request.addHeader(e.getKey(), e.getValue());
        }

        return httpClient.execute(request);
    }

    private HttpResponse executePost(HttpClient httpClient) throws Exception {
        HttpPost request = new HttpPost(buildUrl(host, path, querys));
        for (Map.Entry<String, String> e : headers.entrySet()) {
            request.addHeader(e.getKey(), e.getValue());
        }

        if (StringUtils.isNotBlank(body)) {
            request.setEntity(new StringEntity(body, "utf-8"));
        } else if (byteBody != null) {
            request.setEntity(new ByteArrayEntity(byteBody));
        } else {
            List<NameValuePair> nameValuePairList = new ArrayList<>();

            for (String key : querys.keySet()) {
                nameValuePairList.add(new BasicNameValuePair(key, querys.get(key)));
            }

            UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(nameValuePairList, "utf-8");
            formEntity.setContentType("application/x-www-form-urlencoded; charset=UTF-8");
            request.setEntity(formEntity);
        }

        return httpClient.execute(request);
    }

    private HttpResponse executePut(HttpClient httpClient) throws Exception {
        HttpPut request = new HttpPut(buildUrl(host, path, querys));
        for (Map.Entry<String, String> e : headers.entrySet()) {
            request.addHeader(e.getKey(), e.getValue());
        }

        if (StringUtils.isNotBlank(body)) {
            request.setEntity(new StringEntity(body, "utf-8"));
        } else if (byteBody != null) {
            request.setEntity(new ByteArrayEntity(byteBody));
        }

        return httpClient.execute(request);
    }

    private HttpResponse executeDelete(HttpClient httpClient) throws Exception {
        HttpDelete request = new HttpDelete(buildUrl(host, path, querys));
        for (Map.Entry<String, String> e : headers.entrySet()) {
            request.addHeader(e.getKey(), e.getValue());
        }

        return httpClient.execute(request);
    }

    private String buildUrl(String host, String path, Map<String, String> querys) throws UnsupportedEncodingException {
        StringBuilder sbUrl = new StringBuilder();
        sbUrl.append(host);
        if (!StringUtils.isBlank(path)) {
            sbUrl.append(path);
        }
        if (querys != null) {
            StringBuilder sbQuery = new StringBuilder();
            for (Map.Entry<String, String> query : querys.entrySet()) {
                if (0 < sbQuery.length()) {
                    sbQuery.append("&");
                }
                if (StringUtils.isBlank(query.getKey()) && !StringUtils.isBlank(query.getValue())) {
                    sbQuery.append(query.getValue());
                }
                if (!StringUtils.isBlank(query.getKey())) {
                    sbQuery.append(query.getKey());
                    if (!StringUtils.isBlank(query.getValue())) {
                        sbQuery.append("=");
                        sbQuery.append(URLEncoder.encode(query.getValue(), "utf-8"));
                    }
                }
            }
            if (0 < sbQuery.length()) {
                sbUrl.append("?").append(sbQuery);
            }
        }

        return sbUrl.toString();
    }

    private HttpClient wrapClient(String host) {
        HttpClient httpClient = new DefaultHttpClient();
        if (host.startsWith("https://")) {
            sslClient(httpClient);
        }

        return httpClient;
    }

    private void sslClient(HttpClient httpClient) {
        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                public void checkClientTrusted(X509Certificate[] xcs, String str) {

                }

                public void checkServerTrusted(X509Certificate[] xcs, String str) {

                }
            };
            ctx.init(null, new TrustManager[]{tm}, null);
            SSLSocketFactory ssf = new SSLSocketFactory(ctx);
            ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            ClientConnectionManager ccm = httpClient.getConnectionManager();
            SchemeRegistry registry = ccm.getSchemeRegistry();
            registry.register(new Scheme("https", 443, ssf));
        } catch (KeyManagementException ex) {
            throw new RuntimeException(ex);
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static class Builder {
        private final String host;
        private String path;
        private Map<String, String> headers;
        private Map<String, String> querys;
        private String body;
        private byte[] byteBody;

        public Builder(String host) {
            this.host = host;
        }

        public Builder path(String path) {
            this.path = path;
            return this;
        }

        public Builder headers(Map<String, String> headers) {
            this.headers = headers;
            return this;
        }

        public Builder querys(Map<String, String> querys) {
            this.querys = querys;
            return this;
        }

        public Builder body(String body) {
            this.body = body;
            return this;
        }

        public Builder body(byte[] byteBody) {
            this.byteBody = byteBody;
            return this;
        }

        public RawResponse get() throws Exception {
            HttpClient httpClient = wrapClient(host);
            return new RawResponse(executeGet(httpClient));
        }

        public RawResponse post() throws Exception {
            HttpClient httpClient = wrapClient(host);
            return new RawResponse(executeGet(httpClient));
        }

        public RawResponse put() throws Exception {
            HttpClient httpClient = wrapClient(host);
            return new RawResponse(executeGet(httpClient));
        }

        public RawResponse delete() throws Exception {
            HttpClient httpClient = wrapClient(host);
            return new RawResponse(executeGet(httpClient));
        }

        private String buildUrl(String host, String path, Map<String, String> querys) throws UnsupportedEncodingException {
            StringBuilder sbUrl = new StringBuilder();
            sbUrl.append(host);
            if (!StringUtils.isBlank(path)) {
                sbUrl.append(path);
            }
            if (querys != null) {
                StringBuilder sbQuery = new StringBuilder();
                for (Map.Entry<String, String> query : querys.entrySet()) {
                    if (0 < sbQuery.length()) {
                        sbQuery.append("&");
                    }
                    if (StringUtils.isBlank(query.getKey()) && !StringUtils.isBlank(query.getValue())) {
                        sbQuery.append(query.getValue());
                    }
                    if (!StringUtils.isBlank(query.getKey())) {
                        sbQuery.append(query.getKey());
                        if (!StringUtils.isBlank(query.getValue())) {
                            sbQuery.append("=");
                            sbQuery.append(URLEncoder.encode(query.getValue(), "utf-8"));
                        }
                    }
                }
                if (0 < sbQuery.length()) {
                    sbUrl.append("?").append(sbQuery);
                }
            }

            return sbUrl.toString();
        }

        private HttpResponse executeGet(HttpClient httpClient) throws Exception {
            HttpGet request = new HttpGet(buildUrl(host, path, querys));
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    request.addHeader(e.getKey(), e.getValue());
                }
            }

            return httpClient.execute(request);
        }

        private HttpResponse executePost(HttpClient httpClient) throws Exception {
            HttpPost request = new HttpPost(buildUrl(host, path, querys));
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    request.addHeader(e.getKey(), e.getValue());
                }
            }

            if (body != null) {
                request.setEntity(new StringEntity(body, "utf-8"));
            } else if (byteBody != null) {
                request.setEntity(new ByteArrayEntity(byteBody));
            }

            return httpClient.execute(request);
        }

        private HttpResponse executePut(HttpClient httpClient) throws Exception {
            HttpPut request = new HttpPut(buildUrl(host, path, querys));
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    request.addHeader(e.getKey(), e.getValue());
                }
            }

            if (body != null) {
                request.setEntity(new StringEntity(body, "utf-8"));
            } else if (byteBody != null) {
                request.setEntity(new ByteArrayEntity(byteBody));
            }

            return httpClient.execute(request);
        }

        private HttpResponse executeDelete(HttpClient httpClient) throws Exception {
            HttpDelete request = new HttpDelete(buildUrl(host, path, querys));
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    request.addHeader(e.getKey(), e.getValue());
                }
            }

            return httpClient.execute(request);
        }

        private HttpClient wrapClient(String host) {
            HttpClient httpClient = new DefaultHttpClient();
            if (host.startsWith("https://")) {
                sslClient(httpClient);
            }

            return httpClient;
        }

        private void sslClient(HttpClient httpClient) {
            try {
                SSLContext ctx = SSLContext.getInstance("TLS");
                X509TrustManager tm = new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(X509Certificate[] xcs, String str) {

                    }

                    public void checkServerTrusted(X509Certificate[] xcs, String str) {

                    }
                };
                ctx.init(null, new TrustManager[]{tm}, null);
                SSLSocketFactory ssf = new SSLSocketFactory(ctx);
                ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
                ClientConnectionManager ccm = httpClient.getConnectionManager();
                SchemeRegistry registry = ccm.getSchemeRegistry();
                registry.register(new Scheme("https", 443, ssf));
            } catch (KeyManagementException ex) {
                throw new RuntimeException(ex);
            } catch (NoSuchAlgorithmException ex) {
                throw new RuntimeException(ex);
            }
        }
        public HttpUtils build() {
            return new HttpUtils(this);
        }
    }
}
