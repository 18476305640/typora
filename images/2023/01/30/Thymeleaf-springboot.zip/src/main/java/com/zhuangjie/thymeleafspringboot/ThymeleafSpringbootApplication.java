package com.zhuangjie.thymeleafspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThymeleafSpringbootApplication.class, args);
    }

}
