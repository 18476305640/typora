package com.zhuangjie.thymeleafspringboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
    @RequestMapping({"/","index.html"})
    public String index(Model model) {
//        model.addAttribute("desc","请输入用户名！");
        return "index";
    }
}
