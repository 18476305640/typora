package com.zhuangjie.springbootRabbitmq;

import com.zhuangjie.springbootRabbitmq.config.RabbitMQConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ProductTest {
    @Resource
    private RabbitTemplate rabbitTemplate;

    @Test
    public void productSend() {
        rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME,"order.error","将error信息写入日志文件~");
    }

}
