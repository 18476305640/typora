# Java基础

## Java基础上篇

1、Java语言有哪些特点？

平台无关性、编译与解释并存、面向对象、网络编程、多线程、可靠性、安全性、简单易学。

2、JDK vs JRE vs JVM

JVM是Java虚拟机，是运行Java字节码的虚拟机。

JRE是Java运行环境

JDK是Java开发工具包

![2022-09-26](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/09/26/1664167479410.png "2022-09-26")

3、为什么说Java是编译与解释共存的语言？

![2022-09-16](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/09/16/1663340233445.png "2022-09-16")

java是解释与编译并行的，热点代码就进行jit编译，何为热点代码呢？hotspot采用了惰性评估，根据二八定律，消耗那大部分资源的那小部分代码就是热点代码，会采用编译的方式，因此执行的次数 越多，它的速度越快。

在jdk9中新增AOT将字节码直接编译成机器码，节省了JIT预热的时间。

4、OracleJDK vs OpenJDK

1.  Oracle JDK版本将每三年发布一次LTC版本，而OpenJDK版本每三个月发布一次；
2.  OpenJDK 是一个参考模型并且是完全开源的，而Oracle JDK是OpenJDK的一个实现，并不是完全开源的；
3.  Oracle JDK 比 OpenJDK 更稳定。OpenJDK和Oracle JDK的代码几乎相同，但Oracle JDK有更多的类和一些错误修复。因此，如果您想开发企业/商业软件，我建议您选择Oracle JDK，因为它经过了彻底的测试和稳定。某些情况下，有些人提到在使用OpenJDK 可能会遇到了许多应用程序崩溃的问题，但是，只需切换到Oracle JDK就可以解决问题；
4.  在响应性和JVM性能方面，Oracle JDK与OpenJDK相比提供了更好的性能；
5.  Oracle JDK不会为即将发布的版本提供长期支持，用户每次都必须通过更新到最新版本获得支持来获取最新版本；
6.  Oracle JDK根据二进制代码许可协议获得许可，而OpenJDK根据GPL v2许可获得许可。

5、Java与C++的区别？

1.  Java不提供指针来操作内存，程序更安全，Java有自己的内存回收机制（GC），不需要程序员手动释放。
2.  Java是单继承的，C++是多继承的。Java支持方法重载与操作符重载，Java只支持方法重载。

6、注释类型&#x20;

&#x20;     单行注释、多行注释、文档注释

7、标识符与关键字

关键字是被赋予特殊含义的标识符

8、continue、break、return的区别

continue是跳过当次循环，break是退出当前for循环，return是结束当前方法的执行，并可选地返回一个值。

9、成员变量与局部变量的区别？

-   **语法形式** ：从语法形式上看，成员变量是属于类的，而局部变量是在代码块或方法中定义的变量或是方法的参数；成员变量可以被`public`,`private`,`static` 等修饰符所修饰，而局部变量不能被访问控制修饰符及 `static` 所修饰；但是，成员变量和局部变量都能被 `final` 所修饰。
-   **存储方式** ：从变量在内存中的存储方式来看,如果成员变量是使用 `static` 修饰的，那么这个成员变量是属于类的，如果没有使用 `static` 修饰，这个成员变量是属于实例的。而对象存在于堆内存，局部变量则存在于栈内存。
-   **生存时间** ：从变量在内存中的生存时间上看，成员变量是对象的一部分，它随着对象的创建而存在，而局部变量随着方法的调用而自动生成，随着方法的调用结束而消亡。
-   **默认值** ：从变量是否有默认值来看，成员变量如果没有被赋初始值，则会自动以类型的默认值而赋值（一种情况例外:被 `final` 修饰的成员变量也必须显式地赋值），而局部变量则不会自动赋值。

10、字符型常量和字符串常量的区别?

1.  **形式** : 字符常量是单引号引起的一个字符，字符串常量是双引号引起的 0 个或若干个字符。
2.  **含义** : 字符常量相当于一个整型值( ASCII 值或者UNICODE值),可以参加表达式运算;  字符串常量代表一个地址值(该字符串在内存中存放位置)。

11、重载与重写

可以重载任何方法，就算是构造方法。

重写是子类对父类的可访问的方法进行重写，注意构造方法不能重写，因为普通方法是要有返回值的，而构造方法是没有的，所以是不能重写的。重写要遵循“两同两小一大”

-   “两同”即方法名相同、形参列表相同；
-   “两小”指的是子类方法返回值类型应比父类方法返回值类型更小或相等，子类方法声明抛出的异常类应比父类方法声明抛出的异常类更小或相等；
-   “一大”指的是子类方法的访问权限应比父类方法的访问权限更大或相等。

12、可变长参数

从jdk1.5开始就引入了可变长参数，可作为方法参数的最后一个参数存在，可以传入任意长度的指定类型。

```java
public static void method1(String... args) {
   //......
}
```

固定长度还是可变长度优先呢？

们通过下面这个例子来证明一下。

```java
/**
  - 微信搜 JavaGuide 回复"面试突击"即可免费领取个人原创的 Java 面试手册

  *

  - @author Guide哥
  - @date 2021/12/13 16:52

  **/

public class VariableLengthArgument {

  public static void printVariable(String... args) {

    for (String s : args) {

      System.out.println(s);

    }

  }

  public static void printVariable(String arg1, String arg2) {

    System.out.println(arg1 + arg2);

  }

  public static void main(String[] args) {

    printVariable("a", "b");

    printVariable("a", "b", "c", "d");

  }

}
```

输出：

```text
ab
a
b
c
d
```

所以答案是：固定长度的优先于可变长度的。

可变长参数是一个语法糖，在编译成class文件后，实际上被转换成了一个数组。

13、基本数据类型

有4种整型，2种浮点型，1种char类型，一种布尔型。

14、基本类型和包装类型

1.  对于成员变量，基本类型有默认的值，而包装类型没有赋值就为null
2.  包装类型可用于泛型，而基本类型不可以。

15、包装类型的缓存机制

`Byte`,`Short`,`Integer`,`Long` 缓存范围在-128\~127,Character在 **\[0,127]**，`Boolean` 直接返回 `True` or `False`。

两个浮点类型`Float`，`Double`浮点类型没有使用缓存机制，

我们可以这样从缓存中获取指定的缓存值，但注意范围：

```java
public class test01 {
    public static void main(String[] args) {
        Integer integer1 = Integer.valueOf("1");
        Integer integer2 = 1; // 内部就是 调用valueOf方法
        System.out.println(integer1 == integer2);
    }
}
```

因为通过new的方式创建一个两个同包装类型且值也相等的，使用“==”的方式比较时，是为flase的， 除非两个都是缓存中的对象才是相等的，否则都是为false的，所以：

![2022-09-27](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/09/27/1664261459965.png "2022-09-27")

15、拆箱与装箱的原理理解吗？

```java
Integer i = 10 等价于 Integer i = Integer.valueOf(10) // 调用Xxx.valueOf()方法
int n = i 等价于 int n = i.intValue(); // 调用xxxValue()方法
```

拆箱与装箱就是基本类型与对应的包装类型进行转换时使用的，这现行对应的字节码如下：

```bash
 L1

    LINENUMBER 8 L1

    ALOAD 0

    BIPUSH 10

    INVOKESTATIC java/lang/Integer.valueOf (I)Ljava/lang/Integer;

    PUTFIELD AutoBoxTest.i : Ljava/lang/Integer;

   L2

    LINENUMBER 9 L2

    ALOAD 0

    ALOAD 0

    GETFIELD AutoBoxTest.i : Ljava/lang/Integer;

    INVOKEVIRTUAL java/lang/Integer.intValue ()I

    PUTFIELD AutoBoxTest.n : I

    RETURN
```

从上面也验证了上面的等价关系。

拆箱与装箱都是使用了语法糖，在进行javac编译成`.class` 时会进行解糖，JVM是不支持的。语法糖只是方便了我们程序员的使用，提高代码的可读性。

Java 中最常用的语法糖主要有泛型、变长参数、条件编译、自动拆装箱、内部类等。本文主要来分析下这些语法糖背后的原理。一步一步剥去糖衣，看看其本质。

16、为什么我们使用浮点数进行运算时会有丢去精度的风险？

在使用小数的类型做运算时，小数部分进行转二进制的时候是一个不断乘于2的过程，当得不到一个整数时，也就是X%1≠0时，就会不断将余数乘2，当形成循环时（如0.2）,在计算机中只能被截断，从而出现精度丢失的问题。

```bash
// 0.2 转换为二进制数的过程为，不断乘以 2，直到不存在小数为止，
// 在这个计算过程中，得到的整数部分从上到下排列就是二进制的结果。
0.2 * 2 = 0.4 -> 0
0.4 * 2 = 0.8 -> 0
0.8 * 2 = 1.6 -> 1
0.6 * 2 = 1.2 -> 1
0.2 * 2 = 0.4 -> 0（发生循环）
0.4 * 2 = 0.8 -> 0
...
```

为什么会出现单精度与双精度的问题呢？

答:一个数字转为二进制，转为二进制科学计数法的形式，示例如下:

![](image/image_n5oJZR8b6j.png)

在计算机上以三个部分表示，分别是符号位（sign）、小数位（fraction）、指数位（exponent）。

![2022-09-28](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/09/28/1664372643639.png "2022-09-28")

在float、double上占位不同，在float上以上三部分总占用32位，double占用64位。而决定精度的是小数位float占用23位，double占用52位（ps ：指数部分决定大小），故此解题。

## Java基础中篇

1、面向过程和面向对象的区别

面向过程是将解决问题的步骤组装到一个个函数中，通过依次调用方法解决问题。

面向对象是将解决问题的步骤抽象为若干对象（实体）的方法，通过调用对象的方法实现。

优缺点 :

面向过程效率高但扩展性差，维护性难度大，重用性低。

面向对象开销大所以性能低，但程序是模块化使得结构清晰，更加符合人类的思维方式，易扩展，易维护，重用率高（继承，多态）。

2、如果一个类没有声明构造方法，该程序能正确执行吗?

默认是有一个无参的构造方法，所以就算我没有创建也可以执行。

如果我们重载了构造方法，就不会有默认的无参构造方法了，重载后最好也要写一个无参的构造方法。

3、面向对象的三大特性

封装: 将对象的成员通过控制访问权限，让外界不能直接访问，但类自身可以提供一些方法让外界进行访问。

继承: 子类通过继承父类的属性与方法，让子类也具有与父类相同的行为。

多态: 是指**同一名字的事物可以完成不同的功能**，如多个类实现同一个接口，通过向上转型表现为同一个对象名有不能的表现形式。

![2022-09-28](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/09/28/1664372623458.png "2022-09-28")

再比如通过方法重载，让相同方法名有不同的行为。

4、接口与抽象类区别

相同点:

都可以有抽象方法、默认方法（从JDK1.8开始使用 \`default\`关键字，默认方法就是方法的默认实现），都不能被实例化（因为都可能存在抽象方法）

&#x20;区别: &#x20;

-   接口主要强调约束对象的行为，抽象类主要用于代码的复用与所属关系。
-   一个类只能继承一个类，但是可以实现多个接口。
-   接口中的成员变量只能是 `public static final` 类型的，不能被修改且必须有初始值，而抽象类的成员变量默认 default，可在子类中被重新定义，也可被重新赋值。

5、引用拷贝、浅拷贝、深拷贝的区别

![2022-09-28](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/09/28/1664372601525.png "2022-09-28")

-   引用拷贝: 就只拷贝对象对象的引用地址。
-   浅拷贝:  真正拷贝的是对象的内部基本成员属性，而引用成员属性只拷贝对象的地址。
-   深拷贝:  不仅拷贝对象的基本成员属性还拷贝引用成员属性，如果使用clone的方式需要实现Cloneable接口，引用成员使用set方式设置，第二种方式是使用序列化与反序列化的方式，类上需要实现Serializable接口。

6、Object

Object 类的常见方法有哪些？

Object 类是一个特殊的类，是所有类的父类。它主要提供了以下 11 个方法：

```java
/**
 * native 方法，用于返回当前运行时对象的 Class 对象，使用了 final 关键字修饰，故不允许子类重写。
 */
public final native Class<?> getClass()
/**
 * native 方法，用于返回对象的哈希码，主要使用在哈希表中，比如 JDK 中的HashMap。
 */
public native int hashCode()
/**
 * 用于比较 2 个对象的内存地址是否相等，String 类对该方法进行了重写以用于比较字符串的值是否相等。
 */
public boolean equals(Object obj)
/**
 * naitive 方法，用于创建并返回当前对象的一份拷贝。
 */
protected native Object clone() throws CloneNotSupportedException
/**
 * 返回类的名字实例的哈希码的 16 进制的字符串。建议 Object 所有的子类都重写这个方法。
 */
public String toString()
/**
 * native 方法，并且不能重写。唤醒一个在此对象监视器上等待的线程(监视器相当于就是锁的概念)。如果有多个线程在等待只会任意唤醒一个。
 */
public final native void notify()
/**
 * native 方法，并且不能重写。跟 notify 一样，唯一的区别就是会唤醒在此对象监视器上等待的所有线程，而不是一个线程。
 */
public final native void notifyAll()
/**
 * 调用对象这个方法的，必须拥有这个对象锁，这也是为什么wait(),notify(),notifyAll()必须在同步方法/代码块中调用
 * native方法，并且不能重写。暂停线程的执行。注意：sleep 方法没有释放锁，而 wait 方法释放了锁 ，timeout 是等待时间。
 */
public final native void wait(long timeout) throws InterruptedException
/**
 * 多了 nanos 参数，这个参数表示额外时间（以毫微秒为单位，范围是 0-999999）。 所以超时的时间还需要加上 nanos 毫秒。。
 */
public final void wait(long timeout, int nanos) throws InterruptedException
/**
 * 跟之前的2个wait方法一样，只不过该方法一直等待，没有超时时间这个概念
 */
public final void wait() throws InterruptedException
/**
 * 实例被垃圾回收器回收的时候触发的操作
 */
protected void finalize() throws Throwable { }

```

> 总结 ：
>
> 调用对象wait(),notify(),notifyAll()的，必须拥有这个对象锁，这也是为什么wait(),notify(),notifyAll()必须在同步方法/代码块中调用的原因了。

7、==与equals的区别

\==对于基本类型是值判断 ，而对于对象“==”比较的是地址

equals

重写前是在Object中的方法，默认是使用“==”比较

重写后，一般比较的是对象中的属性值

> 注意：重写equals后，也要重写hashCode，不然在put时会equals比较虽然为true，但hashCode不相等，依然可以put成功。
>
> ```java
> if (p.hash == hash &&
>                 ((k = p.key) == key || (key != null && key.equals(k))))
> ```

8、hashCode() 有什么用？

hashCode是本地方法，是由C/C++语言实现的，该方法通常用来将对象的内存地址转换为整数之后返回。

hashCode与equals都是Object的方法，两者都是比较对象是否相等的。

-   但hashCode相等，两个对象不一定相等，因为会存在“哈希碰撞”
-   `equals` 方法判断两个对象是相等的，那这两个对象的 `hashCode` 值也要相等。
    > hashCode在HashMap中，可以用来获取在数组中的索引位置，大大提高了put的效率，而equals是在逻辑上判断两个元素是否关键，hashCode与equals方法都用在HashMap的put中，且要求equals相等时，hashCode值必须得相等，否则在HashMap中就会有两个equals相等的多个元素。

9、String、StringBuffer、StringBuilder 的区别？

`String`被final修饰且为私有的，并且`String` 类没有提供/暴露修改这个字符串的方法，所以是不可变的。

```java
// String类
public final class String implements java.io.Serializable, Comparable<String>, CharSequence {
    private final char value[];
  //...
}
```

`StringBuffer`、`StringBuilder`这两个都继承自`AbstractStringBuilder`, 没有使用final修饰，是可变字符串，还提供了一些操作字符串的方法，比如`append` 方法。

StringBuffer与StringBuilder的区别是在线程安全上，StringBuffer是线程安全的，而StringBuilder是线程不安全的。使用 `StringBuilder` 相比使用 `StringBuffer` 仅能获得 10%\~15% 左右的性能提升，但却要冒多线程不安全的风险。

> **对于三者使用的总结：**
>
> 1.  操作少量的数据: 适用 `String`
> 2.  单线程操作字符串缓冲区下操作大量数据: 适用 `StringBuilder`
> 3.  多线程操作字符串缓冲区下操作大量数据: 适用 `StringBuffer`

**♥ Java 9 为何要将 ****`String`**** 的底层实现由 ****`char[]`**** 改成了 ****`byte[]`**** ?**

> 通过阅读官方介绍：[https://openjdk.org/jeps/254](https://openjdk.org/jeps/254 "https://openjdk.org/jeps/254")
>
> 该类的当前实现`String`将字符存储在一个 `char`数组中，每个字符使用两个字节（十六位）。从许多不同应用程序收集的数据表明，字符串是堆使用的主要组成部分，而且大多数`String`对象仅包含 Latin-1 字符。此类字符仅需要一个字节的存储空间，因此此类对象的内部`char`数组中的 一半空间未使用。
>
> 所以这样可以节省空间。

**♥ 字符串拼接用“+” 还是 StringBuilder?**

> 通过查看字符码可以知道，以下这种：
>
> ```java
> String str1 = "he";
> String str2 = "llo";
> String str3 = "world";
> String str4 = str1 + str2 + str3;
> ```
>
> 是使用了StringBuilder的append方法进行连接的。
>
> ![2022-10-05](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/05/1664941057295.png "2022-10-05")
>
> 但如果是以下这种：
>
> ```java
> String[] arr = {"he", "llo", "world"};
> String s = "";
> for (int i = 0; i < arr.length; i++) {
>     s += arr[i];
> }
> System.out.println(s);
> ```
>
> `StringBuilder` 对象是在循环内部被创建的，这意味着每循环一次就会创建一个 `StringBuilder` 对象。
>
> ![2022-10-05](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/05/1664941230960.png "2022-10-05")

**♥ 字符串常量池的作用了解吗？**

> 在new String() 时会创建几个对象？
>
> ```java
> String str1 = "abc";  // 在常量池中
> String str2 = new String("abc"); // 在堆上
> ```
>
> 第一行，会可能创建0，1个对象，是先在常量池中找，如果有直接引用赋值给str1。，如果没有，那么创建一个对象，并将引用赋值给str1。
>
> 第二行，可能创建1，2个对象，也是先在常量池中找，如果有会创建一个对象，并将常量池中的引用到对象中，如果没有需要在常量池中创建对象，再在堆中创建一个对象并引用常量池中的。
>
> ![2022-10-05](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/05/1664943341670.png "2022-10-05")
>
> 示例1：
>
> ```java
> String str = "abc" + "def";
> ```
>
> 在进行编译为字节码时，会优化为String str = "abcdef"; 所以只会创建一个对象。
>
> 示例2：
>
> ```java
> String str = "abc" + new String("def"); 
> ```
>
> 在进行编译时，会优化为
>
> ```java
> String s = new String("def"); // 2 （String对象，字符串常量池中没有"def"）
> new StringBuilder().append("abc").append(s).toString();
>                                //2（StringBuilder对象，字符串常量池中没有"abc"）+1(s)
> ```
>
> 所以会创建5个对象。
>
> 了解更多：[https://cloud.tencent.com/developer/article/1686226](https://cloud.tencent.com/developer/article/1686226 "https://cloud.tencent.com/developer/article/1686226")

## Java基础下篇

**1、异常**

![2022-10-05](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/05/1664946381717.png "2022-10-05")

说一说Java的异常：Java的异常分为Exception与Error, 两者共同的父类是Throwable， `Exception`分为受检查（`checked Exception`）的异常与不受检查的异常(`Unchecked Exceptin`)，不受检查的异常有RuntimeException，即只有在运行时才能知道是否会出现异常，所以我们在编码时可以进行catch进行捕获，也可以不做任何处理,比如算术运算异常（ArithmeticException），其它的Exception子类为受检查的异常，比如我们创建一个IO流对象时会抛出异常,这是我人必须要捕获的。

而`Error`异常是不不建议捕获的，比如：内存溢出异常（OutOfMemoryError）、栈溢出等异常(StackOverflowError)。

> Throwable 类常用方法有哪些？
>
> -   `String getMessage()`: 返回异常发生时的简要描述
> -   `String toString()`: 返回异常发生时的详细信息
> -   `String getLocalizedMessage()`: 返回异常对象的本地化信息。使用 `Throwable` 的子类覆盖这个方法，可以生成本地化信息。如果子类没有覆盖该方法，则该方法返回的信息与 `getMessage()`返回的结果相同
> -   `void printStackTrace()`: 在控制台上打印 `Throwable` 对象封装的异常信息

> **try-catch-finally 如何使用？**
>
> -   `try`块 ： 用于捕获异常。其后可接零个或多个 `catch` 块，如果没有 `catch` 块，则必须跟一个 `finally` 块。
> -   `catch`块 ： 用于处理 try 捕获到的异常。
> -   `finally` 块 ： 无论是否捕获或处理异常，`finally` 块里的语句都会被执行。当在 `try` 块或 `catch` 块中遇到 `return` 语句时，`finally` 语句块将在方法返回之前被执行。
>
> ```java
> try {
>     System.out.println("Try to do something");
>     throw new RuntimeException("RuntimeException");
> } catch (Exception e) {
>     System.out.println("Catch Exception -> " + e.getMessage());
> } finally {
>     System.out.println("Finally");
> }
> ```
>
> catch与finally中的return哪个会执行？ finally会覆盖catch中的。
>
> finally在一般情况下一定会执行，但在执行System.exit(1);使虚拟机终止运行的话，finally 中的代码就不会被执行。除此还有以下情况finally也不会执行。
>
> 1.  程序所在的线程死亡。
> 2.  关闭 CPU。
>
> > try-with-resources：出自 Java 7 之后的，如果try中有多个resources资源需要关闭，使用try-with-resources会变得非常简单。
> >
> > ```java
> > try (BufferedInputStream bin = new BufferedInputStream(new FileInputStream(new File("test.txt")));
> >      BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(new File("out.txt")))) {
> >     int b;
> >     while ((b = bin.read()) != -1) {
> >         bout.write(b);
> >     }
> > }
> > catch (IOException e) {
> >     e.printStackTrace();
> > }
> > ```

**2、泛型**

**Java 泛型（Generics）** 是 JDK 5 中引入的一个新特性。使用泛型参数，可以增强代码的可读性以及稳定性。

> **类型：** 泛型一般有三种使用方式:**泛型类**、**泛型接口**、**泛型方法**。
>
> 泛型类 & 泛型接口：
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/05/1664949496325.png)
>
> 泛型方法：
>
> ![2022-10-05](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/05/1664950536555.png "2022-10-05")

**3、反射**

1、getDeclaredXXX 忽略权限修饰，解除限制（只获取public）

2、setAccessable: 获取到私有的属性或方法想要 访问了还需要设置可访问。功能是启用或禁用安全检查，能提升操作的效率，具有“爆破”的功能

3、通过直接new比反射创建实例高很多，使用反射性能较低，需要解析字节码，将内存中的对象进行解析。

[Java集合框架源码解](Java集合框架源码解/Java集合框架源码解.md "Java集合框架源码解")
