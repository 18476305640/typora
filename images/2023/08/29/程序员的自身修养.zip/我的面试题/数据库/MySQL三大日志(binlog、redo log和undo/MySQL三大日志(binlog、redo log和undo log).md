# MySQL三大日志(binlog、redo log和undo log)

MySQL 日志 主要包括错误日志、查询日志、慢查询日志、事务日志、二进制日志几大类。其中，比较重要的还要属二进制日志 binlog（归档日志）和事务日志 redo log（重做日志）和 undo log（回滚日志）。

下面就聊聊 `redo log`（重做日志）、`binlog`（归档日志）、两阶段提交、`undo log` （回滚日志）。

## redo log重做日志

`redo log` 它是物理日志，记录内容是“在某个数据页上做了什么修改”，属于 **`InnoDB`**\*\* 存储引擎\*\*, 它让`MySQL`拥有了崩溃恢复能力。

比如当提交事务后，还没好得及持久化时，宕机了，重启后，`InnoDB`存储引擎会使用`redo log`恢复数据，保证数据的持久性与完整性。

> 流程说明：以一个更新事务为例，redo log 流转过程，如下图所示：
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/09/28/20220928232410527.png)
>
> 第1步：先将原始数据从磁盘中读入内存中来，修改数据的内存拷贝
> 第2步：生成一条重做日志并写入redo log buffer，记录的是数据被修改后的值
>
> 而 redo log buffer → redo log file的策略是怎么的呢？
>
> **`innodb_flush_log_at_trx_commit`** 参数决定的：
>
> > &#x20;Write-Ahead Log，简称WAL (预先日志持久化)：它的关键点就是日志先写内存，再写磁盘。

**刷盘时机：**`InnoDB` 存储引擎为 `redo log` 的刷盘策略提供了 **`innodb_flush_log_at_trx_commit`** 参数，它支持三种策略：

-   0: 每次提交事务时，会将生成的redo log日志放在log Buffer中，表示 commit完成，不会将 Log Buffer 中的日志写入 OS buffer, 而是通过一个单独的线程，每秒写入 OS buffer 并调用系统的 fsync() 函数写入磁盘的 Redo Log File, 这种方式不是实时写磁盘的， 而是每隔 1s 写一次日志，如果系统崩溃，可能会丢失 1s 的数据。
-   1: 每次提交事务都会将 Log Buffer 中的日志写入 OS buffer 中，并且会调用 fsync() 函数将日志写入 Redo Log File 中，然后再commit成功。如果还没来得及写到磁盘中就宕机了，事务也不会提交成功，系统启动后，将进行回滚。

    这种方式虽然不会再崩溃时丢失数据，但是性能比较差。也是这个变量的默认值。
-   2: 每次提交事务时，都只是将数据写入 os buffer 中,就表示commit 成功了，之后系统每隔 1s ,通过 fsync() 函数将 os buffer 中的数据写入 Redo Log 文件中。

    所以只要事务提交成功，redo log buffer中的内容只写入文件系统缓存，如果只是MySQL挂了不会有任何数据丢失，但是操作系统宕机可能会有1秒数据的丢失，这种情况下无法满足ACID中的D，但是数值2是效率最高的。
    > 日志刷新频率由 控制 [innodb\_flush\_log\_at\_timeout](https://dev.mysql.com/doc/refman/5.7/en/innodb-parameters.html#sysvar_innodb_flush_log_at_timeout "innodb_flush_log_at_timeout")，它允许您将日志刷新频率设置为 \_`N`\_秒（其中 \_`N`*是*\*`1 ... 2700`\*\*，默认值为 1）。但是，任何意外的\*[***mysqld***](https://dev.mysql.com/doc/refman/5.7/en/mysqld.html "mysqld")*进程退出都可以擦除长达*`N`\_几秒钟的事务。

**存储形式：**`redo log` 不只是一个文件，而是以**日志文件组**的方式（由一四个文件，每个1G）形成一个环。

![2022-10-09](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/09/1665314719439.png "2022-10-09")

> 如果 `write pos` 追上 `checkpoint` ，表示**日志文件组**满了，这时候不能再写入新的 `redo log` 记录，`MySQL` 得停下来，清空一些记录，把 `checkpoint` 推进一下。

**思考 ： 只要每次把修改后的数据页直接持久化不就好了，还有 ****`redo log`**** 什么事？**

写入redo log日志的数据（记录的是对某个数据页的修改）比一次持久化将整个数据页持久化的数据量更小，性能会远远超过刷数据页的方式，这也让数据库的并发能力更强。

## bin log  归档日志

`binlog` 是逻辑日志，记录内容是语句的原始逻辑，类似于“给 ID=2 这一行的 c 字段加 1”，属于`MySQL `**`Server`** 层。

不管用什么存储引擎，只要发生了表数据更新，都会产生 `binlog` 日志

**作用：** 可以说MySQL数据库的数据备份、主备、主主、主从都离不开binlog，需要依靠binlog来同步数据，保证数据一致性。

![2022-10-10](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/10/1665363266162.png "2022-10-10")

&#x20;

**记录格式：**`binlog` 日志有三种格式，可以通过`binlog_format`参数指定。

比如执行一条`update T set update_time=now()`

-   **statement**：`update_time=now()`这里会获取当前系统时间，直接执行会导致与原库的数据不一致。
-   **row**：`update_time=now()`变成了具体的时间`update_time=1627112756247`
-   **mixed**：`mixed`，记录的内容是前两者的混合。`MySQL`会判断这条`SQL`语句是否可能引起数据不一致，如果是，就用`row`格式，否则就用`statement`格式。

**写入机制：**`binlog`的写入时机也非常简单，事务执行过程中，先把日志写到`binlog cache`，事务提交的时候，再把`binlog cache`写到`binlog`文件中。

因为一个事务的`binlog`不能被拆开，无论这个事务多大，也要确保一次性写入(保证事务的binlog日志原子性)，所以系统会给每个线程分配一个块内存作为`binlog cache`。

我们可以通过`binlog_cache_size`参数控制单个线程 binlog cache 大小，如果存储内容超过了这个参数，就要暂存到磁盘（`Swap`）。

`binlog`日志刷盘流程如下

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/04/20221004093713471.png)

`sync_binlog` 刷盘参数：

-   **`0`**：设置为`0` 时，表示每次提交事务都只 write，由系统自行判断什么时候执行fsync。虽然性能得到提升，但是机器宕机，page cache里面的 binglog 会丢失
-   **`1`**：表示每次提交事务都会执行fsync，就如同redo log 刷盘流程一样。
-   **`2`**：如果设置为`2`，表示每次提交事务都write，但累积N个事务后才fsync，如果宕机会丢失N个事务的binlog日志。

    也说明了，当第N个事务提交是不等fsync完成就表示commit成功了

**二阶段提交**

`redo log`（重做日志）让`InnoDB`存储引擎拥有了崩溃恢复能力。

`bin log`（归档日志）保证了`MySQL`集群架构的数据一致性。

会不会出现以下这种问题呢？有一个主从架构，当执行一条更新语句时，主机器在写入redo log日志时，在准备写bin log时，主机器宕机了，主机器通过重启恢复了，主机器是修改后的值，但从机器还是旧值，因为从机器是通过bin log日志保持与主机器数据的一致性的。

![2022-10-10](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/10/1665385482488.png "2022-10-10")

为了解决这种问题，Mysql 引入了二阶提交：

![2022-10-10](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/10/1665385529562.png "2022-10-10")

原理是将`redo log`的写入拆成两个步骤`prepare` 和 `commit` ，两阶段提交就是为了保证redo log和binlog数据的安全一致性。只有在这两个日志文件逻辑上高度一致了。你才能放心的使用redo log帮你将数据库中的状态恢复成crash之前的状态，使用binlog实现数据备份、恢复、以及主从复制。

![2022-10-10](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/10/1665385842218.png "2022-10-10")

`redo log` 与 `bin log` 是通过`xid` 进行关联的，可以通过redo log找到对应的bin log.

二阶提交就是为了保证redo log和binlog数据的安全一致性，从机从binlog同步数据，主机发现为prepare状态且发现有对应的binlog后才进行事务重做。

## undo log 回滚日志

-   当事务回滚时用于将数据恢复到修改前的样子
-   另一个作用是 `MVCC` ，当读取记录时，若该记录被其他事务占用或当前版本对该事务不可见，则可以通过 `undo log` 读取之前的版本数据，以此实现非锁定读

我们知道如果想要**保证事务的原子性**，就需要在异常发生时，对已经执行的操作进行**回滚**，在 MySQL 中，恢复机制是通过 **回滚日志（undo log）** 实现的，所有事务进行的修改都会先记录到这个回滚日志中，然后再执行相关的操作。如果执行过程中遇到异常的话，我们直接利用 **回滚日志** 中的信息将数据回滚到修改之前的样子即可！并且，回滚日志会先于数据持久化到磁盘上。这样就保证了即使遇到数据库突然宕机等情况，当用户再次启动数据库的时候，数据库还能够通过查询回滚日志来回滚将之前未完成的事务。

另外，`MVCC` 的实现依赖于：**隐藏字段、Read View、undo log**。
