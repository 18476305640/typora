# Linux基础简介

<https://www.cnblogs.com/zjazn/p/15597560.html>

[Shell](Shell/Shell.md "Shell")
