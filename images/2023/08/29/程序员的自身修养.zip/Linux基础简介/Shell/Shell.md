# Shell

学习视频：[https://www.bilibili.com/video/BV1c7411x7bw](https://www.bilibili.com/video/BV1c7411x7bw "https://www.bilibili.com/video/BV1c7411x7bw")

## \[1] Shell基本内容

### 1.1 Shell概述

Shell是一个命令解释器，它接收应用程序/用户命令，然后调用操作系统内核。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/20/1674221787066.png)

Shell是一个功能强大的编程语言，易编写、易调试、灵活性强。

1.  Linux提供的Shelll解析器有（`cat /etc/shells`）
2.  bash和sh的关系 (`ll /bin/  | grep bash` )
3.  默认的解析器是Bash ( `echo $SHELL` )

### 1.2 脚本入门

1、须知：脚本以#!/bin/bash开头 （指定解析器）

2、Hello,world脚本内容

vim helloworld.sh   # 安装 yum install -y vim&#x20;

```bash
# !/bin/bash
echo "hellow world"
```

3、脚本的常用执行方式

第一种：bash <.sh脚本文件路径>

第二种：给文件执行权限（`chmod 777 <.sh文件路径>`）后，直接：`<.sh脚本文件路径>`

> 其实我们`bash <脚本文件路径>` 与`source <脚本文件路径>` 也可以执行，那两者有什么区别呢?
>
> source 是在当前shell执行，如果是bash是新开的shell 。 区别就在于，环境变量的集成关系，如在子shell中设置的当前变量，父shell是不可见的。

### 1.3 系统预定义变量

`$HOME`、`$PWD`、`$SHELL `、 `$SHELL`、`$SHELL`、`$USER`

1）查看存在的变量

```bash
env # 显示当前Shell中所有变量
set # 包含所有系统自定义和用户自定义的变量 
# printenv HOME #可以输出变量，不用"$"
```

### 1.4 自定义变量

（1）基本语法

1.  定义/修改变量：`变量名=变量`，注意"="号前后不能有空格
2.  撤销变量：`usset变量名`
3.  声明静态变量：`readonly变量`，注意：不能unset

> 在bash中，变量默认类型都是字符串类型，无法进行数值运算。

简单操作：

```bash
[root@lys shell]# a=2
[root@lys shell]# echo $a
2
# 提升为全局变量，那样在子shell，都能访问到变量了
[root@lys shell]# export a
```

计算

```bash
a=$((1+5))
a=$[1+5]
```

> **普通变量类型**
>
> -   **1) 局部变量** 局部变量在脚本或命令中定义，仅在当前shell实例中有效，其他shell启动的程序不能访问局部变量。
> -   **2) 环境变量** 所有的程序，包括shell启动的程序，都能访问环境变量，有些程序需要环境变量来保证其正常运行。必要的时候shell脚本也可以定义环境变量。

### 1.5 特殊变量

除了普通的变量（局部变量，环境变量或全局变量），还有特殊变量

#### \$n

我们在执行脚本时，可以 `./test.sh 1 2 3` ，而

`$0`：./test.sh

`$1`：1

`$2`：2

`$3`：3

#### \$\#

表示参数个数；

我们在执行脚本时，可以 `./test.sh 100 200 300` ，而

`$#`：3&#x20;

#### \$\*或\$@

两个效果是一样的

我们在执行脚本时，可以 `./test.sh 1 2 3` ，而

`$*` :  ./test.sh 1 2 3

`$@` :  ./test.sh 1 2 3

#### \$?

上一次执行命令状态 （如果这个变量的值为0，证明上一个命令正确执行；如果这个变量非0（具体是哪个数，由命令自己来决定）则证明上一命令执行不正确了）

```bash
[root@VM-16-6-centos ~]# touch /tmp/zhuangjie.txt
[root@VM-16-6-centos ~]# echo $?
0
```

### 1.6 运算符

`$((运算式))` 或 `$[运算式]`或`expr 5 \* 2`

前两种运算不是那么注意空格，但expr方式就要。&#x20;

```bash
[root@VM-16-6-centos ~]# echo $((1+2))
3
[root@VM-16-6-centos ~]# echo $[1+2]
3
[root@VM-16-6-centos ~]# echo `expr 1 + 2`
3

```

### 1.7 条件判断

> 注意: 条件非空即为true, \[lys] 返回true, \[ ]返回false

常用判断条件

(1) 两个整数之间比较

-eq 等于（equal）

-ne 不等于 （not equal)

-lt 小于 （less than)

-le 小于等于 （less equal)

-gt 大于 （greate than)

-ge 大于等于 （greater equal)

注：如果是字符串之间的比较，用等号”=“判断相等；用”！=“判断不等。

(2)按照文件权限进行判断

-r 有读的权限（read)

-w 有写的权限 （write)

-x 有执行的权限 （execute)

(3) 按照文件类型进行判断

-e 文件存在（existence)

-f 文件存在并且是一个常规的文件（file)

-d 文件存在并且是一个目录（directory)

### 1.8 流程控制

#### if

```bash
if [ $2 -lt 18 ]
then
        echo "未成年人"
elif [ $2 -lt 35 ]
then
        echo "中年人"
else
        echo "成年人"
fi
```

#### case

```bash
#!/bin/bash
case $1 in
"90")
        echo "很强"
        ;;
"100")
        echo "太棒了"
        ;;
*)
        echo "继续加油！"
        ;;
esac
```

> 注意点：
>
> 1、case行尾必须为单词 “in”, 每个模式匹配必须以有括号")" 结束
>
> 2、双分号“;;"表示命令序列结束，相当于java的breakl
>
> 3、最后的“ \*）"表示默认模式，相当于java中的default

#### for

```bash
#!/bin/bash

for(( i=$1; i<=$2; i++)) 
do
  echo $i
done

```

```bash
#!/bin/bash
for os in windows linux mac # 也可以: for os in $* 来遍历参数
do
        echo $os
done

```

#### while

```bash
#!/bin/bash
i=0
sum=0
while [ $sum -lt 100 ]
do
  sum=$[$sum+$i]
  i=$(($i+1))
  echo $sum
done
echo "${sum}大于100"
```

### 1.9 read 动态取值

基本语法

read (选项) （参数）

-p：指定读取值时的提示符：

-t：指定读取值时等待的时间（秒）如果-t不加表示一直等待

参数：

变量：指定读取值的变量名

案例实操

提示7秒内，读取控制台输入的名称

read -t 10 -p "请输入您的名称：" name

echo "welcome \$name"

### 1.10 注释

单行注释

```bash
# 注释内容
```

多行注释

```bash
:<<EOF
注释内容...
注释内容...
注释内容...
EOF
```

## \[2] 进阶内容

### 2.1 函数

#### 系统函数：basename

​basename 可以理解为取`路径`里的`文件名称`

```bash
[root@VM-16-6-centos ~]# basename /usr/local/nginx/sbin/nginx
nginx
```

#### 系统函数：dirname

取文件路径

```bash
[root@VM-16-6-centos ~]# dirname /usr/local/nginx/sbin/nginx
/usr/local/nginx/sbin

```

#### 自定义函数

```bash
#!/bin/bash
# 函数声明
function sum(){
  return $(($1+$2))
}
# 调用
sum 1 2
#取出返回的值输出
echo $?

```

发现执行脚本后，输出：3

### 2.2 文本处理工具 （精）

#### cut

**cut**  提取列：

-d 指定分隔符

-f 指定取的列（`1,2`、`1-`、`1-3`）

```bash
cut  -d' ' -f 2,3 file
```

#### awk

须知：awk是比cut更强的列处理工具，其实很简单！！

> 当我们cut无法解决时，我们需要使用便强大的工具了，**awk 可以筛选行&筛选列**。awk也算是一门编程语言，很多结构都有。而我们要掌握的就一点即可

-   -F fs or --field-separator fs &#x20;

    指定输入文件折分隔符，fs是一个字符串或者是一个正则表达式，如-F:。
-   -v var=value or --asign var=value &#x20;

    赋值一个用户定义变量。

...

```bash
[root@VM-16-6-centos ~]# ip addr | grep inet | awk -F '[ ]+' -v i=1 'BEGIN{print "开始"} /.*(inet6)+.*/{print i"=>"$3;i++} /.*(inet)[^6].*/{print i"=>"$3;i++} END{print "结束"}'
开始
1=>127.0.0.1/8
2=>::1/128
3=>10.0.16.6/22
4=>fe80::5054:ff:fe66:20d1/64
5=>192.168.122.1/24
6=>172.17.0.1/16
7=>172.18.0.1/16
8=>172.19.0.1/16
9=>fe80::42:3aff:fe59:8d69/64
10=>fe80::ec59:8dff:fe19:6051/64
11=>fe80::f0cf:72ff:fe06:ca28/64
12=>fe80::f866:18ff:fe2c:c9eb/64
13=>fe80::b020:49ff:fe9b:7335/64
14=>fe80::88ae:94ff:feae:4616/64
15=>fe80::3cc3:47ff:fe11:62d0/64
16=>fe80::4899:8ff:fe93:1483/64
17=>fe80::9c47:17ff:feec:a4c8/64
18=>fe80::68d3:a3ff:feff:96f9/64
结束

```

解析：

-F ： 指定分隔符，可以使用正则

-v ：声明一个变量

`BEGIN{print "开始"} `： 是在处理输出最前的操作（打印“开始”）

`/.*(inet6)+.*/{print i"=>"$3;i++}` : 这是主体，表示每行的操作 ，这里涉及到了字符拼接、变量重新赋值

结构：/`<正则，用于筛选行>`/{`<这里用来操作列>`}

`/.*(inet)[^6].*/{print i"=>"$3;i++}` : 这也是主体（与第一条主体是或关系）

`END{print "结束"}` : 是在处理完后的操作 （打印“结束”）

> `i`是自定义的变量，上面的`i` 可以用系统变量`NR` 代替，常用内置的变量：
>
> |          |                     |
> | -------- | ------------------- |
> | FILENAME | 文件名                 |
> | NR       | 已读的记录数（行号）          |
> | DF       | 浏览记录的域的个数（切割后，列的个数） |

#### sed

可以对文本文件或字符串进行“**增删改查**”，不管是哪种操作都是先匹配行，然后再进行操作。&#x20;

-n 是取消默认输出

-r是可以使用“扩展正则”

-i 如果操作的是文件就保存更改到文件。单引号中的p是匹配输出、a、i 加入行，c、s是替换操作。

-e\<script>或--expression=\<script> 以选项中指定的script来处理输入的文本文件。

-f\<script文件>或--file=\<script文件> 以选项中指定的script文件来处理输入的文本文件。

语法： sed \[-XX] '<筛选要操作的行><操作符><对行进行的操作>' 文件

上面的操作符：

a : 在后面加

i：在前面加

s ： 替换

d ：删除

p ：输出（查）

**示例：**

`sed -n '3p' file`   　　　　   #该命令是输出第三行, n是取消默认输出，r是识别正则。 进行字符串或文件文件的“增删改查”     &#x20;

`sed -n '1,3p' ` 　　　　  #输出第1\~3行，共三行。当然1,3也可以是正则，可以行号与正则混用

`sed -nr '/8:00/,/9:00/p'`   #输出8:00\~9:00的内容，注意这里使用的是正则。 原理是先找到第一个，找到后开始输出，然后找第二个正则，找不到会一直输出。

`sed -i '/error/i  99' test.sh`    #在/error/ 匹配成功的行前加入一行内容为"99“ 。  a是行后加入一行内容 ，i是行前加入一行内容。

> 上面都是一个操作，即增/删/改/查的其中一种，如果我们想对一个文件进行多种操作，必须得指定`-e` 表示一次编辑
>
> ```bash
> sed -i -e '4d' -e '3a echo "一样"' test.sh
> ```

#### sort

Linux sort 命令用于将文本文件内容加以排序。

sort 可针对文本文件的内容，以行为单位来排序。

参数说明

-n 依照数值的大小排序

-r 以相反的顺序来排序

-t 设置排序时所用的分隔字符

-k 指定需要排序的列

演示：

```bash
[root@VM-16-6-centos ~]# cat test.log
大聪明 100
猪猪 120
小猪 150
[root@VM-16-6-centos ~]# sort -t ' ' -nrk 2 test.log
小猪 150
猪猪 120
大聪明 100


```
