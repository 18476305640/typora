# 服务调用：OpenFeign&#x20;

<https://www.cnblogs.com/zhuangjie/p/14945002.html>
