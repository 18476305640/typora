# Thymeleaf模板引擎

学习到最后的代码：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/06/Thymeleaf-springboot.zip](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/06/Thymeleaf-springboot.zip "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/06/Thymeleaf-springboot.zip")

**模板+数据 =模板引擎⇒ html页面**

Thymeleaf 是一个服务器端 Java 模板引擎，能够处理 HTML、XML、CSS、JAVASCRIPT 等模板文件。Thymeleaf 模板可以直接当作静态原型来使用，它主要目标是为开发者的开发工作流程带来优雅的自然模板，也是 Java 服务器端 HTML5 开发的理想选择。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/29/1674981685880.png)

## \[1] Thymeleaf 认识

thymeleaf依赖

```xml
        <dependency>
            <groupId>org.thymeleaf</groupId>
            <artifactId>thymeleaf</artifactId>
            <version>3.0.9.RELEASE</version>
        </dependency>
```

### 1.1直接传入模板方式

```java
package com.zhuangjie.thymeleaf;

import org.junit.jupiter.api.Test;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

public class _1_String作为模板 {
    @Test
    public void test01(){
        // 创建模板
        TemplateEngine engine = new TemplateEngine();
        // 准备模板
        String templateText = "<input type='text' th:value='${name}'>";
        // 准备数据
        Context context = new Context();
        context.setVariable("name","请输入姓名");

        String html = engine.process(templateText, context);
        System.out.println("html=>"+html);


    }

}
```

### 1.2 以文件作为模板

下面代码中有两个测试方法

-   test01：不设置前后缀
-   test02：设置了前后缀，如果一个模板文件在 `resources > templates > index.html` ，那设置前缀 "`templates/`" ,后缀是"`.html`" ，我们只需传入`index`文件名

```java
 package   com . zhuangjie . thymeleaf ; 

 import   org . junit . jupiter . api . Test ; 
import   org . thymeleaf . TemplateEngine ; 
import   org . thymeleaf . context . Context ; 
import   org . thymeleaf . templateresolver . ClassLoaderTemplateResolver ; 

 import   java . util . HashMap ; 

 public   class  _2_以文件作为模板  { 
     @Test 
     public   void   test01 ( )   { 
         // 1、创建模板引擎 
         TemplateEngine  engine  =   new   TemplateEngine ( ) ; 
         // 2、创建模板引擎使用的resolver 
         ClassLoaderTemplateResolver  resolver  =   new   ClassLoaderTemplateResolver ( ) ; 
        engine . setTemplateResolver ( resolver ) ; 
         // 3、数据 
         Context  context  =   new   Context ( ) ; 
        context . setVariable ( "name" , "小庄" ) ; 
         // 4、渲染， index.html文件在resources > index.html 
         String  html  =  engine . process ( "index.html" ,  context ) ; 
         System . out . println ( "html=>" + html ) ; 
     } 
     @Test 
     public   void   test02 ( )   { 
         // 1、创建模板引擎 
         TemplateEngine  engine  =   new   TemplateEngine ( ) ; 
         // 2、创建模板引擎使用的resolver 
         ClassLoaderTemplateResolver  resolver  =   new   ClassLoaderTemplateResolver ( ) ; 
        resolver . setPrefix ( "templates/" ) ;  
        resolver . setSuffix ( ".html" ) ; 
        engine . setTemplateResolver ( resolver ) ; 
         // 3、数据 
         Context  context  =   new   Context ( ) ; 
        context . setVariable ( "name" , "小庄" ) ; 
         // 4、渲染, 模板文件 ： resources > templates > index.html 
         String  html  =  engine . process ( "index" ,  context ) ; 
         System . out . println ( "html=>" + html ) ; 

     } 

 } 

```

## \[2] SpringBoot 加入Thymeleaf

1、创建Springboot项目：使用 `Spring initializr` ，选择“spring web”、“Thymeleaf”来创建springboot项目，springboot中thymeleaf依赖：

```xml
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-thymeleaf</artifactId>
        </dependency>
```

2、application.properties : 下面的配置都是默认的配置

```.properties
spring.thymeleaf.cache=false
spring.thymeleaf.mode=HTML
spring.thymeleaf.prefix=classpath:/templates/
spring.thymeleaf.suffix=.html
```

3、数据的准备 - Controller

根包名 → controller → HelloController.java

```java
package com.zhuangjie.thymeleafspringboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
    @RequestMapping({"/","index.html"})
    public String index(Model model) {
        model.addAttribute("desc","请输入用户名！");
        return "index";
    }
}

```

4、模板的准备

根据我们的配置，我们要在 resources >templates > index.html

注意：下面需要加`xmlns:th="http://www.thymeleaf.org"` ，作用是有提示。

```html
 <! DOCTYPE   html > 
< html   lang = " en "   xmlns: th = " http://www.thymeleaf.org " > 
< head > 
     < meta   charset = " UTF-8 " > 
     < title > 第一个模板 </ title > 
</ head > 
< body > 
   < form > 
     < input   th: placeholder = " ${desc} " > 
   </ form > 
</ body > 
</ html >
```

5、测试

启动项目，访问 <http://127.0.0.1:8080/index.html> 或 <http://127.0.0.1:8080/>

## \[3] Thymeleaf 表达式

### 3.1 简单表达式

#### \${}变量表达式

Variable expressions（变量表达式）`${...}`

可以取model中的变量的值

#### \*{} 选择表达式

#### @{}链接表达式

@{} 可以应用于以下

```纯文本
<script src="..."> , <link href="..."> <a href=".."> ,<form action="..."> <img src="...">

```

示例：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/29/1675006516105.png)

#### #{} 消息表达式（国际化）

下面我们就要使用`#{}` 进行国际化

1）编写国际化文件

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/29/1675006945218.png)

messages.properties文件是默认文件

```.properties
login=登陆
```

messages\_zh\_CN.properties 是中文i18n文件

```.properties
login=登陆
```

messages\_en\_US.properties 是英文

```.properties
login=Sign In
```

> 注意：`zh_CN` 有两部分`zh` 是语言，`CN`是国家

在application.properties中配置i18n文件位置信息

```.properties
#相对路径 开头请勿添加斜杠
spring.messages.basename=i18n/messages
```

> i18n/messages的messages可不是目录，是i18n文件名前缀。

让springboot知道是哪个`语言_国家`

包名 > config > MyLocalResolver.java : 表示从请求参数中获取lang参数（...?lang=zh\_CN） ，组织为Locale对象，如果没有传入，使用 `request.getLocale();` 的Locale对象。

```java
package com.zhuangjie.thymeleafspringboot.config;


import com.sun.corba.se.spi.orbutil.closure.Closure;
import com.sun.corba.se.spi.resolver.LocalResolver;
import org.omg.CORBA.Object;
import org.springframework.web.servlet.LocaleResolver;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Locale;
import java.util.Set;

public class MyLocalResolver implements LocaleResolver {


    @Override
    public Locale resolveLocale(HttpServletRequest request) {
        String lang = request.getParameter("lang");
        Locale locale = request.getLocale();
        String[] localeArr = null;
        if(!StringUtils.isEmpty(lang) && (localeArr = lang.split("_")).length >= 2) {
            locale = new Locale(localeArr[0],localeArr[1]);
        }
        return locale;
    }

    @Override
    public void setLocale(HttpServletRequest request, HttpServletResponse response, Locale locale) {

    }
}

```

包名 > config > MyWebConfig.java : 将我们写的`LocaleResolver` 对象的加入容器中

```java
package com.zhuangjie.thymeleafspringboot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyWebConfig implements WebMvcConfigurer {
    @Bean
    public LocaleResolver localeResolver() {
        return new MyLocalResolver();
    }
}

```

在模板文件中, 使用的是 #{...} , 获取i18n文件中的变量。

```html
 <! DOCTYPE   html > 
< html   lang = " en "   xmlns: th = " http://www.thymeleaf.org " > 
< head > 
     < meta   charset = " UTF-8 " > 
     < title > 第一个模板 </ title > 
</ head > 
< body > 
   < form > 
     < button   th: text = " #{login} " > </ button > 
   </ form > 
</ body > 
</ html >
```

测试：

访问 [http://127.0.0.1:8080/](http://127.0.0.1:8080/ "http://127.0.0.1:8080/") 没有lang参数，使用的是默认i18n文件中的变量

访问[http://127.0.0.1:8080/?lang=en\_US](http://127.0.0.1:8080/?lang=en_US "http://127.0.0.1:8080/?lang=en_US") 是英文

访问[http://127.0.0.1:8080/?lang=zh\_CN](http://127.0.0.1:8080/?lang=zh_CN "http://127.0.0.1:8080/?lang=zh_CN") 是中文

[示例代码下载>>](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/30/Thymeleaf-springboot.zip "示例代码下载>>")

#### \~{} 分段表达式

### 3.2 文本表达式

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:text="'zhuang jie'+就是+${name}"></p>
    <p th:text="|zhuang jie就是${name}|"></p>
</body>
</html>
```

### 3.3 数字表达式

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:text="1+2"></p>
    <p th:text="${num1}+${num2}"></p>
    <p th:text="${num1}+${num2}+'是数字'"></p>
</body>
</html>
```

渲染html：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/04/1675497757825.png)

### 3.4 布尔表达式

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:if="${age} >= 18">已成年</p>
    <p th:if="${age} ge 18">已成年</p>
</body>
</html>
```

> 除了`ge` ，其它的
>
> gt：great than（大于）>
> ge：great equal（大于等于）>=
> eq：equal（等于）==
> lt：less than（小于）<
> le：less equal（小于等于）<=
> ne：not equal（不等于）!=

### 3.5 空字符串与null

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:text="null">null跟空字符串显示一样</p>
    <hr />
    <p th:text="'' == null">空字符串与null不相等</p>
</body>
</html>
```

### 3.6 逻辑表达式

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:text="!${b}">!取反</p>
    <p th:text="not(${b}) or true">not()取反</p>
    <p th:text="not(${b}) and false">not()取反</p>
</body>
</html>
```

### 3.7 三目运算符

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:text="${age} >= 18?'已成年':'未成年'"></p>
</body>
</html>
```

## \[4] Thymeleaf设置键值

#### 4.1 th:attr="k1=v1"

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:attr="class='msg',id='msg'">hello</p>
</body>
</html>
```

渲染为

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p class="msg" id="msg">hello</p>
</body>
</html>
```

#### 4.2 th:k="v"

```html
<p th:class="${className}"></p>
```

#### 4.3 th:k1-k2="v"   &#x20;

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:attr="class='msg',id='msg'">hello</p>
    <p th:alt-title="${className}"></p>
</body>
</html>
```

虽然上面两条 `<p th:attr="alt=${className},title=${className}">hello</p>` 与`<p th:alt-title="${className}"></p>` 是一样的，

**但**\*\*`th:k1-k2="v"`这种方式，好像只对alt、title有效。要是​`th:class-id="${className}"`就无效，渲染为​`class-id="XXX"`\*\*

### 4.4 th:checked="true/false" 与 th:selected="true/false"

会渲染为

th:checked="true" ⇒ th:checked="checked"

th:selected="true" ⇒ th:th:selected="th:selected"

但如果不加th，值是true/false ，但也没什么影响，都是可以的。

### 4.5 th:text与th:utext

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:text="'<b>哈哈</b>'"></p>
    <p th:utext="'<b>哈哈</b>'"></p>
</body>
</html>
```

`th:text=''` 会将里面的特殊字符进行转义 ( > ⇒ \&gt; )，即不会解析，最终里面的标签也会进行直接显示。

`th:utext=''` 不会会将里面的特殊字符进行转义，即自然会进行解析，最终里面的标签会解析为节点。

## \[5] 循环

### 5.1 渲染List

```html
    <ul>
        <li th:each="user:${users}" 
            th:text="|${user.username}-${user.age}-${user.getSex()}|" >
        </li>
    </ul>
```

### 5.2 遍历Map

```html
    <ul>
        <li th:each="userInfo:${map}"
            th:text="|${userInfo.key}-${userInfo.value}|">
        </li>
    </ul>
```

### 5.3 each循环状态变量

each的循环状态变量有：

forEach 标签还有一个属性: varStatus，这个属性用来指定接收“循环状态“的变量名，例如：`<forEach varStatus="vs" …/>`  或 `<li th:each="user,vs:${users}" ... />`，这时就可以使用vs这个变量来获取循环的状态了。

-   count：int 类型，当前以遍历元素的个数；
-   index：int 类型，当前元素的下标；
-   first：boolean类型，是否为第一个元素；
-   last：boolean类型，是否为最后一个元素；
-   current：Object 类型，表示当前项目。

演示：

```html
        <li th:each="user,loopStatus:${users}"
            th:text="|${loopStatus.count}/${loopStatus.size}: ${user.username}-${user.age}-${user.getSex()}|">
        </li>
```

## \[6] if 与unless

### 6.1 if

**满足条件（true）时显示**

`th:if="false/true"` 以下几种情况会为false

null、'no'、 'off'、  'no'、 0 == false，&#x20;

注意，空字符串是`true`

演示：

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:if="not(null)">null为false</p>
    <p th:if="not('')">''为false</p>
    <p th:if="not('no')">no为false</p>
    <p th:if="not('off')">off为false</p>
    <p th:if="not(0)">0为false</p>
    <p th:if="not(false)">false</p>
</body>
</html>
```

### 6.2 unless

条件不满足时显示

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <p th:unless="null">null为false</p>
    <p th:unless="''">''为false？</p>
    <p th:unless="'no'">no为false</p>
    <p th:unless="'off'">off为false</p>
    <p th:unless="0">0为false</p>
    <p th:unless="false">false</p>
</body>
</html>
```

渲染：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/04/1675522935710.png)

## \[7] 模板

### 7.1 基本定义与使用

#### 模板定义

resources > frag > footer.html

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>模板</title>
</head>
<body>
  <div th:fragment="frag1">
      frag1
  </div>
  <div th:fragment="frag2(par1,par2)">
    frag2: <span th:text="|${par1}与${par2}|"></span>
  </div>
</body>
</html>
```

#### 模板使用

resources > index.html

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    引用模板
    <br/>
    <p th:insert="frag/footer::frag1">

    </p>
    <p th:replace="frag/footer::frag1">

    </p>
    <p th:include="frag/footer::frag2('猪猪','大聪明')"></p>
</body>
</html>
```

渲染后的html

```html

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    引用模板
    <br/>
  <p>
     <div>
      frag1
     </div>
  </p>
  <div>
      frag1
  </div>
  <p>
    frag2: <span>猪猪与大聪明</span>
  </p>
</body>
</html>
```

> 小总结 ：
>
> 引用方式：
>
> 使用 `th:insert='...'` 是将整个模板插入到引用模板的标签内
>
> 使用 `th:replace='...'` 是将整个模板放替换引用模板的标签
>
> 使用 `th:include='...'` 是将模板内容（除了模板外标签）放到引用模板的标签内  (官网已不推荐使用该用法)
>
> 引用路径方式：
>
> `th:insert="frag/footer::frag1"`  这种方式是相对templates 目录下frag > footer.html 的frag1模板
>
> `th:insert="::模板名称"` 这种方式是模板定义与模板使用在同一html下
>
> `th:insert="::#msg"`  这种方式是根据id为msg的标签（模板）进行引用
>
> ```html
> <!DOCTYPE html>
> <html lang="en" xmlns:th="http://www.thymeleaf.org">
> <head>
>     <meta charset="UTF-8">
>     <title>i18n-demo</title>
> </head>
> <body>
>     <span id="msg">提示：XXX</span>
>
>     
>     <p>模板使用：</p>
>     <div th:insert="::#msg">
>
>     </div>
> </body>
> </html>
> ```
>
> 动态指定模板：
>
> `th:insert="/frag/footer::${tplname}"`   :  动态值就是`${tplname}`&#x20;

#### 模板删除

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/04/1675525607634.png)

## \[8] 内联

### 8.1 （\[\[]] 与\[()]）

内联主要说的是 `[[]]` 与 `[()]`  ， 用在标签内

`[[]]` 相当于th:text="..."会进行转义，即特殊内容会被显示，即标签不会被解析

`[()]` 相当于th:utext="..." 不会进行转义，即标签会被解析成文档对象。

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>i18n-demo</title>
</head>
<body>
    <div>
        <span>[[${msg}]]</span>
        <br />
        <span>[(${msg})]</span>
    </div>
</body>
</html>
```

渲染为：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/05/1675598337810.png)

### 8.2 内联javascript

```html
<script th:inline="javascript">
    console.log("你好，这是内联js, 收到的消息是"+[[${msg}]]);
</script>
```

会渲染为：

```html
<script>
    console.log("你好，这是内联js, 收到的消息是"+"<b>\u662F\u5426\u8F6C\u4E49<\/b>");
</script>
```

### 8.3 禁用内联

如果我们想页面显示\[\[ ]] ,但默认会被解析的，这时候我们就需要禁用内联了

`<span>[[hello]]</span>`

禁用：&#x20;

`<span th:inline="none">[[hello]]</span>`

禁用前后对比：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/05/1675599260984.png)

## \[9] 局部变量

定义：

```html
<div th:with="name='猪猪',age=23">
    <b th:text="|${name}-${age}|"></b>
</div>
```

渲染：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/05/1675599502719.png)

## \[10] 内置工具类

### 10.1 url编码与解码

```html
<div th:with="url='https://baidu.com?wd=你好',url2='https://baidu.com%3Fwd=%E4%BD%A0%E5%A5%BD'">
        <p>编码的值：[[${#uris.escapePath(url)}]]</p>
        <p th:text="|解码的值: ${#uris.unescapePath(url2)}|"></p>
    </div>
```

### 10.2 时间格式化

```html
<p th:text="${date}"></p>
<p th:text="${#dates.format(date,'yyyy-MM-dd HH:mm:ss')}"></p>
```

### 10.3 数字格式化

```html
    <div th:with="price=13.145678">
        <span th:text="${#numbers.formatInteger(price,3)}"></span>
        <span th:text="${#numbers.formatDecimal(price,0,3)}"></span>
    </div>
```

效果：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/05/1675601558606.png)

### 10.4 字符串操作方法

```html
    <div th:with="name='HelloWorld'">
        <span th:text="${#strings.toUpperCase(name)}"></span>
        <span th:text="${#strings.substring(name,0,5)}"></span>
        <span th:text="${#strings.indexOf(name,'Wo')}"></span>
    </div>
```

更多请查看官网：[https://waylau.gitbooks.io/thymeleaf-tutorial/content/docs/expression-utility-objects.html](https://waylau.gitbooks.io/thymeleaf-tutorial/content/docs/expression-utility-objects.html "https://waylau.gitbooks.io/thymeleaf-tutorial/content/docs/expression-utility-objects.html")

## \[11] 内置对象

### 11.1 request 与 session

> request 与 session 对象前面需要加`#` , 但后面要讲的param与application不用。

```html
<p th:text="${#request.getAttribute('requestAttr')}"></p>
<p th:text="${#session.getAttribute('sessionAttr')}"></p>
```

### 11.2 param 与application

> param 与application 不像 request 与 session 对象前面需要加`#` , 但param与application不用。

#### param

请求url: [http://127.0.0.1:8080/?name=helloworld\&age=22](http://127.0.0.1:8080/?name=helloworld\&age=22 "http://127.0.0.1:8080/?name=helloworld\&age=22")

```html
<p th:text="|参数key为name: ${param.get('name')}|"></p>
```

会获取到“[helloworld](http://127.0.0.1:8080/?name=helloworld\&age=22 "helloworld")” 值。

#### application

向application对象中设置值

```java
ServletContext context = request.getServletContext();
        context.setAttribute("contextAttr","我是application的属性值");
```

```html
<p th:text="${application.contextAttr}"></p>
```
