# SpringBoot 核心讲解

学习自：[https://www.bilibili.com/video/BV1bg411Y7go](https://www.bilibili.com/video/BV1bg411Y7go "https://www.bilibili.com/video/BV1bg411Y7go")  以下总结为视频1-11集内容

## \[1]\_Spring各版本内容

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/1669188611813f153022b-609d-49a5-9a9b-672dae066807.jpg)

### \[v1] v1版本

**Spring Framework 1.x**
在`SpringFramework1.x`时代，其中在1.2.0是这个时代的分水岭，当时Java5刚刚发布，业界正兴起了使用Annotation的技术风，Spring Framework自然也提供了支持，比如当时已经支持了`@Transactional`等注解，但是这个时候，XML配置方式还是唯一选择。spring-tx

1、创建一个maven项目，右击项目选择 `添加框架支持`， 添加`web`

引入依赖：我们引入最新的即可，不用一定要引v1

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.2.12.RELEASE</version>
</dependency>
```

创建 service.UserService.java 类

创建文件 resources → applicationContext.xml：配置bean信息

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">
    <bean class="com.zhuangjie.springboot.service.UserService" id="userService"></bean>
</beans>
```

创建一个测试类：

```java
public class StuApplication {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new FileSystemXmlApplicationContext("classpath:applicationContext.xml");
        System.out.println(applicationContext.getBean("userService"));
    }
}

```

执行输出：说明注册bean成功了，且获取到了bean

```bash
com.zhuangjie.springboot.service.UserService@1794d431

进程已结束,退出代码0

```

### \[v2] v2版本

Spring Framework2.x时代，2.0版本在Annotation中添加了`@Required`、`@Repository`以及AOP相关的`@Aspect`等注解，同时也提升了XML配置能力，也就是可扩展的XML,比如Dubbo这样的开源框架就是基于SpringXML的扩展来完美的集成Spring,从而降低了Dubbo使用的门槛。

在2.x时代，2.5版本也是这个时代的分水岭，它引入了一些很核心的`Annotation`

-   @Autowired依赖注入
-   @Qualifier依赖查找
-   @Component、@Service组件声明
-   @Controller、@RequestMappring等spring mvc的注解

尽管Spring2.x时代提供了不少的注解，但是仍然没有脱离XML配置驱动，比如context:annotation-context:context-scan,前者的职责是注册
Annotation处理器，后者是负责扫描classpath下指定包路径下被Spring模式注解标注的类，将他们注册成为Spring Bean。

基本演示：

创建项目-引入spirng-context依赖，在v2版本中加入一些常用的注解，如`@Component` ，这让我们可以不用在xml配置bean信息了，我们只需要在需要加入bean的类上加上`@Component`，然后配置扫描即可。

resources → applicationContext.xml：为了使用import，我们在这里演示一下，首先写import, 然后再在引入 的xml中再写扫描。

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd
    ">
    <import resource="classpath*:beans.xml" />
</beans>
```

resources → beans.xml : 在这里配置了扫描包路径， 注意需要加入context头信息，才能使用

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:context="http://www.springframework.org/schema/context" 
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
         http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd 
    ">
    <!--配置扫描包-->
    <context:component-scan base-package="com.zhuangjie.springboot" />
</beans>
```

创建 service → UserService.java：加入`@Component`注解

```java
@Component
public class UserService {

}
```

测试类：

```java
public class StuApplication {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new FileSystemXmlApplicationContext("classpath:applicationContext.xml");
        // V2版本中，还是没有提供根据类型获取bean
        System.out.println(applicationContext.getBean("userService"));
    }
}

```

### \[v3] v3版本

Spring Framework3.0是一个里程碑式的时代，他的功能特性开始出现了非常大的扩展，比如全面拥抱Java5、以及Spring Annotation。更重要的是，它提供了配置类注解@Configuration, 他出现的首要任务就是取代XML配置方式，不过比较遗憾的是，Spring Framework3.0还没有引入替换XML元素context:componet-scan的注解，而是选择了一个过渡方式@ImportResource。@ImportResource允许导入遗留的XML配置文件，比如

```java
@ImportResource("classpath:/META-INF/spring/other.xml")
@configuration
public class SpringConfiguration{
}
```

并且在Spring Frameworkd提供了AnnotationConfigApplicationContext注册，用来注册@ConfigurationClass,通过解析Configuration类来进行装配。在3.1版本中，引入了@ComponentScan,替换了XML元素Context:component-scan,这个注解虽然是一个小的升级，但是对于spring来说在注解驱动领域却是一个很大的进步，至此也体现了Spring的无配置化支持。

**演示：那v3版本是如何取代xml的呢？**

如果读懂下面的东西？先看下面这个类上的注释，然后再看图。

```java
/**
 * 斯图应用
 *
 * @author manzhuangjie
 * @date 2022/11/23
 */
 // @Configuration 相当于xml配置文件
@Configuration
// 第一种注册Bean方式：相当xml的  <context:component-scan /> 通过扫描指定包标明了需载入窗口的注解
@ComponentScan
/**
 * @Import注解相当于xml <import> 标签, 导入其它配置
 * 这里还有三种：
 *  1、直接引入一个配置了 @Configuration的类，下面的方法如果标了@Bean注解，标明返回的值需要加入容器
 *  2、引入一个实现了ImportBeanDefinitionRegistrar接口的类，所实现的方法参数有注册器BeanDefinitionRegistry，可以根据注册器加入
 *  3、引入一个实现了ImportSelector的类，所实现的方法selectImports ，通过返回类的全类名数组来加入bean容器中
 */
@Import({MvcConfig.class, RedisConfig.class, MybatisConfig.class})
public class StuApplication {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(StuApplication.class);
        for (String beanName : context.getBeanDefinitionNames()) {
            System.out.println(context.getBean(beanName));
        }
    }
}
```

解析图：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16691928929521669192892823.png)

> **应用：spring注解在redis**中的使用
>
> 引入依赖：
>
> ```xml
>         <dependency>
>             <groupId>org.springframework</groupId>
>             <artifactId>spring-context</artifactId>
>             <version>5.2.12.RELEASE</version>
>         </dependency>
>         <dependency>
>             <groupId>org.redisson</groupId>
>             <artifactId>redisson</artifactId>
>             <version>3.15.6</version>
>         </dependency>
> ```
>
> 写一个配置类： config → MyRedisConfig.java
>
> ```java
> @Configuration
> public class MyRedisConfig {
>     @Bean
>     public RedissonClient  getRedissonClient() {
>         Config config = new Config();
>         config.useSingleServer().setAddress("redis://192.168.87.101:6379")
>                 .setTimeout(5000);
>         return Redisson.create(config);
>     }
> }
> ```
>
> 写一个注解：作用是作为一个开关，当要使用时只需要在可被扫描的类加上该注解即可，注解里有`@Import({MyRedisConfig.class})` 会导入其它需要的配置类。
>
> annotation → EnableRedisAutoConfiguration.java&#x20;
>
> ```java
> @Target(ElementType.TYPE)
> @Retention(RetentionPolicy.RUNTIME)
> @Documented
> @Inherited
> @Import({MyRedisConfig.class})
> public @interface EnableRedisAutoConfiguration {
>
> }
> ```
>
> 写一个入口类（也是配置类）：StuApplication.java
>
> ```java
> @Configuration
> @EnableRedisAutoConfiguration
> public class StuApplication {
>     public static void main(String[] args) {
>         ApplicationContext context = new AnnotationConfigApplicationContext(StuApplication.class);
>         RedissonClient bean = context.getBean(RedissonClient.class);
>         System.out.println(bean);
>     }
> }
>
> ```
>
> 可以观察到，在没有添加 `@EnableRedisAutoConfiguration` 注解时，bean是找不到的，只有加入了该注解后容器中才有`RedissonClient`的bean

### \[v4] v4 版本

新增了以下注解：

**`@Conditional`**  可以用在类上或方法上，是注入容器的条件.
`@EventListener``@AliasFor``@CrossOrigin` 解决跨域的注解

### \[v5] v5 版本

新增了 `@indexed` 注解

注解讲解：

**1、使用场景**

在应用中有大量使用`@ComponentScan`扫描的package包含的类越多的时候，Spring模式注解解析耗时就越长。

2、使用方法

> 模式注解：
>
> | Spring注解       | 场景说明       |
> | -------------- | ---------- |
> | @Repository    | 数据仓库模式注解   |
> | @Component     | 通用组件模式注解   |
> | @Service       | 服务模式注解     |
> | @Controller    | Web控制器模式注解 |
> | @Configuration | 配置类模式注解    |

在项目中使用的时候需要导入一个`spring-context-indexer` jar包，有Maven和Gradle 两种导入方式，具体可以看官网，我这里使用maven方式，引入jar配置如下：

```xml
<dependencies>
  <dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context-indexer</artifactId>
    <version>5.1.12.RELEASE</version>
    <optional>true</optional>
  </dependency>
</dependencies>
```

然后在代码中，对于使用了**模式注解**的类上加上`@Indexed`注解即可。如下：

```java
@Indexed
@Controller
public class HelloController {
}
```

**3、原理说明**

简单说明一下：在项目中使用了`@Indexed`之后，编译打包的时候会在项目中自动生成`META-INT/spring.components`文件。 当Spring应用上下文执行`ComponentScan`扫描时，`META-INT/spring.components`将会被`CandidateComponentsIndexLoader` 读取并加载，转换为`CandidateComponentsIndex`对象，这样的话`@ComponentScan`不在扫描指定的package，而是读取`CandidateComponentsIndex`对象，从而达到提升性能的目的。

## \[2] SPI

形如JDBC会提供`接口`，但谁实现呢，各自`实现的类路径`是什么？那也要规定实现接口的类路径放在哪里，在项目中引入依赖：

```xml
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <version>8.0.22</version>
</dependency>
```

查看IDEA左侧代码下面的`外部库` ，发现 `mysql` 依赖下面的`META-INF → service → java.sql.Driver` 里面写的是

```text
com.mysql.cj.jdbc.Driver
```

发现该类`com.mysql.cj.jdbc.Driver`继承了` java.sql.Driver` 这样我们就可以在引入mysql驱动的项目中进行` Class.forName(...)` ，然后将`java.sql.Driver`的`com.mysql.cj.jdbc.Driver`实现进行注册了。

模拟上面我们自己写一个：

创建一个项目jdbc，这个项目定义接口，有一个唯一方法`show`, 且规定在`service →abc.jdbc` 存放该接口实现类的全类名。将项目进行`mvn install` (注意打包放在C盘用户下的`.m2`)

创建实现项目mysql, 引入上面打包好的`jdbc`（因为打包了，相当于本地库了，可以在其它项目中引入）， 创建一个类实现项目jdbc说的接口，且在`resources → service → abc.jdbc` 写：

```java
com.zhuangjie.mysql.MySql
```

打包！

创建项目oracle,   引入上面打包好的`jdbc`（因为打包了，相当于本地库了，可以在其它项目中引入）， 创建一个类实现项目jdbc说的接口，且在`resources → service → abc.jdbc` 写：

```java
com.zhuangjie.oracle.Oracle
```

打包！

创建一个测试项目，引入上面的实现oracle或mysql，创建一个测试类→ 测试方法：加载`resources → service → abc.jdbc` 存放的类名，创建`newInstance`

```java
public class Application {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        InputStream resourceAsStream = new Application().getClass().getClassLoader().getResourceAsStream("service/abc.jdbc");
        InputStreamReader inputStreamReader = new InputStreamReader(resourceAsStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        String className = bufferedReader.readLine().trim();
        Class<?> aClass = Class.forName( className);
        Jdbc jdbc = (Jdbc)aClass.newInstance();
        jdbc.show();
    }
}
```

执行输出：

```bash
I'm oracle...

进程已结束,退出代码0
```

SPI不仅用在JDBC中，SpringBoot中也有使用，请往下看...

## \[3] SpringBoot的自动装配

使用`Initializr`  创建项目，选择一个 `spring web` ，点击创建。

下面有一个主启动类 `Application.java`  我们可以直接启动。

那在SpringBoot有什么玄机呢？我们看主启动类：

```java
@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

先看 `SpringApplication.run(Application.class, args);`  一直往`run(...) `方法追，发现最终执行的是`SpringApplication` → `public ConfigurableApplicationContext run(String... args) { ... }`  方法：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16694723946031669472394061.png)

发现这个方法其实就是IOC的初始化，在调用`refreshContext(context)`方法前后都有监听，在点进`refreshContext(context)` 方法内时，一起往refresh追，最后一个是接口，选择`AbstractApplicationContext` 抽象类，进入真正的`refresh`方法，这里进行IOC的初始化等操作。

看完主启动类的 ` SpringApplication.run(Application.class, args);` ，发现只是IOC容器的初始化，但SpringBoot明显没有这么简单，我们继续看主启动类上的`@SpringBootApplication` 注解，点进行发现是一个复合注解

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16694729656061669472965309.png)

上面的`主要探索的注解` 中的`@SpringBootConfiguration` 点进去发现是一个复合注解，里面有一个`@Configuration` 注解，所以可以知道`@SpringBootConfiguration`注解其实是一个标注是一个配置类的注解。

而另一个注解`@EnableAutoConfiguration` ，点进行，再点进行它的子注解`@Import(AutoConfigurationImportSelector.class)` 的`AutoConfigurationImportSelector.class` 类，发现该类实现了`DeferredImportSelector` ，那我们就要往下看它的方法了，重写了：

```java
  @Override
  public String[] selectImports(AnnotationMetadata annotationMetadata) {
    if (!isEnabled(annotationMetadata)) {
      return NO_IMPORTS;
    }
    AutoConfigurationEntry autoConfigurationEntry = getAutoConfigurationEntry(annotationMetadata);
    return StringUtils.toStringArray(autoConfigurationEntry.getConfigurations());
  }
```

再点进上面方法中的`getAutoConfigurationEntry` :&#x20;

```java
  protected AutoConfigurationEntry getAutoConfigurationEntry(AnnotationMetadata annotationMetadata) {
    if (!isEnabled(annotationMetadata)) {
      return EMPTY_ENTRY;
    }
    AnnotationAttributes attributes = getAttributes(annotationMetadata);
    List<String> configurations = getCandidateConfigurations(annotationMetadata, attributes);
    configurations = removeDuplicates(configurations);
    Set<String> exclusions = getExclusions(annotationMetadata, attributes);
    checkExcludedClasses(configurations, exclusions);
    configurations.removeAll(exclusions);
    configurations = getConfigurationClassFilter().filter(configurations);
    fireAutoConfigurationImportEvents(configurations, exclusions);
    return new AutoConfigurationEntry(configurations, exclusions);
  }
```

这是自动配置的核心方法，分析上面方法的`getCandidateConfigurations`  往下面追 `..loadFactoryNames..`  →  `loadSpringFactories ... ` →  方法内引用的常量`FACTORIES_RESOURCE_LOCATION` 就是`META-INF/spring.factories`  ,且下面进行了while， 所以发现就是打包了该文件进行自动配置的，规定了自动注入哪些的对象到Bean容器中：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16694747746041669474774543.png)

而`META-INF` 下还有一个文件 `spring-autoconfigure-metadata.properties` 文件，spring.factories中注入的条件。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16694756394761669475639348.png)

现在我们来验证一下：

创建一个maven项目，引入 依赖

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.2.12.RELEASE</version>
</dependency>
```

创建一个普通类（没有任何注解，就直接创建）`UserServiceImpl` 然后创建一个配置类 `MvcConfig`：

```java
@Configuration
public class MvcConfig {
    @Bean
    public UserServiceImpl getUserServiceImpl() {
        return new UserServiceImpl();
    }
}
```

返回 `UserServiceImpl` 对象，创建Bean。将项目安装 `mvn install` 然后在SpringBoot项目中引入，在主启动类中：

```java
@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(Application.class, args);
        System.out.println(context.getBean(UserServiceImpl.class));
    }
}

```

发现没有找到Bean (报错)，所以如果其它配置，只有使用了配置类，那是没用的，不会被扫描。

继续实验：在resources → META-INF →  spring.factories :

```text
org.springframework.boot.autoconfigure.EnableAutoConfiguration=com.zhuangjie.starter.config.MvcConfig
```

> 说明：加了**org.springframework.boot.autoconfigure.EnableAutoConfiguration=****`加了@Configuration`**** 的配置类全类名**

安装 ，再进行执行主启动类，发现找到了。

继续实验：在项目的`META-INF` → `spring-autoconfigure-metadata.properties` ：

```java
com.zhuangjie.starter.config.MvcConfig.ConditionalOnClass=com.zhuangjie.utils.FileUtil
```

> 说明：**`加了@Configuration`的配置类全类名**.ConditionalOnClass=com.zhuangjie.utils.FileUtil
>
> 也就是说，想要扫描左边的配置类，需要有右边的这个类存在。否则会被过滤。

转回上面的自动配置的`getAutoConfigurationEntry` 方法:  (请看下面代码注释)

```java
  protected AutoConfigurationEntry getAutoConfigurationEntry(AnnotationMetadata annotationMetadata) {
    if (!isEnabled(annotationMetadata)) {
      return EMPTY_ENTRY;
    }
    // 从 META-INF -> spring.factories 扫描自动配置得到要注入容器的Bean
    AnnotationAttributes attributes = getAttributes(annotationMetadata);
    List<String> configurations = getCandidateConfigurations(annotationMetadata, attributes);
    // 去重
    configurations = removeDuplicates(configurations);
    // 去除声明要排除的Bean
    Set<String> exclusions = getExclusions(annotationMetadata, attributes);
    checkExcludedClasses(configurations, exclusions);
    configurations.removeAll(exclusions);
    // 依据spring-autoconfigure-metadata.properties 得到新的Bean与过滤存在的Bean
    configurations = getConfigurationClassFilter().filter(configurations);
    fireAutoConfigurationImportEvents(configurations, exclusions);
    return new AutoConfigurationEntry(configurations, exclusions);
  }
```

## \[4] 手写Starter

下面演示写一个配置Redis的starter, 创建一个maven项目， 加入依赖 pom.xml：

```xml
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <dependency>
            <groupId>org.redisson</groupId>
            <artifactId>redisson</artifactId>
            <version>3.14.0</version>
        </dependency>
    </dependencies>
    
    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-dependencies</artifactId>
                <version>${spring-boot.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>

```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16695432943131669543294070.png)

就三个文件，RedisConfig文件是加了`@Configuration` 注解的类，表示一个配置文件，想要被扫描（自动配置），那就要加入`spring.factories`配置，如果不想RedisConfig文件写的配置写死，那还需要加入`RedisConfigProperties.java `:

```java
// 后面引入我们写的这个starter后，就可以按下面这样配置了如： zhuangjie.redis.host=192.168.87.101
@ConfigurationProperties("zhuangjie.redis")
public class RedisConfigProperties {
    private String host = "localhost";
    private int port = 6379;
    private int timeout = 5000;
    private boolean ssl = false;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public boolean isSsl() {
        return ssl;
    }

    public void setSsl(boolean ssl) {
        this.ssl = ssl;
    }
}
```

在RedisConfig文件中开启配置 `@EnableConfigurationProperties({RedisConfigProperties.class})`

不然上面写的`RedisConfigProperties.java` 就没有作用了，开启后就将`RedisConfigProperties `类加入了容器，然后在下面的@Bean修改的方法参数就有值了（会自动注入），也就可以用于配置了。

```java
@Configuration
@EnableConfigurationProperties({RedisConfigProperties.class})
public class RedisConfig {
    @Bean
    public RedissonClient redissonClient(RedisConfigProperties redisConfigProperties ) {
        Config config = new Config();
        String prefix = "redis://";
        if (redisConfigProperties.isSsl()) {
            prefix = "rediss://";
        }
        config.useSingleServer()
                .setAddress(prefix+redisConfigProperties.getHost()+":"+redisConfigProperties.getPort())
                .setTimeout(redisConfigProperties.getTimeout());
        return Redisson.create(config);
    }

}
```

在resources → META-INF → `spring.factories` ：（配置要开启的配置）

```text
org.springframework.boot.autoconfigure.EnableAutoConfiguration=com.zhuangjie.redis.RedisConfig
```

完成这个，我们还不能执行安装命令，因为人家引入我们这个starter后，人家怎么知道要怎么配置呢？

那就得有下面这个文件了，我们要手动写吗？其实不然

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16695446135221669544613383.png)

我们只需再引入 一个依赖+插件配置 即可，在打包时，会自动生成。

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-configuration-processor</artifactId>
    <optional>true</optional>
</dependency>
```

同样在pom.xml下加入

```xml
<build>
    <plugins>
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
            <configuration>
                <excludes>
                    <exclude>
                        <groupId>org.springframework.boot</groupId>
                        <artifactId>spring-boot-configuration-processor</artifactId>
                    </exclude>
                </excludes>
            </configuration>
        </plugin>
    </plugins>
</build>
```

最终starter :&#x20;

[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/27/myconfig-spring-boot-starter.zip](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/27/myconfig-spring-boot-starter.zip "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/27/myconfig-spring-boot-starter.zip")
