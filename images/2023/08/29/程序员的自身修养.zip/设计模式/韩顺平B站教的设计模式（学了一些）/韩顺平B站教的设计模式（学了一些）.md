# 韩顺平B站教的设计模式（学了一些）

[https://www.bilibili.com/video/BV1G4411c7N4](https://www.bilibili.com/video/BV1G4411c7N4 "https://www.bilibili.com/video/BV1G4411c7N4")  (视频)

第二波学习视频：[https://www.bilibili.com/video/BV1u3411P7Na?p=9\&vd\_source=efcb6bee91cb11215a6c31f8ee75f85c](https://www.bilibili.com/video/BV1u3411P7Na?p=9\&vd_source=efcb6bee91cb11215a6c31f8ee75f85c "https://www.bilibili.com/video/BV1u3411P7Na?p=9\&vd_source=efcb6bee91cb11215a6c31f8ee75f85c")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16469242019262.png)

> 概念：编写软件过程中， 程序员面临着来自 耦合性， 内聚性以及可维护性， 可扩展性， 重用性， 灵活性 等多方面的挑战， 设计模式是为了让程序(软件)， 具有更好

1\) 代码重用性 (即： 相同功能的代码， 不用多次编写)

2\) 可读性 (即： 编程规范性, 便于其他程序员的阅读和理解)

3\) 可扩展性 (即： 当需要增加新的功能时， 非常的方便， 称为可维护)

4\) 可靠性 (即： 当我们增加新的功能后， 对原来的功能没有影响)

5\) 使程序呈现高内聚， 低耦合的特性

分享金句：

> 设计模式包含了面向对象的精髓， “懂了设计模式， 你就懂了面向对象分析和设计（OOA/D） 的精要”

> Scott Mayers 在其巨著《Effective C++》 就曾经说过： C++老手和 C++新手的区别就是前者手背上有很多伤疤

### 1.1 设计模式的七大原则

#### 1.1 单一职责原则（高内聚）

> 对类来说的， 即一个类应该只负责一项职责。 如类 A 负责两个不同职责： 职责 1， 职责 2。 当职责 1 需求变更而改变 A 时， 可能造成职责 2 执行错误， 所以需要将类 A 的粒度分解为 A1， A2

在演示，有两个就分别是在类上遵守单一职责原则，与方法上遵守单一职责原则（方法比较少的时候适用）。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16470942383631647094238213.png)

要我说：一个方法或一个类只做一件事

#### 1.2 接口分离原则

> 客户端不应该依赖它不需要的接口， 即一个类对另一个类的依赖应该建立在最小的接口上。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16470988097091647098809424.png)

要我说：对接口进行单一职责

#### 1.3 依赖倒转原则（低耦合）

**官方翻译**：高层模块不应该依赖低层模块，两者都应该依赖其抽象；抽象不应该依赖细节，细节应该依赖抽象。

依赖倒转原则(Dependence Inversion Principle)是指：

1\) 高层模块不应该依赖低层模块， 二者都应该依赖其抽象

2\) 抽象不应该依赖细节， 细节应该依赖抽象

3\) 依赖倒转(倒置)的中心思想是面向接口编程

4\) 依赖倒转原则是基于这样的设计理念： 相对于细节的多变性， 抽象的东西要稳定的多。 以抽象为基础搭建的架

构比以细节为基础的架构要稳定的多。 在 java 中， 抽象指的是接口或抽象类， 细节就是具体的实现类

5\) 使用接口或抽象类的目的是制定好规范， 而不涉及任何具体的操作， 把展现细节的任务交给他们的实现类去完成。

**依赖倒置的目的：**

上面说了，在三层架构里面增加一个接口层能实现依赖倒置，它的目的就是降低层与层之间的耦合，使得设计更加灵活。从这点上来说，依赖倒置原则也是“松耦合”设计的很好体现。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16471842214431647184221246.png)

**个人理解**：由依赖实现转为依赖接口（以接口作为参数）或说由依赖细节转为依赖细节的抽象（接口或抽象类）。这样我们的变量引用和实际对象间，就存在一个缓冲层，利于程序扩展和优化，增强程序的稳定性与设计的灵活性，依赖倒置原则也是“松耦合”设计的很好体现。

-   代码说明：
    -   不遵守：直接使用哪个邮箱类，使用时直接依赖这个接口。
    -   遵守后：优化后：添加一个邮箱接口，具体的邮箱类实现这个抽口，直接依赖邮箱接口。

#### 1.4 里氏替换原则

**内容**：如果对每个类型为T1的对象o1,都有类型为T2的对象02,使得以T1定义的所有程序P在所有的对象o1都代换成02时，程序P的行为没有发生变化，那么类型T2是类型T1的子类型。换句话说，所有引用基类的地方必须能透明地使用其子类的对象。

**通俗地说**：**就是教我们如何正确地用继承。** 子类可以扩展父类的功能，但不能改变父类原有的功能。
也就是说：子类继承父类时，除添加新的方法完成新增功能外，尽量不要重写父类的方法。

**总结如下：**

-   子类可以实现父类的抽象方法，但不能覆盖父类的非抽象方法
-   子类中可以增加自己特有的方法
-   当子类的方法重载父类的方法时，方法的前置条件（即方法的输入参数）要比父类的方法更宽松
-   当子类的方法实现父类的方法时（重写/重载或实现抽象方法）,方法的后置条件（即方法的的输出/返回值）要比父类的方法更严格或相等

里氏替换原则告诉我们，继承实际上让两个类藕合性增强了，在适当的情况下，可以通过聚合，组合，依赖来解决问题。

继承就是为了使用父类的方法，如果真的需要复写，则就用里氏替换原则。

#### 1.5 开闭原则

在增加一个新的功能时，尽量不要修改原有的功能模块。对扩展开放，对修改关闭。

**一个解决方法**：如果我们要对A类进行修改能实现对功能的扩展的话，我们可以创建一个B类继承A类，重写要修改的这个方法（要遵循`里氏替换原则`），这样就实现了不修改原有代码来对功能的扩展了。

#### 1.6 迪米特法则

只与你的直接朋友交谈，不跟“陌生人”说话（最少知道原则）。

**直接的朋友：** 每个对象都会与其他对象有藕合关系，只要两个对象之间有羁合关系，我们就说这两个对象之间是朋友关系。羁合的方式很多，依赖，关联，组合，聚合等。其中，我们称出现`成员变量`，`方法参数`，`方法返回值中的类`为直接的朋友，而出现在局部变量中的类不是直接的朋友。也就是说，陌生的类最好不要以局部变量的形式出现在类的内部。

**迪米特法则注意事项和细节:**
1\) 迪米特法则的核心是`降低`类之间的耦合
2\) 但是注意：由于每个类都`减少了不必要的依赖`，因此迪米特法则只是要求降低类间（对象间）精合关系，并不是要求完全没有依赖关系

**要我说：** 核心就是减少不必要的依赖来降低类之间的耦合，而直接朋友（成员变量、方法参数、返回值类）是我们需要依赖的，局部变量的类则最好不要以局部变量的形式出现在类部。

#### 1.7  合成复用原则

<https://zhuanlan.zhihu.com/p/359672087>

原则说明：尽量先使用组合、聚合、关联关系来实现，其次才考虑使用继承关系来实现。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16486947931921648694792393.png)

### 2.1 UML类图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16487793690051648779368854.png)

Association：关联（irected Association：有方向的关联）:是一种拥有的关系，它使一个类知道另一个类的属性和方法；如：老师与学生，丈夫与妻子关联可以是双向的，也可以是单向的。双向的关联可以有两个箭头或者没有箭头，单向的关联有一个箭头。
Aggregation：聚合：成员变量+set，可分开
Composition：组合：在B类new 时就直接创建了，是不可分开的
Dependency：依赖：是一种使用的关系，即一个类的实现需要另一个类的协助，所以要尽量不使用双向的互相依赖.
Generalization：继承
Interface Realization：实现

1.  具体类在类图中用矩形框表示，矩形框分为三层：第一层是类名字。第二层是类的成员变量；第三层是类的方法（如果是抽象方法，方法的字为斜体）。成员变量以及方法前的访问修饰符用符号来表示：
    -   “+”表示 `public`；
    -   “-”表示 `private`；
    -   “#”表示 `protected`；
    -   不带符号表示 `default`。
        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16487758893461648775888904.png)
2.  在UML类图中表示包

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16487760643691648776064304.png)

### 3.1 设计模式的介绍

#### 3.1 介绍

1\)  设计模式是程序员在面对同类软件工程设计问题所总结出来的有用的经验，**模式不是代码**，**而是某类问题的通用解决方案**，设计模式（Design pattern)代表了最佳的实践。这些解决方案是众多软件开发人员经过相当长的一段时间的试验和错误总结出来的。

2\)  设计模式的本质提高软件的**维护性，通用性和扩展性，并降低软件的复杂度**。

#### 3.2 设计模式类型

设计模式分为三种类型，共23种

-   创建型模式：单例模式、抽象工厂模式、原型模式、建造者模式、工厂模式。
-   结构型模式：适配器模式、桥接模式、装饰模式、组合模式、外观模式、享元模式、代理模式。
-   行为型模式：模版方法模式、命令模式、访问者模式、迭代器模式、观察者模式、中介者模式、备忘录模式、
-   解释器模式（Interpreter模式）、状态模式、策略模式、职责链模式（责任链模式）。

### 4.1 23种设计模式

#### 4.1 单例模式

4.1.1 速览

单例模式分为饿汉式与懒汉式，饿汉式不会存在多线程问题，如果不确实一定会使用的话，会存在内存浪费问题；懒汉式，普通的实现方法会出现多线程问题，为了解决这个问题，如果单纯加入同步代码块，又可能会引效率问题，能解决多线程问题又不存在效率问题就有双重检查、静态内部类、枚举的方法

4.1.2 单例模式的说明

**什么是单例模式：** 所谓类的单例设计模式，就是采取一定的方法保证在整个的软件系统中，对某个类只能存在一个对象实例，并且该类只提供一个取得其对象实例的方法（静态方法）。

比如Hibernate的SessionFactory,它充当数据存储源的代理，并负责创建Session对象。SessionFactory并不是轻量级的，一般情况下，一个项目通常只需要一个SessionFactory就够，这是就会使用到单例模式。

**单例模式使用的场景**：需要频繁的进行创建和销毁的对象、创建对象时耗时过多或耗费资源过多（即：重量级对象）,但又经常用到的对象、工具类对象、频繁访问数据库或文件的对象（比如数据源、session工厂等）。

**单便模式在JDK源码中的使用：** java.lang.Runtime , 在这里使用的是饿汉式（静态常量）的方式实现的单例模式。

**有哪些示例：**

![](image/image_oWTuN994yl.png)

#### ——饿汉式

饿汉式，就是还没用时就创建，那什么时候用呢？当我们确定一定能用到这个实例时，就可以使用饿汉式。

饿汉式的实现方法有二种，但作用上没什么区别，第一，是通过`直接new`的方式，第二，是`通过静态代码块`的方式 。

饿汉式的优缺点：

优点：无多线程问题 &#x20;

缺点：浪费内存

-   代码：以下代码分别写了2种饿汉式实现的方式，并在main方法中进行了测试
    ```java
    package com.zjazn.dm._3_23种设计模式._1_单例设计模式._1_饿汉式;

    /**
     * 饿汉式，就是还没用时就创建，饿汉式的实现方法有二种，但作用上没什么区别，
     *      第一，是通过直接new的方式，第二，是通过静态代码块的方式
     *      优点：无多线程问题
     *      缺点：浪费内存
     */
    public class main {
        public static void main(String[] args) {
            //直接new的两个对象
            Singleton_type1 instance11 = Singleton_type1.getInstance();
            Singleton_type1 instance12 = Singleton_type1.getInstance();
            //通过静态代码块实现的两个对昂
            Singleton_type2 instance21 = Singleton_type2.getInstance();
            Singleton_type2 instance22 = Singleton_type2.getInstance();
            //分别判断是否相等
            System.out.println(instance11.hashCode()+"=="+instance12.hashCode());
            System.out.println(instance21.hashCode()+"=="+instance22.hashCode());
        }

    }
    //饿汉式，直接new实现
    class Singleton_type1 {
        //1.设置为私有，使不能new
        private Singleton_type1() {

        }
        //2.开始创建对象
        private final static Singleton_type1 instance = new Singleton_type1();

        //3。使能让外界获取该对象实例
        public static Singleton_type1 getInstance() {
            return instance;
        }
    }
    //饿汉式，通过”静态代码块“进行内部创建实现
    class Singleton_type2 {
        //1.设置为私有，使不能new
        private Singleton_type2() {

        }
        //2.开始创建对象
        private final static Singleton_type2 instance;
        static {
            instance = new Singleton_type2();
        }

        //3。使能让外界获取该对象实例
        public static Singleton_type2 getInstance() {
            return instance;
        }
    }


    ```

#### ——懒汉式

懒汉式，就是要用的时候才创建这个单一实例。

普通的写法，会存在多线程问题，使用"synchronized"解决多线程而引起的效率问题，如果我们想既不存在多线程问题，也没有效率问题，我们一般选择：`双重检查`、`静态内部类`、`枚举`的方法。

-   代码：以下代码分别写了5种懒汉式实现的方式，并在main方法中进行了测试
    ```java
    package com.zjazn.dm._3_23种设计模式._1_单例设计模式._2_懒汉式;

    public class main {
        public static void main(String[] args) {
            Singleton_Type3 instance31 = Singleton_Type3.getInstance();
            Singleton_Type3 instance32 = Singleton_Type3.getInstance();
            System.out.println(instance31==instance32);
            System.out.println(instance31.hashCode()+"=="+instance32.hashCode());


            Singleton_Type4 instance41 = Singleton_Type4.getInstance();
            Singleton_Type4 instance42 = Singleton_Type4.getInstance();
            System.out.println(instance41==instance42);
            System.out.println(instance41.hashCode()+"=="+instance42.hashCode());

            Singleton_Type5 instance51 = Singleton_Type5.getInstance();
            Singleton_Type5 instance52 = Singleton_Type5.getInstance();
            System.out.println(instance51==instance52);
            System.out.println(instance51.hashCode()+"=="+instance52.hashCode());

            Singleton_Type6 instance61 = Singleton_Type6.getInstance();
            Singleton_Type6 instance62 = Singleton_Type6.getInstance();
            System.out.println(instance61==instance62);
            System.out.println(instance61.hashCode()+"=="+instance62.hashCode());

            Singleton_Type7 instance71 = Singleton_Type7.INSTANCE;
            Singleton_Type7 instance72 = Singleton_Type7.INSTANCE;
            System.out.println(instance71==instance72);
            System.out.println(instance71.hashCode()+"=="+instance72.hashCode());

        }
    }
    //存在线程安全问题
    class Singleton_Type3 {
        //创建实例的成员变量
        private  static Singleton_Type3 instance;
        //让构造方法为私有，使不能用
        private Singleton_Type3() {}
        //向外提供一个获取实例的方法
        public static Singleton_Type3 getInstance() {
            if (instance == null) {
                instance = new Singleton_Type3();
            }
            return instance;
        }
    }
    //解决了上面的线程安全问题，但这种效率低
    class Singleton_Type4 {
        //创建实例的成员变量
        private static Singleton_Type4 instance;
        //让构造方法为私有，使不能用
        private Singleton_Type4() {}
        //向外提供一个获取实例的方法, 加了方法同步代码块 “synchronized”
        public static synchronized Singleton_Type4 getInstance() {
            if (instance == null) {
                instance = new Singleton_Type4();
                //也有人把像synchronized放在下面这样写，这是错误的，多余的，无法解决线程安全问题，在多线程下，会产生多个实例
                //            synchronized (Singleton_Type4.class) {
                //                instance = new Singleton_Type4();
                //            }
            }
            return instance;
        }
    }
    //解决了线程安全，效率低问题——“双重检查” Double Check
    class Singleton_Type5 {
        //创建一个成员变量
        //volatile 作用是在多线程操作下，第一，修改后，直接将线程的操作内存，放在所有线程的主操作内存上，会同步到所有线程内存——可见性。第二，禁止指令重排优化的规则，避免系统优化机制的干扰
        //详细的volatile作用：https://blog.csdn.net/qiushisoftware/article/details/102912395
        private static volatile Singleton_Type5 instance;
        //使构造方法私有，对外不可见
        private Singleton_Type5(){}
        //创建一个方法，使外界获取单一实例
        public static Singleton_Type5 getInstance() {
            //第一层检查虽然不能拦着后面的线程，但可以保证成员变量 instance 赋值后，不让线程执行synchronized 同步代码块，从而造成的效率低问题
            if (instance == null) {
                //同步代码块
                synchronized (Singleton_Type5.class) {
                    //让界于第一层if与synchronized 的初始线程，跳过，从而避免其它线程创建实例
                    if (instance == null) {
                        instance = new Singleton_Type5();
                    }
                }
            }
            return instance;
        }

    }

    //使用“静态内部类”的方法实现单一实例，且具线程安全，效率问题,同时也是具有懒加载的
    class Singleton_Type6 {
        private Singleton_Type6(){

        }
        //类的静态属性只会在第一次加载类的时候初始化，所以在这里，JVM帮助我们保证了线程的安全性，在类进行初始化时，别的线程是无法进入的。
        private static class SingletonInstance {
            public static final Singleton_Type6 INSTANCE = new Singleton_Type6();
        }
        public static Singleton_Type6 getInstance(){
            return SingletonInstance.INSTANCE;
        }
    }

    //使用“枚举”要实现,同样可以解决线程安全，且不存在效率问题，推荐使用
    //这借助JDK1.5中添加的枚举来实现单例模式。不仅能避免多线程同步问题，而且还能防止反序列化重新创建新的对象。
    enum Singleton_Type7 {
        INSTANCE;
    }



    ```

#### 4.2 工厂模式

4.2.1 速览

工厂模式分为简单工厂模式、工厂方法模式、抽象工厂模式。简单工厂模式核心是创建一个工厂，在工厂内写一个静态的create方法，接收要创建对象的关键信息，然后返回实例；工厂方法模式可以生产二层类型的产品，而抽象工厂模式可以生产三层及以上类型的产品。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16499082383081649908238170.png)

#### ——简单工厂模式

如果一个消费类A需要用到一个类B，如果B类改变了A类也要改变时，这时候就违反了OCP原则，我们可以创建一个工厂类。

简单式模式的核心是，创建一个工厂，在工厂内写一个静态的create 方法，接收产品的关键信息，返回该产品的实例。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16490513642441649051364159.png)

-   生产水果的工厂代码：

    抽象水果类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._1_简单工厂模式;

    /**
     * 1. 创建了一个抽象水果类
     */
    public abstract class Fruit {
        abstract void getName();
    }

    ```
    苹果类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._1_简单工厂模式;

    /**
     * 2、写了一个苹果类继承了水果类
     */
    public class Apple extends Fruit {
        @Override
        void getName() {
            System.out.println("Apple");
        }
    }


    ```
    梨类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._1_简单工厂模式;
    /**
     * 3、写了一个梨类继承了水果类
     */
    public class Pear extends Fruit{
        @Override
        void getName() {
            System.out.println("Pear");
        }
    }

    ```
    水果工厂类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._1_简单工厂模式;

    /**
     * 4、写了一个简单工厂类，对水果类进行生产
     */
    public class FruitFactory {
        //简单工厂模式也叫静态工厂模式
        public static Fruit createFruit(String type) {

            System.out.println("简单工厂模式正在创建实例~");
            if (type.equals("apple")) {
                return  new Apple();
            }else if (type.equals("pear")) {
                return new Pear();
            }
            return null;
        }
    }

    ```
    简单工厂测试类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._1_简单工厂模式;

    /**
     * 5、简单工厂模式测试入口
     */
    public class main {
        public static void main(String[] args) {
            Fruit pear = FruitFactory.createFruit("pear");
            pear.getName();

            Fruit apple = FruitFactory.createFruit("apple");
            apple.getName();

        }
    }

    ```

**工厂模式在JDK源码的使用**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16490448372501649044836425.png)

#### ——工厂方法模式

其实最大优点是创建一个新的对象，不用违反开闭原则,之前是创建哪个需要用if，那现在如何使用工厂方法模式创建示例呢，有两种实体即，要生产的对象与对应的工厂。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16559457802161655945779933.png)

-   Pizza类代码：

    Pizza抽象类
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza;
    //将Pizza类做成抽象
    public abstract class Pizza {
        //Pizza 名称
        public String name;
    }

    ```
    北京Pizza
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza;

    public class BJPepperPizza extends Pizza {
      public String name = "北京的胡椒pizza";
    }

    ```
    伦敦Pizza
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza;

    public class LDPepperPizza extends Pizza{
        public String name = "伦敦的胡椒pizza";
    }

    ```
-   **Pizza工厂类代码**：

    工厂抽象类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.order;

    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.Pizza;


    public abstract class OrderPizza {
        //定义一个抽象方法，createPizza,让各个工厂子类自己实现
        public abstract Pizza createPizza(String orderType);

    }

    ```
    北京工厂类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.order;


    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.BJPepperPizza;
    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.Pizza;

    public class BJOrderPizza extends OrderPizza {

      //北京Pizza工厂制作
      @Override
      public Pizza createPizza(String orderType) {
      
        Pizza pizza = null;
        if (orderType.equals("pepper")) {
          pizza = new BJPepperPizza();
        }
        return pizza;
      }

    }

    ```
    伦敦工厂类：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.order;


    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.LDPepperPizza;
    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.Pizza;

    public class LDOrderPizza extends OrderPizza {

      //伦敦Pizza工厂制作
      @Override
      public Pizza createPizza(String orderType) {
      
        Pizza pizza = null;
        if(orderType.equals("pepper")) {
          pizza = new LDPepperPizza();
        }
        return pizza;
      }

    }

    ```
-   测试类main方法代码：
    ```java
    package com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式;

    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.order.BJOrderPizza;
    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.order.LDOrderPizza;
    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.BJPepperPizza;
    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.LDPepperPizza;
    import com.zjazn.dm._3_23种设计模式._2_工厂模式._2_工厂方法模式.pizza.Pizza;

    import java.io.BufferedReader;
    import java.io.IOException;
    import java.io.InputStreamReader;

    public class main {
        public static void main(String[] args) throws IOException {
            LDOrderPizza factory = new LDOrderPizza();
            LDPepperPizza pizza = (LDPepperPizza) factory.createPizza("pepper");
            System.out.println(pizza.name +"真好吃~");

            BJOrderPizza factory2 = new BJOrderPizza();
            BJPepperPizza pizza2 = (BJPepperPizza) factory2.createPizza("pepper");
            System.out.println(pizza2.name +"真好吃~");


        }
    }

    ```

#### ——抽象工厂模式

工厂方法模式中的“抽象工厂”改为接口。

什么是 “系列对象”？ 例如有这样一组的对象：  `运输工具`+ `引擎`+ `控制器` 。 它可能会有几个变体：

1.  `汽车`+ `内燃机`+ `方向盘`
2.  `飞机`+ `喷气式发动机`+ `操纵杆`

再比如：

具体工厂（装饰风艺术、维多利亚、现代）通过方法，获取以下椅子、沙发、咖啡桌的实例。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16490507992391649050799085.png)

**如果你的程序中并不涉及产品系列的话， 那就不需要抽象工厂。**

再次重申， 许多人分不清\_抽象工厂\_模式和声明为 `abstract`的简单工厂。 不要犯这个错误！

#### 4.3 原型模式

4.3.1 速览

原型模式分为两种浅拷贝与深拷贝，浅拷贝我们可以通过实现Cloneable 重写clone方法实现对象的拷贝，但这是浅拷贝，就是引用类型的成员变量还是没有拷贝的，就是拷贝了引用类型的地址。而深拷贝就对引用类型的成员变量进行拷贝，实现方法有实现Cloneable或利用 序列化与反序列化的方法实现。

#### ——浅拷贝

特点：无法进行对象变量的拷贝，它们是共用的。

表现为：（这里说的羊的对象，这是左边着的一个成员对象变量）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492194508151649219450673.png)

-   代码

    Sheep："克隆羊"
    ```java
    package com.zjazn.dm._3_23种设计模式._3_原型链模式._1_浅拷贝;

    public class Sheep implements Cloneable {
        public String name;
        public int age;
        public String address = "蒙古羊";
        Sheep friend;

        public Sheep(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public Sheep getFriend() {
            return friend;
        }

        public void setFriend(Sheep friend) {
            this.friend = friend;
        }

        @Override
        public String toString() {
            return "Sheep{" +
                    "name='" + name + '\'' +
                    ", age=" + age +
                    ", address='" + address + '\'' +
                    ", friend=" + friend +
                    '}';
        }

        @Override
        protected Object clone() {
            Object clone = null;
            try {
                clone = super.clone();
            }catch (CloneNotSupportedException e) {
                System.out.println(e.getMessage());
            }
            return clone;
        }
    }

    ```
    测试代码：
    ```java
    package com.zjazn.dm._3_23种设计模式._3_原型链模式._1_浅拷贝;

    public class main {
        public static void main(String[] args) {
            Sheep sheep = new Sheep("tom", 1);
            sheep.friend = new Sheep("beautiful",2);

            Sheep sheep1 = (Sheep)sheep.clone();
            Sheep sheep2 = (Sheep)sheep.clone();
            Sheep sheep3 = (Sheep)sheep.clone();

            //可以看出克隆出来的羊，基本数据类型会进行值传递，如果是对象类型，它们的的hashCode是相同的。这也就是浅拷贝的特点。
            System.out.println("sheep1 = "+sheep1+", friend = "+sheep1.getFriend().hashCode());
            System.out.println("sheep2 = "+sheep2+", friend = "+sheep2.getFriend().hashCode());
            System.out.println("sheep3 = "+sheep3+", friend = "+sheep3.getFriend().hashCode());
        }
    }

    ```

可以看出克隆出来的羊，基本数据类型会进行值传递，如果是引用类型，它们的的hashCode是相同的。这也就是浅拷贝的特点。

#### ——深拷贝

特点：可以对引用类型进行深拷贝，克隆出来的成员的引用类型的hashCode是不相同的，即是不同的对象，这就是深拷贝。

表现为：（这里说的羊的对象，这是左边的一个成员对象变量）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492195718041649219571170.png)

实现方式：通过实现Cloneable重写clone方法、利用序列化与反序列化进行拷贝。

-   代码：(聚合了以上两种拷贝方式，是里面的两个方法)
    ```java
    package com.zjazn.dm._3_23种设计模式._3_原型链模式._2_深拷贝;

    import java.io.*;

    /**
     * 深拷贝有两种实现方案：
     *  重写Cloneable的clone，对对象的变量进行再拷贝（有明显缺点）
     *  利用序列化与反序列化的方法实现（推荐）
     */
    public class Sheep implements Cloneable, Serializable {
        public String name;
        public int age;
        public String address = "蒙古羊";
        Sheep friend;

        public Sheep(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public Sheep getFriend() {
            return friend;
        }

        public void setFriend(Sheep friend) {
            this.friend = friend;
        }

        @Override
        public String toString() {
            return "Sheep{" +
                    "name='" + name + '\'' +
                    ", age=" + age +
                    ", address='" + address + '\'' +
                    ", friend=" + friend +
                    '}';
        }

        //利用clone进行深拷贝，这有明显的缺点就是有越多的成员对象，拷贝就要写多少。或说只要成员变量新加了一个对象的，就需要改clone方法。
        @Override
        protected Object clone() {

            Sheep deep = null;
            try {
                deep = (Sheep) super.clone();
                if (deep.friend != null) { //拷贝的对象不能为null
                    deep.friend = (Sheep)friend.clone();
                }
            } catch (CloneNotSupportedException e) {
                System.out.println(e.getMessage());
            }
            return deep;

        }

        //深拷贝——利用序列化与反序列化的方式（推荐）
        public Object deepClone() {
            ByteArrayOutputStream bos = null;
            ObjectOutputStream oos = null;
            ByteArrayInputStream bis = null;
            ObjectInputStream ois = null;
            try {
                //序列化
                bos = new ByteArrayOutputStream();
                oos = new ObjectOutputStream(bos);
                oos.writeObject(this);
                //反序列化
                bis = new ByteArrayInputStream(bos.toByteArray());
                ois = new ObjectInputStream(bis);
                Object obj = ois.readObject();
                return obj;
            }catch (IOException | ClassNotFoundException e) {
                System.out.println(e.getMessage());
            }finally {
                //关闭流
                try {
                    bos.close();
                    oos.close();
                    bis.close();
                    ois.close();
                }catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
            return null;

        }
    }


    ```
    测试代码：
    ```java
    package com.zjazn.dm._3_23种设计模式._3_原型链模式._2_深拷贝;


    public class main {
        public static void main(String[] args) throws CloneNotSupportedException {
            Sheep sheep = new Sheep("tom", 1);
            sheep.friend = new Sheep("beautiful",2);

            Sheep sheep1 = (Sheep)sheep.deepClone();
            Sheep sheep2 = (Sheep)sheep.deepClone();
            Sheep sheep3 = (Sheep)sheep.deepClone();

            //可以看出克隆出来的羊，基本数据类型会进行值传递，如果是对象类型，它们的的hashCode是相同的。这也就是浅拷贝的特点。
            System.out.println("sheep1 = "+sheep1+", friend = "+sheep1.getFriend().hashCode());
            System.out.println("sheep2 = "+sheep2+", friend = "+sheep2.getFriend().hashCode());
            System.out.println("sheep3 = "+sheep3+", friend = "+sheep3.getFriend().hashCode());
        }
    }

    ```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492366940881649236693961.png)

**缺点：** 需要为每一个类配备一个克隆方法，这对全新的类来说不是很难，但对已有的类进行改造时，需要修改其源代码，违背了ocp原则，这点请同学们注意。

#### 4.4 建造者模式

4.4.1建造者模式

比如盖房子，传统实现方法，把产品（即：房子）和创建产品的过程（即：建房子流程）封装在一起，藕合性增强了。而建造者模式就是把产品与创建产品的过程分开了，建造者模式有四个角色，即产品、抽象建造者（一系列流程的抽象 ）、具体建造者（一系列流程的具体）、指挥者（将流程有序化）。

比如盖房子，传统实现方法，把产品（即：房子）和创建产品的过程（即：建房子流程）封装在一起，藕合性增强了。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492429089921649242908926.png)

**解决方案**：**将产品和产品建造过程解羁**=> 建造者模式.

**建造者模式的四个角色**

1）Product(产品角色）:一个具体的产品对象。
2）Builder(抽象建造者）:创建一个Product对象的各个部件指定的接口/抽象类。
3）ConcreteBuilder(具体建造者）:实现接口，构建和装配各个部件。
4）Director(指挥者）:构建一个使用Builder接口的对象。它主要是用于创建一个复杂的对象。它主要有两个作用，一是：隔离了客户与对象的生产过程，二是：负责控制产品对象的生产过程。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492424828441649242482753.png)

-   代码实现：

    House
    ```java
    package com.zjazn.dm._3_23种设计模式._4_建造者模式;
    //产品->Product
    public class House {
        private String baise;
        private String wall;
        private String roofed;

        public String getRoofed() {
            return roofed;
        }

        public void setRoofed(String roofed) {
            this.roofed = roofed;
        }

        public String getBaise() {
            return baise;
        }

        public void setBaise(String baise) {
            this.baise = baise;
        }

        public String getWall() {
            return wall;
        }

        public void setWall(String wall) {
            this.wall = wall;
        }
    }

    ```
    HouseBuilder
    ```java
    package com.zjazn.dm._3_23种设计模式._4_建造者模式;

    public abstract class HouseBuilder {
        protected House house = new House();

        //将建造的流程写好, 抽象的方法
        public abstract void buildBasic();
        public abstract void buildWalls();
        public abstract void roofed();

        //建行房子后，将产品（房子）返回
        public House buildHouse() {
            return house;
        }

    }

    ```
    HighBuilder
    ```java
    package com.zjazn.dm._3_23种设计模式._4_建造者模式;

    public class HighBuilding extends HouseBuilder {

        @Override
        public void buildBasic() {
            // TODO Auto-generated method stub
            System.out.println(" 高楼的打地基100米 ");
        }

        @Override
        public void buildWalls() {
            // TODO Auto-generated method stub
            System.out.println(" 高楼的砌墙20cm ");
        }

        @Override
        public void roofed() {
            // TODO Auto-generated method stub
            System.out.println(" 高楼的透明屋顶 ");
        }
    }

    ```
    CommonBuilder
    ```java
    package com.zjazn.dm._3_23种设计模式._4_建造者模式;

    public class CommonBuilder extends HouseBuilder{
        @Override
        public void buildBasic() {
            // TODO Auto-generated method stub
            System.out.println(" 普通房子打地基5米 ");
        }

        @Override
        public void buildWalls() {
            // TODO Auto-generated method stub
            System.out.println(" 普通房子砌墙10cm ");
        }

        @Override
        public void roofed() {
            // TODO Auto-generated method stub
            System.out.println(" 普通房子屋顶 ");
        }
    }

    ```
    HouseDirector
    ```java
    package com.zjazn.dm._3_23种设计模式._4_建造者模式;

    public class HouseDirector {
        HouseBuilder houseBuilder = null;
        //通过setter 传入 houseBuilder
        public HouseDirector(HouseBuilder houseBuilder) {
            this.houseBuilder = houseBuilder;
        }

        public void setHouseBuilder(HouseBuilder houseBuilder) {
            this.houseBuilder = houseBuilder;
        }

        //如何处理建造房子的流程，交给指挥者
        public House constructHouse() {
            houseBuilder.buildBasic();
            houseBuilder.buildWalls();
            houseBuilder.roofed();
            return houseBuilder.buildHouse();
        }

    }

    ```
    main 测试类：
    ```java
    package com.zjazn.dm._3_23种设计模式._4_建造者模式;

    public class main {
        public static void main(String[] args) {
            HouseDirector houseDirector = new HouseDirector(new CommonBuilder());
            House house1 = houseDirector.constructHouse();

            System.out.println("-----------------------");
            houseDirector.setHouseBuilder(new HighBuilding());
            House house2 = houseDirector.constructHouse();
        }
    }

    ```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492427647941649242764276.png)

#### 4.5 适配器模式

4.5.1速览

适配器模式就是将某个类的接口转换成客户端期望的另一个接口表示，使可以使用，使兼容。适配器模式有三种，即类适配器（实现的方法进行改造，但这违反了合成复合原则），对象适配器（使用聚合，组合，依赖的方式，推荐），接口适配器（使用实现的方式，抽象类全部实现，具体实现类继承抽象类，只实现要使用的方法）。

1）适配器模式（Adapter Pattern)将某个类的接口转换成客户端期望的另一个接口表示，主要的目的是兼容性，让原本因接口不匹配不能一起工作的两个类可以协同工作。其别名为包装器（Wrapper)
2）适配器模式属于结构型模式
3）主要分为三类：类适配器模式、对象适配器模式、接口适配器模式

假如你有现在存在一个类的接口方法，但是这个接口**不太符合**你的预期（方法签名对应不上），如果要用他就需要在他的源码上进行一些修改，显然这个不可行。

这时还有一种方案：你可以做一个适配器，在不修改原来这个接口源码的情况下，在适配器上对这个接口进行运用，使得**适配器符合你的接口规范**。

以下情况可以使用适配器模式

-   你想使用一个**已经存在的类**，而它的 接口不符合你的需求（但你又不能修改器源码）
-   你想创建一个可以复用的类，该类可以与其他不相关的类或不可预见的类（即那些接口可能不一定兼容的类）协同工作

#### ——类适配器

**适配器是以类的方式持有被适配(src) ，一般以继承的方式。这就是类适配器。**

说明：手机（Phone）肯定是不能直接连接插座充电的，那肯定会炸，我们需要用到一个适配器（充电器），将原本不适的220V转为手机充电可用的低功率5V。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492980528961649298052678.png)

[点击查看代码>>](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_5_%E9%80%82%E9%85%8D%E5%99%A8%E6%A8%A1%E5%BC%8F/_1_%E7%B1%BB%E9%80%82%E9%85%8D%E5%99%A8 "点击查看代码>>")

#### ——对象适配器

**适配器是以对象的方式持有被适配(src) ，一般以聚合、组合的方式。这就是对象适配器。**

由“类适配器”优化为了聚合的方式实现适配器——对象适配器

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16492985757291649298575598.png)

-   代码：对象适配器

    Voltage220V:
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._2_对象适配器;

    public class Voltage220V {
        //输出220V的电压
        public int output220V() {
            int src = 220;
            System.out.println("插座输出=" + src + "伏");
            return src;
        }
    }

    ```
    接口IVoltage5V：
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._2_对象适配器;
    //适配接口
    public interface IVoltage5V {
        public int output5V();
    }

    ```
    适配器VoltageAdapter:
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._2_对象适配器;

    public class VoltageAdapter implements IVoltage5V {
        private Voltage220V voltage220V;

        //由继承转为聚合的方式——对象适配器
        public void setVoltage220V(Voltage220V voltage220V) {
            this.voltage220V = voltage220V;
        }

        @Override
        public int output5V() {
            int srcV = voltage220V.output220V();
            int dstV = srcV / 44;
            System.out.println("被转换成为"+dstV+"V");
            return dstV;
        }
    }

    ```
    Phone:
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._2_对象适配器;

    public class Phone {
        public void charging(IVoltage5V iVoltage5V) {
            if (iVoltage5V.output5V() == 5) {
                System.out.println("电压正常，正在充电~");
            }else if(iVoltage5V.output5V() > 5) {
                System.out.println("电压异常，无法正常充电~");
            }
        }
    }

    ```
    测试类main (Client):
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._2_对象适配器;

    /**
     * 由继承转为聚合的方式——对象适配器
     */
    public class main {
        public static void main(String[] args) {
            //一个手机
            Phone phone = new Phone();
            //一个适配器（充电器）
            VoltageAdapter voltageAdapter = new VoltageAdapter();
            //适配器插上插座
            voltageAdapter.setVoltage220V(new Voltage220V());
            //适配器给手机充电
            phone.charging(voltageAdapter);
        }
    }

    ```

#### ——接口适配器

**适配器是以接口的方式持有被适配(src) ，一般以接口实现的方式。这就是接口适配器。**

1）一些书籍称为：适配器模式（Default Adapter Pattern)或缺省适配器模式。
2）核心思路：当不需要全部实现接口提供的方法时，可先设计一个抽象类实现接口，并为该接口中每个方法提供一个默认实现（空方法）,那么该抽象类的子类可有选择地覆盖父类的某些方法来实现需求
**3）适用于一个接口不想使用其所有的方法的情况。**

**说明**：一个接口——> 一个抽象类实现了这个接口，并全部重写了接口的方法（空方法）——>  在使用时，再进行重写需要的方法。

-   代码：

    接口Interface\_4：
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._3_接口适配器;

    public interface Interface_4 {
        public void m1();
        public void m2();
        public void m3();
        public void m4();
    }

    ```
    AbsAdapter ：抽象类实现了Interface\_4接口
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._3_接口适配器;

    public abstract class AbsAdapter implements Interface_4 {
        //默认实现
        @Override
        public void m1() {

        }

        @Override
        public void m2() {

        }

        @Override
        public void m3() {

        }

        @Override
        public void m4() {

        }
    }

    ```
    main：测试方法
    ```java
    package com.zjazn.dm._3_23种设计模式._5_适配器模式._3_接口适配器;

    public class main {
        public static void main(String[] args) {
            AbsAdapter absAdapter = new AbsAdapter() {
                @Override
                public void m1() {
                    System.out.println("使用了m1的方法");
                }
            };
            absAdapter.m1();

        }
    }

    ```

源码分析：SpringMvc中的HandlerAdapter,就使用了适配器模式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16493822592341649382259071.png)

假如你有现在存在一个类的接口方法，但是这个接口**不太符合**你的预期（方法签名对应不上），如果要用他就需要在他的源码上进行一些修改，显然这个不可行。

这时还有一种方案：你可以做一个适配器，在不修改原来这个接口源码的情况下，在适配器上对这个接口进行运用，使得**适配器符合你的接口规范**。

#### 4.6 桥接模式

4.6.1 速览

解决的是具有分支层次关系的，使用桥接模式后，就上由“垂直关系”变为“平行关系”。实现方法是每个层次都有一个接口，将低层次的聚合到高层次中。

**桥接模式解决的问题**：传统方法实现，**手机——手机类型——手机品牌**，可以知道，每当我们增强一种手机类型时，就要对应地添加若干的手机品牌，这违反了单一职责原则，出现了“类爆炸”，即出现了不必要的类。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16495552292551649555228481.png)

**使用桥接模式后：** 就上由“垂直关系”变为“平行关系”。明显可以知道，`手机品牌`与`手机类型` 是分开了，添加一个手机类型，对其它类，没有任何影响，添加一个手机品牌对其它类也没有任何影响。而具体怎么使用，是在Client上。

```java
 FoldedPhone phone1 = new FoldedPhone(new XiaoMiBrand());
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16494704052871649470405166.png)

-   代码实现：桥接模式实现的代码

    Brand: 手机品牌接口
    ```java
    package com.zjazn.dm._3_23种设计模式._6_桥接模式.phone;

    public interface Brand {
        void open();
        void close();
        void call();

    }

    ```
    VivoBrand: Vivo手机品牌
    ```java
    package com.zjazn.dm._3_23种设计模式._6_桥接模式.phone;

    public class VivoBrand implements Brand {
        @Override
        public void open() {
            System.out.println("Vivo手机开机了");
        }

        @Override
        public void close() {
            System.out.println("Vivo手机关机了");
        }

        @Override
        public void call() {
            System.out.println("Vivo手机打电话了");
        }
    }

    ```
    XiaoMiBrand：小米手机品牌
    ```java
    package com.zjazn.dm._3_23种设计模式._6_桥接模式.phone;

    public class XiaoMiBrand implements Brand {
        @Override
        public void open() {
            System.out.println("小米手机开机了");
        }

        @Override
        public void close() {
            System.out.println("小米手机关机了");
        }

        @Override
        public void call() {
            System.out.println("小米手机打电话了");
        }
    }

    ```
    Phone: 手机类型接口类
    ```java
    package com.zjazn.dm._3_23种设计模式._6_桥接模式.type;

    import com.zjazn.dm._3_23种设计模式._6_桥接模式.phone.Brand;

    public abstract class Phone {
        private Brand brand;
        public Phone(Brand brand) {
            this.brand = brand;
        }
        public void open() {
            this.brand.open();
        }
        public void close() {
            this.brand.close();
        }
        public void call() {
            this.brand.call();
        }

    }

    ```
    FoldedPhone ：折叠手机
    ```java
    package com.zjazn.dm._3_23种设计模式._6_桥接模式.type;

    import com.zjazn.dm._3_23种设计模式._6_桥接模式.phone.Brand;

    public class FoldedPhone extends Phone {
        public FoldedPhone(Brand brand) {
            super(brand);
        }

        @Override
        public void open() {
            System.out.print("折叠手机——");
            super.open();

        }

        @Override
        public void close() {
            System.out.print("折叠手机——");
            super.close();
        }

        @Override
        public void call() {
            System.out.print("折叠手机——");
            super.call();
        }
    }

    ```
    UpRightPhone: 直立手机
    ```java
    package com.zjazn.dm._3_23种设计模式._6_桥接模式.type;

    import com.zjazn.dm._3_23种设计模式._6_桥接模式.phone.Brand;

    public class UpRightPhone extends Phone {
        public UpRightPhone(Brand brand) {
            super(brand);
        }

        @Override
        public void open() {
            System.out.print("直立手机——");
            super.open();
        }

        @Override
        public void close() {
            System.out.print("直立手机——");
            super.close();
        }

        @Override
        public void call() {
            System.out.print("直立手机——");
            super.call();
        }
    }

    ```
    main: 也就是Client, 即测试类
    ```java
    package com.zjazn.dm._3_23种设计模式._6_桥接模式;

    import com.zjazn.dm._3_23种设计模式._6_桥接模式.phone.VivoBrand;
    import com.zjazn.dm._3_23种设计模式._6_桥接模式.phone.XiaoMiBrand;
    import com.zjazn.dm._3_23种设计模式._6_桥接模式.type.FoldedPhone;
    import com.zjazn.dm._3_23种设计模式._6_桥接模式.type.UpRightPhone;

    public class main {
        public static void main(String[] args) {
            FoldedPhone phone1 = new FoldedPhone(new XiaoMiBrand());
            phone1.open();
            phone1.call();
            phone1.close();
            System.out.println("=================");
            UpRightPhone phone2 = new UpRightPhone(new VivoBrand());
            phone2.open();
            phone2.call();
            phone2.close();

        }
    }

    ```

**桥接模式在JDBC源代码中的使用：**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16494714837421649471483606.png)

**桥接模式通常适用于以下场景：**

1.  当一个类存在两个独立变化的维度，且这两个维度都需要进行扩展时。
2.  当一个系统不希望使用继承或因为多层次继承导致系统类的个数急剧增加时。
3.  当一个系统需要在构件的抽象化角色和具体化角色之间增加更多的灵活性时。

**常见的应用场景：**

-   JDBC驱动程序
-   银行转账系统
-   转账分类：网上转账，柜台转账，AMT转账
    转账用户类型：普通用户，银卡用户，金卡用户..
-   消息管理
    消息类型：即时消息，延时消息
    消息分类：手机短信，邮件消息，QQ消息...

#### 4.7 装饰者模式

4.7.1速览

核心是系统中“产品”都实现或间接实现同一个接口。

**问题的引出：** 星巴克咖啡订单项目（咖啡馆）
1）咖啡种类/单品咖啡：Espresso(意大利浓咖啡）、ShortBlack、LongBlack(美式咖啡）、Decaf(无因咖县。
2）调料：Milk、Soy(豆浆）、Chocolate
3）要求在扩展新的咖啡种类时，具有良好的扩展性、改动方便、维护方便
4）使用OO的来计算不同种类咖啡的费用：客户可以点单品咖啡，也可以单品咖啡+调料组合。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16495922460521649592245727.png)

**存在的问题：** 这样设计，会有很多类，当我们增加一个单品咖啡，或者一个新的调料，类的数量就会倍增，就会出现类爆炸。

**装饰者模式**

-   装饰者模式解决星巴克咖啡订单

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16495925370511649592536870.png)

-   装饰者模式下的订单：2份巧克力+一份牛奶的LongBlack

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16495935533481649593553248.png)

-   代码实现：星巴克咖啡订单

    全饮品抽象类：Drink&#x20;
    ```java
    package com.zjazn.dm._3_23种设计模式._7_装饰者模式;

    /**
     * 全饮品抽象类
     */
    public abstract class Drink {
        public String desc;
        public float price = 0.0f;

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public float getPrice() {
            return price;
        }

        public void setPrice(float price) {
            this.price = price;
        }
        //计算费用的抽象方法
        //子类来实现
        public abstract float cost();


    }

    ```
    单品抽象类：Coffee&#x20;
    ```java
    package com.zjazn.dm._3_23种设计模式._7_装饰者模式;

    /**
     * 饮品抽象类（单品）
     */
    public abstract class Coffee extends Drink{

        @Override
        public float cost() {
            return super.getPrice();
        }

    }

    ```
    单品: Decaf&#x20;
    ```java
    package com.zjazn.dm._3_23种设计模式._7_装饰者模式._1_单品饮品;

    import com.zjazn.dm._3_23种设计模式._7_装饰者模式.Coffee;

    public class Decaf extends Coffee {
        public Decaf() {
            setPrice(5.0f);
            setDesc("Decaf（单品）-"+getPrice());
        }
    }

    ```
    单品：ShortBlack&#x20;
    ```java
    package com.zjazn.dm._3_23种设计模式._7_装饰者模式._1_单品饮品;

    import com.zjazn.dm._3_23种设计模式._7_装饰者模式.Coffee;
    //单品 ShortBlack
    public class ShortBlack extends Coffee {
        public ShortBlack() {
            setPrice(5.0f);
            setDesc("ShortBlack（单品）-"+getPrice());
        }


    }

    ```
    辅助食品抽象类：Decorator&#x20;
    ```java
    package com.zjazn.dm._3_23种设计模式._7_装饰者模式;

    /**
     * 辅助品抽象类
     */
    public abstract class Decorator extends Drink{
        private Drink obj;
        public Decorator(Drink obj) {
            this.obj = obj;
        }

        @Override
        public String getDesc() {
            //之前的描述+当前饮品的描述
            return  obj.getDesc()+" && "+this.desc;
        }

        @Override
        public float cost() {
            //之前的总费用 + 当前饮品的费用
            return obj.cost() + this.price;
        }
    }

    ```
    Chocolate : 辅助品巧克力
    ```java
    package com.zjazn.dm._3_23种设计模式._7_装饰者模式._2_辅助品;

    import com.zjazn.dm._3_23种设计模式._7_装饰者模式.Decorator;
    import com.zjazn.dm._3_23种设计模式._7_装饰者模式.Drink;

    //辅助品——巧克力
    public class Chocolate extends Decorator {
        public Chocolate(Drink drink) {
            super(drink);
            setPrice(2.0f);
            setDesc("巧克力-"+this.getPrice());

        }
    }

    ```
    Milk : 辅助品牛奶
    ```java
    package com.zjazn.dm._3_23种设计模式._7_装饰者模式._2_辅助品;

    import com.zjazn.dm._3_23种设计模式._7_装饰者模式.Decorator;
    import com.zjazn.dm._3_23种设计模式._7_装饰者模式.Drink;

    public class Milk extends Decorator {
        public Milk(Drink obj) {
            super(obj);
            setPrice(3.0f);
            setDesc("牛奶-"+getPrice());
        }
    }

    ```

**装饰者模式在JDK源码中的使用**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16496405432471649640542455.png)

```java
package com.zjazn.dm;


import java.io.DataInputStream;
import java.io.FileInputStream;

public class main {


    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        //说明
        //1. InputStream 是抽象类, 类似我们前面讲的 Drink
        //2. FileInputStream 是  InputStream 子类，类似我们前面的 DeCaf, LongBlack
        //3. FilterInputStream  是  InputStream 子类：类似我们前面 的 Decorator 修饰者
        //4. DataInputStream 是 FilterInputStream 子类，具体的修饰者，类似前面的 Milk, Soy 等
        //5. FilterInputStream 类 有  protected volatile InputStream in; 即含被装饰者
        //6. 分析得出在 jdk 的 io 体系中，就是使用装饰者模式
        
        DataInputStream dis = new DataInputStream(new FileInputStream("d:\\abc.txt"));
        System.out.println(dis.read());
        dis.close();
    }


}


```

#### 4.8 组合模式

4.8.1 速览

**速览：** 需要遍历组织机构，或者处理的对象具有树形结构时, 非常适合使用组合模式。如果要求较高的抽象性，如果节点和叶子有很多差异性的话，比如很多方法和属性都不一样，不适合使用组合模式。组合模式表现为“整体-部分”的关系。以下以“学校院系”的例子来说明了组合模式，并且在JDK源码 HashMap使用了组合模式。（）

4.8.2 组合模式的概述

1）基本介绍

1\) 组合模式（Composite Pattern），又叫部分整体模式，它创建了对象组的树形结构，将对象组合成树状结构以表示“**整体-部分**”的层次关系。

2\) 组合模式依据树形结构来组合对象，用来表示部分以及整体层次。

3\) 这种类型的设计模式属于结构型模式。

4\) 组合模式使得用户对单个对象和组合对象的访问具有一致性，即：组合能让客户以一致的方式处理个别对象以及组合对象

2）组合模式原理图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16496516242661649651623870.png)

4.8.3 使用组合模式实现“学校院系展示”

编写程序展示一个学校院系结构：需求是这样，要在一个页面中展示出学校的院系组成，一个学校有多个学院， 一个学院有多个系(专业)。

1）传统实现方式，存在的问题分析

传统方案解决学校院系展示(类图)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16496512226711649651222539.png)

将学院看做是学校的子类，系是学院的子类，这样实际上是站在组织大小来进行分层次的

2）传统方案解决学校院系展示存在的问题分析

其实我们的要求是：在一个页面中展示出学校的院系组成，一个学校有多个学院，一个学院有多个系，因此这种方案，不能很好实现的管理的操作，比如对学院、系的添加，删除，遍历等

把学校、院、系都看做是组织结构，他们之间没有继承的关系，而是一个树形结构，可以更好的实现管理操作。=> 组合模式

学校-学院-专业（系）使用组合模式实现的原理图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16496516711891649651671095.png)

解析说明 **：** Department、College、University都是OrganizationComponent的子类，且University与College都组合了一个OrganizationComponent，从逻辑上来说，University组合的是College，College组合的是Department。而Department是一个“叶子节点”，与College、University代码是比较不同的，表现了 Department < College。因为Department 是“叶子节点”，所以一些方法或一些属性是不用写的。

3）组合模式的注意事项和细节

1.  简化客户端操作。客户端只需要面对一致的对象而不用考虑整体部分或者节点叶子的问题。
2.  具有较强的扩展性。当我们要更改组合对象时，我们只需要调整内部的层次关系，客户端不用做出任何改动.
3.  方便创建出复杂的层次结构。客户端不用理会组合里面的组成细节，容易添加节点或者叶子从而创建出复杂的树形结构
4.  需要遍历组织机构，或者处理的对象具有树形结构时, 非常适合使用组合模式.
5.  要求较高的抽象性，如果节点和叶子有很多差异性的话，比如很多方法和属性都不一样，不适合使用组合模式

代码实现：[点击查看>>](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_8_%E7%BB%84%E5%90%88%E6%A8%A1%E5%BC%8F "点击查看>>")

4.8.4组合模式在JDK源码 中的使用

在HashMap中的源码分析

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16499012029961649901202294.png)

类图：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16499012302461649901230042.png)

#### 4.9外观模式

4.9.1速览

调用往往需要调用子系统的很多方法才能实现功能， 那么我们把实现这个泛化的功能作为一个高层接口的一个接口最终形成一个高层接口，那这就是外观类（Facade）。

如果子系统如果已经变得非常难于维护与扩展，此时可以考虑为新系统开发一个Facade 类，来提供遗留系统的比较清晰简单的接口，让新系统与 Facade 类交互，提高复用性。

4.9.2介绍

> 外观模式可以理解为转换一群接口，客户只要调用一个接口，而不用调用多个接口才能达到目的。比如：在pc 上安装软件的时候经常有一键安装选项（省去选择安装目录、安装的组件等等），还有就是手机的重启功能（把关机和启动合为一个操作）。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16500803839981650080383720.png)

1）外观模式（Facade），也叫“过程模式：外观模式为子系统中的一组接口提供一个一致的界面，此模式定义了一个高层接口，这个接口使得这一子系统更加容易使用

2）外观模式通过定义一个一致的接口，用以屏蔽内部子系统的细节，使得调用端只需跟这个接口发生调用，而无需关心这个子系统的内部细节

3）在维护一个遗留的大型系统时，可能这个系统已经变得非常难以维护和扩展，此时可以考虑为新系统开发一个Facade 类，来提供遗留系统的比较清晰简单的接口，让新系统与 Facade 类交互，提高复用性。

4.9.3影视管理示例说明

组建一个家庭影院：

DVD 播放器、投影仪、自动屏幕、环绕立体声、爆米花机,要求完成使用家庭影院的功能，其过程为：&#x20;

直接用遥控器：统筹各设备开关

开爆米花机放下屏幕 开投影仪 开音响

开 DVD，选 dvd

去拿爆米花调暗灯光 播放

观影结束后，关闭各种设备

1.  传统的方法实现：

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16500807699231650080769740.png)

    存在的问题分析:

    1\) 在 ClientTest 的 main 方法中，创建各个子系统的对象，并直接去调用子系统(对象)相关方法，会造成调用过程混乱，没有清晰的过程

    2\) 不利于在 ClientTest 中，去维护对子系统的操作
2.  使用外观模式实现

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16500809634101650080963330.png)

    思路：

    1）定义一个高层接口，给子系统中的一组接口提供一个一致的界面(比如在高层接口提供四个方法

    ready, play, pause,end )，用来访问子系统中的一群接口

    2）也就是说 就是通过定义一个一致的接口(界面类)，用以屏蔽内部子系统的细节，使得调用端只需跟这个接口发生调用，而无需关心这个子系统的内部细节 => 外观模式

    [代码实现>>](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_9_%E5%A4%96%E8%A7%82%E6%A8%A1%E5%BC%8F "代码实现>>")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16500809634101650080963330.png)

4.9.4 MyBase源代码使用了外观模式

**1)** **MyBatis** 中的 Configuration 去创建 **MetaObject** 对象使用到外观模式

**2)** 代码分析+Debug 源码+示意图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16502466924661650246692179.png)

**3)** 对源码中使用到的外观模式的角色类图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16502467859761650246785872.png)

#### 5.0 享元模式

5.0速览

享元角色内部状态作为type是享元工厂的池（HashMap）的key，，享元模式用于解决系统的性能问题。像数据库连接池，里面都是创建好的连接对象，在这些连接对象中有我们需要的则直接拿来用，避免重新创建，如果没有我们需要的，则创建一个。享元模式增加了系统的复杂性，耦合性，使用享元模式需要区别内部状态与外部状态。

5.0.1享元模式的介绍

1\) 享元模式（Flyweight Pattern） 也叫 蝇量模式: 运用共享技术有效地支持大量细粒度的对象

2\) 常用于系统底层开发，解决系统的性能问题。像数据库连接池，里面都是创建好的连接对象，在这些连接对象中有我们需要的则直接拿来用，避免重新创建，如果没有我们需要的，则创建一个

3\) 享元模式能够解决重复对象的内存浪费的问题，当系统中有大量相似对象，需要缓冲池时。不需总是创建新对象，可以从缓冲池里拿。这样可以降低系统内存，同时提高效率

4\) 享元模式经典的应用场景就是池技术了，String 常量池、数据库连接池、缓冲池等等都是享元模式的应用，享元模式是池技术的重要实现方式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16502559388841650255938782.png)

5）享元模式原理类图

![](image/image__nZkAioJvE.png)

对原理图的说明-即(模式的角色及职责)

-   FlyWeight 是抽象的享元角色, 他是产品的抽象类, 同时定义出对象的外部状态和内部状态(后面介绍) 的接口或实现
-   ConcreteFlyWeight 是具体的享元角色，是具体的产品类，实现抽象角色定义相关业务
-   UnSharedConcreteFlyWeight 是不可共享的角色，一般不会出现在享元工厂。
-   FlyWeightFactory 享元工厂类，用于构建一个池容器(集合)， 同时提供从池中获取对象方法

内部状态和外部状态

比如围棋、五子棋、跳棋，它们都有大量的棋子对象，围棋和五子棋只有黑白两色，跳棋颜色多一点，所以棋子颜色就是棋子的内部状态；而各个棋子之间的差别就是位置的不同，当我们落子后，落子颜色是定的，但位置是变化的，所以棋子坐标就是棋子的外部状态

1.  享元模式提出了两个要求：细粒度和共享对象。这里就涉及到内部状态和外部状态了，即将对象的信息分为两个部分：内部状态和外部状态
2.  **内部状态指对象共享出来的信息，存储在享元对象内部且不会随环境的改变而改变。**
3.  **外部状态指对象得以依赖的一个标记，是随环境改变而改变的、不可共享的状态。**
4.  举个例子：围棋理论上有 361 个空位可以放棋子，每盘棋都有可能有两三百个棋子对象产生，因为内存空间有限，一台服务器很难支持更多的玩家玩围棋游戏，如果用享元模式来处理棋子，那么棋子对象就可以减少到只有两个实例，这样就很好的解决了对象的开销问题

5.02享元模式示例

小型的外包项目，给客户 A 做一个产品展示网站，客户 A 的朋友感觉效果不错，也希望做这样的产品展示网站，但是要求都有些不同：

1\) 有客户要求以新闻的形式发布

2\) 有客户人要求以博客的形式发布

3\) 有客户希望以微信公众号的形式发布

传统实现：

1\) 直接复制粘贴一份，然后根据客户不同要求，进行定制修改

2\) 给每个网站租用一个空间

方案设计示意图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16502795454391650279532329.png)

使用享元模式：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16502793710411650279370944.png)

[代码实现>>](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_10_%E4%BA%AB%E5%85%83%E6%A8%A1%E5%BC%8F "代码实现>>")

5.0.3 JDK源码中的享元模式

&#x20;Integer.valueOf(num); 也用到的享元模式，有效范围在-128\~127内。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16502561127061650256112635.png)

比如围棋、五子棋、跳棋，它们都有大量的棋子对象，围棋和五子棋只有黑白两色，跳棋颜色多一点，所以棋子颜色就是棋子的内部状态；而各个棋子之间的差别就是位置的不同，当我们落子后，落子颜色是定的，但位置是变化的，所以棋子坐标就是棋子的外部状态

享元模式提出了两个要求：细粒度和共享对象。这里就涉及到内部状态和外部状态了，即将对象的信息分为两个部分：内部状态和外部状态
内部状态指对象共享出来的信息，存储在享元对象内部且不会随环境的改变而改变
外部状态指对象得以依赖的一个标记，是随环境改变而改变的、不可共享的状态。
举个例子：围棋理论上有 361 个空位可以放棋子，每盘棋都有可能有两三百个棋子对象产生，因为内存空间有限，一台服务器很难支持更多的玩家玩围棋游戏，如果用享元模式来处理棋子，那么棋子对象就可以减少到只有两个实例，这样就很好的解决了对象的开销问题

更多链接：[https://www.cnblogs.com/blknemo/p/13258409.html](https://www.cnblogs.com/blknemo/p/13258409.html "https://www.cnblogs.com/blknemo/p/13258409.html")

#### 5.1代理模式

5.1.0速览

代理模式有静态代理、动态代理、cglib代理, 静态代理就是实现或继承与代理一样的类，然后聚合被代理类，用于代理类调用，静态代理优点是不修改被代理类的代码，缺点是当被代理类修改时，代理类也要改。动态代理与cglib代理，动态代理不用实现接口，是指定生成代理类的，cglib代理属于动态代理的范畴，当要代理的对象只是一个单独的对象，没有实现任何接口时使用cglib。&#x20;

[示例代码>>](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_11_%E4%BB%A3%E7%90%86%E6%A8%A1%E5%BC%8F "示例代码>>")

#### ——静态代理

静态代理就是实现或继承与代理一样的类，然后聚合被代理类，用于代理类调用，静态代理优点是不修改被代理类的代码，缺点是当被代理类修改时，代理类也要改。

代码说明：这是[代码](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_11_%E4%BB%A3%E7%90%86%E6%A8%A1%E5%BC%8F/_1_%E9%9D%99%E6%80%81%E4%BB%A3%E7%90%86 "代码") , TeacherDao是教师类，TeacherDao实现了 ITeacherDao，TeacherDaoProxy类实现了ITeacherDao接口，聚合了ITeacherDao接口，重写了这些方法，方法内调用所聚合对象的对应方法。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513024395831651302439483.png)

#### ——动态代理

动态代理也叫JDK代理/接口代理, 通过使用Proxy.newProxyInstance(...) 的方法创建一个代理类，我们可以使用这个代理对象调用方法。这是[代码](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_11_%E4%BB%A3%E7%90%86%E6%A8%A1%E5%BC%8F/_2_%E5%8A%A8%E6%80%81%E4%BB%A3%E7%90%86 "代码") TeacherDao是教师类，TeacherDao实现了 ITeacherDao接口，而ProxyFactory类更像是一个工具类，它能创建一个指定的类的代理类对象。这样我们就可以将返回的代理类对象调用方法了。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513024149861651302414893.png)

#### ——cglib代理

cglib代理属于动态代理的范畴，当要代理的类是没有实现接口时使用，这是[代码](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_11_%E4%BB%A3%E7%90%86%E6%A8%A1%E5%BC%8F/_3_cglib%E4%BB%A3%E7%90%86 "代码") , TeacherDao是一个教师类，ProxyFactory是一个cglib实现代理类的类。用法跟动态代理一样。（注意使用cglib，需要导入jar包，在代码中已存在）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513023855181651302384797.png)

-   Cglib 代理也叫作子类代理,它是在内存中构建一个子类对象从而实现对目标对象功能扩展, 有些书也将Cglib 代理归属到动态代理。
-   Cglib 是一个强大的高性能的代码生成包,它可以在运行期扩展 java 类与实现 java 接口.它广泛的被许多 AOP 的框架使用,例如 Spring AOP，实现方法拦截
-   在 AOP 编程中如何选择代理模式：&#x20;
    1.  目标对象需要实现接口，用 JDK 代理
    2.  目标对象不需要实现接口，用 Cglib 代理
-   Cglib 包的底层是通过使用字节码处理框架ASM来转换字节码并生成新的类

5.1.3几种常见的代理模式介绍— 几种变体

-   防火墙代理

内网通过代理穿透防火墙，实现对公网的访问。

-   缓存代理

比如：当请求图片文件等资源时，先到缓存代理取，如果取到资源则ok,如果取不到资源，再到公网或者数据库取，然后缓存。

-   远程代理

远程对象的本地代表，通过它可以把远程对象当本地对象来调用。远程代理通过网络和真正的远程对象沟通信息。

-   同步代理

主要使用在多线程编程中，完成多线程间同步工作同步代理：主要使用在多线程编程中，完成多线程间同步工作

#### 5.2模板模式

5.3.1速览

当若干程序其执行过程基本相同，只是有些步骤在可能有点不同时，我们要使用模板模式，模板模式有个控制执行过程的方法，这个方法一般是final，因为不想让子类修改。模板方法是抽象方法。

钩子方法，当在模板方法中某一些步骤是可选的时候，也就是该步骤不一定要执行，可以由子类来决定是否要执行，则此时就需要用上钩子。钩子是一种被声明在抽象类中的方法，但一般来说它只是空的或者具有默认值，子类可以实现覆盖该钩子，来设置算法步骤的某一步骤是否要执行。钩子可以让子类实现算法中可选的部分，让子类能够有机会对模板方法中某些一即将发生的步骤做出反应。

`钩子方法实现方式`

-   方式一
    最简单的钩子方法就是空方法，代码如下：
    ```java
    public virtual void Display() { };

    ```
    当然也可以在钩子方法中定义一个默认的实现，如果子类不覆盖钩子方法，则执行父类的默认实现代码。
-   方式二
    另一种钩子方法可以实现对其他方法进行约束，这种钩子方法通常返回一个 bool 类型，即返回 true 或 false，用来判断是否执行某一个基本方法，下面通过一个实例来说明这种钩子方法的使用。

5.3.2没有钩子的模板方法

这是[代码](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_12_%E6%A8%A1%E6%9D%BF%E6%A8%A1%E5%BC%8F "代码") , SoyaMilk是一个抽象方法，PeanutSoyaMilk、RedBeanSoyaMilk是其实现类。在main类上直接new 一个SoyaMilk的子类，然后调用make方法。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513145506191651314550518.png)

5.3.3有钩子的模板方法

这是[代码](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_12_%E6%A8%A1%E6%9D%BF%E6%A8%A1%E5%BC%8F/improve "代码") , SoyaMilk是一个抽象方法，里面定义了模板方法、钩子方法。PeanutSoyaMilk、RedBeanSoyaMilk、PureSoyaMilk是其实现类。使用了钩子方法实现形成的第二种，通过一个方法（customerWantCondiments）返回boolean来决定某个模板方法（addCondiments）是否启用。在main类上直接new 一个SoyaMilk的子类，然后调用make方法。

5.3.4 Spring IOC 容器初始化时运用到的模板方法模式

代码分析+角色分析+说明类图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513146522091651314652058.png)

1\) 针对源码的类图(说明层次关系)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513146719001651314671788.png)

#### 5.3命令模式

5.3.0速览

命名模式使得请求发送者与请求接收者消除彼此之间的耦合，命令模式有三个角色命令、命令发布者（遥控器）、命令执行者（空调），每个命令都是一个类，类中聚合了命令执行者。命令中有“空命令”的概念，它也就一种设计模式，省去了判空的操作，就像引用类型的null一样，作用是在未初始时，给于一个空操作。

`todo`

5.3.1命令模式基本介绍

1.  命令模式（Command Pattern）：在软件设计中，我们经常需要向某些对象发送请求，但是并不知道请求的接收者是谁，也不知道被请求的操作是哪个，我们只需在程序运行时指定具体的请求接收者即可，此时，可以使用命令模式来进行设计
2.  命名模式使得请求发送者与请求接收者消除彼此之间的耦合，让对象之间的调用关系更加灵活，实现解耦。
3.  在命名模式中，会将一个请求封装为一个对象，以便使用不同参数来表示不同的请求(即命名)，同时命令模式也支持可撤销的操作。
4.  通俗易懂的理解：将军发布命令，士兵去执行。其中有几个角色：将军（命令发布者）、士兵（命令的具体执行者）、命令(连接将军和士兵)。Invoker 是调用者（将军），Receiver 是被调用者（士兵），MyCommand 是命令，实现了 Command 接口，持有接收对象。

命令模式的原理类图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513835637511651383563629.png)

Ø对原理类图的说明-即(命名模式的角色及职责)

1\) Invoker 是调用者角色

2\) Command: 是命令角色，需要执行的所有命令都在这里，可以是接口或抽象类

3\) Receiver: 接受者角色，知道如何实施和执行一个请求相关的操作

4\) ConcreteCommand: 将一个接受者对象与一个动作绑定，调用接受者相应的操作，实现 execute

5.3.2示例：智能生活项目

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513821969321651382196715.png)

1\) 我们买了一套智能家电，有照明灯、风扇、冰箱、洗衣机，我们只要在手机上安装 app 就可以控制对这些家电工作。

2\) 这些智能家电来自不同的厂家，我们不想针对每一种家电都安装一个App，分别控制，我们希望只要一个 app

就可以控制全部智能家电。

3\) 要实现一个 app 控制所有智能家电的需要，则每个智能家电厂家都要提供一个统一的接口给 app 调用，这时 就可以考虑使用命令模式。

4\) 命令模式可将“动作的请求者”从“动作的执行者”对象中解耦出来.

5\) 在我们的例子中，动作的请求者是手机 app，动作的执行者是每个厂商的一个家电产品

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513839814641651383981363.png)

[代码示例>>](https://github.com/18476305640/DesignMode/tree/master/src/com/zjazn/dm/_3_23%E7%A7%8D%E8%AE%BE%E8%AE%A1%E6%A8%A1%E5%BC%8F/_13_%E5%91%BD%E4%BB%A4%E6%A8%A1%E5%BC%8F "代码示例>>")

#### 5.4 访问者模式

#### 5.5 迭代器模式

#### 5.6 观察者模式

#### 5.7 中介模式

#### 5.7 备忘录模式

#### 5.8解析器模式

#### 5.9 状态模式

#### 6.0 策略模式

#### 6.1 职责链模式
