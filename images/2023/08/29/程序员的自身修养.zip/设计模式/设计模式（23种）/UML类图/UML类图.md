# UML类图

### \[\_2\_] UML类图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16487793690051648779368854.png)

Association：关联（irected Association：有方向的关联）:是一种拥有的关系，它使一个类知道另一个类的属性和方法；如：老师与学生，丈夫与妻子关联可以是双向的，也可以是单向的。双向的关联可以有两个箭头或者没有箭头，单向的关联有一个箭头。 Aggregation：聚合：成员变量+set，可分开 Composition：组合：在B类new 时就直接创建了，是不可分开的 Dependency：依赖：是一种使用的关系，即一个类的实现需要另一个类的协助，所以要尽量不使用双向的互相依赖. Generalization：继承 Interface Realization：实现

1.  具体类在类图中用矩形框表示，矩形框分为三层：第一层是类名字。第二层是类的成员变量；第三层是类的方法（如果是抽象方法，方法的字为斜体）。成员变量以及方法前的访问修饰符用符号来表示：
    -   “+”表示 `public`；
    -   “-”表示 `private`；
    -   “#”表示 `protected`；
    -   不带符号表示 `default`。
        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16487758893461648775888904.png)
2.  在UML类图中表示包

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16487760643691648776064304.png)
