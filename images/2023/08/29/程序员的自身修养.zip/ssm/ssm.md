# ssm

[Spring](Spring/Spring.md "Spring")

[SpringMVC](SpringMVC/SpringMVC.md "SpringMVC")

[Mybatis](Mybatis/Mybatis.md "Mybatis")

SSM整合，整体结构

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16519199184271651919918276.png)

文件下载：[https://github.com/18476305640/fileBox/raw/master/杂项/ssm.7z](https://github.com/18476305640/fileBox/raw/master/杂项/ssm.7z "https://github.com/18476305640/fileBox/raw/master/杂项/ssm.7z")
