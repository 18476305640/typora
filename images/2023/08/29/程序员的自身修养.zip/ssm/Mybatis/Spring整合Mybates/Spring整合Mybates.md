# Spring整合Mybates

在spring+springmvc的基础上继续整合mybatis：

下载[spring+springmvc整合好的>>](https://github.com/18476305640/fileBox/raw/master/%E6%9D%82%E9%A1%B9/spring_springmvc.zip "spring+springmvc整合好的>>")

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16608313616901660831361375.png)

### \[\_1\_] 依赖分析

整合所需的Jar分析

。Junit测试jar(4.12版本）
。 Mybatis的jar (3.4.5)
。Spring相关jar(spring-context、spring-test、spring-jdbc、spring-tx、spring-aop、aspectjweaver)
。Mybatis/Spring整合包jar(mybatis-spring-xx.jar)
。Mysql数据库驱动jar
。Druid数据库连接池的jar

### \[\_2\_] 开始整合到 (Spring+SpringMVC)

-   开始整合

    &#x20; 下载[spring+springmvc整合好的>>](https://github.com/18476305640/fileBox/raw/master/%E6%9D%82%E9%A1%B9/spring_springmvc.zip "spring+springmvc整合好的>>")
    1.  创建一个maven webapp 项目，编辑以下文件

        pom.xml
        ```xml
        <?xml version="1.0" encoding="UTF-8"?>

        <project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
            <modelVersion>4.0.0</modelVersion>

            <groupId>com.zhuangjie</groupId>
            <artifactId>ssm</artifactId>
            <version>1.0-SNAPSHOT</version>
            <packaging>war</packaging>

            <name>ssm Maven Webapp</name>
            <!-- FIXME change it to the project's website -->
            <url>http://www.example.com</url>

            <properties>
                <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
                <maven.compiler.source>1.8</maven.compiler.source>
                <maven.compiler.target>1.8</maven.compiler.target>
            </properties>

            <dependencies>


                <!--【1】 spring+springmvc依赖-->
                <dependency>
                    <groupId>org.springframework</groupId>
                    <artifactId>spring-webmvc</artifactId>
                    <version>5.1.12.RELEASE</version>
                </dependency>
                <dependency>
                    <groupId>org.springframework</groupId>
                    <artifactId>spring-tx</artifactId>
                    <version>5.1.12.RELEASE</version>
                </dependency>
                <dependency>
                    <groupId>org.springframework</groupId>
                    <artifactId>spring-test</artifactId>
                    <version>5.1.12.RELEASE</version>
                </dependency>
                <dependency>
                    <groupId>org.springframework</groupId>
                    <artifactId>spring-jdbc</artifactId>
                    <version>5.1.12.RELEASE</version>
                </dependency>
                <!--不引入，HttpServletRequest , HttpServletResponse , HttpSession 都不能引入，项目可以运行，是因为这个依赖在tomcat中有 -->
                <dependency>
                    <groupId>javax.servlet</groupId>
                    <artifactId>javax.servlet-api</artifactId>
                    <version>3.1.0</version>
                    <scope>provided</scope>
                </dependency>

                <!--【2】mybatis依赖-->
                <!--mybatis-->
                <dependency>
                    <groupId>org.mybatis</groupId>
                    <artifactId>mybatis</artifactId>
                    <version>3.4.5</version>
                </dependency>
                <!--mybatis与spring的整合包-->
                <dependency>
                    <groupId>org.mybatis</groupId>
                    <artifactId>mybatis-spring</artifactId>
                    <version>2.0.3</version>
                </dependency>
                <!--数据库驱动jar-->
                <dependency>
                    <groupId>mysql</groupId>
                    <artifactId>mysql-connector-java</artifactId>
                    <version>5.1.46</version>
                </dependency>
                <!--druid连接池-->
                <dependency>
                    <groupId>com.alibaba</groupId>
                    <artifactId>druid</artifactId>
                    <version>1.1.21</version>
                </dependency>

                <!--【3】其它依赖-->
                <dependency>
                    <groupId>junit</groupId>
                    <artifactId>junit</artifactId>
                    <version>4.12</version>
                    <scope>test</scope>
                </dependency>
                <dependency>
                    <groupId>org.projectlombok</groupId>
                    <artifactId>lombok</artifactId>
                    <version>1.18.22</version>
                </dependency>


            </dependencies>


            <build>
                <!--不写报错，指定一些目录或文件文件的位置-->
                <resources>
                    <resource>
                        <directory>src/main/java</directory>
                        <includes>
                            <include>**/*.properties</include>
                            <include>**/*.xml</include>
                        </includes>
                        <filtering>false</filtering>
                    </resource>
                    <resource>
                        <directory>src/main/resources</directory>
                        <includes>
                            <include>**/*.properties</include>
                            <include>**/*.xml</include>
                        </includes>
                        <filtering>false</filtering>
                    </resource>
                </resources>
                <!--    <finalName>demo</finalName> 自定义打包名-->
                <plugins>
                    <plugin>
                        <groupId>org.apache.maven.plugins</groupId>
                        <artifactId>maven-war-plugin</artifactId>
                        <version>2.2</version>
                    </plugin>
                </plugins>
            </build>
        </project>

        ```
    2.  applicationContext.xml

        `resources`  → jdbc.properties：
        ```.properties
        jdbc.driver=com.mysql.jdbc.Driver
        jdbc.url=jdbc:mysql://localhost:3306/user_db
        jdbc.username=root
        jdbc.password=3333
        ```
        applicationContext.xml：
        ```xml
        <?xml version="1.0" encoding="UTF-8"?>
        <beans xmlns="http://www.springframework.org/schema/beans"
               xmlns:context="http://www.springframework.org/schema/context"
               xmlns:tx="http://www.springframework.org/schema/tx"
               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
               xsi:schemaLocation="
               http://www.springframework.org/schema/beans
               http://www.springframework.org/schema/beans/spring-beans.xsd
               http://www.springframework.org/schema/context
               http://www.springframework.org/schema/context/spring-context.xsd
               http://www.springframework.org/schema/tx
               http://www.springframework.org/schema/tx/spring-tx.xsd
        ">
        <!--这个文件是Spring-Mybaties的配置文件-->


            <!--引入外部资源文件-->
            <context:property-placeholder location="classpath:jdbc.properties"></context:property-placeholder>
            <!--第三方jar中的bean定义在xml中-->
            <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource">
                <property name="driverClassName" value="${jdbc.driver}"/>
                <property name="url" value="${jdbc.url}"/>
                <property name="username" value="${jdbc.username}"/>
                <property name="password" value="${jdbc.password}"/>
            </bean>

            <!--事务管理: 数据库连接池以及事务管理都交给Spring容器来完成-->
            <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
                <property name="dataSource" ref="dataSource"/>
            </bean>

            <!--事务管理注解驱动-->
            <tx:annotation-driven transaction-manager="transactionManager"/>




        </beans>
        ```
        SqlSessionFactory对象应该放到Spring容器中作为单例对象管理

        编辑 applicationContext.xml： 追加
        ```xml
            <!--SqlSessionFactory对象应该放到Spring容器中作为单例对象管理
            原来mybaits中sqlSessionFactory的构建是需要素材的：SqlMapConfig.xml中的内容
        -->
            <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
                <!--别名映射扫描-->
                <property name="typeAliasesPackage" value="com.zhuangjie.ssm.pojo"/>
                <!--数据源dataSource-->
                <property name="dataSource" ref="dataSource"/>

                <!-- 自动扫描mybatis配置文件 -->
        <!--        <property name="configLocation" value="classpath:mybatis-config.xml"></property>-->
                <!-- 自动扫描mapping.xml文件 -->
                <property name="mapperLocations" value="classpath:mapper/*.xml"></property>
            </bean>
        ```
        Mapper动态代理对象交给Spring管理，我们从Spring容器中直接获得Mapper的代理对象

        编辑 applicationContext.xml： 追加
        ```xml
            <!--Mapper动态代理对象交给Spring管理，我们从Spring容器中直接获得Mapper的代理对象-->
            <!--扫描mapper接口，生成代理对象，生成的代理对象会存储在ioc容器中-->
            <bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
                <!--mapper接口包路径配置-->
                <property name="basePackage" value="com.zhuangjie.ssm.mapper"/>
                <property name="sqlSessionFactoryBeanName" value="sqlSessionFactory"/>
            </bean>
        ```
        编辑 applicationContext.xml： 追加
        ```xml
            <!--包扫描-->
            <context:component-scan base-package="com.zhuangjie.ssm" />
        ```
    3.  web.xml
        ```xml
        <?xml version="1.0" encoding="UTF-8"?>
        <web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
                 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                 xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd"
                 version="4.0">


            <display-name>Archetype Created Web Application</display-name>

            <!--启动spring+mybaties-->
            <context-param>
                <param-name>contextConfigLocation</param-name>
                <param-value>classpath*:applicationContext.xml</param-value>
            </context-param>
            <!--spring框架启动-->
            <listener>
                <listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>
            </listener>

        </web-app>
        ```
    4.  加入代码：在指定位置加入项目代码：

        ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16608293384541660829338104.png)

        与：

        ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16608294438081660829443703.png)
    5.  使用日志 输出mybatis执行的SQL

        pom.xml：追加依赖
        ```xml
        <dependency>
            <groupId>log4j</groupId>
            <artifactId>log4j</artifactId>
            <version>1.2.17</version>
        </dependency>
        ```
        resources → log4j.properties：
        ```.properties
        #定义LOG输出级别
        log4j.rootLogger=DEBUG,INFO,Console,File  
        #定义日志输出目的地为控制台
        log4j.appender.Console=org.apache.log4j.ConsoleAppender  
        log4j.appender.Console.Target=System.out  
        #可以灵活地指定日志输出格式，下面一行是指定具体的格式
        log4j.appender.Console.layout = org.apache.log4j.PatternLayout  
        log4j.appender.Console.layout.ConversionPattern = [%p] [%d{yyyy-MM-dd HH\:mm\:ss}][%c]%m  %l%n

        #文件大小到达指定尺寸的时候产生一个新的文件
        log4j.appender.File = org.apache.log4j.RollingFileAppender  
        #指定输出目录
        log4j.appender.File.File = logs/ssm.log  
        #定义文件最大大小
        log4j.appender.File.MaxFileSize = 10MB  
        #输出所以日志，如果换成DEBUG表示输出DEBUG以上级别日志
        log4j.appender.File.Threshold = ALL  
        log4j.appender.File.layout = org.apache.log4j.PatternLayout  
        log4j.appender.File.layout.ConversionPattern = [%p] [%d{yyyy-MM-dd HH\:mm\:ss}][%c]%m  %l%n
        #mybatis日志配置 需要将日志的输出级别调为debug
        log4j.logger.com.ibatis=DEBUG
        log4j.logger.com.ibatis.common.jdbc.SimpleDataSource=DEBUG
        log4j.logger.com.ibatis.common.jdbc.ScriptRunner=DEBUG
        log4j.logger.com.ibatis.sqlmap.engine.impl.SqlMapClientDelegate=DEBUG
        #与sql相关
        log4j.logger.java.sql.Connection=DEBUG
        log4j.logger.java.sql.Statement=DEBUG
        log4j.logger.java.sql.PreparedStatement=DEBUG
        ```
        web.xml：在`<web-app>` 标签下加如下，加载 log4j.properties 文件
        ```xml
        <!-- log4j日志输出 -->
            <context-param>
                <param-name>log4jConfigLocation</param-name>
                <param-value>classpath:log4j.properties</param-value>
            </context-param>
        ```
        resources → mybatis-config.xml：创建文件
        ```xml
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE configuration
                PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
                "http://mybatis.org/dtd/mybatis-3-config.dtd">
        <configuration>
            <settings>
                <!-- 打印查询语句 -->
                <setting name="logImpl" value="STDOUT_LOGGING" />
            </settings>
        </configuration>
        ```
        applicationContext.xml：编辑，作如何配置，加载mybatis-cofig.xml

        ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16608308035981660830802867.png)

        效果：当mybatis执行sql时，会输出sql信息

        ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16608308895921660830888986.png)

整合好后：[https://github.com/18476305640/fileBox/raw/master/杂项/spring\_springmvc\_mybatis.zip](https://github.com/18476305640/fileBox/raw/master/杂项/spring_springmvc_mybatis.zip "https://github.com/18476305640/fileBox/raw/master/杂项/spring_springmvc_mybatis.zip")
