# 手写Spring

手写的源码下载：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/26/mySpring.zip](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/26/mySpring.zip "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/26/mySpring.zip")

从仓库中下载（未公开）：[https://gitee.com/zjazn/my-spring](https://gitee.com/zjazn/my-spring "https://gitee.com/zjazn/my-spring")

**拿到项目，如何看懂？**

**1、介绍：** 创建前是一个基本的`Java项目`+`添加web块`（右击项目名→添加框架支持→web）

**2、项目构成：根下**

resources :

layouts : 静态文件，如html

application.properties : 配置文件

src.com.zhuangjie：

demo:&#x20;

controller，service层

spring.framework :

annotation: 存放注解

`v1`:  一个类，直接搞定。

`v2`:  基于V1进行IOC的顶层设计 （）

`v3`：基于V2进行MVC的顶层设计

> v1,v2,v3版本都能进行MVC （使用tomcat启动）
>
> 如何看懂？都是先看 MyDispatcherServlet 类下的`init`方法，再看下面的 `doDispatch`方法。
>
> v3版本是最接近官方spring框架的。

web：

WEB-INF → web.xml : servlet web的基本配置

> **心得：** 知道了注解与反射的具体使用，利用了一天的时间也学会正则。因为里面视图解析用到了正则。
>
> 知道了springmvc的执行流程 是：
>
> **init方法：** 先初始化 IOC, 再初始化九大组件
>
> **doDispatch方法：** 使用request去匹配HandlerMapping, 没有找到就会报404，找到就会用HandlerMapping去匹配HandlerAdapter, 然后用HandlerAdapter对象去调用handle得到ModelAndView, 然后用ModelAndView去进行视图解析渲染返回。
