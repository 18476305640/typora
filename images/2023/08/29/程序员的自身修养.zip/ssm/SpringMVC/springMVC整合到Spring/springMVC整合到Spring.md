# springMVC整合到Spring

**Spring与Springmvc基本整合**

（1）创建一个webapp项目

（2）pom.xml依赖

-   pom.xml&#x20;
    ```xml
    <?xml version="1.0" encoding="UTF-8"?>

    <project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
             xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
        <modelVersion>4.0.0</modelVersion>

        <groupId>com.zhuangjie</groupId>
        <artifactId>ssm</artifactId>
        <version>1.0-SNAPSHOT</version>
        <packaging>war</packaging>

        <name>ssm Maven Webapp</name>
        <!-- FIXME change it to the project's website -->
        <url>http://www.example.com</url>

        <properties>
            <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
            <maven.compiler.source>1.8</maven.compiler.source>
            <maven.compiler.target>1.8</maven.compiler.target>
        </properties>

        <dependencies>
            <dependency>
                <groupId>junit</groupId>
                <artifactId>junit</artifactId>
                <version>4.11</version>
                <scope>test</scope>
            </dependency>

            <!--引入spring webmvc的依赖-->
            <dependency>
                <groupId>org.springframework</groupId>
                <artifactId>spring-webmvc</artifactId>
                <version>5.1.12.RELEASE</version>
            </dependency>
            <!--不引入，HttpServletRequest , HttpServletResponse , HttpSession 都不能引入，项目可以运行，是因为这个依赖在tomcat中有 -->
            <dependency>
                <groupId>javax.servlet</groupId>
                <artifactId>javax.servlet-api</artifactId>
                <version>3.1.0</version>
                <scope>provided</scope>
            </dependency>
        </dependencies>


        <build>
            <!--不写报错，指定一些目录或文件文件的位置-->
            <resources>
                <resource>
                    <directory>src/main/java</directory>
                    <includes>
                        <include>**/*.properties</include>
                        <include>**/*.xml</include>
                    </includes>
                    <filtering>false</filtering>
                </resource>
                <resource>
                    <directory>src/main/resources</directory>
                    <includes>
                        <include>**/*.properties</include>
                        <include>**/*.xml</include>
                    </includes>
                    <filtering>false</filtering>
                </resource>
            </resources>
            <!--    <finalName>demo</finalName> 自定义打包名-->
            <plugins>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-war-plugin</artifactId>
                    <version>2.2</version>
                </plugin>
            </plugins>
        </build>
    </project>


    ```

（3）配置扫描注解并配置全局Servlet

-   在resources中创建一个`springmvc.xml` 文件，主要作用是，配置扫描注解

    springmvc.xml：
    ```xml
    <?xml version="1.0" encoding="UTF-8"?>
    <beans xmlns="http://www.springframework.org/schema/beans"
           xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:context="http://www.springframework.org/schema/context"
    xmlns:mvc="http://www.springframework.org/schema/mvc"
           xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
    http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd
    http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc.xsd">


        <!--开启controller扫描（扫描的是Controller中的注解）-->
        <context:component-scan base-package="com.zhuangjie.springmvc.controller" />
        <!--配置springmvc的视图解析器（让我们在返回视图时，由原来的“/WEB-INF/jsp/success.jsp”只需写"success"即可）-->
        <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
            <property name="prefix" value="/WEB-INF/jsp/"/>
            <property name="suffix" value=".jsp"/>
        </bean>


        <!--自动注册最合适的处理器映射器，处理器适配器(调用handler方法)-->
        <mvc:annotation-driven />


    </beans>
    ```
-   需要加载这个配置文件`springmvc.xml`。在配置全局servlet中将`springmvc.xml`进行加载。\*\*src/main/webapp/WEB-INF/web.xml \*\*文件下配置

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16515703151461651570314937.png)

    web.xml
    ```xml
    <!DOCTYPE web-app PUBLIC
     "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
     "http://java.sun.com/dtd/web-app_2_3.dtd" >

    <web-app>
      <display-name>Archetype Created Web Application</display-name>

      <!--这个servlet+servlet-mapping是（图）： https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16515703151461651570314937.png-->
      <servlet>
        <servlet-name>springmvc</servlet-name>
        <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
        <!--扫描springmvc.xml配置文件-->
        <init-param>
          <param-name>contextConfigLocation</param-name>
          <param-value>classpath:springmvc.xml</param-value>
        </init-param>
      </servlet>
      <servlet-mapping>
        <servlet-name>springmvc</servlet-name>
        <!--
          方式一：带后缀，比如*.action  *.do *.aaa
                 该种方式比较精确、方便，在以前和现在企业中都有很大的使用比例
          方式二：/ 不会拦截 .jsp，但是会拦截.html等静态资源（静态资源：除了servlet和jsp之外的js、css、png等）

                为什么配置为/ 会拦截静态资源？？？
                    因为tomcat容器中有一个web.xml（父），你的项目中也有一个web.xml（子），是一个继承关系
                          父web.xml中有一个DefaultServlet,  url-pattern 是一个 /
                          此时我们自己的web.xml中也配置了一个 / ,覆写了父web.xml的配置
                为什么不拦截.jsp呢？
                    因为父web.xml中有一个JspServlet，这个servlet拦截.jsp文件，而我们并没有覆写这个配置，
                    所以springmvc此时不拦截jsp，jsp的处理交给了tomcat


                如何解决/拦截静态资源这件事？


          方式三：/* 拦截所有，包括.jsp
        -->
        <!--拦截匹配规则的url请求，进入springmvc框架处理-->
        <url-pattern>/</url-pattern>
      </servlet-mapping>
    </web-app>

    ```

（4）写一个Controller

-   DomeController
    ```java
    package com.zhuangjie.springmvc.controller;

    import org.springframework.stereotype.Controller;
    import org.springframework.web.bind.annotation.RequestMapping;
    import org.springframework.web.servlet.ModelAndView;

    import java.util.Date;

    @Controller
    @RequestMapping("/demo")
    public class DemoController {
        /**
         * url: http://localhost:8080/demo/handle01
         */
        @RequestMapping("/handle01")
        public ModelAndView handle01() {
            System.out.println("你好服务器~");
            Date date = new Date();// 服务器时间
            // 返回服务器时间到前端页面
            // 封装了数据和页面信息的 ModelAndView
            ModelAndView modelAndView = new ModelAndView();
            // addObject 其实是向请求域中request.setAttribute("date",date);
            modelAndView.addObject("date",date);
            // 视图信息(封装跳转的页面信息) 逻辑视图名,在springmvc.xml已经配置了视图解析器
            modelAndView.setViewName("success");
            return modelAndView;
        }
    }

    ```

（5）写一个`.jsp`   :&#x20;

-   src/main/webapp/WEB-INF/jsp/success.jsp
    ```html
    <%@ page language="java" isELIgnored="false" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>

    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Insert title here</title>
    </head>
    <body>
    跳转成功！服务器时间：${date}
    </body>
    </html>
    ```

上面做好的：[spring\_springmvc.zip](https://github.com/18476305640/fileBox/raw/master/%E6%9D%82%E9%A1%B9/spring_springmvc.zip "spring_springmvc.zip")

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16608313616901660831361375.png)
