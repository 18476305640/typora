# RabbitMQ-消息中间件（黑马）

## \[1] RabbitMQ基本内容

### 1.1 MQ简介

MQ全称 MessageQueue(消息队列)，是在消息的传输过程中保存消息的容器。多用于分布式系统之间进行通信。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673765647006.png)

> 1、MQ，消息队列，存储消息的中间件
> 2、分布式系统通信两种方式:直接远程调用和借助第三方完成间接通信
>
> 3、发送方称为生产者, 接收方称为消费者

### 1.2 MQ的优劣

#### 优势

-   **应用解耦：** 使得系统间的容错提高，发送消息到MQ后，就算消费者暂时不可用了也没有关系，系统重新起来后，会继续从MQ中将消息消费。如果从消费端再加入其它消费者，生产者服务端也不用修改代码，提高了可维护性。 （应用解耦→ 可用性提高 → 可维护性提高）
-   **异步提速：** 如果没有MQ，我们是下单后会以同步的形式（for） 通知各个依赖系统（库存、支付 、...） 消耗的时间是累加的，但有了MQ后我们只需要将消息push到MQ，就可以告诉用户成功了，消费端会进行消费。这就大大提高了系统的响应速度与系统的吞吐量。
-   **削峰填谷：** 请求峰期打到MQ上，消费者会以其处理能力的最大速度处理消息，不至于让消费端处理过多请求而崩溃，提高了系统的稳定性。

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673767305387.png)

    使用了MQ之后，限制消费消息的速度为1000，这样一来，高峰期产生的数据势必会被积压在 MQ 中，高峰就被“削”掉了，但是因为消息积压，在高峰期过后的一段时间内，消费消息的速度还是会维持在1000，直到消费完积压的消息，这就叫做“填谷”

#### 劣势

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673768210624.png)

-   **系统的可用性降低：** 系统引入的外部依赖越多，系统稳定性越差。一旦 MQ 宕机，就会对业务造成影响。如何保证MQ的高可用?
-   **系统复杂度增加：** MQ 的加入大大增加了系统的复杂度，以前系统间是同步的远程调用，现在是通过 MQ 进行异步调用。如何保证消息没有被重复消费? 怎么处理消息丢失情况? 那么保证消息传递的顺序性?
-   **一致性问题：** A系统处理完业务，通过 MQ给B、C、D三个系统发消息数据，如果B 系统、C系统处理成功，D 系统处理失败。如何保证消息数据处理的一致性?

### 1.3 何时才要使用MQ

1、生产者不需要从消费者处获得反馈。引入消息队列之前的直接调用，其接口的返回值应该为空，这才让明明下层的动作还没做，上层却当成动作做完了继续往后走，即所谓异步成为了可能。（应用在：发布/订阅场景）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673769042012.png)

2、容许短暂的不一致性。

3、确实是用了有效果。即解耦、提速、削峰这些方面的收益，超过加入MQ，管理MQ这些成本。

### 1.4 市面上常见的MQ

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673769919696.png)

### 1.5 RabbitMQ简介

#### AMQP协议

AMQP，即Advanced Message Queuing Protocol (高级消息队列协议)，是一个网络协议，是应用层协议的一个开放标准，为面向消息的中间件设计。基于此协议的客户端与消息中间件可传递消息，并不受客户端/中间件不同产品，不同的开发语言等条件的限制。2006年，AMQP 规范发布（类比HTTP）。

规定了如下角色：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673770687591.png)

> 解析说明：Publisher是消息的生产者，Exchange通过Routes路由到Queue中，Queue将消息推送给Consumer。

#### Rabbit由此产生

2007年，Rabbit 技术公司基于AMQP 标准开发的 RabbitMQ 1.0 发布。RabbitMQ 采用 Erlang 语言开发Erlanq 语言由 Ericson 设计，专门为开发高并发和分布式系统的一种语言，在电信领域使用广泛

RabbitMo基础架构如下图:

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673770998657.png)

`Broker`：又称 Server，接收客户端的连接，实现AMQP实体服务，接收和分发消息的应用，RabbitMQ Server 就是 Message Broker &#x20;

`Connection`：连接，应用服务与Server的连接 &#x20;

`Channel`：信道，客户端可建立多个Channel，每个Channel代表一个会话任务 &#x20;

`Message`：消息，由 MessageProperties 和 body 构成 &#x20;

MessageProperties （SpringBoot）、AMQP.BasicProperties （基本API）可对消息的优先级、过期时间等参数进行设置，其中参数 correlation\_id 一般作为消息主键 &#x20;

`Exchange`：交换机，消息将根据 routeKey 被交换机转发给对应的绑定队列 &#x20;

`Queue`：队列，消息最终被送到这里等待消费者取走，参数中的Auto-delete意为当前队列的最后一个消息被取出后是否自动删除 &#x20;

`Binding`：绑定 exchange 和 queue 之间的虚拟连接，二者通过 routingkey 进行绑定 &#x20;

`Routingkey`：路由规则，交换机可以用它来确定消息改被路由到哪里 &#x20;

`Virtual host`：虚拟主机，用于进行逻辑隔离，是最上层的消息路由，一个虚拟主机中可以有多个 Exchange 和 Queue，同一个虚拟主机中不能有名称一样的 Exchange 和 Queue

> RabbitMQ是基于AMQP 协议使用 Erlang 语言开发的一款消息队列产品
>
> RabbitMQ提供了6种工作模式，我们学习5种。这是今天的重点。
>
> AMQP 是协议，类比HTTP
>
> JMS 是API 规范接口，类比JDBC

#### RabbitMQ的六种工作模式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673772060113.png)

### 1.6 RabbitMQ安装

RabbitMQ与对应Erlang版本：[https://rabbitmq.com/which-erlang.html](https://rabbitmq.com/which-erlang.html "https://rabbitmq.com/which-erlang.html")

-   **linux安装**

    1、安装包
    ```yaml
    【erlang下载地址】：https://hub.fastgit.org/rabbitmq/erlang-rpm/releases
           el6：CentOS 6.x 的下载
           el7：CentOS 7.x 的下载
           el8：CentOS 8.x 的下载
     #可以直接使用命令安装  【socat下载地址】：http://www.rpmfind.net/linux/rpm2html/search.php?query=socat(x86-64)
    【rabbitmq下载地址】：https://github.com/rabbitmq/erlang-rpm/releases
    ```
    2、安装：

    基本环境：

    **须知1**：erlang与rabbit-mq 版本：[https://rabbitmq.com/which-erlang.html](https://rabbitmq.com/which-erlang.html "https://rabbitmq.com/which-erlang.html")

    **须知2**：在下载erlang时 `erlang-23.3.4.8-1.el7.x86_64.rpm` 的`el7` 是centos7安装，如果是`el8` 在centos7上就不能安装！！
    ```bash
    #C++依赖
    yum install -y build-essential openssl openssl-devel unixODBC unixODBC-devel make gcc gcc-c++ kernel-devel m4 ncurses-devel tk tc xz
    #安装 socat
    yum install -y socat 
    #安装erlang  
    wget https://github.com/rabbitmq/erlang-rpm/releases/download/v23.3.4.8/erlang-23.3.4.8-1.el7.x86_64.rpm
    rpm -ivh  erlang-23.3.4.8-1.el7.x86_64.rpm
    #安装rabbitmq
    wget https://github.com/rabbitmq/rabbitmq-server/releases/download/v3.10.7/rabbitmq-server-3.10.7-1.el8.noarch.rpm
    rpm -ivh  rabbitmq-server-3.10.7-1.el8.noarch.rpm

    ```
    ```bash
    # 添加开机启动 RabbitMQ 服务
    chkconfig rabbitmq-server on
    # 启动服务
    /sbin/service rabbitmq-server start 
    # 查看服务状态
    /sbin/service rabbitmq-server status
    # 停止服务(选择执行) 
    /sbin/service rabbitmq-server stop 
    # 开启 web 管理插件 
    rabbitmq-plugins enable rabbitmq_management 
    ```
    用默认账号密码(guest)访问地址 [http://47.115.185.244:15672/出现权限问题](http://47.115.185.244:15672/出现权限问题 "http://47.115.185.244:15672/出现权限问题")

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16536522810081653652280347.png)
    ```bash
    # 添加一个新的用户 创建账号 
    rabbitmqctl add_user admin 3333

    # 设置用户角色 
    rabbitmqctl set_user_tags admin administrator 

    #设置用户权限 语法：rabbitmqctl  set_permissions [-p <vhostpath>] <user> <conf> <write> <read>
    rabbitmqctl set_permissions -p "/" admin ".*" ".*" ".*"  # 具有/vhost1 这个 virtual host 中所有资源的配置、写、读权限

    #当前用户和角色 
    rabbitmqctl list_users
    ```
    再次利用 admin 用户登录
-   windows安装

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16533860169891653386016865.png)
    -   1、安装：RabbitMQ 它依赖于Erlang,

        需要先安装Erlang：[https://www.rabbitmq.com/install-windows.html](https://www.rabbitmq.com/install-windows.html "https://www.rabbitmq.com/install-windows.html")
    -   2、配置erlang环境变量信息

        新增环境变量ERLANG\_HOME=erlang的安装地址

        将%ERLANG\_HOME%\bin加入到path中
    -   3、安装RabbitMQ，

        下载地址：[http://www.rabbitmq.com/download.html](http://www.rabbitmq.com/download.html "http://www.rabbitmq.com/download.html")
    -   4、启动RabbitMQ服务

        请保证设备名称为英文

        1\)进入RabbitMQ安装目录的sbin目录下，cmd执行 (先不要关掉)：
        ```bash
        rabbitmq-plugins enable rabbitmq_management

        rabbitmqctl start_app
        ```
        在win右下角菜单中选择点击 RabbitMQ Service - start

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/img/1620184338340-1620184338339.png)

        访问地址，查看是否成功： [http://localhost:15672/](http://localhost:15672/ "http://localhost:15672/")
        ```markdown
        15672端口: rabbitmq Web控制台管理台 http协议
         5672端口：rabbitmq 内部通信的一个端口号
        25672端口：rabbitmq 集群通信端口号

        ```
    -   \#5、在Web管理界面进行配置

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16533877947031653387794665.png)
        -   **RabbitMQ**常见名词

            /Virtual Hosts---分类

            /队列 存放我们消息

            Exchange 分派我们消息在那个队列存放起来 类似于nginx
        1、创建一个VirtualHosts

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16533871244551653387124401.png)

        2、创建一个用户来关联

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16533873143661653387314329.png)

        3、让用户可以操作该VirtualHosts

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16533874340321653387433992.png)

        4、给VirtualHosts创建一个Queues

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16533875027431653387502704.png)

        综上得到以下，可用于连接操作。

        用户:**zhuangjie**/**3333**

        VirtualHosts：**/myvh**

        Queues：**mqu**
    -   \#6、程序测试

        pom.xml
        ```xml
                <!--rabbit依赖-->
                <dependency>
                    <groupId>com.rabbitmq</groupId>
                    <artifactId>amqp-client</artifactId>
                    <version>3.6.5</version>
                </dependency>
        ```
        RabbitMQConnection.java：负责创建连接对象
        ```java
        package com.zhuangjie.mq.config;

        import com.rabbitmq.client.Connection;
        import com.rabbitmq.client.ConnectionFactory;

        import java.io.IOException;
        import java.util.concurrent.TimeoutException;

        public class RabbitMQConnection {

            /**
             * 获取连接
             *
             * @return
             */
            public static Connection getConnection() throws IOException, TimeoutException {
                // 1.创建连接
                ConnectionFactory connectionFactory = new ConnectionFactory();
                // 2.设置连接地址
                connectionFactory.setHost("127.0.0.1");
                // 3.设置端口号:
                connectionFactory.setPort(5672);
                // 4.设置账号和密码
                connectionFactory.setUsername("zhuangjie");
                connectionFactory.setPassword("3333");
                // 5.设置VirtualHost
                connectionFactory.setVirtualHost("/myvh");
                return connectionFactory.newConnection();
            }
        }

        ```
        Test.java：生产者与消费者，先对push方法进行单元测试，再对poll单元测试
        ```java
            //队列
            private static final String QUEUE = "mqu";

            @Test
            public void push() throws Exception {

                Connection connection = null;
                Channel channel = null;
                try {
                    //建立新连接
                    connection = RabbitMQConnection.getConnection();
                    //创建会话通道,生产者和mq服务所有通信都在channel中完成
                    channel = connection.createChannel();
                    //声明队列String queue, boolean durable, boolean exclusive, boolean autoDelete, Map<String, Object> arguments
                    //参数名称:
                    // 1.队列名称
                    // 2.是否持久化mq重启后队列还在
                    // 3.是否独占连接,队列只允许在该连接中访问,如果连接关闭后就会自动删除了,设置true可用于临时队列的创建
                    // 4.自动删除,队列不在使用时就自动删除,如果将此参数和exclusive参数设置为true时,就可以实现临时队列
                    // 5.参数,可以设置一个队列的扩展参数,比如可以设置队列存活时间
                    channel.queueDeclare(QUEUE, true, false, false, null);
                    // 发送消息String exchange, String routingKey, boolean mandatory, BasicProperties props, byte[] body
                    //参数名称:
                    // 1.交换机,如果不指定将会使用mq默认交换机
                    // 2.路由key,交换机根据路由key来将消息转发至指定的队列,如果使用默认的交换机,routingKey设置为队列名称
                    // 3.消息属性
                    // 4.消息内容
                    String message = "HelloWorld2";
                    channel.basicPublish("", QUEUE, null, message.getBytes());
                    System.out.println("Send to mq: " + message);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (channel != null) {
                            channel.close();
                        }
                        if (connection != null) {
                            connection.close();
                        }
                    } catch (IOException  e) {
                        e.printStackTrace();
                    }
                }
            }

            @Test
            public void poll() throws Exception{
                Connection connection = RabbitMQConnection.getConnection();
                Channel channel = connection.createChannel();
                DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
                    @Override
                    public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                        String msg = new String(body, "UTF-8");

                        System.out.println("消费者获取消息:" + msg);
                    }
                };
                channel.basicConsume(QUEUE, true, defaultConsumer);

            }
        ```

### 1.7 RabbitMQ管理界面的基本使用

#### 创建用户

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673786642856.png)

#### 给用户分配Virtual Hosts

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673786946872.png)

#### 端口查看/数据迁移

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/15/1673787235577.png)

### 1.8 六种工作模式

#### Hello world模式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673855201071.png)

创建一个空项目，右击创建两个maven项目，一个作为生产者，另一个作为消费者。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673853899319.png)

两个的pom.xml 都是一样的，如下：

```xml
    <dependencies>
        <!--rabbitmq 依赖客户端-->
        <dependency>
            <groupId>com.rabbitmq</groupId>
            <artifactId>amqp-client</artifactId>
            <version>5.8.0</version>
        </dependency>
        <!--操作文件流的一个依赖-->
        <dependency>
            <groupId>commons-io</groupId>
            <artifactId>commons-io</artifactId>
            <version>2.6</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <artifactId>maven-compiler-plugin</artifactId>
                <configuration>
                    <source>1.8</source>
                    <target>1.8</target>
                </configuration>
            </plugin>
        </plugins>
    </build>
```

前提：已存在一个`admin/3333`的账号，关联一个虚拟机 `/mqvm`

**生产者代码：**

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

/**
 * 生产者
 *
 * @author zhuangjie
 * @date 2023/01/16
 */
public class Product {
    public static final String QUEUE_NAME = "hello"; // 队列名称
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道
        /*  队列设置（创建队列)
         *参数1：队列名称，名称不存在就自动创建
         *参数2：定义队列是否持久化（重启MQ后是队列否存在）,true开启，false关闭
         *参数3：exclusive 是否独占队列（设置是否只能有一个消费者使用），true独占，false非独占
         *参数4：autoelete 是否在消费完成后是否自动删除队列 ，true删除,false不删除
         *参数5：额外附加参数
         */
        channel.queueDeclare(QUEUE_NAME, true, false, false, null);

        String message = "Hello RabbitMQ,this product send message!";            // 需要发送的消息
        /*  交换机&队列设置（指定消息使用的交换机和队列）
         * 参数1： exchange交换机名称（简单队列无交换机，这里不写）
         * 参数2： 有交换机就是路由key。没有交换机就是队列名称，意为往该队列里存放消息
         * 参数3： 传递消息的额外设置 (设置消息是否持久化）  MessageProperties.PERSISTENT_TEXT_PLAIN设置消息持久化
         * 参数4： 消息具体内容（要为 Byte类型）
         */
        channel.basicPublish("", QUEUE_NAME, null, message.getBytes(StandardCharsets.UTF_8));

        /*关闭资源*/
        channel.close();
        connection.close();

        System.out.println("消息生产完毕");
    }
}

```

注意：请检查  `VirtualHost` 的值在代码中没有写错！

执行后，在管理中可以看到`hello` 队列已经存在未消费的消息。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673854257371.png)

**消费者代码：**

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

public class Consumer {
    public static final String QUEUE_NAME = "hello"; // 队列名称
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道
        /*  队列设置（创建队列)
         *参数1：队列名称，名称不存在就自动创建
         *参数2：定义队列是否持久化（重启MQ后是队列否存在）,true开启，false关闭
         *参数3：exclusive 是否独占队列（设置是否只能有一个消费者使用），true独占，false非独占
         *参数4：autoelete 是否在消费完成后是否自动删除队列 ，true删除,false不删除
         *参数5：额外附加参数
         */


        /*  消费消息
         * 参数1 ： 消费队列的名称
         * 参数2 ： 消息的自动确认机制(一获得消息就通知 MQ 消息已被消费)  true打开，false关闭 (接收到消息并消费后也不通知 MQ ，常用)
         * 参数3 ： 消费者成功消费时的回调接口
         * 参数4 ： 消费者取消消费的回调
         */
        /*消费者取消消费的回调*/
        CancelCallback callback = consumerTag -> {
            System.out.println("消息者取消消费接口回调逻辑");
        };
        /*消费者成功消费时的回调接口，这里为打印获取到的消息*/
        DeliverCallback deliverCallback = (consumerTag, message) -> {
            System.out.println(new String(message.getBody()));
        };
        System.out.println("消费者执行完毕");
        channel.basicConsume(QUEUE_NAME, true, deliverCallback, callback);
        /*消费者端不应该关闭连接，因为消费者本来就应该处于监听状态*/
    }

}

```

执行后，发现控制台输出消息（消费者消费消息）

```bash
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.
消费者执行完毕
Hello RabbitMQ,this product send message!
```

执行完后，消费端并不会关闭，通过查看管理面板，就可以看到消费者数。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673855075764.png)

#### Work Queue模式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673855307563.png)

Work Queue模式与Hello world模式在代码上几乎没什么不同。

在Hello world模式下作如下修改：

生产者：使用for批量生产消息（为了测试）

消费者：创建一个消费者的副本

测试：启动两个消费者，启动生产者批量生产消费

结果：两个消费者，以轮流消费（一个0,2,4,6, ... , 另一个 1，3，5，...）

#### Pub/Sub模式 （开始引入交换机）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673861148316.png)

之前是竞争关系，只需要一个队列即可。

现在是做两件事，就需要两个队列了。

> 即一个队列做一种件事

\*\*交换机：  \*\*

-   实际情况中，生产者生产的消息从不会直接发送到队列，只会先发送到交换机中，再由交换机通过RoutingKey将消息发送到对应的绑定队列上 &#x20;
-   交换机的类型包括：直接(`direct`)、主题(`topic`) 、标题(`headers`) 、扇出(`fanout`)，其中 `headers` 类型已基本弃用 &#x20;
-   通常情况下生产者产生消息后才会执行消费者代码，因此交换机的创建都由生产者执行，消费者不需要再次创建交换机（交换机只需要被声明一次即可） &#x20;
-   在发布订阅模式中，只要有任意一个消费者的代码中进行了其他消费者交换机和 routingKey 的绑定，则这些消费者可以直接进行消息消费，而不再需要再次声明交换机和队列绑定 &#x20;
-   **如果整合SpringBoot，所有的交换机、队列声明将会放在一个配置文件**，无需像非SpringBoot案例中如此麻烦 &#x20;

    在上面的案例中虽然发送消息没有使用任何交换机，但实际上底层走的是 AMQP default 交换机进行消息发送

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673859772710.png)

    每个RabbitMQ虚拟要都有一个默认交换机，默认交换隐式绑定到每个队列。

> 临时队列标志：
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673859896626.png)

**演示** : 两个消费者收到生产者发送过来的消息后，一个将消息打印到控制台，另一个存储到数据库。

生产者：

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class PubSub_Product {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道
        /*
        exchangeDeclare(String exchange, BuiltinExchangeType type, boolean durable, boolean autoDelete, boolean internal, Map<String, Object> arguments)
         1.exchange:交换机名称
         2.type:交换机类型
            DIRECT("direct"),定向
            FANOUT("fanout"),扇形（广播），发送到每一个队列
            TOPIC("topic"),通配符的方式
    H       EADERS("headers");参数匹配
         3.durable：是否持久化
         4.autoDelete：自动删除
         5.internal：内部使用。一般为false
         6.arguments：参数
         */
        String exchangeName="test_fanout";
        //5.创建交换机
        channel.exchangeDeclare(exchangeName, BuiltinExchangeType.FANOUT,true,false,false,null);
        String queue1Name = "test_fanout_queue1";
        String queue2Name = "test_fanout_queue2";
        channel.queueDeclare(queue1Name,true,false,false,null);
        channel.queueDeclare(queue2Name,true,false,false,null);
        //7.绑定队列和交换机
        /*
        queueBind(String queue, String exchange, String routingKey)
        参数：
            1.queue:队列名称
            2.exchange:交换机名称
            3.routingKey:路由键，绑定规则
                如果交换机的类型为fanout，routingKey设置为""
         */

        channel.queueBind(queue1Name,exchangeName,"");
        channel.queueBind(queue2Name,exchangeName,"");

        //8.发送消息
        String body="日志信息：张三调用了findAll方法...日志级别:info...";
        channel.basicPublish(exchangeName,"",null,body.getBytes());
        //9.释放资源
        channel.close();
        connection.close();
    }

}
```

消费者1

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class PubSub_Consumer1 {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道

        String queue1Name = "test_fanout_queue1";
        String queue2Name = "test_fanout_queue2";

        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            /*
            回调方法，当收到消息后，自动执行该方法
            1.consumerTag：标识
            2.envelope:获取一些信息，交换机，路由key
            3.properties：配置信息
            4.body：数据
            */
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("consumer输出: " + new String(body));
                System.out.println("--将日志打皱到控制台--");
            }
        };

        channel.basicConsume(queue1Name,true,defaultConsumer);
        // 不需要关闭资源
    }
}


```

消费者2 : 代码与消费者1不同点是绑定的Queue不同。

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class PubSub_Consumer2 {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道

        String queue1Name = "test_fanout_queue1";
        String queue2Name = "test_fanout_queue2";

        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            /*
            回调方法，当收到消息后，自动执行该方法
            1.consumerTag：标识
            2.envelope:获取一些信息，交换机，路由key
            3.properties：配置信息
            4.body：数据
            */
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("consumer输出: " + new String(body));
                System.out.println("--将日志信息存至数据库--");
            }
        };

        channel.basicConsume(queue2Name,true,defaultConsumer);
        // 不需要关闭资源
    }
}

```

测试：启动生产者，再启动两个消费者。

消费者1：

```bash
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.
consumer输出: 日志信息：张三调用了findAll方法...日志级别:info...
--将日志打印到控制台--
```

消费者2：

```bash
SLF4J: Failed to load class "org.slf4j.impl.StaticLoggerBinder".
SLF4J: Defaulting to no-operation (NOP) logger implementation
SLF4J: See http://www.slf4j.org/codes.html#StaticLoggerBinder for further details.
consumer输出: 日志信息：张三调用了findAll方法...日志级别:info...
--将日志信息存至数据库--
```

#### Routing 模式 （引入了RouingKey）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673863202025.png)

在Pub/Sum模式中，只要生产者发送了消息交换机，与交换机绑定的队列都会进行消费，但有时候这是不合理的，比如如果`info`、`warning`消息也存储到数据库，那肯定会给数据库很大的压力，这时候我们要求只有是`error`消息才存储到数据库。

想要实现，我们就要引入RouingKey来实现了, RouingKey相当于路由到队列的条件。

消费者：

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Rouing_Product {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道
        /*
        exchangeDeclare(String exchange, BuiltinExchangeType type, boolean durable, boolean autoDelete, boolean internal, Map<String, Object> arguments)
         1.exchange:交换机名称
         2.type:交换机类型
            DIRECT("direct"),定向
            FANOUT("fanout"),扇形（广播），发送到每一个队列
            TOPIC("topic"),通配符的方式
    H       EADERS("headers");参数匹配
         3.durable：是否持久化
         4.autoDelete：自动删除
         5.internal：内部使用。一般为false
         6.arguments：参数
         */
        String exchangeName="test_direct";
        //5.创建交换机
        channel.exchangeDeclare(exchangeName, BuiltinExchangeType.DIRECT,true,false,false,null);
        String queue1Name = "test_direct_queue1";
        String queue2Name = "test_direct_queue2";
        channel.queueDeclare(queue1Name,true,false,false,null);
        channel.queueDeclare(queue2Name,true,false,false,null);
        //7.绑定队列和交换机
        /*
        queueBind(String queue, String exchange, String routingKey)
        参数：
            1.queue:队列名称
            2.exchange:交换机名称
            3.routingKey:路由键，绑定规则
                如果交换机的类型为fanout，routingKey设置为""
         */

        //队列1绑定error
        channel.queueBind(queue1Name,exchangeName,"error");
        //队列2绑定 info，error，warning
        channel.queueBind(queue2Name,exchangeName,"info");
        channel.queueBind(queue2Name,exchangeName,"error");
        channel.queueBind(queue2Name,exchangeName,"warning");

        //8.发送消息
        String msgLevel = "info";
        String body="日志信息：张三调用了findAll方法...日志级别:"+msgLevel+"...";
        channel.basicPublish(exchangeName,msgLevel,null,body.getBytes());
        //9.释放资源
        channel.close();
        connection.close();
    }

}

```

消费者1：

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Rouing_Consumer1 {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道

        String queue1Name = "test_direct_queue1";
        String queue2Name = "test_direct_queue2";

        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            /*
            回调方法，当收到消息后，自动执行该方法
            1.consumerTag：标识
            2.envelope:获取一些信息，交换机，路由key
            3.properties：配置信息
            4.body：数据
            */
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("consumer输出: " + new String(body));
                System.out.println("--将日志打皱到控制台--");
            }
        };

        channel.basicConsume(queue1Name,true,defaultConsumer);
        // 不需要关闭资源
    }
}

```

消费者2：

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Rouing_Consumer2 {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道

        String queue1Name = "test_direct_queue1";
        String queue2Name = "test_direct_queue2";

        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            /*
            回调方法，当收到消息后，自动执行该方法
            1.consumerTag：标识
            2.envelope:获取一些信息，交换机，路由key
            3.properties：配置信息
            4.body：数据
            */
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("consumer输出: " + new String(body));
                System.out.println("--将日志打皱到控制台--");
            }
        };

        channel.basicConsume(queue2Name,true,defaultConsumer);
        // 不需要关闭资源
    }
}

```

执行生产者，发现交换机与队列进行了绑定：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673864620660.png)

再启动两个消费者，修改生产者消息的日志级别为`error` ,两个控制台一共输出：

消费者1

```bash
consumer输出: 日志信息：张三调用了findAll方法...日志级别:error...
--将日志打皱到控制台--
```

消费者2

```bash
consumer输出: 日志信息：张三调用了findAll方法...日志级别:info...
--将日志打皱到控制台--
consumer输出: 日志信息：张三调用了findAll方法...日志级别:error...
--将日志打皱到控制台--

```

#### Topic通配符模式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/16/1673869246996.png)

topic模式是Routing模式的加强模式。是对RouingKey的通配。

topic 模式不能具有任意的 routingKey，必须由一个英文句点号“.”分隔的字符串（我们将被句点号“.”分隔开的每一段独立的字符串称为一个单词），*“\**”用于匹配一个单词，“#”用于匹配多个单词（可以是零个）。

生产者：

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Topics_Product {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道
        /*
        exchangeDeclare(String exchange, BuiltinExchangeType type, boolean durable, boolean autoDelete, boolean internal, Map<String, Object> arguments)
         1.exchange:交换机名称
         2.type:交换机类型
            DIRECT("direct"),定向
            FANOUT("fanout"),扇形（广播），发送到每一个队列
            TOPIC("topic"),通配符的方式
    H       EADERS("headers");参数匹配
         3.durable：是否持久化
         4.autoDelete：自动删除
         5.internal：内部使用。一般为false
         6.arguments：参数
         */
        String exchangeName="test_topic";
        //5.创建交换机
        channel.exchangeDeclare(exchangeName, BuiltinExchangeType.TOPIC,true,false,false,null);
        String queue1Name = "test_topic_queue1";
        String queue2Name = "test_topic_queue2";
        channel.queueDeclare(queue1Name,true,false,false,null);
        channel.queueDeclare(queue2Name,true,false,false,null);
        //7.绑定队列和交换机
        /*
        queueBind(String queue, String exchange, String routingKey)
        参数：
            1.queue:队列名称
            2.exchange:交换机名称
            3.routingKey:路由键，绑定规则
                如果交换机的类型为fanout，routingKey设置为""
         */

        //队列1绑定error
        channel.queueBind(queue1Name,exchangeName,"*.error");
        channel.queueBind(queue1Name,exchangeName,"order.*");
        //队列2绑定 info，error，warning
        channel.queueBind(queue2Name,exchangeName,"*.*");

        //8.发送消息
        String msgLevel = "order.info";
        String body="日志信息：张三调用了findAll方法...日志级别:"+msgLevel+"...";
        channel.basicPublish(exchangeName,msgLevel,null,body.getBytes());
        //9.释放资源
        channel.close();
        connection.close();
    }

}

```

消费者1：

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Topic_Consumer1 {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道

        String queue1Name = "test_topic_queue1";
        String queue2Name = "test_topic_queue2";

        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            /*
            回调方法，当收到消息后，自动执行该方法
            1.consumerTag：标识
            2.envelope:获取一些信息，交换机，路由key
            3.properties：配置信息
            4.body：数据
            */
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("consumer输出: " + new String(body));
                System.out.println("--将日志打皱到控制台--");
            }
        };

        channel.basicConsume(queue1Name,true,defaultConsumer);
        // 不需要关闭资源
    }
}

```

消费者2：

```java
package com.zhuangjie.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Topic_Consumer2 {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("192.168.87.201");           // 设置MQ所在机器IP进行连接
        factory.setPort(5672);                        // 指定MQ服务端口
        factory.setUsername("admin");                 // 指定MQ账号名
        factory.setPassword("3333");
        factory.setVirtualHost("/mqvm");              // 指定使用的VirtualHost
        Connection connection = factory.newConnection();    // 创建连接
        Channel channel = connection.createChannel();       // 创建信道

        String queue1Name = "test_topic_queue1";
        String queue2Name = "test_topic_queue2";

        DefaultConsumer defaultConsumer = new DefaultConsumer(channel) {
            /*
            回调方法，当收到消息后，自动执行该方法
            1.consumerTag：标识
            2.envelope:获取一些信息，交换机，路由key
            3.properties：配置信息
            4.body：数据
            */
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                System.out.println("consumer输出: " + new String(body));
                System.out.println("--将日志打皱到控制台--");
            }
        };

        channel.basicConsume(queue2Name,true,defaultConsumer);
        // 不需要关闭资源
    }
}

```

测试：

消费者1：`*.error` 、`order.*`

消费者2：`*.*`

在上面通配符"`order.info`" 启动生产者，然后启动两个消费者 , 消费者1、消费者2 都会消费，换到“`product.info`”后消费者1不会消费，消费者2会消费。

#### RPC模式

略

## \[2] spring整合RabbitMQ&#x20;

与Spring整合目录结构， 下面代码下载：[点击下载](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/17/rabbit-mq-spring.zip "点击下载")

解析：

-   不管是消费模块还是生产模块都有`rabbitmq.properties` 文件，里面存储的是 MQ的登录信息。
-   `pom.xml` 的依赖文件都是一样的。
-   注意在spring中他们声明的交换机、队列等信息都是放在xml配置文件中

    生产者：`spring-rabbitmq-product.xml`

    消费者：`spring-rabbitmq-consumer.xml`
-   在测试代码上，生产者只有一个测试文件，不像消费者要定义一个监听类(`SpringQueueListener.java`)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/17/1673942193652.png)

## \[3] SpringBoot整合RabbitMQ

### 3.1 生产者模块

创建一个模块`springboot-rabbit-product` （maven模块）

#### **pom.xml**

```xml
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.2.6.RELEASE</version>
        <relativePath/>
    </parent>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-amqp</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
```

#### 普通主启动类

```java
package com.zhuangjie.springbootRabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductMain {
    public static void main(String[] args) {
        SpringApplication.run(ProductMain.class,args);
    }
}
```

#### application.yml

```yaml
spring:
  rabbitmq:
    host: 192.168.87.201
    username: admin
    password: 3333
    virtual-host: /mqvm
    port: 5672
```

#### 配置类：交换机、队列声明配置

在  包 → config → RabbitMQConfig.java

```java

package com.zhuangjie.springbootRabbitmq.config;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    public static final String EXCHANGE_NAME = "springboot_topic_exchange";
    public static final String QUEUE_NAME = "springboot_topic_queue";

    // 交换机
    @Bean("bootExchange")
    public Exchange bootExchange() {
        return ExchangeBuilder.topicExchange(EXCHANGE_NAME).durable(true).build();
    }
    // 队列
    @Bean("bootQueue")
    public Queue bootQueue() {
        return QueueBuilder.durable(QUEUE_NAME).build();
    }
    //3.队列和交换就绑定关系 Binding
    /*
    1.知道哪个队列
    2.知道哪个交换机
    3.routing key
     */
    @Bean
    public Binding bindingQueueExchange(@Qualifier("bootExchange") Exchange exchange, @Qualifier("bootQueue") Queue queue) {
        return BindingBuilder.bind(queue).to(exchange).with("#.error").noargs();
    }






}

```

#### 测试类

在test下

注意包要相同，否则会报错：java.lang.IllegalStateException: Unable to find a @SpringBootConfiguration, you need to use @ContextConfiguration or @SpringBootTest(classes=...) with your test

```java
package com.zhuangjie.springbootRabbitmq;

import com.zhuangjie.springbootRabbitmq.config.RabbitMQConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ProductTest {
    @Resource
    private RabbitTemplate rabbitTemplate;

    @Test
    public void productSend() {
        rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME,"order.error","将error信息写入日志文件~");
    }

}

```

### 3.2 消费者模块

#### pom.xml

```xml
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.2.6.RELEASE</version>
        <relativePath/>
    </parent>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-amqp</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
```

#### 普通主启动类

```java
package com.zhuangjie.springbootRabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductMain {
    public static void main(String[] args) {
        SpringApplication.run(ProductMain.class,args);
    }
}
```

#### application.yml

```yaml
spring:
  rabbitmq:
    host: 192.168.87.201
    username: admin
    password: 3333
    virtual-host: /mqvm
    port: 5672
```

#### 监听类

包 → listener → RabbitMQListener.java

```java
package com.zhuangjie.springbootRabbitmq.listener;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class RabbitMQListener {
    @RabbitListener(queues = "springboot_topic_queue")
    public void ListenerQueue(Message message) {
        System.out.println(new String(message.getBody()));
    }

}

```

### 3.3 测试

生产者模块：执行测试类 （普通启动信息输出到控制台）

消费者模块：启动主启动类 (发现消息会输出到控制台)

```bash
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.2.6.RELEASE)

2023-01-17 17:14:57.454  INFO 6836 --- [           main] c.z.springbootRabbitmq.ConsumerMain      : Starting ConsumerMain on DESKTOP-DCM73A2 with PID 6836 (D:\code\i\rabbit-mq\springboot-rabbit-consumer\target\classes started by zhuangjie in D:\code\i\rabbit-mq)
2023-01-17 17:14:57.456  INFO 6836 --- [           main] c.z.springbootRabbitmq.ConsumerMain      : No active profile set, falling back to default profiles: default
2023-01-17 17:14:58.557  INFO 6836 --- [           main] o.s.a.r.c.CachingConnectionFactory       : Attempting to connect to: [192.168.87.201:5672]
2023-01-17 17:14:58.587  INFO 6836 --- [           main] o.s.a.r.c.CachingConnectionFactory       : Created new connection: rabbitConnectionFactory#424ebba3:0/SimpleConnection@4f2613d1 [delegate=amqp://admin@192.168.87.201:5672//mqvm, localPort= 2728]
2023-01-17 17:14:58.631  INFO 6836 --- [           main] c.z.springbootRabbitmq.ConsumerMain      : Started ConsumerMain in 1.689 seconds (JVM running for 2.464)
将error信息写入日志文件~
```

[代码下载](https://raw.githubusercontent.com/18476305640/typora/master/images/2023/01/17/rabbit-mq-springboot.zip "代码下载")

## \[4] RabbitMQ的高级特性

### 4.1 product-消息的可靠投递

在使用 RabbitMQ 的时候，作为消息发送方希望杜绝任何消息丢失或者投递失败场景。RabbitMQ 为我们提供了`两种`方式用来控制消息的投递可靠性模式。

-   `confirm`确认模式
-   `return` 退回模式

rabbitmq整个消息投递的路径为:
producer--->rabbitmg broker--->exchange--->queue--->consumer

消息从 producer到exchange 则会返回一个 `confirmCallback`   （失败/成功都会调用）

消息从exchange-->queue 投递失败则会返回一个 `returnCallback`。 (只失败调用)

我们将利用这两个callback 控制消息的可靠性投递。

#### confirm (product → exchange)

在前面与springboot整合的基本案例下，在生产端加入两点，即可实现confirm 。

1、application.yml

```yaml
spring:
  rabbitmq:
    ...
    #新版本使用这个即可
    publisher-confirm-type: correlated
    #老版本的话用下面这个即可 开启确认模式
    #publisher-confirms: true
```

2、在 投递前，设置一下 `RabbitTemplate`  对象。 `rabbitTemplate.setConfirmCallback ...`

```java
package com.zhuangjie.springbootRabbitmq;

import com.zhuangjie.springbootRabbitmq.config.RabbitMQConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;


@SpringBootTest
@RunWith(SpringRunner.class)
public class ProductTest {
    @Resource
    private RabbitTemplate rabbitTemplate;

    @Test
    public void productSend() {
        rabbitTemplate.setConfirmCallback(new RabbitTemplate.ConfirmCallback() {
            /**
             *
             * @param correlationData 相关配置信息
             * @param ack 交换机是否成功收到消息
             * @param cause 错误信息
             */
            @Override
            public void confirm(CorrelationData correlationData, boolean ack, String cause) {
                if (ack){
                    System.out.println("消息成功送达！");
                }else {
                    System.out.println("消息发送失败");
                    System.out.println("错误原因" + cause);
                }
            }});
        rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME,"order.error","将error信息写入日志文件~");
    }

}

```

测试：想要消息 product → exchange失败，只需要将send发送的exchange设置为不存在的exchange即可。

#### return (exchange → queue)

在前面与springboot整合的基本案例下，在生产端加入两点，即可实现return。

1、开启消息`return` 失败后，执行回调

方式一：（全局配置）

```yaml
spring:
  rabbitmq:
    ...
    publisher-returns: true
```

方式二：在消息发送前设置 （局部设置）

```java
rabbitTemplate.setMandatory(true);
```

2、设置return回调函数 `rabbitTemplate.setReturnCallback(...`

```java
package com.zhuangjie.springbootRabbitmq;

import com.zhuangjie.springbootRabbitmq.config.RabbitMQConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;


@SpringBootTest
@RunWith(SpringRunner.class)
public class ProductTest {
    @Resource
    private RabbitTemplate rabbitTemplate;

    @Test
    public void productSend() {
        //设置交换机处理失败消息的模式
        //rabbitTemplate.setMandatory(true);

        //2.设置ReturnCallBack
        rabbitTemplate.setReturnCallback(new RabbitTemplate.ReturnCallback() {
            /**
             *
             * @param message   消息对象
             * @param replyCode 错误码
             * @param replyText 错误信息
             * @param exchange  交换机
             * @param routingKey 路由键
             */
            @Override
            public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
                System.out.println("return 执行了....");

                System.out.println(message);
                System.out.println(replyCode);
                System.out.println(replyText);
                System.out.println(exchange);
                System.out.println(routingKey);

                //处理
            }
        });
        rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME,"2order.error2","将error信息写入日志文件~");
    }

}

```

测试：只需要设置RouingKey为不匹配任何Queue的就会 `result`失败

### 4.2 consumer-消息可靠性投递

ack指Acknowledge，确认。 表示消费端收到消息后的确认方式

有三种确认方式

自动确认: acknowledge="none
手动确认: acknowledge="manual"
根据异常情况确认: acknowledge="auto”(这种方式使用麻烦，不作讲解)

其中自动确认是指，当消息一旦被Consumer接收到，则自动确认收到，并将相应 message 从 RabbitMQ的消息缓存中移除。但是在实际业务处理中，很可能消息接收到，业务处理出现异常，那么该消息就会丢失。如果设置了手动确认方式，则需要在业务处理成功后，调用channel.basicAck0，手动签收，如果出现异常，则调用channel.basicNack0方法，让其自动重新发送消息。

#### consumer-Ack

在前面与springboot整合的基本案例下，在生产端加入两点，即可实现消费端手动Ack。

1、开启手动Ack （消费端application.yml）

```yaml
spring:
  rabbitmq:
    ...
    listener:
      simple:
        acknowledge-mode: manual
```

2、修改监听器（消费端代码）

```java
package com.zhuangjie.springbootRabbitmq.listener;

import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class AckListener {
    @RabbitListener(queues = "springboot_topic_queue")
    public void ListenerQueue(String content, Message message, Channel channel) throws IOException {
        long deliveryTag = message.getMessageProperties().getDeliveryTag();

        try {
            //1.接收转换消息
            System.out.println(new String(message.getBody()));

            //2. 处理业务逻辑
            System.out.println("处理业务逻辑..."+content);
//            int i = 3/0;//出现错误
            //3. 手动签收
            channel.basicAck(deliveryTag,true);
        } catch (Exception e) {
            //e.printStackTrace();

            //4.拒绝签收
            /*
            第三个参数：requeue：重回队列。如果设置为true，则消息重新回到queue，broker会重新发送该消息给消费端
             */
            channel.basicNack(deliveryTag,true,true);
            //channel.basicReject(deliveryTag,true);
        }
    }

}

```

### 4.3 限流

1、需要确保是手动ack

2、配置

```yaml
spring:
  rabbitmq:
    ...
    listener:
      simple:
        # 确保是手动ack
        acknowledge-mode: manual
        # 配置一次从MQ中拉取消息的数量
        prefetch: 500
        # 处理消息的并发数（MIN）
        concurrency: 3
        # 处理消息的最大并发数（MAX）
        max-concurrency: 5



```

### 4.4 ttl

下面要设置的是消息过期ttl

#### 指定消息的过期时间

在生产模块中，配置一下Queue的Bean，这是在最开始整合就写的代码，现在 只是修改它。

```java

package com.zhuangjie.springbootRabbitmq.config;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    ...
    
    // 队列
    @Bean("bootQueue")
    public Queue bootQueue() {
        // 配置队列消息的ttl（过期时间）
        return QueueBuilder.durable(QUEUE_NAME).ttl(50000).build();
    }
    ...
    
}

```

注意：如果之前有该队列，需要删除，否则执行报错！！

#### 给队列中的所有消息设置过期时间

在发送消息时指定，设置的是Message对象。

此种过期，当过期消息在最上面时，过期后会被清除，如果消息在队列中间，过期也不会清除。

```java
package com.zhuangjie.springbootRabbitmq;

import com.zhuangjie.springbootRabbitmq.config.RabbitMQConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;


@SpringBootTest
@RunWith(SpringRunner.class)
public class ProductTest {
    @Resource
    private RabbitTemplate rabbitTemplate;

    @Test
    public void productSend() {
        for (int i = 0; i < 1000; i++) {
          
            // 设置过期消息为顶层消息，过期时会被清除，如果过期消息在中间，即使过期了，也不会被清除。
            if (i == 0) {
                // 对消息单独设置ttl
                MessageProperties messageProperties = new MessageProperties();
                messageProperties.setExpiration("5000"); // 设置过期时间，单位：毫秒
                byte[] msgBytes = "测试消息自动过期".getBytes();
                Message message = new Message(msgBytes, messageProperties);
                rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME,"order.error",message);
                continue;
            }

            rabbitTemplate.convertAndSend(RabbitMQConfig.EXCHANGE_NAME,"order.error","消息编号："+i+", 将error信息写入日志文件~");

        }
    }

}

```

### 4.5 死信队列

#### 核心讲解

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674038074758.png)

RabbitMQ中的死信与其它的MQ产品的死信不同，RabbitMQ有死信交换器，不像其它的，是直接加入死信Queue中。

**在RabbitMQ中什么情况会加入死信队列？**

1、`auto` 签收模式，超过最大重试时或`manual` 模式拒收且不放入原队列时

2、消息过期

3、超过队列存储长度限制时

**如何设置死信队列？**

首先要知道RabbitMQ中的死信交换机与死信队列 与普通的没有区别，我们只需要设置队列，当队列中的消息成为死信交给死信交换机路由到死信队列中。

所以只需要给普通工作的Queue , 设置如下参数：

-   信交换机:`x-dead-letter-exchange`，
-   死信消息路由键:`x-dead-letter-routing-key`

在springboot中，生产模块

1、定义一个死信交换机与死信队列（与普通的无区别）

2、在声明普通Queue时，设置上面两个参数

```java
    @Bean("bootQueue")
    public Queue bootQueue() {
        return QueueBuilder.durable(QUEUE_NAME).deadLetterExchange("dlx_exchange").deadLetterRoutingKey("dlx.order").build();
    }
```

#### 几种成为死信的实验

**实验一**：过期，加入队列

在声明Queue，给消息指定过期时间

```java
    @Bean("bootQueue")
    public Queue bootQueue() {
        return QueueBuilder.durable(QUEUE_NAME).ttl(5000).build();
    }
```

过期会消息转到死信，已测试！

**实验二**：`auto` 签收模式，超过最大重试时或`manal` 模式拒收且不放入原队列时

`auto`子实验 ：且最大重试次数（注意如果不是auto没有最大重试的配置，需要我们在代码中判断）

```yaml
spring:
  rabbitmq:
    ...
    listener:
      simple:
        acknowledge-mode: auto
        retry:
          enabled: true
          # 第一次尝试时间间隔
          initial-interval: 1S
          # 两次尝试之间的最长持续时间。
          max-interval: 1S
          # 最大重试次数(=第一次正常投递1+重试次数4)
          max-attempts: 5
          # 上一次重试时间的乘数
          multiplier: 1.0
```

当处理报错时，表示失败。

`manual`子实验 : 设置为`manual`  且处理出错，拒收且不放入原队列

```yaml
spring:
  rabbitmq:
    ...
    listener:
      simple:
        acknowledge-mode: manual

```

监听类：

```java
package com.zhuangjie.springbootRabbitmq.listener;

import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class AckListener {
    @RabbitListener(queues = "springboot_topic_queue")
    public void ListenerQueue(String content, Message message, Channel channel) throws IOException, InterruptedException {
        System.out.println("=="+Thread.currentThread().getName()+"==");
        long deliveryTag = message.getMessageProperties().getDeliveryTag();
        try {
            //1.接收转换消息
            System.out.println(new String(message.getBody()));
            //2. 处理业务逻辑
            System.out.println("处理业务逻辑..."+content);
            int i = 3/0;//出现错误
            //3. 手动签收
            channel.basicAck(deliveryTag,true);
        } catch (Exception e) {
            //4.拒绝签收
            /*
            第三个参数：requeue：重回队列。如果设置为true，则消息重新回到queue，broker会重新发送该消息给消费端
             */
            channel.basicNack(deliveryTag,true,false);
            //channel.basicReject(deliveryTag,true);
        }
    }

}

```

**实验三**：超过队列存储长度限制时加入队列

在配置生产模块Queue时，设置参数 `x-max-length`&#x20;

```java
    @Bean("bootQueue")
    public Queue bootQueue() {
        return QueueBuilder.durable(QUEUE_NAME).maxLength(5).deadLetterExchange("dlx_exchange").deadLetterRoutingKey("dlx.order").build();
    }
```

### 4.6 延迟队列

表示消息进入队列后，可以延迟一段时间后再消费，但RabbitMQ没有延迟队列，但我们可以使用`ttl`+`dlx` 实现。

**延迟队列有什么作用？**

比如下单后，等30分钟后，查看订单状态，如果未支持，取消订单，回滚库存。流程如下：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674042276767.png)

RabbitMQ中实现延迟队列

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674042308715.png)

具体实现：请参考本文`死信队列`的`实验一`

### 4.7 日志与监控

RabbitMQ的日志默认存放在：/var/log/rabbitmq/rabbit@<主机名>.log

监控：RabbitMQ的web管理器

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674043686311.png)

RabbitMQ命令：

```bash
# 查看队列
rabbitmqctl list queues
# 查看exchanges
rabbitmqctl list exchanges
# 查看用户
rabbitmqctl list users
# 查看连接
rabbitmqctl list connections
# 查看环境变量
rabbitmgctl environment
# 查看未被确认的队列
rabbitmqctl list queues name messages unacknowledged
# 查看单个队列的内存使用
rabbitmgctl list queues name memory
# 查看准备就绪的队列
rabbitmqctl list queues name messages ready
# 查看消费者信息
rabbitmgctl list consumers
```

### 4.8 消息追踪

在使用任何消息中间件的过程中，难免会出现某条消息异常丢失的情况。对于RabbitMQ而言，可能是因为生产者或消费者与RabbitMQ断开了连接，而它们与RabbitMQ又采用了不同的确认机制;也有可能是因为交换器与队列之间不同的转发策略，甚至是交换器并没有与任何队列进行绑定，生产者又不感知或者没有采取相应的措施:另外RabbitMO本身的集群策略也可能导致消息的丢失。这个时候就需要有一个较好的机制跟踪记录消息的投递过程，以此协助开发和运维人员进行问题的定位。

在RabbitMQ中可以使用Firehose和rabbitmq tracing插件功能来实现消息追踪

#### 方式一：Firehose

firehose 的机制是将生产者投递给 rabbitmq 的消息，rabbitmq 投递给消费者的消息按照指定的格式发送到默认的 exchange上。这个默认的 exchange 的名称为 amq.rabbitmq.trace，它是一个 topic 类型的 exchange。

发送到这个 exchange 上的消息的 routing key 为 `publish.exchangename` 和 `deliver.queuename`。其中 `exchangename` 和 `queuename`为实际 `exchange` 和 `queue` 的名称，分别对应生产者投递到 exchange 的消息，和消费者从 queue 上获取的消息。

“publish.#”匹配发送到所有交换器的消息，“deliver.#”匹配消费所有队列的消息，而“#”则包含了“publish.#”和“deliver.#”。

注意：打开 trace 会显示的消息会更加详细，但影响MQ的性能，适当打开后请关闭。

-   rabbitmqctl trace\_on：开启 Firehose 命令
-   rabbitmqctl trace\_off：关闭 Firehose 命令

创建下面的几个队列（一个也可以），是“/”虚拟机的，然后将队列绑定到`amq.rabbitmq.trace` 交换机。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674048683902.png)

这样我们随便向“/”虚拟机上的队列发送消息， RouingKey为`publish.#` 的`queue1` 队列都会收到消息。

#### 方式二：rabbitmq tracing插件

rabbitmq tracing和Firehose在实现上如出一辙，只不过rabbitmg tracing的方式比Firehose多了-层GUI的包装，更容易使用和管理。
启用插件: rabbitmq-plugins enable rabbitmq\_tracing

那在Admin 页的右侧就有`Tracing`

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674049089664.png)

创建, 那么我们“/”虚拟机上给Queue发的消息都会有记录。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674056222838.png)

记录在：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674056357333.png)

## \[5] 应用问题

### 5.1 消息补偿

我们通过之前的消息可靠性投递 , ACK 确认机制 , 以及死信队列 , 基本上已经能够保证消息投递成功了 !

为什么还要消息补偿机制呢？ 难道消息还会丢失，没错，系统是在一个复杂的环境，不要想的太简单了，虽然以上的三种方案，基本可以保证消息的高可用不丢失的问题，但是作为有追求的程序员来讲，要绝对保证我的系统的稳定性，有一种危机意识。

比如：持久化的消息，保存到硬盘过程中，当前队列节点挂了，存储节点硬盘又坏了，消息丢了，怎么办？

产线网络环境太复杂，所以不知数太多，所以要做消息补偿机制 !

消息补偿机制需要建立在业务数据库和MQ数据库的基础之上 , 当我们发送消息时 , 需要同时将消息数据保存在数据库中, 两者的状态必须记录。 然后通过业务数据库和MQ数据库的对比检查消费是否成功，不成功，进行消息补偿措施，重新发送消息处理

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/18/1674057196193.png)

### 5.2 幂等性保障

幂等是源于一种数学概念。其主要有两个定义

如果在一元运算中，x 为某集合中的任意数，如果满足 f(x) = f(f(x)) ，那么该 f 运算具有幂等性，比如绝对值运算 abs(a) = abs(abs(a)) 就是幂等性函数。

在数学中幂等的概念或许比较抽象，但是在开发中幂等性是极为重要的。简单来说，**对于同一个系统，在同样条件下，一次请求和重复多次请求对资源的影响是一致的，就称该操作为幂等的**。

在RabbitMQ中消息队列发送 ACK 消息到生产者过程出现的问题开启 ACK 确认机制后，发送方发送消息之后，消息队列发送 ACK 确认的时候，如果由于网络波动造成 ACK 消息丢失，发送方重复发送造成的消息重复。

那出现重复的消息时，如何保障幂等性呢？

1.  消息中携带全局唯一的 id，当消息重复发送时，检查该全局唯一 id 是否存在于数据库中。（当消息消费前与后全局id都存在，那我们就要使用乐观锁, 利用版本号解决了）
2.  使用 redis 记录已经消费的消息，当消息消费之后使用 redis 记录，当重复消费的时候直接返回 ACK 即可。

## \[6] 集群搭建

### 6.1 节点加入到集群

已存在两个主机节点（`rabbit_mq_node1`、`rabbit_mq_node2` ）, 都安装了rabbit-mq ,  开始让`rabbit_mq_node2`加到集群`rabbit_mq_node1`中，

1、确保主机名分别是`rabbit_mq_node1`与`rabbit_mq_node2`&#x20;

2、确保后面执行命令时，能知道`rabbit_mq_node1`或`rabbit_mq_node2` 对应的主机ip，设置一个两台机器的hosts文件：

```bash
# 注意是hosts不是host
cat << EOF >> /etc/hosts
192.168.87.201 rabbit_mq_node1
192.168.87.202 rabbit_mq_node2
EOF

```

3、在加入集群时，需要确保集群机器的 `/var/lib/rabbitmq/.erlang.cookie` 保持一致

在 `rabbit_mq_node2` 机器&#x20;

```bash
scp /var/lib/rabbitmq/.erlang.cookie rabbit_mq_node2:/var/lib/rabbitmq/
# 如果操作下面这个命令，会出现： [error] Error when reading /var/lib/rabbitmq/.erlang.cookie: eacces
chown rabbitmq:rabbitmq /var/lib/rabbitmq/.erlang.cookie：：

```

4、开始将`rabbit_mq_node2`加到集群`rabbit_mq_node1`中

`rabbit_mq_node1` 需要执行命令：

```bash
rabbitmqctl stop_app
rabbitmqctl reset
rabbitmqctl start_app

```

`rabbit_mq_node2` 需要执行命令：

```bash
rabbitmqctl stop_app
rabbitmqctl reset
# 加入集群命令
rabbitmqctl join_cluster rabbit@rabbit_mq_node1
rabbitmqctl start_app
```

查看集群状态

```bash
# 查看集群状态
rabbitmqctl cluster_status


# 输出信息如下：
...
Disk Nodes

rabbit@rabbit_mq_node1
rabbit@rabbit_mq_node2

Running Nodes

rabbit@rabbit_mq_node1
rabbit@rabbit_mq_node2
...


```

5、初步测试

现在两台机器rabbitmq都成功启动了，访问两台机器

[http://192.168.87.201:15672/](http://192.168.87.201:15672/ "http://192.168.87.201:15672/")

[http://192.168.87.202:15672/](http://192.168.87.202:15672/ "http://192.168.87.202:15672/")

在登录时，发现无法登录，我们创建一个用户 （两台任意一台都可以）

```bash
# 添加一个新的用户 创建账号 
rabbitmqctl add_user admin 3333

# 设置用户角色 
rabbitmqctl set_user_tags admin administrator 

#设置用户权限 语法：rabbitmqctl  set_permissions [-p <vhostpath>] <user> <conf> <write> <read>
rabbitmqctl set_permissions -p "/" admin ".*" ".*" ".*"  # 具有/vhost1 这个 virtual host 中所有资源的配置、写、读权限

#当前用户和角色 
rabbitmqctl list_users
```

发现别一台web管理器都可以用该账号admin/3333 登录了。

在任意一个web管理器创建Queue发送消息，发现别一台web管理器也有了数据。

存在的问题，当master 机器停止了，发现刚才创建的消息数据：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/19/1674110906351.png)

我们需要让节点进行同步，在任意一台节点机器

```bash
rabbitmqctl set_policy my_ha "^" '{"ha-mode":"all"}'
```

> 这样我们就可以在web管理页面 **Admin->Policies** 看到创建的 `my_ha` 的policie 了，所以当然也可以使用界面创建。
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/19/1674111196195.png)
>
> -   Name:策略名称
> -   Pattern：匹配的规则，如果是匹配所有的队列，是^.
> -   Definition:使用ha-mode模式中的all，也就是同步所有匹配的队列。问号链接帮助文档。

这样节点就创建好了。

### 6.2统一访问入口 (HAProxy)

创建统一访问入口，即创建负载均衡-HAProxy

**HAProxy**

HAProxy提供高可用性、负载均衡以及基于TCP和HTTP应用的代理，支持虚拟主机，它是免费、快速并且可靠的一种解决方案,包括Twitter，Reddit，StackOverflow，GitHub在内的多家知名互联网公司在使用。HAProxy实现了一种事件驱动、单一进程模型，此模型支持非常大的并发连接数。

**安装HAProxy**

下载Haproxy包：[http://www.haproxy.org/#down](http://www.haproxy.org/#down "http://www.haproxy.org/#down")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/19/1674113843111.png)

```bash
//下载依赖包
yum install gcc vim wget
//上传haproxy源码包
wget http://www.haproxy.org/download/2.7/src/haproxy-2.7.1.tar.gz
//解压
tar -zxvf haproxy-2.7.1.tar.gz -C /usr/local
//进入目录、进行编译、安装
cd /usr/local/haproxy-2.7.1
make TARGET=linux31 PREFIX=/usr/local/haproxy
make install PREFIX=/usr/local/haproxy
mkdir /etc/haproxy
//赋权
groupadd -r -g 149 haproxy
useradd -g haproxy -r -s /sbin/nologin -u 149 haproxy
//创建haproxy配置文件
mkdir /etc/haproxy
vim /etc/haproxy/haproxy.cfg
```

```纯文本
#全局配置
global
    #设置日志
    log 127.0.0.1 local0 info
    #当前工作目录
    chroot /usr/local/haproxy
    #用户与用户组
    user haproxy
    group haproxy
    #运行进程ID
    uid 99
    gid 99
    #守护进程启动
    daemon
    #最大连接数
    maxconn 4096

#默认配置
defaults
    #应用全局的日志配置
    log global
    #默认的模式mode {tcp|http|health}
    #TCP是4层，HTTP是7层，health只返回OK
    mode tcp
    #日志类别tcplog
    option tcplog
    #不记录健康检查日志信息
    option dontlognull
    #3次失败则认为服务不可用
    retries 3
    #每个进程可用的最大连接数
    maxconn 2000
    #连接超时
    timeout connect 5s
    #客户端超时
    timeout client 120s
    #服务端超时
    timeout server 120s

#绑定配置
listen rabbitmq_cluster 
        bind 0.0.0.0:5671
        #配置TCP模式
        mode tcp
        #简单的轮询
        balance roundrobin
        #RabbitMQ集群节点配置
  server node1 192.168.87.201:5672 check inter 5000 rise 2 fall 2
  server node2 192.168.87.202:5672 check inter 5000 rise 2 fall 2

#haproxy监控页面地址
listen monitor 
        # web访问端口
        bind 0.0.0.0:8100
        mode http
        option httplog
        stats enable
        # web访问路径：http://<ip>:8100/stats
        stats uri /stats
        stats refresh 5s

```

```bash
# 启动
/usr/local/haproxy/sbin/haproxy -f /etc/haproxy/haproxy.cfg
//查看haproxy进程状态
ps -ef | grep haproxy

```

访问如下地址对mq节点进行监控 （下面的8100与/stats 访问路径是上面配置的）
<http://192.168.87.201:8100/stats>

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/19/1674114223650.png)

以后用代码操作就是上面`haproxy.cfg` 文件配置的 `5671` 端口。

（因为Haproxy与node1在同一机器上6572被占用了，建议再加一台安装 haproxy软件）

[\[待回收\]尚硅谷版-RabbitMQ消息中间件](\[待回收]尚硅谷版-RabbitMQ消息中间件/\[待回收]尚硅谷版-RabbitMQ消息中间件.md "\[待回收]尚硅谷版-RabbitMQ消息中间件")
