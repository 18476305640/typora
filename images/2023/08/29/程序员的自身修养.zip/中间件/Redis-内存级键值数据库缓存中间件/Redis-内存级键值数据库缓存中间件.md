# Redis-内存级键值数据库缓存中间件

## 1. Redis入门概述

### 1.1 Redis是什么&#x20;

Remote Dictionary Server(远程字典服务)是完全开源的，使用ANSIC语言编写遵守BSD协议，是一个高性能的Key-Value数据库提供了丰富的数据结构，例如String、Hash、List、Set、SortedSet等等。数据是存在内存中的，同时Redis支持事务、持久化、LUA脚本、发布/订阅、缓存淘汰、流技术等多种功能特性提供了主从模式、Redis Sentinel和Redis Cluster集群架构方案

来自官网：[https://redis.io/docs/about/](https://redis.io/docs/about/ "https://redis.io/docs/about/")

**作者：**

Redis之父Salvatore Sanfilippo，一名意大利程序员，大家更习惯称呼他Antirez （安特雷兹）

Github：[https://github.com/antirez](https://github.com/antirez "https://github.com/antirez")

个人博客：[http://antirez.com/latest/0](http://antirez.com/latest/0 "http://antirez.com/latest/0")

### 1.2 Redis能干嘛

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/06/1678111081844.png)

#### Redis主流功能与应用

-   作为分布式缓存，挡在mysql数据库之前的带刀护卫。
-   内存存储和持久化(RDB+AOF)，redis支持异步将内存中的数据写到硬盘上，即使到宕机也再次启动时也不会导致缓存失效。
-   高可用架构搭配：单体、主从、哨兵、集群
-   缓存穿透、击穿、雪崩
-   分布锁
-   队列

功能一览图：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/06/1678112258295.png)

#### 优势

-   性能极高 - Redis能读的速度是110000次/秒,写的速度是81000次/秒
-   Redis数据类型丰富，不仅仅支持简单的key-value类型的数据，同时还提供list，set，zset，hash等数据结构的存储
-   Redis支持数据的持久化，可以将内存中的数据保持在磁盘中重启的时候可以再次加载进行使用
-   Redis支持数据的备份，即master-slave模式的数据备份

总结：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/06/1678112472295.png)

### 1.3 Redis去哪下

开源Github：[https://github.com/redis/redis](https://github.com/redis/redis "https://github.com/redis/redis")

官网：[https://redis.io/](https://redis.io/ "https://redis.io/")

中文：[https://www.redis.com.cn/](https://www.redis.com.cn/ "https://www.redis.com.cn/")

中文2：[https://www.redis.com.cn/documentation.html](https://www.redis.com.cn/documentation.html "https://www.redis.com.cn/documentation.html")

下载：[https://redis.io/download/](https://redis.io/download/ "https://redis.io/download/")

在线命令参考：[http://doc.redisfans.com/](http://doc.redisfans.com/ "http://doc.redisfans.com/")

### 1.4 Redis怎么玩

请往后看...

### 1.5 Redis迭代演化和Redis7新特性浅谈

在线测试：[https://try.redis.io](https://try.redis.io "https://try.redis.io")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/06/1678113435130.png)

**版本的命令规则：** Redis从发布至今，已经有十余年的时光了，一直遵循着自己的命名规则：奇数为非稳定版本（2.7、2.9、3.1），偶数为稳定版本（2.6、2.8、3.0 ...）

各版本新功能

...

## 2. Redis安装配置

安装gcc环境：

```bash
yum install -y gcc-c++
gcc -v
```

下载安装：（根据官网的提示，紧急发布了6.0.8 ,之前版本估计出现了安全Bug, 本次我们使用Redis7）

```bash
wget -P /opt https://github.com/redis/redis/archive/7.0.0.tar.gz
tar -xvf 7.0.0.tar.gz
mv redis-7.0.0 redis-7
cd redis-7
make && make install
# 安装完成后，查看目录
```

redis-benchmark:性能测试工具，服务启动后运行该命令，看看自己本子性能如何

redis-check-aof: 修复有问题的AOF文件，rdb和aof后面讲

redis-check-dump: 修复有问题的dump.rdb文件

**redis-cli: 客户端，操作入口**

redis-sentinel: redis集群使用

**redis-server: Redis服务器启动命令**

```bash
# 在编辑配置文件时，对配置文件进行备份
cp -r /opt/redis-7/redis.conf /opt/redis-7/redis.conf.back
# 编辑配置文件 （改完后确保生效，记得重启，记得重启）
vi /opt/redis-7/redis.conf

```

修改以下：

-   默认daemonize no   ⇒   daemonize yes  后台运行，不随着命令关闭而关闭。
-   默认protected-mode  yes  ⇒  protected-mode no  关闭保护模式，开启时只接受来自本地地址（127.0.0.1或者其他本地IP地址）的客户端连接请求
-   默认bind 127.0.0.1  ⇒  默认表示只能本地连接，需要注释掉
-   requirepass    ⇒   requirepass  XXX    添加redis密码           &#x20;

```bash
# 启动redis服务
redis-server /opt/redis-7/redis.conf
# 登录  （设置了登录不用-a , 也可以直接进入但元操作权限，可以用 auth <密码> 再验证）
redis-cli -a <密码>

```

**警告内容**：下面演示的是Redis的卸载

```bash
# 停止redis服务 （已登录直接shutdown）
redis-cli -a 3333 -p 6379 shutdown
# 卸载
ls -l /usr/local/bin/redis-*
rm -rf /usr/local/bin/redis-*

```

> 想要让外面连接redis, 还需要关闭防火墙
>
> ```bash
> sudo systemctl stop firewalld
> sudo systemctl disable firewalld
> sudo systemctl is-enabled firewalld
>
> ```

## 3. 数据类型及其命令的落地运用

“键”操作命令

`keys *` : 列出当前DB下的key

`exists key` :  查看指定的key是否存在

`type key` : 查看指定key的数据类型

`del key` : 删除一个key

`unlink key` : 异步地删除一个key，请求删除即返回结果（相当于MQ 任务）。

`ttl key` ： 查看指定的key还有多久过期（-2 已过期 - 1永不过期）

`expire key` : 为指定的key设置过期时间

`move key <dbindex>` : 将指定的key移动到指定的DB 下【0-15】

`select <dbindex>` : 切换到指定DB下

`dbsize` ：查看当前db下key的数量

`flushdb` : 清空当前DB下的数据

`flushall` ：清空所有DB下的数据

> 命令不区分大小写，但key区别大小写&#x20;
>
> `help @string` : 查看string类型的操作命令

### 3.1 String （单key单value）

-   `set <key> <value>`   : 设置一项String类型数据。如果已经存在key，且存在ttl，设置时是默认覆盖原来的过期时间的，如果想继承过期时间`set <key> <value> keepttl`。&#x20;
-   `set <key> <value> [ex 过期秒|px 过期毫秒]` : 设置有过期时间的key-value
-   同时设置/获取多个键值
    -   `MSET key value [key value ... ]` :  批量设置给定的k-v
    -   `MGET key [key ... ]`  : 批量获取给定的key的value
    -   `MSETNX key value [key value ... ]` :  批量设置给定的k-v, 但必须都不存在，否则都无法设置。事务性质
-   字符串截取/插入
    -   `getrange <key> <0,> <,length-1>`  : 字符串截取
    -   `setrange key 2 abc` : 将原有index为2位置的向后推三位存放"abc"
    -   `strlen <key>`  : 查看指定key的value长度。
    -   `append <key> <追加内容>` : 字符串追加
-   自增自减：注意value一定要是数字
    -   `INCR <KEY> [增量]`&#x20;
    -   `DECR <KEY> [减量]`
-   判断后set
    -   `setex <key> <过期时间> <value>`  :  当指定的key存在时，覆盖并设置过期时间。
    -   `setnx <key> <value>` : 当指定的key不存在时，设置。

### 3.2 List  (一键多值)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/08/1678256344810.png)

一个双端链表的结构，容量是2的32次方减1个元素，大概40多亿。

可以左右`left`、`right` 两个方向进行push/pop ，一般用在`栈`、`队列`、`消息队列`等场景。

push时：

-   如果键不存在，创建新的链表；
-   如果键已存在，新增内容；

如果值全移除，对应的键也就消失了。

它的底层实际是个**双向链表，对两端的操作性能很高，通过索引下标的操作中间的节点性能会较差。**

操作：

-   `lpush、rpush` : 向list链表左右两边添加元素
-   `lpop、rpop`: 链表的左右pop操作
-   `lrange <key> <start index> <end index>` :  遍历指定遍历的数据。如lrange key 0 -1 就是查看指定key的全部元素。
-   `lindex <key> <index>` : 查看指定list索引值
-   `llen <key>` : 查看指定key的长度。
-   `lrem <key> n v1` : 表示删除指定list的n个值为v1的元素。
-   `ltrim <key> <开始Index> <结束index>` : 截取key的list，再覆盖给key。
-   `rpoplpush <源list>  <目标list>` ：表示源list进行rpop 的元素lpush到目标list中。
    ```bash
    > rpush k1 1 2 3
    3
    > rpush k2 a b c
    3
    > rpoplpush  k1 k2
    3
    > lrange k1 0 -1
    1
    2
    > lrange k2 0 -1
    3
    a
    b
    c
    ```
-   `lset <key> <要修改的index> <value>` : 将list指定已存在的index值set新值。&#x20;
-   `linsert <key> <before/after> <目标value>  <新邻居value>` : 在list指定一个位置（以值锁定）前/后插入一个新值。

**应用场景：** 小明在微信公众号关注了大黑和小黑，他们发布了文章AA、BB ，那AA、BB两个文章都会装进小明的list中，当小明查看订阅消息时：lrange  小明key 0 9。获取10条给小明查看。

### 3.3 hash  ( Map\<String,Map\<Object,Object>> )

-   `hset/hmset`  : 批量设置一个键中的值示例：hmset user id 1 username zhuangjie
-   `hget/hmget` : 批量获取值，示例：hmget user id username
-   `hgetall <key>` : 获取指定key的所有k-v对
-   `hdel <key> <列1> [列2, ... ]` ：删除指定key的对应的map列。
-   `hlen <key>` : 获取某个key内的完整列记录。
-   `hexists <key> <列>` : 查看指定key的列是否存在。
-   `hkeys/hvals <key>`  : 查看指定key的所有key/value
-   `hincrby/hincrbyfloat <key> <field> <增量>` : 让指定key的指定field进行 `+=` 操作
-   `hsetnx <key> <field> <fieldValue>` : 当指定的key的field不存在时，给该key的field设置值。

应用场景：JD购物车早期 设计目前不再采用，当前小中厂可用&#x20;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/08/1678262373398.png)

### 3.4 Set （一键多值（不重复））

-   `SADD <key> <value1> <value2>` : 添加元素 （只添加还不存在的元素）
-   `SMEMBERS <key>` ：遍历指定key set集合中所有元素。
-   `SISMEMBER <key> <value>` ：判断set集合指定key中是否存在指定的vlaue。
-   `SREM <key> <value1> [<value2> ...]` 删除set指定key中指定value
-   `SCARD <key>` : 获取set集合里面的元素个数。
-   `SRANDMEMBER <key> <随机展示元素个数>` ：从指定key集合中随机展现指定元素个数。&#x20;
-   `SPOP <key> <随机弹出个数>` : 从指定key随机弹出指定个数元素。
-   `SMOVE <key1> <key2> <将key1中哪个值移动到key2的set集合中> ` : 元素移动。
-   集合运算：
    -   `SDIFF <key1>  [<key2> ... ]` :  将key1后面key对应的set集合并集去“击打”key1, key1被击中的集合元素将不在命令输出的结果集合中。 （diff）
    -   `SUNION <key1> [<key2> ... ]` ：获取所有key对应的集合的交集。（并集）
    -   `SINTER <key1> [<key2> ... ]` ：所有key对应的set集合交集（交集）。
    -   `SINTERCARD <keyNumber> <key1> [<key2> ... ] limit <输出最大基数> ` ： SINTERCARD是redis7新增的，与SINTER相比，SINTERCARD只返回交集的基数。

应用场景：

-   微信抽奖：

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/08/1678267881015.png)
    |                          |                                                                                                  |
    | ------------------------ | ------------------------------------------------------------------------------------------------ |
    | 1 用户ID，立即参与按钮            | sadd key 用户ID                                                                                    |
    | 2 显示已经有多少人参与了，上图23208人参加 | SCARD key                                                                                        |
    | 3 抽奖(从set中任意选取N个中奖人)     | SRANDMEMBER key 2       随机抽奖2个人，元素不删除&#xA;&#xA;SPOP  key 3                         随机抽奖3个人，元素会删除 |
-   微信朋友圈点赞查看同赞朋友

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/08/1678268062734.png)
    |                       |                                  |
    | --------------------- | -------------------------------- |
    | 1 新增点赞                | sadd pub:msgID  点赞用户ID1  点赞用户ID2 |
    | 2 取消点赞                | srem pub:msgID  点赞用户ID           |
    | 3 展现所有点赞过的用户          | SMEMBERS  pub:msgID              |
    | 4 点赞用户数统计，就是常见的点赞红色数字 | scard  pub:msgID                 |
    | 5 判断某个朋友是否对楼主点赞过      | SISMEMBER pub:msgID 用户ID         |

### 3.5 ZSet (有序的一键多值（ {score,value} ） )

简单说明：ZSet与set有两点不同，set的元素是（v1,v2 ,v3 ...） ，而zset是（ score1:v1, score2:v2 , score3:v3 ）。且ZSet是有序的。

命令：

-   `ZADD <key> <score1 v1> [<score2 v2>  ... ]` : 添加元素
-   `ZRANGE <key> <startIndex> <endIndex> [WITHSCORES]` : 获取指定范围的元素（按分数从小到大），如果指定了`WITHSCORES`  ，将同时返回它们的得分。
    -   `ZREVRANGE <key> <startIndex> <endIndex> [WITHSCORES]` ：与`ZRANGE`区别是`ZREVRANGE `从大到小输出。
-   `ZRANGEBYSCORE <key> [(]<minScore> [(]<maxScore> WITHSCORES ` :  根据分数获取指定范围的元素。其中“（”表示 不包括。 比如`[(]<minScore> [(]<maxScore>` ⇒  `(0 (100  == (0,100)`
-   `ZSCORE <key> <value>` : zset获取指定key下指定value对应的分数。
-   `ZCARD <key>` ：zset获取指定key的元素数据
-   `ZREM <key> <value>` ：删除指定key下的指定value所在的（score,value）的zset元素整体。
-   `ZINCRBY <key> <增量> <value>` : 为指定的key指定的value所在元素的score += 增量。
-   `ZCOUNT <key> <min> <max>` : 获取指定key 指定分数范围 \[min, max] 的元素个数。
-   `ZMPOP <keyCount> <key1> [key2 ... ] <MIN|MAX> [COUNT <弹出个数>]` : 指定一个或多个key, 按指定的MIN/MAX 端弹出指定元素个数 。(如果指定多个key，是从key1按指定的顺序MAX/MIN，全部弹出再到key2 ... )
-   `ZRANK <key> <value>` ： 根据指定的key中指定value获取所在元素的索引。
-   `ZREVRANK <key> <value>`: 根据指定的key中指定value逆序（从右到左）获取所在元素的索引。

**应用场景：**

商品销量排行 : 定义商品销售排行榜(sorted set集合)，key为goods:sellsort，分数为商品销售数量。

|                               |                                      |
| ----------------------------- | ------------------------------------ |
| 商品编号1001的销量是9，商品编号1002的销量是15  | zadd goods:sellsort 9 1001 15 1002   |
| 有一个客户又买了2件商品1001，商品编号1001销量加2 | zincrby goods:sellsort 2 1001        |
| 求商品销量前10名                     | ZRANGE goods:sellsort 0 9 withscores |

### 3.6 Bitmap (位图)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/08/1678284915092.png)

说明：用String类型作为底层数据结构实现的一种统计二值状态的数据类型

位图本质是数组，它是基于String数据类型的按位的操作。该数组由多个二进制位组成，每个二进制位都对应一个偏移量(我们称之为一个索引)。

Bitmap支持的最大位数是2^32位，它可以极大的节约存储空间，使用512M内存就可以存储多达42.9亿的字节信息(2^32 = 4294967296)

**基本命令：**

-   `setbit <key> <index或说offset> <0|1>` ：设置指定key下指定位置\[0,]的状态。
-   `getbit <key> <index>` ：获取指定key指定index的状态
-   `strlen <key>` : 输出单位是b,  1b = 8位
-   `bitcount <key>` ：获取指定key下状态位数量。
    -   `BITCOUNT <key> <startIndex> <startIndex>` ：查看指定范围下状态为1的数量。
-   `bitop` 与 `BITCOUNT`

    连续2天都签到的用户
    加入某个网站或者系统，它的用户有1000W，做个用户id和位置的映射
    比如0号位对应用户id：uid-092iok-lkj
    比如1号位对应用户id：uid-7388c-xxx

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/08/1678286385125.png)

**应用场景：**

用户是否登陆过Y、N，比如京东每日签到送京豆；

电影、广告是否被点击播放过；

钉钉打卡上下班、签到统计；&#x20;

一年365天，全年天天登陆占用多少字节

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/08/1678286952834.png)

按年去存储一个用户的签到情况，365 天只需要 365 / 8 ≈ 46 Byte，1000W 用户量一年也只需要 44 MB 就足够了。

假如是亿级的系统，

每天使用1个1亿位的Bitmap约占12MB的内存（10^8/8/1024/1024），10天的Bitmap的内存开销约为120MB，内存压力不算太高。

此外，在实际使用时，最好对Bitmap设置过期时间，让Redis自动删除不再需要的签到记录以节省内存开销。

### 3.7 HyperLogLog (一键多值，类List)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/1678325960407.png)

不返回原有数据，只返回基数。

应用：

-   统计网站UA（独立访客，一般理解为客户端IP）
-   统计用户网站搜索关键词的数量

命令：

-   `PFADD <key> <value1> [<value2> ... ]` ：添加元素到指定的key中
-   `PFCOUNT <key1> [<key> ... ]`：对给定的一些key中的全部HyperLogLog元素进行真实统计（去重）个数。

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/1678327763372.png)
-   `PFMERGE <mergeKey> <sourceKey1> [<sourceKey2> ...]`   ：将给定的一些sourceKey进行合并成新的HyperLogLog, 对应的key是mergeKey 。

> 底层实现原理：见高阶篇\~

### 3.8 GEO （一键多值（经纬度  位置名））

Redis在3.2版本以后增加了地理位置的处理。

移动互联网时代LBS应用越来越多，交友软件中附近的小姐姐、外卖软件中附近的美食店铺、高德地图附近的核酸检查点等等，那这种附近各种形形色色的XXX地址位置选择是如何实现的？

地球上的地理位置是使用二维的经纬度表示，经度范围 (-180, 180]，纬度范围 (-90, 90]，只要我们确定一个点的经纬度就可以名取得他在地球的位置。

例如：滴滴打车，最直观的操作就是实时记录更新各个车的位置，然后当我们要找车时，在数据库中查找距离我们(坐标x0,y0)附近r公里范围内部的车辆，使用如下SQL即可：

```sql
select taxi from position where x0-r < x < x0 + r and y0-r < y < y0+r
```

**但是这样会有什么问题呢？**

1.  查询性能问题，如果并发高，数据量大这种查询是要搞垮数据库的
2.  这个查询的是一个矩形访问，而不是以我为中心r公里为半径的圆形访问。
3.  精准度的问题，我们知道地球不是平面坐标系，而是一个圆球，这种矩形计算在长距离计算时会有很大误差

GEO 原理：核心思想就是将球体转换为平面，区块转换为一点

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/1678331076262.png)

命令：

> 如果想要避免在命令行下出现中文问题：在启动命令行时：`redis-cli -a <密码> --raw`

-   `GEOADD <key> <经度> <纬度> <地理名> [<经度> <纬度> <地理名> ... ]` ：添加GEO元素
-   `ZRANGE <key> <startIndex> <endIndex>` ：查看元素。不知道你有没有注意，在ZSet类型命令中也有这个命令，从这也可以看出GEO类型跟ZSET类型是紧密相关的。
-   `GEOPOS <key> <地理名1> [<地理是名2> ... ]` ：获取指定地理名对应的经纬度。
-   `GEOHASH <key> <地理名1> [<地理是名2> ... ]`：获取指定地理名对应的hash值（二维-经纬度 ⇒ 一维-hash，geohash算法生成的base32编码值）。
-   `GEODIST <key> <地理名1> <地理名2> [单位，m|km|mi|ft，默认是m]`：计算两个给定位置之间的距离。
-   `GEORADIUS <key> <经度> <纬度> <距离> <距离单位，m|km|mi|ft> [WITHHASH] [WITHDIST] [WITHHASH] [COUNT count]  [desc|asc]`

    解析：

    WITHDIST: 在返回位置元素的同时， 将位置元素与中心之间的距离也一并返回。 距离的单位和用户给定的范围单位保持一致。

    WITHCOORD: 将位置元素的经度和维度也一并返回。

    WITHHASH: 以 52 位有符号整数的形式， 返回位置元素经过原始 geohash 编码的有序集合分值。 这个选项主要用于底层应用或者调试， 实际中的作用并不大。（一串数字）

    COUNT 限定返回的记录数。
-   `GEORADIUSBYMEMBER <key> <地理名，已存储在KEY中的地理点> <距离> <距离单位，m|km|mi|ft> [WITHHASH] [WITHDIST] [WITHHASH] [COUNT count]  [desc|asc]`

    这个命令和 [GEORADIUS](http://www.redis.cn/commands/georadius.html "GEORADIUS") 命令一样， 都可以找出位于指定范围内的元素， 但是 `GEORADIUSBYMEMBER` 的中心点是由给定的位置元素决定的， 而不是像 [GEORADIUS](http://www.redis.cn/commands/georadius.html "GEORADIUS") 那样， 使用输入的经度和纬度来决定中心点

    指定成员的位置被用作查询的中心。

**应用场景：**

-   团地图位置附近的酒店推送
-   高德地图附近的核酸检查点

### 3.9 Stream流（Redis MQ）

Redis之前除Stream，是如果实现的MQ功能的？

Redis5.0之前的痛点：

-   List实现消息队列 - List 实现方式其实就是点对点的模式
-   Redis 发布订阅 (pub/sub) ：缺点就是消息无法持久化，如果出现网络断开、Redis 宕机等，消息就会被丢弃。而且也没有 Ack 机制来保证数据的可靠性，假设一个消费者都没有，那消息就直接被丢弃了。

而Stream就是Redis5.0版本新增的数据结构。

Stream实现消息队列，它支持消息的持久化、支持自动生成全局唯一 ID、支持ack确认消息的模式、支持消费组模式等，让消息队列更加的稳定和可靠

Stream流原理：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/1678349498779.png)

一个消息链表，将所有加入的消息都串起来，每个消息都有一个唯一的 ID 和对应的内容

|   |                     |                                                                                                                                                                                                                                    |
| - | ------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1 | Message Content     | 消息内容                                                                                                                                                                                                                               |
| 2 | Consumer group      | 消费组，通过XGROUP CREATE 命令创建，同一个消费组可以有多个消费者                                                                                                                                                                                            |
| 3 | Last\_delivered\_id | 游标，每个消费组会有个游标 last\_delivered\_id，任意一个消费者读取了消息都会使游标 last\_delivered\_id 往前移动。                                                                                                                                                      |
| 4 | Consumer            | 消费者，消费组中的消费者                                                                                                                                                                                                                       |
| 5 | Pending\_ids        | 消费者会有一个状态变量，用于记录被当前消费已读取但未ack的消息Id，如果客户端没有ack，这个变量里面的消息ID会越来越多，一旦某个消息被ack它就开始减少。这个pending\_ids变量在Redis官方被称之为 PEL(Pending Entries List)，记录了当前已经被客户端读取的消息，但是还没有 ack (Acknowledge character：确认字符），它用来确保客户端至少消费了消息一次，而不会在网络传输的中途丢失了没处理 |

队列相关命令：

-   `XADD <key> <手动id | *> <field1> <value1> [<field2> <value2> ... ]`: 用于向Stream 队列中添加消息，如果指定的Stream 队列不存在，则该命令执行时会新建一个Stream 队列。

    如果你是使用“ \*”自动生成的，那格式`时间戳Unix时间-自增Id`  , 你这一次添加的，一定要比你上一次的添加的id要大，一个流中信息条目的ID必须是单调增的，这是流的基础，否则会ADD失败。
-   `XRANGE <key> <start,-表示最小消息id> <end,+表示最大消息id> [COUNT count]` ：遍历消息/获取消息。获取指定范围的消息，可以指定获取个数。
-   `XREVRANGE <key> <end,+表示最大消息id> <start,-表示最小消息id>  [COUNT count]` ：与XRANGE的区别是，XREVRANGE是从大的一端开始的。
-   `XDEL <key> <id> [<id> ... ]` ：删除指定id
-   `XLEN <key>` ：获取指定key的Stream数据结构中的消息数量。
-   `XTRIM <key> MAXLEN <保留最新几条>` ：保留指定最新长度（MAXLEN）数据，旧的删除。
    -   &#x20;`XTRIM <key> MINID <id,小于这个id的数据都删除>` ：删除小于指定key指定id，所有小于等于该 ID 的消息都将被删除。
-   `XREAD COUNT <取出个数> BLOCK <XX|阻塞时间，单位是ms> STREAMS <streamKey> <处理的应大于的id值>` ：&#x20;

    窗口1：执行下面命令后会进行阻塞。因为此时mk1这个Stream中没有大于200的id数据，会进行阻塞，因为是`BLOCK 0` 所以会进行永远阻塞。
    ```bash
    XREAD COUNT 2 BLOCK 0 STREAMS mk1 200
    ```
    窗口2：向key为mk1的Steam中加入id为201的消息，那执行后，窗口1将获取到消息。
    ```bash
    XADD mk1 201 aa bb
    ```
    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/1678371555339.png)

消费组相关命令：

-   `XGROUP CREATE <streamKey> <groupname> <id or $> [MKSTREAM]` ：创建组

    MKSTREAM：一个可选参数，如果指定了该参数，当Stream不存在时自动创建。

    \$表示从Stream尾部开始消费

    0表示从Stream头部开始消费

    创建消费者组的时候必须指定 ID, ID 为 0 表示从头开始消费，为 \$ 表示只消费新的消息，队尾新来
-   `XREADGROUP GROUP <groupName> <consumerName> [COUNT count] [BLOCK milliseconds] STREAMS key [key ...] ID [ID ...]`
    -   GROUP：指定消费者组操作。
    -   \<groupName>：指定消费者组的名称。
    -   \<consumerName>：指定消费者的名称。
    -   COUNT count：可选参数，指定一次性读取的消息数量，默认为1。如果未指定该参数，则一次性读取所有可用的消息。
    -   BLOCK milliseconds：可选参数，指定在Stream中没有可用的消息时，命令在等待可用消息时最多阻塞的时间。如果未指定该参数，则命令将立即返回，并可能返回空结果。
    -   STREAMS：指定要从Stream中读取数据。
    -   key \[key ...]：一个或多个Stream的名称。
    -   ID \[ID ...]：消费者组中每个消费者读取Stream的起始位置，以消息ID标识。消费者可以从上次读取的位置继续读取，也可以从Stream中任意位置开始读取。&#x20;

        ">"表示从当前位置开始读取，也就是从上一次读取的位置或者流的开头开始读取所有未读消息。

重点问题：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/1678374265847.png)

|      |                                                                                              |
| ---- | -------------------------------------------------------------------------------------------- |
| 1 问题 | 基于 Stream 实现的消息队列，如何保证消费者在发生故障或宕机再次重启后，仍然可以读取未处理完的消息？                                        |
| 2    | Streams 会自动使用内部队列（也称为 PENDING List）留存消费组里每个消费者读取的消息保底措施，直到消费者使用 XACK 命令通知 Streams“消息已经处理完成”。 |
| 3    | 消费确认增加了消息的可靠性，一般在业务处理完成之后，需要执行 XACK 命令确认消息已经被消费完成                                            |

-   `XPENDING <streamName> <groupName> [start end count] [consumer]` ：查询指定消费组指定消费者\[已读取、但尚未确认]的消息。
    ```bash
    XPENDING mkx g1  - + 100
    127.0.0.1:6379[3]> XPENDING mkx g1  - + 100
    1678211972288-0  
    consumer1             
    1148123
    3
    ```
    -   `1678211972288-0`: 这是未确认消息的消息ID。消息ID通常由流的名称和消息的序列号组成，中间用连字符连接。在这种情况下，消息ID为“1678211972288-0”。
    -   `consumer1`: 这是消费者名称。它指定了未确认消息的接收方。
    -   `1148123`: 这是未确认消息的过期时间（即未确认时间）。过期时间是一个以毫秒为单位的时间戳，表示自 Epoch 以来的毫秒数。
    -   `3`: 这是未确认消息的计数。它表示该消费者有3条未确认消息。
-   `XACK <streamName> <groupName>  <未确认消息id> [<id> ... ]`  ：消费者确认指定stream的组中的消息。

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/1678376650613.png)
-   `XINFO` 查看Stream的信息命令
    -   `XINFO STREAM <key>` 获取Stream信息，返回信息：
        1.  Length：Stream 的长度（即 Stream 中包含的消息数）
        2.  Radix tree keys：Stream 中的所有消息 ID，以及它们的条目数和消费者组信息
        3.  Groups：Stream 中的所有消费者组及其信息
        4.  Last generated ID：当前 Stream 中最新的消息 ID
        5.  First entry：当前 Stream 中最早的消息 ID 和消息的详细信息
        6.  Last entry：当前 Stream 中最新的消息 ID 和消息的详细信息
            这些信息将显示有关流的当前状态，包括其大小、存储方式、剪枝策略和组信息等。
    -   `XINFO GROUPS <stream>`&#x20;

        该命令返回一个包含有关指定流的所有消费者组的信息的列表，包括：
        -   消费者组名称（name）
        -   消费者组的最新消息ID（last-delivered）
        -   消费者组的最新被处理消息的ID（pending）
        -   消费者组中的消费者数量（consumers）
        -   消费者组在Redis中的状态（state）
            这些信息将显示有关消费者组的当前状态，包括其位置、待处理消息的数量以及是否处于活动状态。
    -   `XINFO CONSUMERS <key> <group>`

        该命令返回一个包含有关消费者组中所有消费者的信息的列表，包括：
        -   消费者名称（name）
        -   消费者在消费者组中的消费位置（pending）
        -   消费者当前已经处理的消息数量（idle）
        -   消费者的状态（state）
            这些信息将显示有关消费者的当前状态，包括其位置、待处理消息的数量以及是否处于活动状态。

### 3.10 Bitfield (位域)

将一个Redis字符串看作是一个由二进制位组成的数组并能对变长位宽和任意没有字节对产的指定整型位域进行寻址和修改

这个用的很少，了解即可。主要操作是：

-   位域修改
-   溢出控制

## 4. Redis持久化

为什么需要持久化：防止如系统故障、服务器宕机等情况缓存数据的丢失。

官网说明：[https://redis.io/docs/management/persistence/](https://redis.io/docs/management/persistence/ "https://redis.io/docs/management/persistence/")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678494422880.png)

### 4.1 RDB 方式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678494934585.psd)

RDB的持久化是以一系列的触发方式，触发将内存中的数据生成快照（全量快照，dump.rdb）保存到磁盘上，恢复时再次快照直接读回内存里。

#### 备份（**触发方式**）

> 配置保存路径：
>
> ```bash
> # 配置redis.conf
> dir /opt/redis-rdb
> # bash命令创建目录
> mkdir /opt/redis-rdb
> ```
>
> 配置dump文件名称( redis.conf )：`dbfilename dump6379.rdb`

-   备份：**自动触发**

    Redis6.0.16以下：`save 60 2` 表示在60秒内有2次修改，触发rdb备份（可配置多个）。

    Redis6.2及之后：`save <seconds> <changes> [<seconds> <changes>  ... ]`  一个save可配置多个。
-   备份：**手动触发**
    -   `save` ：使用这个命令，在主程序中执行，会阻塞redis服务器，直到持久化完成，执行save命令期间，Redis不能处理其它命令，**线上禁止使用**。

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678497289057.png)
    -   `bgsave` ：在后台异步操作，不阻塞，同时可以响应客户端请求，该触发方式会[fork](https://www.cnblogs.com/zhuangjie/p/17205472.html "fork")一个子进程由子进程进行持久化过程。

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678503842009.png)

        可以通过`lastsave`命令获取最后一次成功执行快照的时间
-   **禁用快照**
    -   动态所有停止RDB保存规则的方法: `redis-cli config set save ""`
    -   持久禁用：编辑redis.conf文件，配置`save ""`

#### 恢复

启动时，会自动读取之前备份的文件，所以恢复，就是恢复备份文件。

注意当我们执行flushall命令时也会备份到dump.rdb，但这备份的文件是无意义的，如果我们没有将dump.rdb再备份也是不行的。&#x20;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678512332556.png)

**ump文件修复**：`redis-check-rdb dump6379.rdb`

-   配置文件中默认的快照配置
-   手动save/bgsave备份命令，或直接执行flushall/flushdb命令而产生的自动备份dump.rdb文件，但里面是空的，无意义。
-   执行shutdown
-   没有设置开启AOF持久化主从复制时，主节点自动触发

#### 优劣点

-   **优势：**
    -   适合大规模数据恢复：由于rdb文件都是二进制文件，所以很小，在灾难恢复的时候会快些。
    -   效率高：主进程处理命令的效率，而不是持久化的效率。
-   **劣势：** 不适合实时数据处理，会丢失最后一次备份到出现故障的数据，因此在数据一致性与完整性上无法保障。

#### **RDB优化配置项详解：**

-   `save <seconds> <changes>` ：自动备份策略。
-   `dbfilename` rdb文件名
-   `dir` rdb文件保存位置
-   `stop-writes-on-bgsave-error` （推荐默认配置）
    | 默认yes                                                                                |
    | ------------------------------------------------------------------------------------ |
    | 如果配置成no，表示你不在乎数据不一致或者有其他的手段发现和控制这种不一致，那么在快照写入失败时（比如：磁盘空间不足时），也能确保redis继续接受新的写请求（不推荐） |
-   `rdbcompression` （推荐默认配置）
    | 默认yes                                                                                |
    | ------------------------------------------------------------------------------------ |
    | 对于存储到磁盘中的快照，可以设置是否进行压缩存储。如果是的话，redis会采用LZF算法进行压缩。  &#xA;如果你不想消耗CPU来进行压缩的话，可以设置为关闭此功能 |
-   `rdbchecksum`  （推荐默认配置）
    | 默认yes                                                                      |
    | -------------------------------------------------------------------------- |
    | 在存储快照后，还可以让redis使用CRC64算法来进行数据校验，但是这样做会增加大约10%的性能消耗，如果希望获取到最大的性能提升，可以关闭此功能 |
-   `rdb-del-sync-files` （推荐默认配置）

    在没有持久性的情况下删除复制中使用的RDB文件启用。默认情况下no，此选项是禁用的。

### 4.2 AOF 方式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678521902155.png)

解析：以日志的形式来`记录`每个`写操作`，将Redis执行过的所有写指令记录下来(读操作不记录),只许`追加`文件但不可以改写文件，redis启动之初会读取该文件重新构建数据，换言之，redis重启的话就根据日志文件的内容将写指令从前到后`执行一次以完成数据的恢复`工作。

默认情况下，redis是没有开启AOF(append only file)的开启AOF功能需要设置配置: `appendonly yes`

#### **AOF持久化工作流程**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678522531936.png)

1.  命令到达服务器，命令执行完后并不会直接写入文件持久化，而是会先进入`AOF缓存区`, 该缓存区是在内存的一片区域，存在的目的是当这些命令达到一定量以后再写入磁盘，避免频繁的磁盘IO操作。
2.  AOF缓冲会根据AOF缓冲区**同步文件的三种写回策略**将命令写入磁盘上的AOF文件。
3.  随着写入AOF内容的增加为避免文件膨胀，会根据规则进行命令的合并(又称\*\**AOF重写)*\*\*，从而起到AOF文件压缩的目的。
4.  当Redis Server 服务器重启的时候会从AOF文件载入数据。

#### **AOF缓存区三种写回策略**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678523259294.png)

1.  always （默认）

    这是Redis的默认AOF写回策略，当Redis执行任何修改命令时，都会立即将命令追加到AOF文件中。这种策略可以确保数据的持久化，但是会影响Redis的性能。
2.  everysec

    这种策略会定期将AOF缓冲区中的日志刷写到磁盘上，具体的时间间隔由参数“aof-rewrite-incremental-fsync”指定，默认值是`1秒`。这种策略在性能和数据安全之间取得了一个平衡。
3.  no

    这种策略不会主动将AOF缓冲区中的日志写到磁盘上，而是让操作系统来决定何时来处理缓冲区数据的持久化。这种策略性能最好，但是在操作系统崩溃或Redis进程崩溃时可能会丢失数据。

需要注意的是，使用no策略需要谨慎，只有在数据安全性不是最高优先级且需要追求更好的性能时才应该使用。

#### 备份 （6 VS 7）

1.  开启AOF

    编辑`redis.conf` 文件，修改配置`appendonly yes`
2.  配置缓存区写回策略

    编辑`redis.conf` 文件，修改配置`appendfsync everysec`  (默认值)
3.  配置保存路径/保存名称

    **redis6**及之前：由于之前跟rdb一样都是一个文件，所以配置文件都是存放在`dir` （redis.conf配置文件指定）下。只需要通过配置`appendfilename` 即可，即aof文件名。

    **redis7**：在redis7采用`Multi Part AOF的设计`, aof发生了很大的改变，aof由原来的一个文件变为三个文件，所以需要一个文件夹来存放，但这个文件夹还是在`dir` 下，新增了一个`appenddirname`来指定存放aof三个文件的目录名。还需要`appendfilename`来指定aof根文件名。

    假设指定`appendfilename appendonly.aof`, 那生成的三个文件是：
    ```bash
    -rw-r--r--. 1 root root 88 3月   8 22:13 appendonly.aof.1.base.rdb
    -rw-r--r--. 1 root root  0 3月   8 22:13 appendonly.aof.1.incr.aof
    -rw-r--r--. 1 root root 88 3月   8 22:13 appendonly.aof.manifest
    ```
    基本文件：appendonly.aof.1.base.rdb

    增量文件：appendonly.aof.1.incr.aof

    清单文件：appendonly.aof.manifest

#### 恢复

正常恢复，AOF方式也跟RDB一样，在恢复时，会读取之前备份下来的文件。

可以将AOF三个文件所在目录做一个备份，当出现问题时，只需要将那个备份文件恢复上即可。

异常恢复：当备份文件出现问题时，会导致Redis无法启动，我们可以使用AOF备份文件的修复命令：

```bash
redis-check-aof --fix XXX.incr.aof
```

#### 优势

更好的保护数据不丢失、性能高、可做紧急恢复

**劣势**

-   相同数据集的数据而言aof文件要远大于rdb文件，恢复速度慢于rdb
-   aof运行效率要慢于rdb,每秒同步策略效率较好，不同步效率和rdb相同

#### AOF的重写机制

由于AOF持久化是Redis不断将写命令记录到 AOF 文件中，随着Redis不断的进行，AOF 的文件会越来越大，

文件越大，占用服务器内存越大以及 AOF 恢复要求时间越长。

为了解决这个问题，Redis新增了重写机制，将AOF文件的内容压缩，只保留可以恢复数据的最小指令集。

那重写机制是怎样的呢？

```bash
一开始你  set k1 v1
然后改成  set k1 v2
最后改成  set k1 v3

```

通过重写后，上面只有`set k1 v3`

**演示：**

1.  重写机制前提

    编辑redis.conf文件，编辑：
    ```bash
    # 开启AOF
    appendonly yes
    # 修改触发条件，第一次触发是大小达到1k时，当大小超过原来的 100%会再次触发，即：1k->2k->4k-> ...
    auto-aof-rewrite-percentage 100
    auto-aof-rewrite-min-size 1k

    # 禁用aof-rdb混合
    aof-use-rdb-preamble no
    ```
2.  自动触发重写

    上面配置好后，我们执行修改操作`set XXX XXX`&#x20;
    ```bash
    -rw-r--r--. 1 root root   0 3月   9 00:06 appendonly.aof.1.base.aof
    -rw-r--r--. 1 root root 937 3月   9 00:08 appendonly.aof.1.incr.aof
    -rw-r--r--. 1 root root  88 3月   9 00:06 appendonly.aof.manifest
    [root@localhost appendonlydir]# ll
    总用量 8
    -rw-r--r--. 1 root root 127 3月   9 00:08 appendonly.aof.2.base.aof
    -rw-r--r--. 1 root root   0 3月   9 00:08 appendonly.aof.2.incr.aof
    -rw-r--r--. 1 root root  88 3月   9 00:08 appendonly.aof.manifest

    ```
    可以发现当达到1k时，就会进行重写，将增量数据重写后数据放入base.aof中, 将incr.aof文件置空。（打开 base.aof 可以验证，发现我们执行的命令信息）
3.  手动方式
    > REWRITE: 在主线程中重写 AOF，会阻塞工作线程，在生产环境中很少使用，处于废弃状态；
    >
    > BGREWRITE: 在后台（子进程）重写 AOF, 不会阻塞工作线程，能正常服务，此方法最常用。
    > 手动执行`BGREWRITEAOF`
    ```bash
    127.0.0.1:6379> BGREWRITEAOF
    Background append only file rewriting started

    ```

> 小总结：
>
> 1.  也就是说 AOF 文件重写并不是对原文件进行重新整理，而是直接读取服务器现有的键值对，然后用一条命令去代替之前记录这个键值对的多条命令，生成一个新的文件后去替换原来的&#x20;
> 2.  AOF 文件AOF文件重写触发机制: 通过 redis.conf 配置文件中的 auto-aof-rewrite-percentaqe: 默认值为100，以及auto-aof-rewritemin-size: 64mb 配置，也就是说默认Redis会记录上次重写时的AOF大小，默认配置是当AOF文件大小是上次rewrite后大小的一倍且文件大于64M时触发
>
> 重写的原理：fork 出一个子进程进行 rewrite，在重写过程中，当有新的写命令过来时，Redis 会将写命令写入到 AOF 重写缓存中（**aof\_rewrite\_buf\_blocks**），并在 AOF 重写完成后，将**aof\_rewrite\_buf\_blocks** 写到新的 AOF 文件（文件名+1）中。同时，写命令也会被写入到 Redis 内存中(redis server)，以保证 Redis 内存中的数据和 AOF 重写缓存中的数据保持一致。

#### AOF优化配置

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/11/1678535452191.png)

#### RDB + AOF的混合模式

默认是使用混合模式的，所谓的混合模式，其实是将RDB混合到AOF，就算配置了`SAVE ""` 也是没有一点影响到AOF的混合模式的。RDB无法关闭，关闭的只是自动备份RDB。

当关闭混合模式时，即redis.conf 的`aof-use-rdb-preamble no` ,那就不会将RDB混合到AOF中，即AOF的三个文件中的`基本文件`后缀是`.aof` , 意味着，不会使用RDB进行全量备份（最终恢复=全量备份+增量备份），而是使用重写后的AOF作为全量备份。注意这里的全量备份与增量备份在物理上表示为AOF三个文件中的`基本文件`与`增量文件` 。当`aof-use-rdb-preamble yes` 时，那AOF的基本文件是RDB内容（二进制），基本文件后缀就是rdb而不是aof。

总结：开启AOF持久化的RDB+AOF混合模式：

1.  开启 AOF`appendonly yes` , 及其相关配置
2.  &#x20;保证 `aof-use-rdb-preamble yes`

推荐，关闭RDB自动持久代。

### 4.3 纯缓存模式

也就是不做持久化，那就要关闭RDB与AOF

-   关闭RDB：redis.conf 配置`SAVE ""` （仍然可以使用save, bgsave手动进行RDB备份）
-   关闭AOF：redis.conf 配置`appendonly no` (仍然可以使用 rewriteaof（4.0弃用）、 bgrewriteaof 手动进行AOF备份）)

## 5. Redis 事务

官网说明：[https://redis.io/docs/manual/transactions/](https://redis.io/docs/manual/transactions/ "https://redis.io/docs/manual/transactions/")

Redis的事务特点：

Redis事务不具有ACID。在Redis是单线程地执行所有客户端的命令，所以在进行事务EXEC后真正执行时，会保证事务中命令的原子性（此时不会响应客户端命令）。因为前面这种特点，所以Redis不存在EXEC后事务真正执行时出现被其它修改操作，自然就不需要隔离级别的概念。由于我们在向事务命令队列加入时命令时就已经确认了该命令，比如要设置的值，所以只需要我们在此查询的数据没有被修改，就能确事务的一致性。所以引入 了`watch` ，被watch的对象会在`watched_keys` 字典中，它能监听watch到exec数据改变，被监听的数据如果发生改变，那会将与之因watch后关联的事务状态会切换为`REDIS_DIRTY_CAS` 状态，表示监视的键至少有一个已经被修改了，事务的安全性已经被破坏，这些事务将在EXEC后会检查状态，如果是`REDIS_DIRTY_CAS`状态，那会返回空回复（`nil`）。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678679783645.png)

**Redis的事务不保证原子性：**

`不保证`所有指令同时成功或同时失败，只有决定是否开始执行全部指令的能力，没有执行到一半进行回滚的能力，也不支持回滚。

Redis的作者在事务功能的文档中解释说：“不支持事务回滚是因为这种复杂的功能和Redis追求简单高效的设计主旨不相符，并且他认为，Redis事务的执行时错误通常都是编程错误产生的，这种错误通常只会出现在开发环境中，而很少会在实际的生产环境中出现，所以他认为没有必要为Redis开发事务回滚功能。”

但会`保证`一个事务内的命令依次执行，而不会被其它命令插入。

**全体连坐：** 表示在入队时出错，在事务中的命令如果由于语法错误而导致事务失败的，事务且不会执行。

```bash
127.0.0.1:6379(TX)> SET a
(error) ERR wrong number of arguments for 'set' command
127.0.0.1:6379(TX)> SET a 2
QUEUED
127.0.0.1:6379(TX)> exec
(error) EXECABORT Transaction discarded because of previous errors.

```

在Redis 2.6.5以前，即使在入队时出现了错误也会继续执行后面的命令，而不会导致该事务的命令全部失败。

**冤头债主：** 事务运行时某的命令执行出错，不会影响其它事务命令的执行。

```bash
127.0.0.1:6379> MULTI
OK
127.0.0.1:6379(TX)> SET k1 v1
QUEUED
127.0.0.1:6379(TX)> INCR k1
QUEUED
127.0.0.1:6379(TX)> EXEC
1) OK
2) (error) ERR value is not an integer or out of range

```

除了上面因为命令执行的不严谨而生产的错误外，我们也可以在执行事务时，主动放弃事务。

**放弃事务**：主动放弃事务

```bash
127.0.0.1:6379> MULTI
OK
127.0.0.1:6379(TX)> SET k1 v1
QUEUED
127.0.0.1:6379(TX)> DISCARD
OK
127.0.0.1:6379>

```

还有一种，当不满足watch监视的值时，因乐观失败时，也会放弃事务。请先查看下面的命令与解释你就会明白watch监视的原理：

**watch监视**：

```bash
127.0.0.1:6379> SET k1 v1
OK
127.0.0.1:6379> WATCH k1
OK
127.0.0.1:6379> SET k1 v2
OK
127.0.0.1:6379> MULTI
OK
127.0.0.1:6379(TX)> SET k1 v3
QUEUED
127.0.0.1:6379(TX)> EXEC
(nil)
127.0.0.1:6379> GET k1
"v2"

```

事务执行前`watch` 监视了一个值，当watch 到事务开始前如果对监视的值进行修改，那事务的代码就会改为`REDIS_DIRTY_CAS`状态, 在进行EXEC（事务执行前）会对事务状态进行检查，当是`REDIS_DIRTY_CAS`，会放弃执行，并返回一个空回复（nill）。事务执行完后对释放该事务对键监视，或在未EXEC前如果客户端离线，那也会放弃事务并释放事务对键的监视。

也可以在事务执行前进行`unwatch`来取消对某个键的监视。

**事务的结构：**

每个`Redis客户端`都有自己的事务状态，这个事务状态保存在客户端状态的mstate属性里面：

```c
typedef struct redisClient {
  // ...
  // 事务状态
  multiState mstate; /* MULTI/EXEC state */
  // ...
} redisClient;
```

`事务状态`包含一个事务队列，以及一个已入队命令的计数器（也可以说是事务队列的长度）：

```c
typedef struct multiState {
  // 事务队列，FIFO
  multiCmd *commands;
  // 已入队命令计数
  int count;
} multiState;
```

`事务队列`是一个multiCmd类型的数组，数组中的每个multiCmd结构都保存了一个已入队命令的相关信息，包括指向命令实现函数的指针、命令的参数，以及参数的数量：

```c
typedef struct multiCmd {
  // 参数
  robj **argv;
  // 参数数量
  int argc;
  // 命令指针
  struct redisCommand *cmd;
} multiCmd;
```

举例：如果客户端执行以下命令：

```bash
redis> MULTI
OK
redis> SET "name" "Practical Common Lisp"
QUEUED
redis> GET "name"
QUEUED
redis> SET "author" "Peter Seibel"
QUEUED
redis> GET "author"
QUEUED
```

转化为：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678686197856.png)

**事务小总结 ：**

[https://www.bilibili.com/account/history](https://www.bilibili.com/account/history "https://www.bilibili.com/account/history")

1.  开启: 以MULTI开始一个，客户端状态（`mstate`）由`非事务状态` 变为`事务状态`
2.  事务入队:  现在客户端的状态已经变为了`事务状态`,  收到的命令除了`EXEC、DISCARD、WATCH、MULTI` 外都会放入等待执行的事务队列中，然后向客户端返回QUEUED回复。如果是事务前的非事务状态，那收到的命令会立即执行。

    ![服务器判断命令是该入队还是该执行的过程](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678685034085.png "服务器判断命令是该入队还是该执行的过程")
3.  执行: 由EXEC命令触发事务

## 6. Redis管道

### 6.1 管道的说明/使用

先来看一道面试题：**如何优化频繁命令往返造成的性能瓶颈？**

这里说的命令往返是指如果同时需要执行大量的命令，那么就要等待上一条命令应答后再执行，这中间不仅仅多了RTT（Round Time Trip，数据往返时间），而且还频繁调用系统IO，发送网络请求，同时需要redis调用多次read()和write()系统方法，系统方法会将数据从用户态转移到内核态，这样就会对进程上下文有比较大的影响了，性能不太好。

Redis管道就是解决的问题是：当有大量命令且这些命令每条都不依赖于之前命令执行结果时，就可以一起通过管道发出。从而节省数据往返时间，而造成的Redis性能下降。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678691034317.png)

如何使用管道：

```bash
[root@localhost ~]# cat redis-pipeline.txt
SET k1 v1
SADD sk1 v1 v2 v3
RPUSH lk1 v1 v2 v1
[root@localhost ~]# cat redis-pipeline.txt | redis-cli -a 3333 --pipe
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
All data transferred. Waiting for the last reply...
Last reply received from server.
errors: 0, replies: 3

```

### 6.2 Pipeline与原生批量命令对比

-   生批量命令是原子性(例如:mset,mget)，pipeline是非原子性
-   原生批量命令一次只能执行一种命令，pipeline支持批量执行不同命令
-   原生批命令是服务端实现，而pipeline需要服务端与客户端共同完成

### 6.3 Pipeline与事务对比

-   务具有原子性，管道不具有原子性
-   管道一次性将多条命令发送到服务器，事务是一条一条的发，事务只有在接收到exec命令后才会执行，管道不会
-   执行事务时会阻塞其他命令的执行，而执行管道中的命令时不会

### 6.4 Pipeline的注意事项

不能保证原子性，执行中发现异常，将继续执行后续命令。

pipeline组装的命令不能太多

## 7. PUB/SUB 发布订阅

学习定位 -了解即可

定义：是一种消息通信模式:发送者(PUBLISH)发送消息，订阅者(SUBSCRIBE)接收消息，可以实现进程间的消息传递

是stream实现MQ的前身小玩意。stream都不推荐作为mq，更何况pub/sub了。

命令：

-   `SUBSCRIBE <channel > [<channel> ... ]` : 表示要订阅频道(channel), 如果没有该频道会自动创建，并将该客户端挂载该频道链表上。

    推荐先执行订阅后再发布消息，否则订阅成功之前发布的消息是收不到的。
-   `PUBLISH <channel>  <message>`: 表示向哪个频道发布消息。
-   `PSUBSCRIBE <pattern> [<pattern> ... ]` : 以规则方式订阅，或说模糊订阅。即可以使用\*和？进行模糊匹配，他匹配的目标自然是频道。比如 PSUBSCRIBE word.\* ,那可以匹配word.1、word.2  ...
-   `PUBSUB` 命令，用于查看PUB/SUB相关信息。
    -   &#x20;`PUBSUB CHANNELS` : 查看有哪些频道。（频道存在一定有订阅者，当没有订阅者频道也会自动清除）
    -   `PUBSUB NUMSUB <channel> [<channel> ...]` ： 用于查看频道的订阅者。
    -   `PUBSUB NUMPAT` : 用于查看`规则`(匹配频道的规则)的数量 。
-   退订频道
    -   `UNSUBSCRIBE [channel [channel ...]]`   取消订阅
    -   `PUNSUBSCRIBE [pattern [pattern ...]]`  退订所有给定规则的频道（匹配上就退订）

PUB/SUB缺点：

-   发布的消息在Redis系统中不能持久化，因此，必须先执行订阅，再等待消息发布。如果先发布了消息，那么该消息由于没有订阅者，消息将被直接丢弃
-   消息只管发送对于发布者而言消息是即发即失的，不管接收，也没有ACK机制，无法保证消息的消费成功。
-   以上的缺点导致Redis的Pub/Sub模式就像个小玩具，在生产环境中几乎无用武之地，为此Redis5.0版本新增了Stream数据结构，不但支持多播，还支持数据持久化，相比Pub/Sub更加的强大

### 7.1 实现原理

#### 订阅频道

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678711104748.png)

每当执行`SUBSCRIBE`订阅时某个/某些频道时，会检查这些频道是否存在，如果不存在会为频道创建一个键，值是一个空链表，然后该客户端成为该频道的第一个元素。如果订阅的频道已经在`pubsub_channels` 中，只需要在已经存在的链表中尾部追加该客户端即可。

#### 退订频道

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678712000149.png)

退订频道跟订阅频道是相反的，会从`pubsub_channels`字典中找到退订的频道键对应的值也就是订阅者链表，然后从订阅者链表中删除退订客户端的信息。

当自己是最后要订阅者，从链表中删除，那就频道的值的链表就是空链表了，那么说明这个频道已经没有任何订阅者了，程序将从pubsub\_channels字典中删除频道对应的键。

#### 模式（规则）订阅/退订原理

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678712734100.png)

订阅：当执行`PSUBSCRIBE news.*` 进行模式订阅时，就会新建一个pubsubPattern结构，将结构的pattern属性设置为被`订阅的模式（规则）`，client属性设置为`订阅者客户端`。

退订：会找到模式对应的`pubsubPattern` ，比如要`PUNSUBSCRIBE new.*`那上面尾部的"news. \*"的pubsubPattern。

当`PUBLISH news.1 hello` 时：

-   找到对应的频道上的订阅者并通知。
-   会通过遍历整个pubsub\_patterns链表，找到能匹配`news.1` 的pattern模式,并将通知匹配上的pubsubPattern下的client订阅者（上图的`news.*` pubsubPattern就匹配上，会通知上面的client-9订阅者）。

#### 查看订阅者

PUBSUB→PUBSUB CHANNELS， 命令格式如下：

`PUBSUB CHANNELS [pattern]` ：查看频道

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/13/1678715025933.png)

-   当没有指定pattern, 遍历`pubsub_channels` 所有的键即所以的频道。
-   当指定pattern时， 遍历`pubsub_channels` 所有键的频道是否匹配pattern的模式（规则），返回能匹配上的频道。

`PUBSUB NUMSUB <channel> [<channel> ... ]` : 查看订阅者

遍历命令参数上指定的channel频道，然后返回这些频道上的订阅者。

`PUBSUB NUMPAT` ：返回服务器当前被订阅模式（规则）的数量。

## 8. Redis复制&#x20;

官网说明：[https://redis.io/docs/management/replication](https://redis.io/docs/management/replication "https://redis.io/docs/management/replication")

认识：主从复制，master以写为主，slave以读为主。在master数据变化时，自动将新的数据同步到slave从数据库上。

**作用：** 读写分离、容灾恢复、数据备份、水平扩容支撑高并发。

**操作须知：**

-   在下面的配置中，一般都是`配（配置）从不配主`
-   权限问题：如果master机器redis机器上配置了密码（`requirepass`）参数，那从数据库需要配置访问master的密码（`masterauth`）,否则master会拒绝slave的访问请求。
-   基本命令：
    -   `info replication`：可以查看复制节点的主从关系和配置信息
    -   `replicaof/slaveof <masterIP> <masterPort>` : 主从复制/改换门庭，  replicaof与slaveof都是用来将当前 Redis 服务器设置为另一个 Redis 服务器的从服务器。两者完全等价，只是名称不同。需要注意的是，从 Redis 5.0 开始，`slaveof` 命令已经被弃用，官方建议使用 `replicaof` 命令来代替。&#x20;

        在运行期间，如果执行该命令，那么会停止和原主数据库的同步关系，转而和新的主数据库同步（重新拜大哥）。
    -   `slaveof no one` : 自立为王，使当前数据库停止与其它数据库的同步，将自己转为主数据库，自立为王。
-   案例架构：下面的演示用到的机器

    `192.168.87.105:6379`、`192.168.87.106:6380`、`192.168.87.107:6381`

    公共配置：上面的机器都弄好后（其实就是vm上复制，修改一下机器的ip与redis的运行端口），强制要求要配置的会标红/加粗：
    1.  开启daemonize yes
    2.  注释掉bind 127.0.0.1
    3.  关闭安全 protected-mode no
    4.  指定端口port <端口>
    5.  指定当前工作目录，dir
    6.  pid文件名字,pidfile
    7.  log文件名字,logfile
    8.  指定登录密码requirepass
    9.  指定rdb生成的文件名 dbfilename xxx.rdb
    10. 指定aof文件文件名 appendfilename
    11. 指定aof文件存放在dir目录下的哪个目录：appenddirname "appendonlydir"
        从机器如果主redis服务器设置了密码，从机器需要在redis.conf中配置`masterauth`

### 8.1 案例1：主从复制

#### 配置方式

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678752573442.png)

其实都很简单，`主服务器`、`从服务器`配置了上面的基本配置后,主服务器就不要配置了，从服务（`192.168.87.106`、`192.168.87.107`）配置主服务器的信息，即可。

```bash
# master机器ip:port
replicaof 192.168.87.105 6379
# master服务器认证密码
masterauth 3333

```

然后依次启动主服务器与从服务器。

主服务器使用`info replication` :  （也通过可以查看日志也可以查看与从服务器同步成功的信息，上面配置了log文件）

```bash
127.0.0.1:6379> info replication
# Replication
role:master
connected_slaves:2
slave0:ip=192.168.87.106,port=6380,state=online,offset=1993,lag=1
slave1:ip=192.168.87.107,port=6381,state=online,offset=1993,lag=0
master_failover_state:no-failover
master_replid:41332985dc734f16db0a1ef0fdd6cdbad53d1750
master_replid2:0000000000000000000000000000000000000000
master_repl_offset:1993
second_repl_offset:-1
repl_backlog_active:1
repl_backlog_size:1048576
repl_backlog_first_byte_offset:1
repl_backlog_histlen:1993

```

从服务器：

```bash
127.0.0.1:6380> info replication
# Replication
role:slave
master_host:192.168.87.105
master_port:6379
master_link_status:up
master_last_io_seconds_ago:10
master_sync_in_progress:0
slave_read_repl_offset:2105
slave_repl_offset:2105
slave_priority:100
slave_read_only:1
replica_announced:1
connected_slaves:0
master_failover_state:no-failover
master_replid:41332985dc734f16db0a1ef0fdd6cdbad53d1750
master_replid2:0000000000000000000000000000000000000000
master_repl_offset:2105
second_repl_offset:-1
repl_backlog_active:1
repl_backlog_size:1048576
repl_backlog_first_byte_offset:664
repl_backlog_histlen:1442

```

主从问题：

1.  从机可以执行写命令吗?  不可以
2.  从机切入点问题
3.  主机shutdown后，从机会上位吗? 不会，会等待主服务器恢复
4.  主机shutdown后，重启后主从关系还在吗? 从机还能否顺利复制?  会恢复正常主人关系
5.  某台从机down后，master继续，从机重启后它能跟上大部队吗?  可以
6.  从机器之前有数据，建立主从关系后，从机器的数据会保留吗？ 不会，会跟master机器进行同步。

#### 命令方式（临时）

主服务器与从服务器都配置了上面基本东西后。主从机器全部启动，此时主从机器都是master角色，从机器使用命令：

```bash
slaveof <masterIp> <masterPort>
```

来临时建立主从关系（重启slave变为master，主从关系失效）。&#x20;

但注意，如果主机器配置了密码，那还需要在从机器的redis.conf上配置：

```bash
masterauth <masterAuthPassword>
```

### 8.2 案例2：薪火相传

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678768849440.png)

slave机器是可以同时扮演slave与master的，`192.168.87.106` 就是，同时作为`192.168.87.105`的slave，和作为`192.168.87.107`的master。

这样做是为了减轻master与slave的同步压力（可以假设一个master节点下挂了很多slave，master同步压力是非常大的）。

上面`192.168.87.107`机器只需要执行以下，即可作为`192.168.87.106`的从机器：

```bash
# 拜新老大/拜老大 命令
slaveof <新主库IP> <新主库端口>
```

中途变更转向会清除之前的数据，重新建立拷贝最新的。

### 8.3 案例3：自立为王

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678778714463.png)

`192.168.87.107`使用 `slaveof no one`  命令，让自己从slave → master . 使当前数据库停止与其他数据库的同步，转成主数据库.

### 8.4 主从复制工作原理

本章首先介绍Redis在2.8版本以前使用的旧版复制功能的实现原理，并
说明旧版复制功能在处理断线后重新连接的从服务器时，会遇上怎样的低效
情况。
接着，本章将介绍Redis从2.8版本开始使用的新版复制功能是如何通过
部分重同步来解决旧版复制功能的低效问题的，并说明部分重同步的实现原
理。
在此之后，本章将列举SLAVEOF命令的具体实现步骤，并在本章最后，
说明主从服务器心跳检测机制的实现原理，并对基于心跳检测实现的几个功
能进行介绍。

#### 8.4.1 旧版复制功能的实现

Redis的复制功能分为同步（sync）和命令传播（command propagate）两个操作：

-   同步操作用于将服务器的数据库状态更新到主服务器当前所处的数据库状态。
-   命令传播操作则用于在主服务器的数据库状态被修改，导致主从服务器的数据库状态出现不一致时，让主从服务器的数据库重新回到一致状态。

旧版在主从复制的整个过程：

当客户端slaveof命令与主服务器建立好主从关系后，从服务器首先需要执行的是同步操作，也即是，将从服务器的数据库状态更新到主服务器当前气息的数据库状态。

1）从服务器向主服务器发送SYNC命令。

2）收到SYNC命令的主服务器执行BGSAVE命令，在后台生成一个RDB文件，并使用一个缓冲区记录从现在开始执行的所有写命令。

3）主服务BGSAVE命令生成的RDB文件传输到从服务器上，从服务器载入这个RDB文件，将自己的数据库状态更新至主服务器执行BGSAVE命令时的数据库状态。

4）主服务器将记录在缓冲区里面的所有写命令发送给从服务器，从服务器执行这些写命令，将自己的数据库状态更新至主服务器数据库当前所处的状态。

当从服务器断线后再进行连接，连接成功后，从服务器会发送`sync` 与主服务器进行同步，即主服务器要执行BGSAVE命令生成RDB文件 ... , 但其实对于从服务器来说，这是不必要的，从服务器只需要与主服务器连接断开期间执行的写命令，即可使从服务器恢复与主服务器状态一致。

还有`sync` 命令是非常低效的，会消耗计算机大量的资源，如CPU、内存和磁盘I/O资源、网络资源（带宽和流量）在整个过程中对主服务器响应命令请求的时间产生影响。

#### 8.4.2 新版复制功能的实现

为了解决旧版复制功能在处理断线重复制情况时的低效问题，Redis从2.8版本开始，使用PSYNC命令代替SYNC命令来执行复制时的同步操作.

`PSYNC`命令具有完整重同步（full resynchronization）和部分重同步（partial resynchronization）两种模式：

-   中完整重同步用于处理初次复制情况：完整重同步的执行步骤和SYNC命令的执行步骤基本一样，它们都是通过让主服务器创建并发送RDB文件，以及向从服务器发送保存在缓冲区里面的写命令来进行同步。
-   而部分重同步则用于处理断线后重复制情况：当从服务器在断线后重新连接主服务器时，如果条件允许，主服务器可以将主从服务器连接断开期间执行的写命令发送给从服务器，从服务器只要接收并执行这些写命令，就可以将数据库更新至主服务器当前所处的状态，从而解决了旧版在处理断线后产生RDB进行完整同步而造成的低效问题。

    ![主从服务器执行部分重同步的过程](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678781732244.png "主从服务器执行部分重同步的过程")

**部分重同步是如何实现的呢？**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678782642572.png)

主服务器和从服务器会分别维护一个复制偏移量（offset）

-   主服务器每次向从服务器传播N个字节的数据时，就将自己的复制偏移
    量的值加上N。
-   从服务器每次收到主服务器传播来的N个字节的数据时，就将自己的复
    制偏移量的值加上N。

当主服务器有新的操作量33b时，主服务器会更新为10086+33 = 10119，然后向从服务器发送33k,使主从都达到偏移量为10119，使主从数据达到一致，即主从数据偏移量相同时，主从服务器处于一致状态。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678783021959.png)

如果在要传输时，`服务器A` 断线了呢？

![因为断线而处于不一致状态的从服务器A](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678783272453.png "因为断线而处于不一致状态的从服务器A")

假设从服务器A在断线之后就立即重新连接主服务器，并且成功，那么接下来，从服务器将向主服务器发送PSYNC命令，报告从服务器A当前的复制偏移量为10086，那么这时，主服务器应该对从服务器执行完整重同步还是部分重同步呢？如果执行部分重同步的话，主服务器又如何补偿从服务器A在断线期间丢失的那部分数据呢？以上问题的答案都和`复制积压缓冲区`有关。

下面我们就来介绍一下`复制积压缓冲区`及如何利用复制积压缓冲区来实现`部分重同步`的：

`复制积压缓冲区`是 个先进先出（FIFO）队列，默认大小为`1M`：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678783603457.png)

`复制积压缓冲区`工作的特点：假设现在复制积压缓冲区已经满了，当有新33字节要进来时，另一端就要弹出等量的数据。

那是如何利用复制积压缓冲区实现部分重同步的呢？

当从服务器重新连上主服务器时，从服务器会通过PSYNC命令将自己的复制偏移量offset发送给主服务器，主服务器会根据这个复制偏移量来决定对从服务器执行何种同步操作：

-   如果offset偏移量之后的数据（也即是偏移量offset+1开始的数据）仍然存在于复制积压缓冲区里面，那么主服务器将对从服务器执行部分重同步操作。
-   相反，如果offset偏移量之后的数据已经不存在于复制积压缓冲区，那么主服务器将对从服务器执行完整重同步操作。

回到之前图15-9展示的断线后重连接例子：

-   从服务器A断线之后，它立即重新连接主服务器，并向主服务器发送PSYNC命令，报告自己的复制偏移量为10086。
-   主服务器收到从服务器发来的PSYNC命令以及偏移量10086之后，主服务器将检查偏移量10086之后的数据是否存在于复制积压缓冲区里面，结果发现这些数据仍然存在，于是主服务器向从服务器发送+CONTINUE回复，表示数据同步将以部分重同步模式来进行。
-   接着主服务器会将复制积压缓冲区10086偏移量之后的所有数据（偏移量为10087至10119）都发送给从服务器。
-   从服务器只要接收这33字节的缺失数据，就可以回到与主服务器一致的
    状态，如下图所示。

    ![主服务器向从服务器发送缺失的数据](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678783978445.png "主服务器向从服务器发送缺失的数据")

利用复制积压缓冲区实现部分重同步后，我们再来讨论一下，复制积压缓冲区的大小如何设置：

我们知道复制积压缓冲区的大小在一定程序上决定了断线后重新连接主服务器进行同步的方式是部分重同步还是完整重同步，因此，正确估算和设置复制积压缓冲区的大小非常重要。

复制积压缓冲区的最小大小可以根据公式`second*write_size_per_second`来估算：

-   中second为从服务器断线后重新连接上主服务器所需的平均时间（以秒计算）。
-   而write\_size\_per\_second则是主服务器平均每秒产生的写命令数据量（协议格式的写命令的长度总和）。

例如，如果主服务器平均每秒产生1 MB的写数据，而从服务器断线之后平均要5秒才能重新连接上主服务器，那么复制积压缓冲区的大小就不能低于5MB

为了安全起见，可以将复制积压缓冲区的大小设为`2*second*write_size_per_second`，这样可以保证绝大部分断线情况都能用部分重同步来处理。
至于复制积压缓冲区大小的修改方法，可以参考配置文件中关于`repl-backlog-size`选项的明。

复制积压缓冲区并不能完全决定是使用部分重同步还是完整重同步，因为有一种可能，就是当断线到重新连接期间，如果从服务器在此期间转为连接的是其它主服务器，那就不能进行部分重同步了。下面我们就要引出`服务器ID` 了，服务器ID是每台Redise服务器，不管是主服务器还是从服务器在服务器启动后都会自动生成，服务器ID是由40个随机的十六进制字符组成，例如`53b9b28df8042fdc9ab5e3fcbbbabff1d5dce2b3`。

当从服务器对主服务器进行初次复制时，主服务器会将自己的运行ID传送给从服务器，而从服务器则会将这个运行ID保存起来。当从服务器断线并重新连上一个主服务器时，从服务器将向之前连接的主服务器ID，发送给当前连接的主服务器：

-   如果从服务器保存的运行ID和当前连接的主服务器的运行ID`相同`，那么说明从服务器断线之前复制的就是当前连接的这个主服务器，主服务器可以继续尝试执行`部分重同步`操作。
-   相反地，如果从服务器保存的运行ID和当前连接的主服务器的运行ID并`不相同`，那么说明从服务器断线之前复制的主服务器并不是当前连接的这个主服务器，主服务器将对从服务器执行`完整重同步`操作。

举个例子，假设从服务器原本正在复制一个运行ID为
`53b9b28df8042fdc9ab5e3fcbbbabff1d5dce2b3`的主服务器，那么在网络断开，从服务器重新连接上主服务器之后，从服务器将向主服务器发送这个运行ID，主服务器根据自己的运行ID是否
`53b9b28df8042fdc9ab5e3fcbbbabff1d5dce2b3`来判断是执行部分重同步还是执行完整重同步。

**PSYNC命令的实现**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678785856156.png)

以一个示例来解释一下PSYNC命令：

首先，假设有两个Redis服务器，它们的版本都是Redis 2.8，其中主服务器的地址为127.0.0.1:6379，从服务器的地址为127.0.0.1:12345。

如果客户端向从服务器发送命令`SLAVEOF 127.0.0.1 6379`，并且假设从服务器是第一次执行复制操作，那么从服务器将向主服务器发送`PSYNC ? -1` 命令，请求主服务器执行完整重同步操作。

主服务器在收到完整重同步请求之后，将在后台执行BGSAVE命令，并向从服务器返回`+FULLRESYNC 53b9b28df8042fdc9ab5e3fcbbbabff1d5dce2b3  10086`回复，其中

-   53b9b28df8042fdc9ab5e3fcbbbabff1d5dce2b3是主服务器的运行ID
-   10086则是主服务器当前的复制偏移量。

假设完整重同步成功执行，并且主从服务器在一段时间之后仍然保持一致，但是在复制偏移量为20000的时候，主从服务器之间的网络连接中断了，这时从服务器将重新连接主服务器，并再次对主服务器进行复制。因为之前曾经对主服务器进行过复制，所以从服务器将向主服务器发送命令`PSYNC  53b9b28df8042fdc9ab5e3fcbbbabff1d5dce2b3 20000`，请求进行部分重同步。

主服务器在接收到从服务器的PSYNC命令之后，首先对比从服务器传来的运行ID `53b9b28df8042fdc9ab5e3fcbbbabff1d5dce2b3`和主服务器自身的运行ID，结果显示该ID和主服务器的运行ID相同，于是主服务器继续读取从服务器传来的偏移量20000，检查偏移量为20000之后的数据是否存在于复制积压缓冲区里面，结果发现数据仍然存在。

确认运行ID相同并且数据存在之后，主服务器将向从服务器返回+CONTINUE回复，表示将与从服务器执行部分重同步操作，之后主服务器会将保存在复制积压缓冲区20000偏移量之后的所有数据发送给从服务器，主从服务器将再次回到一致状态。

#### 8.4.3 SLAVEOF命令说明

当向redis客户端发送SLAVEOF命令时，表示是redis服务器去复制一个主服务器。

步骤如下：

**步骤1：设置主服务器的地址和端口**

当在客户端向从服务器发送`slaveof <masterIp> <masterPort>`  异步命令时，从服务器要做的是将主服务器的信息（ip、port）保存在`redisServer` 结构中：

```c
struct redisServer {
  // ...
  // 主服务器的地址
  char *masterhost;
  // 主服务器的端口
  int masterport;
  // ...
};
```

从服务器将向客户端返回`OK`

**步骤2：建立套接字连接**

当从服务器设置了主服务器的信息后，将向主服务器创建连向主服务器的套接字连接, 建立成功后，接收RDB文件，以及接收主服务器传播来的写命令，诸如此类。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678793315363.png)

使得**从服务器成为主服务器的客户端**。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678793649229.png)

**步骤3：发送PING命令**

建立连接后，从服务器会向主服务器发送PING命令，当主服务器返回PONG后，就可以进入下一步了。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678793890362.png)

**步骤4：进行身份验证**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678794084525.png)

在认证阶段，从服务器会读取配置文件中的`masterauth`参数值，并向主服务器发送`AUTH <masterPassword> `进行验证, 只有两者都设置了密码且密码相同，或从服务器不发送身份验证且主服务器没有设置身份验证，才会成功进入下一个步骤，否则会创建套接字开始重新执行复制，直到身份验证通过，或者从服务器放弃执行复制为止。

**步骤5：发送端口信息**

在身份验证步骤之后，从服务器将执行命令`REPLCONF listening-port <port-number>`，向主服务器发送从服务器的监听`端口号`。

主服务器在接收到这个命令之后，会将端口号记录在从服务器所对应的客户端状态的slave\_listening\_port属性中：

```c
typedef struct redisClient {
  // ...
  // 从服务器的监听端口号
  int slave_listening_port;
  // ...
} redisClient;
```

`slave_listening_port` 属性唯一的作用是主服务器客户端在执行`info replication` 时输出从服务器的信息：

```bash
127.0.0.1:6379> INFO replication
# Replication
role:master
connected_slaves:1
slave0:ip=127.0.0.1,port=12345,status=online,offset=1289,lag=1
master_repl_offset:1289
repl_backlog_active:1
repl_backlog_size:1048576
repl_backlog_first_byte_offset:2
repl_backlog_histlen:1288
```

**步骤6：同步**

上面的操作完成后，从服务器将向主服务器发送`PSYNC`命令与主服务进行同步，此时主服务器需要成为从服务器的客户端，才能向从服务发送数据进行数据同步。

在执行同步操作之后，主服务器也会成为从服务器的客户端，因此，在同步操作执行之后，主从服务器双方都是对方的客户端，它们可以互相向对方发送命令请求，或者互相向对方返回命令回复。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/14/1678794882501.png)

**步骤7：命令传播**

当完成了同步之后，主从服务器就会进入命令传播阶段，这时主服务器只要一直将自己执行的写命令发送给从服务器，而从服务器只要一直接收并执行主服务器发来的写命令，就可以保证主从服务器一直保持一致了。

以上就是Redis 2.8或以上版本的复制功能的实现步骤。

## 9. Redis哨兵

官网：[https://redis.io/docs/management/sentinel/](https://redis.io/docs/management/sentinel/ "https://redis.io/docs/management/sentinel/")

吹哨人巡查监控后台master主机是否故障，如果故障了根据投票数自动将某一个从库转换为新主库，继续对外服务。（俗称：无人值守）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678868012274.png)

总结介绍：在之前的主从结构下（一主多从），搭建一个sentinue集群，sentinue集群的作用是监视这个redis主从集群，当redis的master机器下线后，会挑选出一个状态良好、数据完整的从服务器作为新的master服务器（通过向该服务器发送`slaveof no one`实现），sentinue也会控制其它从服务器向新的master服务器复制（sentinue通过向从服务器发送`slaveof <newMasterIp> <newMasterPort>`实现 ），当旧master重新上线上，sentinue会向旧master发送`slaveof <newMasterIp> <newMasterPort>`让它成为新的master服务器的从节点。

### 9.1 将哨兵集群加入Redis主从

下面是`sentinel集群+redis主从复制` 搭建示例：

![演示的架构](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678869342415.png "演示的架构")

准备四台机器，其中三台作为`redis主从` , 另一台作为sentinel，如上图`192.168.87.110` 机器内将启动三个sentinel实例，分机器配置也是一样的。

redis的主从就不说了，在上面的redis的复制已经说过了，现在要操作的是在存在redis主从下，如何配置Redis哨兵（sentinel）。

Sentinel只是一个运行在特殊模式下的Redis服务器，所以需要sentinel机器也需要安装redis服务器。在运行sentinel实例前，需要准备一个配置文件（在redis目录下与redis.conf在同一目录下），

准备三个实例的配置文件：

sentinel26379.conf

```bash
# 表示 Sentinel 绑定到本机所有的网络接口上，以便于其他机器可以访问这个 Sentinel。
bind 0.0.0.0
# 表示 Sentinel 将以守护进程的方式运行。
daemonize yes
# 表示 Sentinel 禁用了保护模式，允许外部访问 Sentinel 服务。
protected-mode no
# 表示 Sentinel 监听的端口号为26381，以便于其他 Sentinel 和客户端可以连接到这个 Sentinel。
port 26379
# 表示 Sentinel 的日志文件路径和文件名。
logfile "/opt/redis-7/sentinel26379.log"
# 表示 Sentinel 的 PID 文件路径和文件名。
pidfile "/var/run/redis-sentinel26379.pid"
# 表示 Sentinel 的工作目录路径。
dir "/opt/redis-7/sentinel"
# 表示master的ip与port,2是当多少个实例主观认为master已经下线，就转为master已客观下载
sentinel monitor mymaster 192.168.87.105 6379 2
# 如果master设置了密码，这里需要配置对应master的验证密码
sentinel auth-pass mymaster 3333
```

sentinel26380.conf

```bash
bind 0.0.0.0
daemonize yes
protected-mode no
port 26380
logfile "/opt/redis-7/sentinel26380.log"
pidfile "/var/run/redis-sentinel26380.pid"
dir "/opt/redis-7/sentinel"
sentinel monitor mymaster 192.168.87.105 6379 2
sentinel auth-pass mymaster 3333
```

sentinel26381.conf

```bash
bind 0.0.0.0
daemonize yes
protected-mode no
port 26381
logfile "/opt/redis-7/sentinel26381.log"
pidfile "/var/run/redis-sentinel26381.pid"
dir "/opt/redis-7/sentinel"
sentinel monitor mymaster 192.168.87.105 6379 2
sentinel auth-pass mymaster 3333
```

然后依次启动sentinel：

```bash
# 下面加不加“--sentinel”都是一样的，效果完全相同。
redis-sentinel sentinel26379.conf --sentinel
redis-sentinel sentinel26380.conf --sentinel
redis-sentinel sentinel26381.conf --sentinel

```

已经运行起来，一切安好。

```bash
[root@localhost redis-7]# ps -ef | grep sentinel
root      46528      1  0 18:30 ?        00:00:04 redis-sentinel 0.0.0.0:26379 [sentinel]
root      47462      1  0 18:33 ?        00:00:03 redis-sentinel 0.0.0.0:26380 [sentinel]
root      47486      1  0 18:33 ?        00:00:03 redis-sentinel 0.0.0.0:26381 [sentinel]
root      49525  47275  0 18:41 pts/0    00:00:00 grep --color=auto sentinel

```

到这里已经搭建完成了，但你肯定有很多疑惑，没事，下面会讲。

> **哨兵集群功能测试：**
>
> 现在开始测试哨兵的功能，当redis主从中master节点down后，会出现什么情况呢？
>
> 在master机器上，执行`shutdown`  后观察... , 结果发现新的master会从剩下的从服务器中产生。重新启动旧的master服务器 ... ,发现角色变为slave,master是新的master服务器。

### 9.2 哨兵的工作原理

#### sentinel初始化

sentinel启动后，sentinel进入初始化，sentinel不用使用RDB或AOF恢复状态，并且会将Redis服务器使用的代码替换成Sentinel专用代码。

Sentinel则使用sentinel.c/REDIS\_SENTINEL\_PORT常量的值作为服务器端口而不是普通Redis服务`sentinel.c/REDIS_SENTINEL_PORT常量`作为访问端口。

Redis服务器使用redis.c/redisCommandTable作为服务器的命令表，而Sentinel则使用sentinel.c/sentinelcmds作为服务器的命令表，也解释了为什么在Sentinel模式下，Redis服务器不
能执行诸如SET、DBSIZE、EVAL等等这些命令，因为服务器根本没有在命令表中载入这些命令。PING、SENTINEL、INFO、SUBSCRIBE、UNSUBSCRIBE、PSUBSCRIBE和PUNSUBSCRIBE这七个命令就是客户端可以对Sentinel执行的全部命令了。

服务器还会初始化一个`sentinel.c/sentinelState`结构（后面简称“Sentinel状态”）

```c
struct sentinelState {
  // 当前纪元，用于实现故障转移
  uint64_t current_epoch;
  // 保存了所有被这个sentinel, 监视的主服务器
  // 字典的键是主服务器的名字
  // 字典的值则是一个指向sentinelRedisInstance 结构的指针
  dict *masters;
  // 是否进入了TILT 模式？
  int tilt;
  // 目前正在执行的脚本的数量
  int running_scripts;
  // 进入TILT 模式的时间
  mstime_t tilt_start_time;
  // 最后一次执行时间处理器的时间
  mstime_t previous_time;
  // 一个FIFO 队列，包含了所有需要执行的用户脚本
  list *scripts_queue;
} sentinel;
```

sentinelState.masters是sentinelRedisInstance 结构，一个实例表示一个被Sentinel监视的Redis服务器实例（instance），这个实例可以是主服务器、从服务器，或者另外一个Sentinel。

我们在sentinel配置文件中配置的master就可以实例为一个sentinelRedisInstance ：

```c
typedef struct sentinelRedisInstance {
  // 标识值，记录了实例的类型，以及该实例的当前状态
  int flags;
  // 实例的名字，主服务器的名字由用户在配置文件中设置，从服务器以及Sentinel的名字由Sentinel自动设置，格式为ip:port，例如"127.0.0.1:26379"
  char *name;
  // 实例的运行ID
  char *runid;
  // 配置纪元，用于实现故障转移
  uint64_t config_epoch;
  // 实例的地址 master的Ip与port
  sentinelAddr *addr;
  // SENTINEL down-after-milliseconds选项设定的值，实例无响应多少毫秒之后才会被判断为主观下线（subjectively down）
  mstime_t down_after_period;
  // SENTINEL monitor <master-name> <IP> <port> <quorum>选项中的quorum参数，判断这个实例为客观下线（objectively down）所需的支持投票数量
  int quorum;
  // SENTINEL parallel-syncs <master-name> <number>选项的值，在执行故障转移操作时，可以同时对新的主服务器进行同步的从服务器数量
  int parallel_syncs;
  // SENTINEL failover-timeout <master-name> <ms>选项的值，刷新故障迁移状态的最大时限
  mstime_t failover_timeout;
  // 主服务器实例结构的slaves字典
  dict *slaves;
  // 记录了所有已知的Sentinel的状态，包括它们的ID、地址和上次报告的时间
  dict *sentinels;
  // ...
} sentinelRedisInstance;
```

比如我们在sentinel配置的master信息：

```bash
#####################
# master1 configure #
#####################
sentinel monitor master1 127.0.0.1 6379 2
sentinel down-after-milliseconds master1 30000
sentinel parallel-syncs master1 1
sentinel failover-timeout master1 900000
#####################
# master2 configure #
#####################
sentinel monitor master2 127.0.0.1 12345 5
sentinel down-after-milliseconds master2 50000
sentinel parallel-syncs master2 5
sentinel failover-timeout master2 450000
```

会生成如下结构：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678878341327.png)

sentinel需要与其它sentinel实例建立联系，必须要先"创建连向主服务器的网络连接".

#### Sentinel通过命令连接获取主/从服务器信息

sentinel创建一个连向主服务器的连接，让Sentinel将成为主服务器的客户端，然后向主服务器（redis主从的master节点），从主服务器返回的信息中获取相关信息。

Sentinel会创建两个连向主服务器的异步网络连接：

-   一个是`命令连接`，这个连接专门用于向主服务器发送命令，并接收命令回复。
-   另一个是`订阅连接`，这个连接专门用于订阅主服务器的\_\_sentinel\_\_:hello频道。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678878736714.png)

为什么要创建**命令连接**？

建立命令连接后，sentinel就可以向主服务器发送`info replication`  命令获取主/从节点的信息了。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678879818601.png)

sentinel向主节点发送上述命令获取的信息如下：

```bash
# Replication
role:master
connected_slaves:2
slave0:ip=192.168.87.107,port=6381,state=online,offset=1940005,lag=1
slave1:ip=192.168.87.105,port=6379,state=online,offset=1940005,lag=1
master_failover_state:no-failover
master_replid:e3a1331ac1087d6bf7e8addb54d223bf2f0d4ee6
master_replid2:10548c4673cbbc0069ac5e74a7790b1bb5628f1f
master_repl_offset:1940148
second_repl_offset:4854
repl_backlog_active:1
repl_backlog_size:1048576
repl_backlog_first_byte_offset:880231
repl_backlog_histlen:1059918

```

作用如下：

-   用于更新主节点的信息：根据run\_id域和role域记录的信息，Sentinel将对主服务器的实例结构进行更新，当主服务器重启后run\_id就会改变，如果run\_id与之前保存的run\_id不同就会进行更新。
-   用于更新主节点下的从节点信息 `dict *slaves;`，它是一个sentinelRedisInstance结构的。如果是否已经存在slave的节点信息，如果不存在会创建，存在就进行更新。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678880803716.png)

注意图片主从实例结构中flags属性的区别，主服务器实例结构的flags属性的值为SRI\_MASTER，而从服务器实例结构的flags属性的值为SRI\_SLAVE。

主服务器实例结构的name属性的值是用户使用Sentinel配置文件设置的，而从服务器实例结构的name属性的值则是Sentinel根据从服务器的IP地址和端口号自动设置的。

这也是Sentinel无须用户提供从服务器的地址信息，就可以自动发现从服务器的原理。

#### Sentinel通过订阅连接获取其它Sentinel节点信息

从服务器是通过向主服务发送信息发现的，当发现后，Sentinel除了会为这个新的从服务器创建相应的实例结构之外，Sentinel还会创建连接到从服务器的命令连接和订阅连接。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678881161331.png)

与从服务器建立连接后，会默认每十秒一次的频率通过命令连接向从服务器发送INFO命令，更新其slave的sentinelRedisInstance结构信息：

-   从服务器的运行ID run\_id。
-   从服务器的角色role。
-   主服务器的IP地址master\_host，以及主服务器的端口号master\_port。
-   主从服务器的连接状态master\_link\_status。
-   从服务器的优先级slave\_priority。
-   从服务器的复制偏移量slave\_repl\_offset

sentinel不但与主/从服务器建立了命令连接，还建立了订阅连接，在默认情况下，Sentinel会以每两秒一次的频率，通过命令连接向所有被监视的主服务器和从服务器在频道"`sentinel:hello`"上发布信息：

```bash
PUBLISH __sentinel__:hello "<s_ip>,<s_port>,<s_runid>,<s_epoch>,<m_name>,<m_ip>,<m_port>,<m_epoch>"
# 参数示例："127.0.0.1,26379,e955b4c85598ef5b5f055bc7ebfd5e828dbed4fa,0,mymaster,127.0.0.1,6379,0"
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678882089594.png)

同时也会订阅主/从服务器发送如下命令来订阅频道:

```bash
SUBSCRIBE __sentinel__:hello
```

Sentinel对\_\_sentinel\_\_:hello频道的订阅会一直持续到Sentinel与服务器的连接断开为止

也就是说Sentinel通过命令连接既向服务器的\_\_sentinel\_\_:hello频道发送信息，又通过订阅连接从服务器的**sentinel**:hello频道接收信息:

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678882449746.png)

下面通过举例一个Sentinel接收到订阅的信息后如何处理 :&#x20;

假设分别有`127.0.0.1:26379`、`127.0.0.1:26380`、`127.0.0.1:26381`三个Sentinel正在监视主服务器`127.0.0.1:6379`，那么当`127.0.0.1:26379`这个Sentinel接收到以下信息时：

```bash
1) "message"
2) "__sentinel__:hello"
3) "127.0.0.1,26379,e955b4c85598ef5b5f055bc7ebfd5e828dbed4fa,0,mymaster,127.0.0.1,6379,0"

1) "message"
2) "__sentinel__:hello"
3) "127.0.0.1,26381,6241bf5cf9bfc8ecd15d6eb6cc3185edfbb24903,0,mymaster,127.0.0.1,6379,0"

1) "message"
2) "__sentinel__:hello"
3) "127.0.0.1,26380,a9b22fb79ae8fad28e4ea77d20398f77f6b89377,0,mymaster,127.0.0.1,6379,0"
```

第一条 : 发送是自己发出来的订阅信息,这条信息会被忽略.

第二条 : 发现信息是`127.0.0.1,26381` 发的,会更新/创建自己sentinel实例的sentinel.master对应的 "127.0.0.1:6379"这个master实例结构下的sentinels下`127.0.0.1:26381`sentinel机器信息.

第三条: 发现信息是`127.0.0.1:26380` 发的,会更新/创建自己sentinel实例的sentinel.master对应的 "127.0.0.1:6379"这个master实例结构下的sentinels下`127.0.0.1:26380`sentinel机器信息.

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678883439513.png)

在上面中如果发现sentinel没有源Sentinel的实例结构不存在，那么说明源Sentinel是刚刚开始监视
主服务器的新Sentinel，目标Sentinel会为源Sentinel创建一个新的实例结构，并将这个结构添加到sentinels字典里面。

一个Sentinel可以通过分析接收到的频道信息来获知其他Sentinel的存在，并通过发送频道信息来让其他Sentinel知道自己的存在，所以用户在使用Sentinel的时候并不需要提供各个Sentinel的地址信息，监视同一个主服务器的多个Sentinel可以自动发现对方。

当Sentinel通过频道信息发现一个新的Sentinel时，它不仅会为新Sentinel在sentinels字典中创建相应的实例结构，还会创建一个连向新Sentinel的命令连接(不会创建订阅连接)，而新Sentinel也同样会创建连向这个Sentinel的命令连接，最终监视同一主服务器的多个Sentinel将形成相互连接的网络.

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678884914726.png)

> **关于为什么Sentinel间不创建订阅链接**
>
> Sentinel在连接主服务器或者从服务器时，会同时创建命令连接和订阅连接，但是在连接其他Sentinel时，却只会创建命令连接，而不创建订阅连接。这是因为Sentinel需要通过接收主服务器或者从服务器发来的频道信息来发现未知的新Sentinel，所以才需要建立订阅连接，而相互已知的Sentinel只要使用命令连接来进行通信就足够了。

到此sentinel间就可以进行通信了,他们就可以讨论当master下线后让哪个从服务器作为主服务器了.

下面我们就可学习这一过程.&#x20;

#### Master的主观下线到客观下线

Sentinel会以每秒一次的频率向所有与它创建了命令连接的实例（包括主服务器、从服务器、其他Sentinel在内）发送PING命令，并通过实例返回的PING命令回复来判断实例是否在线。

当返回的是无效的回复时( 除+PONG、-LOADING、-MASTERDOWN三种回复之外的其他回复/无回复 ), 结合用户在sentinel.conf配置的`down-after-milliseconds` 时长,即在该时间内若连续向Sentinel返回无效回复,那么会修改对应的实例结构的flags属性打开`SRI_S_DOWN`标识,此来表示这个实例已经进入主观下线状态。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678886777581.png)

主观下载与我们配置的`down-after-milliseconds`是相关的,有的sentinel实例设置的值比较小就会比较快的主观判定为下线, 此时会向同样监视着他的其它Sentinel询问,看它们是否也认为主服务器已下线状态,如果`down-after-milliseconds`比较长,其它的可能还会认为主服务器还处于正常状态. 向其它sentinel询问的格式是:

```bash
SENTINEL is-master-down-by-addr <ip> <port> <current_epoch> <runid>
```

1.  `<ip>`: 主服务器的 IP 地址。
2.  `<port>`: 主服务器监听的端口号。
3.  `<current_epoch>`: 当前纪元值。这是一个整数，用于标识当前哨兵集群中正在进行的操作序列。如果请求来自具有较旧纪元值的哨兵，则请求将被拒绝。
4.  `<runid>`: 发出此命令的哨兵节点 ID。

如果其它sentinel服务器也认为该master也下线,且达到我们在sentinel.conf中配置的,如: `sentinel monitor master 127.0.0.1 6379 2` , 只要有两台sentinel都主观认为该master已经下载,那发起询问的sentinel会判断为客观下线.

#### 选举领头(leader) 负责故障转移

当一个主服务器被判断为客观下线时，监视这个下线主服务器的各个Sentinel会进行协商，选举出一个领头Sentinel，并由领头Sentinel对下线主服务器执行故障转移操作。

在判定为master客观下线后,再次向其他Sentinel发送`SENTINEL is-master-down-by-addr`命令, 这个命令与询问其它sentinel是否主观下线不同,

```bash
SENTINEL is-master-down-by-
addr 127.0.0.1 6379 0 e955b4c85598ef5b5f055bc7ebfd5e828dbed4fa
```

向其它sentinel表示要求将自己设置为领头Sentinel, 接收到这个命令的Sentinel如果还没有设置局部领头Sentinel的话，它就会将该运行ID设置为自己的局部领头Sentinel (一个sentinel只可以设置一个,后面接到的要求投票命令的将不再接受).  如果返回

```bash
1) 1
2) e955b4c85598ef5b5f055bc7ebfd5e828dbed4fa
3) 0
```

两者runid相同,表示对方将自己设为了领头sentinel.&#x20;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678894409677.png)

当一个sentinel从发出命令与收集到足够的票数后(6/10大于或等于6票时),且是最快达到票数的且作为领头Sentinel.

领头Sentinel负责故障转移 .

**故障转移**

在选举产生出领头Sentinel之后，领头Sentinel将对已下线的主服务器执
行故障转移操作，该操作包含以下三个步骤：

1.  在已下线主服务器属下的所有从服务器里面，挑选出一个从服务器，并将其转换为主服务器。
2.  让已下线主服务器属下的所有从服务器改为复制新的主服务器。
3.  将已下线主服务器设置为新的主服务器的从服务器，当这个旧的主服务器重新上线时，它就会成为新的主服务器的从服务器。

如何从`从服务器`中选出一个从服务器作为新的主服务器呢?

领头Sentinel会将已下线主服务器的所有从服务器保存到一个列表里面，然后按照以下规则，一项一项地对列表进行过滤, 最终挑选出一个状态良好、数据完整的从服务器，然后向这个从服务器发送`SLAVEOF no one`命令，将这个从服务器转换为主服务器。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678895727863.png)

在发送SLAVEOF no one命令之后，领头Sentinel会以每秒一次的频率（平时是每十秒一次），向被升级的从服务器发送INFO命令，并观察命令回复中的角色（role）信息，当被升级服务器的role从原来的slave变为master时，领头Sentinel就知道被选中的从服务器已经顺利升级为主服务器了。

从服务器升级主服务器后就可以将剩余的服务器发送`SLAVEOF <newMasterIp> <newMasterPort>`命令来实现从服务器的复制目标.&#x20;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678895698305.png)

还有最后一步,当旧的主服务器重新上线时, 将旧的主服务器变为从服务器.&#x20;

当旧的主服务器重新上线时, sentinel会检测到, 会向旧的主服务器发送命令`SLAVEOF <newMasterIp> <newMasterPort>` 让旧的主服务器成为新的主服务器的从服务器.

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/15/1678895955823.png)

旧的新机器上在配置文件中就会添加一行`replicaof 192.168.87.106 6380` , 不但旧的主机器被修改,从机器也会多出一行此配置.

> \*\*哨兵使用建议 : \*\*
>
> -   哨兵节点的数量应为多个，哨兵本身应该集群，保证高可用哨兵节点的数量应该是奇数
> -   各个哨兵节点的配置应一致
> -   如果哨兵节点部署在Docker等容器里面，尤其要注意端口的正确映射哨兵集群+主从复制，并能保证数据零丢失承上启下引出集群

## 10. Redis集群

不管是Redis主从复制还是Redis哨兵Redis主服务器都无法负载均衡，而Redis集群解决了存储能力受到单机限制，写操作无法负载均衡的问题。

### 10.1搭建演示

#### 10.1.1 三主三从集群配置：启动三台集群实例

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/16/1678948114506.png)

启动6台Redis实例，演示使用三台机器：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679015375400.png)

上面每台机器，每台实例都一样，进行如何操作，以redis6379为例（其它实例只需要修改差异点就行）：

```bash
cd /opt/redis-7/
mkdir cluster
vim redisCluster6379.conf

```

```bash
bind 0.0.0.0
daemonize yes
protected-mode no
port 6379
logfile "/opt/redis-7/cluster/cluster6379.log"
pidfile "/opt/redis-7/cluster/cluster6379.pid"
dir "/opt/redis-7/cluster"
dbfilename "dump6379.rdb"
appendonly yes
appendfilename "appendonly6379.aof"
requirepass "3333"
masterauth "3333"

cluster-enabled yes
cluster-config-file "nodes-6379.conf"
cluster-node-timeout 5000
```

其它实例复杂以上操作....

启动实例：

```bash
# 在192.168.87.105机器上
redis-server /opt/redis-7/cluster/redisCluster6379.conf
redis-server /opt/redis-7/cluster/redisCluster6380.conf
# 在192.168.87.106机器上
redis-server /opt/redis-7/cluster/redisCluster6381.conf
redis-server /opt/redis-7/cluster/redisCluster6382.conf
# 在192.168.87.107机器上
redis-server /opt/redis-7/cluster/redisCluster6383.conf
redis-server /opt/redis-7/cluster/redisCluster6384.conf

```

#### 10.1.2 三主三从集群配置：构建主从关系

在下面命令中涉及到的任何一台机器上执行以下命令：

```bash
redis-cli -a 3333 --cluster create --cluster-replicas 1 192.168.87.105:6379 192.168.87.105:6380 192.168.87.106:6381 192.168.87.106:6382 192.168.87.107:6383 192.168.87.107:6384
```

执行输出：

在下面的输出中就已经决定了哪些是主服务器哪些是从服务器。

```bash
[root@localhost cluster]# redis-cli -a 3333 --cluster create --cluster-replicas 1 192.168.87.105:6379 192.168.87.105:6380 192.168.87.106:6381 192.168.87.106:6382 192.168.87.107:6383 192.168.87.107:6384
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
>>> Performing hash slots allocation on 6 nodes...
Master[0] -> Slots 0 - 5460
Master[1] -> Slots 5461 - 10922
Master[2] -> Slots 10923 - 16383
Adding replica 192.168.87.106:6382 to 192.168.87.105:6379
Adding replica 192.168.87.107:6384 to 192.168.87.106:6381
Adding replica 192.168.87.105:6380 to 192.168.87.107:6383
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[0-5460] (5461 slots) master
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[5461-10922] (5462 slots) master
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[10923-16383] (5461 slots) master
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   replicates a946caa177d0d77974f90f4954789e5066101721
Can I set the above configuration? (type 'yes' to accept):  yes 
>>> Nodes configuration updated
>>> Assign a different config epoch to each node
>>> Sending CLUSTER MEET messages to join the cluster
Waiting for the cluster to join
..
>>> Performing Cluster Check (using node 192.168.87.105:6379)
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[0-5460] (5461 slots) master
   1 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[10923-16383] (5461 slots) master
   1 additional replica(s)
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[5461-10922] (5462 slots) master
   1 additional replica(s)
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
```

**查看集群信息：**

-   `info replication` : 查看当前节点的角色，如果是master还可以查看slave信息。如果是slave可以查看所属的master。
    ```bash
    127.0.0.1:6379> INFO replication
    # Replication
    role:master
    connected_slaves:1
    slave0:ip=192.168.87.106,port=6382,state=online,offset=476,lag=0
    master_failover_state:no-failover
    master_replid:3a01171018ea8cc4c982a8b43a4e4fd596ab9935
    master_replid2:0000000000000000000000000000000000000000
    master_repl_offset:476
    second_repl_offset:-1
    repl_backlog_active:1
    repl_backlog_size:1048576
    repl_backlog_first_byte_offset:1
    repl_backlog_histlen:476

    ```
-   `CLUSTER INFO`: 查看是否集群成功或说是否已经建立集群关系（`cluster_state:ok`）与集群的更多信息。
    ```bash
    127.0.0.1:6379> CLUSTER INFO
    cluster_state:ok
    cluster_slots_assigned:16384
    cluster_slots_ok:16384
    cluster_slots_pfail:0
    cluster_slots_fail:0
    cluster_known_nodes:6
    cluster_size:3
    cluster_current_epoch:6
    cluster_my_epoch:1
    cluster_stats_messages_ping_sent:762
    cluster_stats_messages_pong_sent:809
    cluster_stats_messages_sent:1571
    cluster_stats_messages_ping_received:804
    cluster_stats_messages_pong_received:762
    cluster_stats_messages_meet_received:5
    cluster_stats_messages_received:1571
    total_cluster_links_buffer_limit_exceeded:0

    ```
-   `CLUSTER NODES` : 查看集群各各节点间的关系（主从关系）
    ```bash
    127.0.0.1:6379> CLUSTER NODES
    a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383@16383 master - 0 1678949553505 5 connected 10923-16383
    ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379@16379 myself,master - 0 1678949552000 1 connected 0-5460
    399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382@16382 slave ff93f4e3b388243775802893db59cd77bf4a0603 0 1678949553506 1 connected
    a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381@16381 master - 0 1678949553505 3 connected 5461-10922
    2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380@16380 slave a2580a1f0417b47479d5837a6713136b56648054 0 1678949553000 5 connected
    5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384@16384 slave a946caa177d0d77974f90f4954789e5066101721 0 1678949552797 3 connected

    ```

#### 10.1.3 三主三从集群配置：测试读写

在集群节点的192.168.87.105:6379实例上进行`set k1 v1` 操作输出错误，

```bash
127.0.0.1:6379> set k1 v1
(error) MOVED 12706 192.168.87.107:6383
```

错误表示 ，你要设置的键值需要去`192.168.87.107:6383`机器上执行（已验证，去目标实例上执行成功！）。因为集群的数据存储是分片的。

验证：key `k1` 在`192.168.87.107:6383`上：

```bash
127.0.0.1:6383> CLUSTER NODES
2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380@16380 slave a2580a1f0417b47479d5837a6713136b56648054 0 1678950839530 5 connected
a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383@16383 myself,master - 0 1678950838000 5 connected 10923-16383
ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379@16379 master - 0 1678950839000 1 connected 0-5460
5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384@16384 slave a946caa177d0d77974f90f4954789e5066101721 0 1678950840036 3 connected
399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382@16382 slave ff93f4e3b388243775802893db59cd77bf4a0603 0 1678950839023 1 connected
a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381@16381 master - 0 1678950839000 3 connected 5461-10922
127.0.0.1:6383> CLUSTER KEYSLOT k1
(integer) 12706

```

那如何让现在执行的机器`192.168.87.105:6379`帮我们转发请求到`192.168.87.107:6383`呢？

那就是在我们进入实例客户端前加`-c` :&#x20;

```bash
127.0.0.1:6379> set k4 v4
(error) MOVED 8455 192.168.87.106:6381
127.0.0.1:6379>
[root@localhost cluster]# redis-cli -a 3333 -c
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
127.0.0.1:6379> set k4 v4
-> Redirected to slot [8455] located at 192.168.87.106:6381
OK

```

#### 10.1.4 三主三从集群配置：集群中主从容错切换

获取一条主从信息，从下面的信息输出中，可以知道`192.168.87.105:6379` 是master节点，并且他的从节点是`192.168.87.106:6382`.

```bash
127.0.0.1:6379> CLUSTER NODES
a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383@16383 master - 0 1678951294065 5 connected 10923-16383
ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379@16379 myself,master - 0 1678951293000 1 connected 0-5460
399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382@16382 slave ff93f4e3b388243775802893db59cd77bf4a0603 0 1678951293000 1 connected
a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381@16381 master - 0 1678951293000 3 connected 5461-10922
2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380@16380 slave a2580a1f0417b47479d5837a6713136b56648054 0 1678951295075 5 connected
5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384@16384 slave a946caa177d0d77974f90f4954789e5066101721 0 1678951293055 3 connected

```

现在测试，当`shutdown` →`192.168.87.105:6379` 时，作为从节点`192.168.87.106:6382` 是否会上位呢？

```bash
127.0.0.1:6381> CLUSTER NODES
a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381@16381 myself,master - 0 1678951368000 3 connected 5461-10922
399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382@16382 master - 0 1678951368860 7 connected 0-5460
5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384@16384 slave a946caa177d0d77974f90f4954789e5066101721 0 1678951368554 3 connected
2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380@16380 slave a2580a1f0417b47479d5837a6713136b56648054 0 1678951367000 5 connected
a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383@16383 master - 0 1678951367000 5 connected 10923-16383
ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379@16379 master,fail - 1678951348523 1678951346000 1 disconnected
```

当shutdown后，查看集群节点信息的输出可以知道 ，`192.168.87.105:6379` 已经“disconnected”，且它的从节点`192.168.87.106:6382`已经上位为master.

当之前的master节点（`92.168.87.105:6379`）恢复上线呢, 会恢复master的位置吗？

```bash
[root@localhost cluster]# redis-server redisCluster6379.conf

```

再次查看集群节点的信息：

```bash
127.0.0.1:6381> CLUSTER NODES
a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381@16381 myself,master - 0 1678952499000 3 connected 5461-10922
399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382@16382 master - 0 1678952500000 7 connected 0-5460
5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384@16384 slave a946caa177d0d77974f90f4954789e5066101721 0 1678952501720 3 connected
2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380@16380 slave a2580a1f0417b47479d5837a6713136b56648054 0 1678952500705 5 connected
a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383@16383 master - 0 1678952500098 5 connected 10923-16383
ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379@16379 slave 399a15d600d2ee2902344ef2f2ccb56f813b2150 0 1678952501000 7 connected

```

从上面输出中可以看出，旧的master节点(`192.168.87.105:6379`)恢复上线后，成为了旧slave(`192.168.87.106:6382`)的slave.&#x20;

那`192.168.87.105:6379`如何恢复之前的master角色（让`192.168.87.106:6382`退位）呢？

`192.168.87.105:6379`可以使用`CLUSTER FAILOVER` 来恢复master的位置，所以下面在`192.168.87.105:6379`客户端上执行：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679025506815.jpg)

注意redis不能保证强一致性，因为当master 下线后，在其从节点切换为主节点时，这个过程中如果写操作对应的槽在down的主从上，写操作将丢失。

#### 10.1.5 三主三从集群配置：添加主从

**添加一个新的master：**

想要创建一个master或slave，要先需要加一个配置：

redisCluster6385.conf

```bash
bind 0.0.0.0
daemonize yes
protected-mode no
port 6385
logfile "/opt/redis-7/cluster/cluster6385.log"
pidfile /opt/redis-7/cluster/cluster6385.pid
dir /opt/redis-7/cluster
dbfilename dump6385.rdb
appendonly yes
appendfilename "appendonly6385.aof"
requirepass 3333
masterauth 3333

cluster-enabled yes
cluster-config-file nodes-6385.conf
cluster-node-timeout 5000

```

然后启动实例：

```bash
redis-server /opt/redis-7/cluster/redisCluster6385.conf
```

将新实例加入集群中：

新实例：192.168.87.107:6385

引路人（集群中节点）：192.168.87.107:6384 &#x20;

```bash
redis-cli -a 3333 --cluster add-node 192.168.87.107:6385 192.168.87.107:6384
```

分配槽位：

刚加入集合是没有分配槽位的（也就是没什么事可做），可以通过`redis-cli -a 3333 --cluster check 192.168.87.107:6384` 来查看集群中各master槽位分配情况，

```bash
[root@localhost cluster]# redis-cli -a 3333 --cluster check  192.168.87.107:6384
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
192.168.87.105:6379 (ff93f4e3...) -> 2 keys | 5461 slots | 1 slaves.
192.168.87.106:6381 (a946caa1...) -> 1 keys | 5462 slots | 1 slaves.
192.168.87.107:6383 (a2580a1f...) -> 1 keys | 5461 slots | 1 slaves.
192.168.87.107:6385 (7b177639...) -> 0 keys | 0 slots | 0 slaves.
[OK] 4 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.87.107:6384)
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[0-5460] (5461 slots) master
   1 additional replica(s)
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[5461-10922] (5462 slots) master
   1 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[10923-16383] (5461 slots) master
   1 additional replica(s)
M: 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9 192.168.87.107:6385
   slots: (0 slots) master
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.


```

发现新实例刚进来是master且槽位为`0 slots` 与`0 slaves` ，新实例的ID为`7b1776396a3e9acc5833702a7d33f8ac7a4be9d9` (槽位分配中使用到)

开始分配：

```bash
redis-cli -a 3333 --cluster reshard 192.168.87.107:6384
```

执行后依次输入`4096`  `7b1776396a3e9acc5833702a7d33f8ac7a4be9d9` `all`

（`7b1776396a3e9acc5833702a7d33f8ac7a4be9d9` 是要分配槽位的主服务器的ID），

分配完成后，再次查看槽位情况：发现已经给`192.168.87.107:6385` 分配了槽位。

```bash
[root@localhost cluster]# redis-cli -a 3333 --cluster check 192.168.87.107:6384
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
192.168.87.105:6379 (ff93f4e3...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.106:6381 (a946caa1...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.107:6383 (a2580a1f...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.107:6385 (7b177639...) -> 1 keys | 4096 slots | 0 slaves.
[OK] 4 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.87.107:6384)
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[1365-5460] (4096 slots) master
   1 additional replica(s)
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[6827-10922] (4096 slots) master
   1 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[12288-16383] (4096 slots) master
   1 additional replica(s)
M: 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9 192.168.87.107:6385
   slots:[0-1364],[5461-6826],[10923-12287] (4096 slots) master
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
```

> 为什么6385是3个新的区间，以前的还是连续？
>
> 重新分配成本太高，所以前3家各自匀出来一部分，从6379/6381/6383三个旧master节点分别匀出1364个坑位给新节点6385.

扩容子节点

准备一个集群实例启动配置文件：

redisCluster6386.conf

```bash
bind 0.0.0.0
daemonize yes
protected-mode no
port 6386
logfile "/opt/redis-7/cluster/cluster6386.log"
pidfile /opt/redis-7/cluster/cluster6386.pid
dir /opt/redis-7/cluster
dbfilename dump6386.rdb
appendonly yes
appendfilename "appendonly6386.aof"
requirepass 3333
masterauth 3333

cluster-enabled yes
cluster-config-file nodes-6386.conf
cluster-node-timeout 5000
```

使用这个配置来启动一个实例：`redis-server /opt/redis-7/cluster/redisCluster6386.conf`

将`192.168.87.107:6386` 作为`192.168.87.107:6385` 子节点，下面的命令`7b1776396a3e9acc5833702a7d33f8ac7a4be9d9` 表示 `192.168.87.107:6385`的ID。

```bash
[root@localhost cluster]# redis-cli -a 3333 --cluster add-node 192.168.87.107:6386 192.168.87.107:6385 --cluster-slave --cluster-master-id 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
>>> Adding node 192.168.87.107:6386 to cluster 192.168.87.107:6385
>>> Performing Cluster Check (using node 192.168.87.107:6385)
M: 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9 192.168.87.107:6385
   slots:[0-1364],[5461-6826],[10923-12287] (4096 slots) master
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[12288-16383] (4096 slots) master
   1 additional replica(s)
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[1365-5460] (4096 slots) master
   1 additional replica(s)
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[6827-10922] (4096 slots) master
   1 additional replica(s)
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
>>> Send CLUSTER MEET to node 192.168.87.107:6386 to make it join the cluster.
Waiting for the cluster to join

>>> Configure node as replica of 192.168.87.107:6385.
[OK] New node added correctly.

```

再次检查集群节点：从命令输出中可以看出`192.168.87.107:6386` 已经成为`192.168.87.107:6385` 子节点。

```bash
[root@localhost cluster]# redis-cli -a 3333 --cluster check 192.168.87.107:6384
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
192.168.87.105:6379 (ff93f4e3...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.106:6381 (a946caa1...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.107:6383 (a2580a1f...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.107:6385 (7b177639...) -> 1 keys | 4096 slots | 1 slaves.
[OK] 4 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.87.107:6384)
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[1365-5460] (4096 slots) master
   1 additional replica(s)
S: b0b7cf5d5d80ca48f1771af52a3ec6cfa8981387 192.168.87.107:6386
   slots: (0 slots) slave
   replicates 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[6827-10922] (4096 slots) master
   1 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[12288-16383] (4096 slots) master
   1 additional replica(s)
M: 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9 192.168.87.107:6385
   slots:[0-1364],[5461-6826],[10923-12287] (4096 slots) master
   1 additional replica(s)
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

```

#### 10.1.6 三主三从集群配置：撤销主从

`192.168.87.107:6385`与`192.168.87.107:6386` 是新加入的主从。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679035539537.png)

如果我们想移除到扩容的节点`redis6385`与`redis 6386` , 操作流程如下：

1）将从节点192.168.87.107:6386 从集群中删除

先查看集群状态：

```bash
[root@localhost ~]# redis-cli  -a 3333 --cluster check 192.168.87.107:6386
Warning: Using a password with '-a' or '-u' option on the command line interface may                                                  not be safe.
192.168.87.105:6379 (ff93f4e3...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.107:6385 (7b177639...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.106:6381 (a946caa1...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.107:6383 (a2580a1f...) -> 1 keys | 4096 slots | 1 slaves.
[OK] 4 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.87.107:6386)
S: b0b7cf5d5d80ca48f1771af52a3ec6cfa8981387 192.168.87.107:6386
   slots: (0 slots) slave
   replicates 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[1365-5460] (4096 slots) master
   1 additional replica(s)
M: 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9 192.168.87.107:6385
   slots:[0-1364],[5461-6826],[10923-12287] (4096 slots) master
   1 additional replica(s)
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[6827-10922] (4096 slots) master
   1 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[12288-16383] (4096 slots) master
   1 additional replica(s)
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

```

可以看到`192.168.87.107:6385`下面有一个从节点是`192.168.87.107:6386`，下面开始从集群中移除`192.168.87.107:6386`从节点。

```bash
redis-cli -a 3333 --cluster del-node 192.168.87.107:6386 b0b7cf5d5d80ca48f1771af52a3ec6cfa8981387

```

再次检测集群状态：发现主节点`192.168.87.107:6385` 下面已经没有从节点了。也就是其从节点`192.168.87.107:6386` 已经从集群中删除了。

```bash
[root@localhost ~]# redis-cli -a 3333 --cluster check 192.168.87.106:6382
Warning: Using a password with '-a' or '-u' option on the command line interface may                                                  not be safe.
192.168.87.107:6385 (7b177639...) -> 1 keys | 4096 slots | 0 slaves.
192.168.87.105:6379 (ff93f4e3...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.106:6381 (a946caa1...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.107:6383 (a2580a1f...) -> 1 keys | 4096 slots | 1 slaves.
[OK] 4 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.87.106:6382)
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
M: 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9 192.168.87.107:6385
   slots:[0-1364],[5461-6826],[10923-12287] (4096 slots) master
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[1365-5460] (4096 slots) master
   1 additional replica(s)
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[6827-10922] (4096 slots) master
   1 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[12288-16383] (4096 slots) master
   1 additional replica(s)
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

```

2）从集群中删除`192.168.87.107:6385`主服务器

对`192.168.87.107:6385` 主服务器的槽位清空：

```bash
redis-cli -a 3333 --cluster reshard 192.168.87.106:6382

```

键入信息：

-   标节点中移除的槽位：`4096`  ，也就是`192.168.87.107:6385`分配进的全部槽位；
-   由谁接收节点：`a946caa177d0d77974f90f4954789e5066101721` , 这是 的ID
-   将哪个主服务器的槽位进行重新分配：`7b1776396a3e9acc5833702a7d33f8ac7a4be9d9` ,这是`192.168.87.107:6385`的ID;
-   `done`

再次查看集群中各主服务器的槽位分配：发现`192.168.87.107:6385`节点虽然还在集群中，但已经是个闲人了，不再拥有槽位了

```bash
[root@localhost ~]# redis-cli -a 3333 --cluster check 192.168.87.106:6382
Warning: Using a password with '-a' or '-u' option on the command line interface may                                                  not be safe.
192.168.87.105:6379 (ff93f4e3...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.106:6381 (a946caa1...) -> 2 keys | 8192 slots | 2 slaves.
192.168.87.107:6383 (a2580a1f...) -> 1 keys | 4096 slots | 1 slaves.
[OK] 4 keys in 3 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.87.106:6382)
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
S: 7b1776396a3e9acc5833702a7d33f8ac7a4be9d9 192.168.87.107:6385
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[1365-5460] (4096 slots) master
   1 additional replica(s)
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[0-1364],[5461-12287] (8192 slots) master
   2 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[12288-16383] (4096 slots) master
   1 additional replica(s)
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

```

将`192.168.87.107:6385`从集群中移除：

```bash
redis-cli -a 3333 --cluster del-node 192.168.87.1-7:6385 7b17763
```

再次检查：发现`192.168.87.107:6385`已经在集群节点列表中了。

```bash
[root@localhost ~]# redis-cli -a 3333 --cluster check 192.168.87.106:6382                                                            Warning: Using a password with '-a' or '-u' option on the command line interface may                                                  not be safe.
192.168.87.105:6379 (ff93f4e3...) -> 1 keys | 4096 slots | 1 slaves.
192.168.87.106:6381 (a946caa1...) -> 2 keys | 8192 slots | 1 slaves.
192.168.87.107:6383 (a2580a1f...) -> 1 keys | 4096 slots | 1 slaves.
[OK] 4 keys in 3 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.87.106:6382)
S: 399a15d600d2ee2902344ef2f2ccb56f813b2150 192.168.87.106:6382
   slots: (0 slots) slave
   replicates ff93f4e3b388243775802893db59cd77bf4a0603
S: 5d1018225a7e850b93f5c00803a522e152b7534a 192.168.87.107:6384
   slots: (0 slots) slave
   replicates a946caa177d0d77974f90f4954789e5066101721
S: 2692f369e55c14c5260ac868beee1f044b223e2c 192.168.87.105:6380
   slots: (0 slots) slave
   replicates a2580a1f0417b47479d5837a6713136b56648054
M: ff93f4e3b388243775802893db59cd77bf4a0603 192.168.87.105:6379
   slots:[1365-5460] (4096 slots) master
   1 additional replica(s)
M: a946caa177d0d77974f90f4954789e5066101721 192.168.87.106:6381
   slots:[0-1364],[5461-12287] (8192 slots) master
   1 additional replica(s)
M: a2580a1f0417b47479d5837a6713136b56648054 192.168.87.107:6383
   slots:[12288-16383] (4096 slots) master
   1 additional replica(s)
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

```

### 10.2 Redis集群的底层工作原理

#### 10.2.1 Redis采用的是分片存储

Redis集群是在Redis3.0加入的，实现了对数据分片存储，将全部的数据分片存储在不同master中。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679040075289.png)

Redis集群可以看成多个主从架构组合，每一个主从架构可以看成一个节点（其中，只有master节点具有处理请求的能力，slave节点主要是用于节点的高可用）

Redis集群采用的是去中心化的思想，没有中心节点的说法，可以连接任意一个节点对集群进行操作，当客户端操作的key没有分配到该node上时，Redis会返回转向指令，指向正确的node。

想要实现分片存储，那肯定要分配操作的，需要考虑的重点就是如何将数据进行拆分到不同的Redis服务器上。Redis采用的是**哈希槽算法**进行分配的。

#### 10.2.2 哈希槽算法实现分片存储

其它相关算法：

-   普通hash算法：将key使用hash算法计算之后，按照节点数量来取余，即hash(key)%N。优点就是比较简单，但是扩容或者摘除节点时需要重新根据映射关系计算，会导致数据重新迁移。
-   一致性hash算法：为每一个节点分配一个token，构成一个哈希环；查找时先根据key计算hash值，然后顺时针找到第一个大于等于该哈希值的token节点。优点是在加入和删除节点时只影响相邻的两个节点，缺点是加减节点会造成部分数据无法命中，所以一般用于缓存，而且用于节点量大的情况下，扩容一般增加一倍节点保障数据负载均衡。

哈希槽算法：Redis集群中一共有`16384`个哈希槽, 哈希槽分配好后，当对数据进行操作时，会使用`slot = CRC16(key)%16383` 计算出槽位，然后找到槽位对应的master，如果是自己可以直接操作，如果不是自己且在启动客户端时加了`-c` 就会重定向。

默认情况下，redis集群的读和写都是到master上去执行的，不支持slave节点读和写，跟Redis主从复制下读写分离不一样，因为redis集群的核心的理念，主要是使用slave做数据的热备。

**Redis中哈希槽相关的数据结构：**

clusterNode数据结构：表示一个节点的信息（主节点 、从节点）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679041986088.png)

clusterState数据结构：记录当前节点所认为的集群目前所处的状态。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679042357857.png)

两个数据结构的关系 ：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679042412023.png)

#### 10.2.3 频繁重定向造成的网络开销的处理：smart客户端

① 什么是 smart客户端：

在大部分情况下，可能都会出现一次请求重定向才能找到正确的节点，这个重定向过程显然会增加集群的网络负担和单次请求耗时。所以大部分的客户端都是smart的。所谓 smart客户端，就是指客户端本地维护一份hashslot => node的映射表缓存，大部分情况下，直接走本地缓存就可以找到hashslot => node，不需要通过节点进行moved重定向，

② JedisCluster的工作原理：

-   在JedisCluster初始化的时候，就会随机选择一个node，初始化hashslot => node映射表，同时为每个节点创建一个JedisPool连接池。
    \*   每次基于JedisCluster执行操作时，首先会在本地计算key的hashslot，然后在本地映射表找到对应的节点node。
    \*   如果那个node正好还是持有那个hashslot，那么就ok；如果进行了reshard操作，可能hashslot已经不在那个node上了，就会返回moved。
    \*   如果JedisCluter API发现对应的节点返回moved，那么利用该节点返回的元数据，更新本地的hashslot => node映射表缓存
    \*   重复上面几个步骤，直到找到对应的节点，如果重试超过5次，那么就报错，JedisClusterMaxRedirectionException

③ hashslot迁移和ask重定向：

如果hashslot正在迁移，那么会返回ask重定向给客户端。客户端接收到ask重定向之后，会重新定位到目标节点去执行，但是因为ask发生在hashslot迁移过程中，所以JedisCluster API收到ask是不会更新hashslot本地缓存。

虽然ASK与MOVED都是对客户端的重定向控制，但是有本质区别。ASK重定向说明集群正在进行slot数据迁移，客户端无法知道迁移什么时候完成，因此只能是临时性的重定向，客户端不会更新slots缓存。但是MOVED重定向说明键对应的槽已经明确指定到新的节点，客户端需要更新slots缓存。

#### 10.2.4 节点间的通信

在Redis集群中，不同的节点之间采用gossip协议进行通信，节点之间通讯的目的是为了维护节点之间的元数据信息。这些元数据就是每个节点包含哪些数据，是否出现故障，通过gossip协议，达到最终数据的一致性。

> gossip协议，是基于流行病传播方式的节点或者进程之间信息交换的协议。原理就是在不同的节点间不断地通信交换信息，一段时间后，所有的节点就都有了整个集群的完整信息，并且所有节点的状态都会达成一致。每个节点可能知道所有其他节点，也可能仅知道几个邻居节点，但只要这些节可以通过网络连通，最终他们的状态就会是一致的。Gossip协议最大的好处在于，即使集群节点的数量增加，每个节点的负载也不会增加很多，几乎是恒定的。

Redis集群中节点的通信过程如下：

-   集群中每个节点都会单独开一个TCP通道，用于节点间彼此通信。
    \*   每个节点在固定周期内通过待定的规则选择几个节点发送ping消息
    \*   接收到ping消息的节点用pong消息作为响应

使用gossip协议的优点在于将元数据的更新分散在不同的节点上面，降低了压力；但是缺点就是元数据的更新有延时，可能导致集群中的一些操作会有一些滞后。另外，由于 gossip 协议对服务器时间的要求较高，时间戳不准确会影响节点判断消息的有效性。而且节点数量增多后的网络开销也会对服务器产生压力，同时结点数太多，意味着达到最终一致性的时间也相对变长，因此官方推荐最大节点数为1000左右。

> redis cluster架构下的每个redis都要开放两个端口号，比如一个是6379，另一个就是加1w的端口号16379。
>
> -   6379端口号就是redis服务器入口。
> -   16379端口号是用来进行节点间通信的，也就是 cluster bus 的东西，cluster bus 的通信，用来进行故障检测、配置更新、故障转移授权。cluster bus 用的是一种叫gossip 协议的二进制协议

**gossip协议的常见类型：**

gossip协议常见的消息类型包含： ping、pong、meet、fail等等。

（1）meet：主要用于通知新节点加入到集群中，通过「cluster meet ip port」命令，已有集群的节点会向新的节点发送邀请，加入现有集群。

（2）ping：用于交换节点的元数据。每个节点每秒会向集群中其他节点发送 ping 消息，消息中封装了自身节点状态还有其他部分节点的状态数据，也包括自身所管理的槽信息等等。

-   因为发送ping命令时要携带一些元数据，如果很频繁，可能会加重网络负担。因此，一般每个节点每秒会执行 10 次 ping，每次会选择 5 个最久没有通信的其它节点。
    \*   如果发现某个节点通信延时达到了 cluster\_node\_timeout / 2，那么立即发送 ping，避免数据交换延时过长导致信息严重滞后。比如说，两个节点之间都 10 分钟没有交换数据了，那么整个集群处于严重的元数据不一致的情况，就会有问题。所以 cluster\_node\_timeout 可以调节，如果调得比较大，那么会降低 ping 的频率。
    \*   每次 ping，会带上自己节点的信息，还有就是带上 1/10 其它节点的信息，发送出去，进行交换。至少包含 3 个其它节点的信息，最多包含 （总节点数 - 2）个其它节点的信息。

（3）pong：ping和meet消息的响应，同样包含了自身节点的状态和集群元数据信息。

（4）fail：某个节点判断另一个节点 fail 之后，向集群所有节点广播该节点挂掉的消息，其他节点收到消息后标记已下线。

由于Redis集群的去中心化以及gossip通信机制，Redis集群中的节点只能保证最终一致性。例如当加入新节点时(meet)，只有邀请节点和被邀请节点知道这件事，其余节点要等待 ping 消息一层一层扩散。除了 Fail 是立即全网通知的，其他诸如新节点、节点重上线、从节点选举成为主节点、槽变化等，都需要等待被通知到，也就是Gossip协议是最终一致性的协议。

**2、meet命令的实现：**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679044428535.png)

（1）节点A会为节点B创建一个clusterNode结构，并将该结构添加到自己的clusterState.nodes字典里面。

（2）节点A根据CLUSTER MEET命令给定的IP地址和端口号，向节点B发送一条MEET消息。

（3）节点B接收到节点A发送的MEET消息，节点B会为节点A创建一个clusterNode结构，并将该结构添加到自己的clusterState.nodes字典里面。

（4）节点B向节点A返回一条PONG消息。

（5）节点A将受到节点B返回的PONG消息，通过这条PONG消息，节点A可以知道节点B已经成功的接收了自己发送的MEET消息。

（6）之后，节点A将向节点B返回一条PING消息。

（7）节点B将接收到的节点A返回的PING消息，通过这条PING消息节点B可以知道节点A已经成功的接收到了自己返回的PONG消息，握手完成。

（8）之后，节点A会将节点B的信息通过Gossip协议传播给集群中的其他节点，让其他节点也与节点B进行握手，最终，经过一段时间后，节点B会被集群中的所有节点认识。

#### 10.2.5 集群的扩容与收缩

Redis集群中每个 Master节点都有分配的槽，集群伸缩主要在于槽和数据在节点之间移动。

\*\*1）扩容 \*\*

扩容时槽位变动：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679044650075.png)

流程：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679044756245.png)

-   （1）客户端对目标节点发起准备导入槽数据的命令，让目标节点准备好导入槽数据。使用命令：cluster setslot {slot} importing {sourceNodeId}
-   （2）之后对源节点发起送命令，让源节点准备迁出对应的槽数据。使用命令：cluster setslot {slot} migrating {targetNodeId}
-   （3）此时源节点准备迁移数据了，在迁移之前把要迁移的数据获取出来。通过命令 cluster getkeysinslot {slot} {count}。Count 表示迁移的 Slot 的个数。
-   （4）然后在源节点上执行，migrate {targetIP} {targetPort} “” 0 {timeout} keys {keys} 命令，把获取的键通过流水线批量迁移到目标节点。
-   （5）重复 3 和 4 两步不断将数据迁移到目标节点。
-   （6）完成数据迁移到目标节点以后，通过 cluster setslot {slot} node {targetNodeId} 命令通知对应的槽被分配到目标节点，并且广播这个信息给全网的其他主节点，更新自身的槽节点对应表。

**2）收缩**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/17/1679044871001.png)

-   迁移槽。
-   忘记节点。通过命令 cluster forget {downNodeId} 通知其他的节点

#### 10.2.6 集群故障与恢复

**1）故障检测**

Redis集群的故障检测是基于gossip协议的，集群中的每个节点都会定期地向集群中的其他节点发送PING消息，以此交换各个节点状态信息，检测各个节点状态：在线状态、疑似下线状态PFAIL、已下线状态FAIL。

**主观下线（pfail）**：当节点A检测到与节点B的通讯时间超过了cluster-node-timeout 的时候，就会更新本地节点状态，把节点B更新为主观下线。同时下线信息也会通过 Gossip 消息传遍所有节点，因此集群内的节点会不断收到下线报告。

**客观下线：** 当有半数以上主节点标记一个节点主观下线，便会触发客观下线的流程（该流程只针对主节点，如果是从节点就会忽略），向集群广播一条主节点B的Fail 消息，所有收到消息的节点都会标记节点B为客观下线。

**2）恢复**

从节点会向集群广播选举消息，要求收到这条消息的主节点进行投票，每个从节点在一个纪元中只能发起一次选举。

主节点投票规则： 如果一个主节点具有投票权，并且这个主节点尚未投票给其他从节点，那么主节点将向要求投票的从节点返回一条`CLUSTERMSG_TYPE_FAILOVER_AUTH_ACK`消息，表示这个主节点支持从节点成为新的主节点。从节点接收到主节点的`CLUSTERMSG_TYPE_FAILOVER_AUTH_ACK`回复信息后，并根据自己收到了多少条这种消息来统计自己获得了多少主节点的支持。

如果超过一半的数量`(N/2 + 1)`的master节点都投票给了某个从节点，那么选举通过，这个从节点可以切换成master，如果在 `cluster-node-timeout*2` 的时间内从节点没有获得足够数量的票数，本次选举作废，更新配置纪元，并进行第二轮选举，直到选出新的主节点为止。

当满足投票条件的从节点被选出来以后，会触发替换主节点的操作。删除原主节点负责的槽数据，把这些槽数据添加到自己节点上，并且广播让其他的节点都知道这件事情，新的主节点诞生了。

1.  被选中的从节点执行SLAVEOF NO ONE命令，使其成为新的主节点
2.  新的主节点会撤销所有对已下线主节点的槽指派，并将这些槽全部指派给自己
3.  新的主节点对集群进行广播PONG消息，告知其他节点已经成为新的主节点
4.  新的主节点开始接收和处理槽相关的请求

> 备注：如果集群中某个节点的master和slave节点都宕机了，那么集群就会进入fail状态，因为集群的slot映射不完整。如果集群超过半数以上的master挂掉，无论是否有slave，集群都会进入fail状态。

Redis集群底层工作原理参考自：[https://blog.csdn.net/a745233700/article/details/112691126](https://blog.csdn.net/a745233700/article/details/112691126 "https://blog.csdn.net/a745233700/article/details/112691126")

## 11. SpringBoot集成Redis

Jedis、Lettuce和RedisTemplate都是用于在Java应用程序中连接和操作Redis的客户端库。

-   Jedis、Lettuce和RedisTemplate在Redis客户端库的发展中都扮演了重要的角色。
-   Jedis最早发布于2011年，是广受欢迎的Redis客户端库，提供了简单易用的API，使得Java开发者可以轻松地在应用程序中连接和操作Redis。

    Lettuce在2013年发布，基于Netty框架提供了异步和响应式Redis客户端的实现，具有更好的性能和伸缩性，特别是在高并发场景下，比Jedis更具优势。
-   RedisTemplate是由Spring Data提供的Redis客户端库，与Spring Framework和Spring Boot紧密集成，使得Spring应用程序可以轻松地与Redis进行交互。它使用Jedis或Lettuce作为底层客户端，提供了更高层面的、类型安全的操作Redis的API，以及缓存和事务管理等扩展功能。

### 11.1 使用Jedis连接Redis

maven依赖：

```xml
<!--jedis-->
<dependency>
    <groupId>redis.clients</groupId>
    <artifactId>jedis</artifactId>
    <version>4.3.1</version>
</dependency>
```

连接代码：

```java
package com.zhuangjie;

import redis.clients.jedis.Jedis;

import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        // 获取操作对象
        Jedis jedis = new Jedis("192.168.87.105", 6479);
        jedis.auth("3333");
        System.out.println("redis connected Success !");
        // 连接成功，准备使用操作对象进行操作
        System.out.println("========String=========");
        jedis.set("k1","1314");
        System.out.println(jedis.get("k1"));
        System.out.println("========List=========");
        jedis.del("lk1");
        jedis.lpush("lk1","1","2","3","4");
        List<String> lk1 = jedis.lrange("lk1", 0, -1);
        for (String item : lk1) {
            System.out.println(item);
        }
        System.out.println("========Set=========");
        jedis.sadd("sk1","2");
        jedis.sadd("sk1","3");
        jedis.sadd("sk1","2");
        String sk1 = jedis.spop("sk1");
        System.out.println(sk1);
        System.out.println("========Hash=========");
        jedis.hset("hk1","k1","1314");
        jedis.hset("hk1","k2","520");
        String hget = jedis.hget("hk1", "k2");
        System.out.println(hget);
        System.out.println("========ZSet=========");
        jedis.zadd("zk1", 2, "z2");
        jedis.zadd("zk1", 1, "z1");
        jedis.zadd("zk1", 3, "z3");
        Double zscore = jedis.zscore("zk1", "z3");
        System.out.println(zscore);
    }
}
```

### 11.2 使用Lettuce连接Redis

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/18/1679124856372.png)

**Jedis和Lettuce区别：**

Jedis和Lettuce都是Redis的客户端，用于连接Redis服务器。但是在Spring Boot 2.0之后，默认使用Lettuce作为客户端连接Redis服务器。使用Jedis客户端连接Redis服务器时，每个线程都需要使用自己创建的Jedis实例去连接Redis客户端，这样会带来开销大、线程不安全等问题。而Lettuce底层使用Netty，可以保证多个线程共享一个Lettuce连接，减少了创建关闭连接的开销，也是线程安全的。因此，相比之下，Lettuce更加适合在高并发场景中使用。

maven依赖：

```xml
        <!--jedis-->
        <dependency>
            <groupId>redis.clients</groupId>
            <artifactId>jedis</artifactId>
            <version>4.3.1</version>
        </dependency>
        <!--lettuce-->
        <dependency>
            <groupId>io.lettuce</groupId>
            <artifactId>lettuce-core</artifactId>
            <version>6.2.1.RELEASE</version>
        </dependency>
```

代码连接：

```java
package com.zhuangjie;


import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;

import java.util.List;

public class LettuceTest {
    public static void main(String[] args) {
        //使用构建器 RedisURI.builder
        RedisURI uri = RedisURI.builder()
                .redis("192.168.87.105")
                .withPort(6479)
                .withAuthentication("default","3333")
                .build();
        // 创建连接客户端
        RedisClient client = RedisClient.create(uri);
        StatefulRedisConnection  connect = client.connect();
        // 操作命令api
        RedisCommands<String,String> commands = connect.sync();
        List<String> keys = commands.keys("*");
        for (String key : keys) {
            System.out.println(key);
        }

    }
}

```

### 11.3 \[重点]RedisTemplate之SpringBoot集成Redis

#### 11.3.1 Redis配置

加入maven：

```java
        <!--SpringBoot与Redis整合依赖-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-redis</artifactId>
        </dependency>
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-pool2</artifactId>
        </dependency> 
        <!--swagger2-->
        <dependency>
            <groupId>io.springfox</groupId>
            <artifactId>springfox-swagger2</artifactId>
            <version>2.9.2</version>
        </dependency>
        <dependency>
            <groupId>io.springfox</groupId>
            <artifactId>springfox-swagger-ui</artifactId>
            <version>2.9.2</version>
        </dependency>
```

application.properties配置：

```.properties
server.port=7777
spring.application.name=redis7_study

# ========================logging=====================
logging.level.root=info
logging.level.com.atguigu.redis7=info
logging.pattern.console=%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger- %msg%n 

logging.file.name=D:/mylogs2023/redis7_study.log
logging.pattern.file=%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger- %msg%n

# ========================swagger=====================
spring.swagger2.enabled=true
#在springboot2.6.X结合swagger2.9.X会提示documentationPluginsBootstrapper空指针异常，
#原因是在springboot2.6.X中将SpringMVC默认路径匹配策略从AntPathMatcher更改为PathPatternParser，
# 导致出错，解决办法是matching-strategy切换回之前ant_path_matcher
spring.mvc.pathmatch.matching-strategy=ant_path_matcher

# ========================redis单机=====================
spring.redis.database=0
# 修改为自己真实IP
spring.redis.host=192.168.111.185
spring.redis.port=6379
spring.redis.password=111111
spring.redis.lettuce.pool.max-active=8
spring.redis.lettuce.pool.max-wait=-1ms
spring.redis.lettuce.pool.max-idle=8
spring.redis.lettuce.pool.min-idle=0
```

主启动类：不用加redis什么东西。

#### 11.3.2 Redis在业务中使用

config > SwaggerConfig.java ：该配置不是Redis，用于构建API文档的工具

```java
package com.zhuangjie.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @auther zzyy
 * @create 2022-11-17 17:44
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig
{
    @Value("${spring.swagger2.enabled}")
    private Boolean enabled;

    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .enable(enabled)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.zhuangjie.controller")) //你自己的package
                .paths(PathSelectors.any())
                .build();
    }
    public ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("springboot利用swagger2构建api接口文档 "+"\t"+ DateTimeFormatter.ofPattern("yyyy-MM-dd").format(LocalDateTime.now()))
                .description("springboot+redis整合,有问题给管理员阳哥邮件:zzyybs@126.com")
                .version("1.0")
                .termsOfServiceUrl("https://www.atguigu.com/")
                .build();
    }
}
```

Service > OrderService.java&#x20;

```java
package com.zhuangjie.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@Service
@Slf4j
public class OrderService
{
    public static final String ORDER_KEY = "order:";

    @Resource
    private RedisTemplate redisTemplate;

    public void addOrder()
    {
        int keyId = ThreadLocalRandom.current().nextInt(1000)+1;
        String orderNo = UUID.randomUUID().toString();
        redisTemplate.opsForValue().set(ORDER_KEY+keyId,"京东订单"+ orderNo);
        log.info("=====>编号"+keyId+"的订单流水生成:{}",orderNo);
    }

    public String getOrderById(Integer id)
    {
        return (String)redisTemplate.opsForValue().get(ORDER_KEY + id);
    }
}
```

controller > OrderController.java

```java
package com.zhuangjie.controller;

import com.zhuangjie.service.OrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Api(tags = "订单接口")
@RestController
@Slf4j
public class OrderController
{
    @Resource
    private OrderService orderService;

    @ApiOperation("新增订单")
    @RequestMapping(value = "/order/add",method = RequestMethod.POST)
    public void addOrder()
    {
        orderService.addOrder();
    }


    @ApiOperation("按orderId查订单信息")
    @RequestMapping(value = "/order/{id}", method = RequestMethod.GET)
    public String findUserById(@PathVariable Integer id)
    {
        return orderService.getOrderById(id);
    }
}

```

#### 11.3.3 存在的问题并优化配置

启动项目，并访问：[http://127.0.0.1:7777/swagger-ui.html](http://127.0.0.1:7777/swagger-ui.html "http://127.0.0.1:7777/swagger-ui.html")

进行`新增订单` ，然后去控制台上，发现如下（正常应该是`order:273`）：

```java
127.0.0.1:6479> keys *
1) "\xac\xed\x00\x05t\x00\torder:273"

```

此时再进行请求`按orderId查订单信息`  , 发现是可以的获取到的，但如果我们在命令行上`get order:273` 则对应不上（返回nil）。

产生原因：key与value在序列化时RedisTemplate默认使用JdkSerializationRedisSerializer，所以才会导致的。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/18/1679129227992.png)

**解决方法1：修改 service > OrderService.java**

为什么可以解决，因为`StringRedisTemplate` 使用的序列化是`RedisSerializer`  , 从该类的无参构造方法就可以看出。所以：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/18/1679130179293.png)

**解决方法2：自定义**\*\*`RedisTemplate`Bean\*\*​

新建文件：config > RedisConfig.java , 重新配置\*\*`RedisTemplate`\*\*的序列化为`StringRedisSerializer`.

```java
package com.zhuangjie.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisConfig {
    @Bean
    public RedisTemplate<String,Object> redisTemplate(LettuceConnectionFactory lettuceConnectionFactory)
    {
        // StringRedisTemplate stringRedisTemplate = new StringRedisTemplate(lettuceConnectionFactory);
        RedisTemplate<String,Object> redisTemplate = new RedisTemplate<>();

        redisTemplate.setConnectionFactory(lettuceConnectionFactory);
        //设置key序列化方式string
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        //设置value的序列化方式json，使用GenericJackson2JsonRedisSerializer替换默认序列化
        redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());

        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
        redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());

        redisTemplate.afterPropertiesSet();

        return redisTemplate;
    }
}

```

### 11.4 \[重点] RedisTemplate连接Redis集群

已搭建Redis集群：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/16/1678948114506.png)

那只需要在上一节，现在是`11.4` ,也就是`11.3` 节代码基础上进行如下操作（RedisTemplate与SpringBoot的基本整合）：

application.properties : 继续追加如下配置（redis的cluster配置）。

```.properties
# 修改为自己真实IP
spring.redis.cluster.nodes=192.168.87.105:6379,192.168.87.105:6380,192.168.87.106:6381,192.168.87.106:6382,192.168.87.107:6383,192.168.87.107:6384
# 获取失败 最大重定向次数
spring.redis.cluster.max-redirects=3

```

删除掉旧的部分配置，配置好后完整为：

```bash
spring.redis.password=3333
spring.redis.lettuce.pool.max-active=8
spring.redis.lettuce.pool.max-wait=-1ms
spring.redis.lettuce.pool.max-idle=8
spring.redis.lettuce.pool.min-idle=0
# 获取失败 最大重定向次数
spring.redis.cluster.max-redirects=3
spring.redis.cluster.nodes=192.168.111.175:6381,192.168.111.175:6382,192.168.111.172:6383,192.168.111.172:6384,192.168.111.174:6385,192.168.111.174:6386
```

重新启动，测试跟普通的测试无异。

但存在的问题：当一个master 宕机后，且我们操作的key对应的槽落在该master上，

在Redis集群上，宕机的master下的slave会上位；

在后端服务上，SpringBoot客户端没有动态感知到RedisCluster的最新集群信息。因为SpringBoot 2.X 版本，Redis默认的连接池采用 Lettuce当Redis 集群节点发生变化后，Letture默认是不会刷新节点拓扑。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/18/1679137380771.png)

问题的解决：开启Lettuce的动态刷新

application.properties : 继续追加如下配置（redis的cluster配置）。

```.properties
#支持集群拓扑动态感应刷新,自适应拓扑刷新是否使用所有可用的更新，默认false关闭
spring.redis.lettuce.cluster.refresh.adaptive=true
#定时刷新
spring.redis.lettuce.cluster.refresh.period=2000

```

然后重新启动后，就可以了，就算宕机后，其slave上位后，会发现替代的master（新上位的slave）.

> 其它解决方案：
>
> 1.  排除lettuce采用jedis (不推荐)
> 2.  重写连接工厂实例 (极度不推荐)&#x20;

[Redis-进阶之原理与实战](Redis-进阶之原理与实战/Redis-进阶之原理与实战.md "Redis-进阶之原理与实战")
