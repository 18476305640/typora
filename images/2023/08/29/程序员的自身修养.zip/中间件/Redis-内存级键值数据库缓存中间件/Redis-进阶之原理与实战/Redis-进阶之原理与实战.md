# Redis-进阶之原理与实战

## 1.Redis是单线程还是多线程

> 三个面试题：
>
> 1）redis到底是多线程还是多线程？
>
> 2）IO多路复用听说过吗？
>
> 3）redis为什么那么快？

![有几个里程碑式的重要版本](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679188508775.png "有几个里程碑式的重要版本")

在Redis4.0前几乎不支持多线程，Redis4.0开始支持多线程操作，如异步持久化、异步删除等。在Redis6.0中引入了多线程IO，这也是Redis为什么那么快的一个原因，下面就来说说多线程IO。

为什么要引入多线程IO，之前不是已经很快了吗？

先说之前为什么快：

1.  基于内存操作: Redis 的所有数据都存在内存中，因此所有的运算都是内存级别的，所以他的性能比较高
2.  数据结构简单: Redis 的数据结构是专门设计的，而这些简单的数据结构的查找和操作的时间大部分复杂度都是 O(1)，因此性能比较高;
3.  多路复用和非阳塞 I/O: Redis使用 I/O多路复用功能来监听多个 socket连接客户端，这样就可以使用一个线程连接来处理多个请求，减少线程切换带来的开销
4.  多路复用和非阻塞 I/o: Redis使用 I/O多路复用功能来监听多个socket连接客户端，这样就可以使用一个线程连接来处理多个请求，减少线程切换带来的开销，同时也避免了 I/O 阻塞操作
5.  避免上下文切换:因为是单线程模型，因此就避免了不必要的上下文切换和多线程竞争，这就省去了多线程切换带来的时间和性能上的消耗，而且单线程不会导致死锁问题的发生。

单线程的苦恼：

在删除大Key时，会删除的特别慢，这时候就需要加入多线程进行异步删除了。

官方也说了“ Redis 是基于内存操作的，因此他的瓶颈可能是机器的内存或者网络带宽而并非 CPU”，内存方面可以通过添加内存解决，主要是单个主线程处理网络请求的速度跟不上底层网络硬件的速度。那如何利用多线程解决瓶颈呢？

采用多个IO线程来处理网络请求，提高网络请求处理的并行度，Redis6/7就是采用的这种方法。

先说一下什么是IO多路复用： I/O多路复用技术就是让一个进程/线程来维护多个socket。而用户程序想要实现I/O多路利用就要使用到 内核提供给用户态的多路复用系统调用函数 select/poll/epoll 。

从Redis6开始，在I/O多路复用上，引入 多线程来处理主线程的 IO 读写任务，这样就可以使多个 socket 的读写可以并行化了，减少主线程在网络IO的时间消耗，并且其他核心部分仍然是线程安全的，是个不错的折中办法，使得可以让主线程高效的处理多个连接请求。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679191032452.png)

Redis6→7将网络数据读写、请求协议解析通过多个IO线程的来处理 ，

对于真正的命令执行来说，仍然使用主线程操作，一举两得，便宜占尽！！！ o(￣▽￣)ｄ

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679191262404.png)

**I/O多线程是默认关闭的（redis6/7），为什么不是默认打开呢？**

Redis7将所有数据放在内存中，内存的响应时长大约为100纳秒，对于小数据包，Redis服务器可以处理8W到10W的QPS，

这也是Redis处理的极限了，对于80%的公司来说，单线程的Redis已经足够使用了。

在Redis6.0及7后，多线程机制默认是关闭的，如果需要使用多线程功能，需要在redis.conf中完成两个设置

-   `io-thread-do-reads yes` 配置成yes表示启动多线程。
-   `io-thread 4` : 官方的建议是如果为 4 核的 CPU，建议线程数设置为 2 或 3，如果为 8 核 CPU 建议线程数设置为 6，线程数一定要小于机器核数，线程数并不是越大越好。

## 2. BigKey问题

BigKey面试题：

1.  阿里广告平台，海量数据里查询某一固定前缀的key
2.  小红书，你如何生产上限制keys \*/flushdb/flushall等危险命令以防止误删误用？
3.  美团，MEMORY USAGE 命令你用过吗?BigKey问题，多大算big? 你如何发现? 如何删除? 如何处理
4.  BigKey你做过调优吗? 惰性释放lazyfree了解过吗？
5.  Morekey问题，生产上redis数据库有1000W记录，你如何遍历? key \*可以吗？

### 2.1 向Redis中加入大量测试数据

使用linux脚本生成 100w写操作文件：

```java
for((i=1;i<=100*10000;i++)); do echo "set k$i v$i" >> /tmp/redisTest.txt ;done;
```

现在已经有一台6479的redis服务器：

```bash
cat /tmp/redisTest.txt | redis-cli -h 127.0.0.1 -p 6479 -a 3333 --pipe
```

登录redis后，执行`DBSIZE` 命令，就可以看到有100w条。

### 2.2 如何防止危险命令的执行

在上一节`2.1` 中，已经向redis`6479` 已经添加了100w数据，如果执行`keys *` ：

```bash
...
999999) "k778033"
1000000) "k515395"
1000001) "k210719"
1000002) "k95515"
(23.22s)

```

可以查看，阻塞了23s, 这在生产中是很严重的，那我们如何防止这些危险的命令的使用呢？

只需要在redis.conf中配置：

```bash
rename-command keys ""
rename-command flushdb ""
rename-command flushall ""

```

表示禁用`keys`、`flushdb`、`flushall` 命令，当我们登录后尝试执行这些命令时，按`tab`不仅没有提示, 执行后还会提示命令不存在：

```bash
127.0.0.1:6479> keys *
(error) ERR unknown command 'keys', with args beginning with: '*'
```

如果不用keys命令，那有没有替代keys的命令呢？

可以使用`SCAN` 命令，他类似了mysql的limit , 语法如下：

```bash
SCAN cursor [MATCH pattern] [COUNT count]
```

示例：`SCAN 0 match *29* count 10` 表示从0游标开始找出包含`29`的keys，本次操作最多打印出10个。如果想继续遍历呢？

那只需要将`cursor` 替换为上一次该命令输出的：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679208078721.png)

### 2.3 如何判断是否为BigKey

“string类型控制在10KB以内，hash、list、set、zset元素个数不要超过5000. ”

-   虽然String最大能存储512M，但`10KB`就算是BigKey了
-   虽然hash、list、set、zset超过`5000`个算BigKey，但类型能存储的元素最多可以存储`40亿` 左右。

### 2.4 BigKey的危害

-   内存不均，集群迁移困难
-   超时删除，大key删除作梗
-   网络流量阻塞

### 2.5 如何发现BigKey

-   `redis-cli --bigkeys` 命令可以扫描 Redis 中的所有 key，找出其中占用内存最大的一些 key，以及不同类型的 key 的平均内存占用大小等统计信息。这个命令主要是为了帮助用户识别 Redis 中的大 key，以便更好地进行内存管理。
-   `MEMORY USAGE <key>` 命令用于查看指定 key 的内存占用大小。

### 2.6 如何删除BigKey

如果一次性全部删除，会导致阻塞时间过长，可以采用渐进式，即先删除一部分，最后key变小了再执行删除 Key。(注意各类型操作命令不一 样)

渐进式删除String类型：一般用del，如果过于庞大unlink

渐进式删除Hash类型：使用hscan每次获取少量field-value，再使用hdel删除每个field

```java
public void delBigHash(String host, int port, String password, String bigHashKey) {
    try (Jedis jedis = new Jedis(host, port)) {
        if (password != null && !"".equals(password)) {
            jedis.auth(password);
        }
        
        ScanParams scanParams = new ScanParams().count(100);
        String cursor = "";
        do {
            ScanResult<Entry<String, String>> scanResult = jedis.hscan(bigHashKey, cursor, scanParams);
            List<Entry<String,String>> entryList = scanResult.getResult();
            if (entryList != null && !entryList.isEmpty()) {
                for (Entry<String, String> entry : entryList) {
                    jedis.hdel(bigHashkey, entry.getKey());
                }
            }
            cursor = scanResult.getstringCursor();
        } while (!"0".equals(cursor));
        
        //删除bigkey
        jedis.del(bigHashKey);
    }
}

```

渐进式删除List类型：使用ltrim渐进式逐步删除，直到全部删除完成

```java
public void delBiglist(String host, int port, String password, String biglistKey) {
    Jedis jedis = new Jedis(host, port);
    if (password != null && !"".equals(password)) {
        jedis.auth(password);
    }
    long llen = jedis.llen(biglistKey);
    int counter = 0;
    int left = 10;
    while (counter < llen) {
        // 每次从左侧裁第10个
        jedis.ltrim(biglistKey, left, llen);
        counter += left;
    }
    // 最终删除key
    jedis.del(biglistKey);
}

```

渐进式删除Set : 使用sscan每次获取部分元素，再使用srem命令删除每个元素

```java
public void delBigSet(String host, int port, String password, String bigsetKey) {
    Jedis jedis = new Jedis(host, port);
    if (password != null && !"".equals(password)) {
        jedis.auth(password);
    }
    ScanParams scanParams = new ScanParams().count(100);
    String cursor = "0";
    do {
        ScanResult<String> scanResult = jedis.sscan(bigsetKey, cursor, scanParams);
        List<String> memberList = scanResult.getResult();
        if (memberList != null && !memberList.isEmpty()) {
            for (String member : memberList) {
                jedis.srem(bigsetKey, member);
            }
        }
        cursor = scanResult.getStringCursor();
    } while (!"0".equals(cursor));
    //删除bigkey
    jedis.del(bigsetKey);
}

```

渐进式删除ZSet : 使用zscan每次获取部分元素，再使用ZREMRANGEBYRANK命令删除每个元素

```java
public void delBigZset(String host, int port, String password, String bigZsetKey) {
    Jedis jedis = new Jedis(host, port);
    if (password != null && !"".equals(password)) {
        jedis.auth(password);
    }
    ScanParams scanParams = new ScanParams().count(100);
    String cursor = "0";
    do {
        ScanResult<Tuple> scanResult = jedis.zscan(bigZsetKey, cursor, scanParams);
        List<Tuple> tupleList = scanResult.getResult();
        if (tupleList != null && !tupleList.isEmpty()) {
            for (Tuple tuple : tupleList) {
                jedis.zrem(bigZsetKey, tuple.getElement());
            }
        }
        cursor = scanResult.getStringCursor();
    } while (!"0".equals(cursor));
    // 删除bigkey
    jedis.del(bigZsetKey);
}

```

### 2.7 BigKey生产调优

redis.conf  配置优化

lazy free应用于被动删除中，目前有4种场景，每种场景对应一个配置参数； 默认都是关闭。

1.  `lazyfree-lazy-eviction no`: 控制是否开启惰性清理（lazy eviction），如果设置为 yes，表示开启惰性清理，可以降低内存占用，但也可能导致请求响应时间延长。
2.  `lazyfree-lazy-expire no`: 控制是否开启惰性过期（lazy expire），如果设置为 yes，表示开启惰性过期，可以降低过期键的删除对请求响应时间的影响，但也可能导致内存占用增加。
3.  `lazyfree-lazy-server-del no`: 控制是否开启惰性服务器删除（lazy server del），如果设置为 yes，表示开启惰性服务器删除，可以降低节点间数据同步的网络开销和响应时间，但也可能导致一些问题，如增加故障恢复的时间和流量。
4.  `lazyfree-lazy-user-del no`: 控制是否开启惰性用户删除（lazy user del），如果设置为 yes，表示开启惰性用户删除，可以降低用户删除操作对响应时间的影响，但也可能导致一些问题，如增加内存占用和 CPU 开销。
5.  `slave-lazy-flush no`: 控制从节点是否开启惰性清空（lazy flush），如果设置为 yes，表示从节点会延迟清空数据，以便提高同步效率和响应时间。但如果从节点长时间处于不可用状态，可能会导致主节点内存占用过高，进而影响性能。

redis在这块推荐配置：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679211922555.png)

## 3. 缓存双写一致性的更新策略探讨

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679228022181.png)

### 3.1 缓存失效了，在并发下如何防止缓存击穿

采用“双检加锁”策略：如下图进来先看一下是否有目标缓存，如果没有再准备获取锁，获取锁在准备从数据库查之前再判断一下，如果没有再去查数据库。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679231204582.png)

### 3.2 缓存双写一致性：四种常见策略

以下的解决策略都是最终一致性的，没方法保证实时一致性。

**1、2）先更新数据库再更新缓存/先更新缓存再更新数据库**

都会导致以下问题：

在并发操作下，可能会导致，A在更新数据库到更新缓存间，在A后面的操作B在A两个操作之间提前完成了B的更新数据库和更新缓存的操作，而导致的数据库与缓存的不一致。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679233182087.png)

**3）先删除缓存，再更新数据库**

会导致以下问题：

在并发操作下，A删除了缓存后在更新数据库前，B发现缓存中没有数据了，去查询数据库并存到了缓存中。这会导致A删除缓存的操作无效，缓存中存储的仍是旧数据，从而使数据库与缓存的数据不一致。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679233590514.png)

**延迟双删**：也就是在更新数据库后，sleep睡眠一下，再执行删除缓存操作，防止数据不一致。

B从读取旧值前必要在更新数据库前，而更新缓存必须在延迟删除后才会导致延迟删除无效。所以线程A sleep的时间，就需要大于线程B读取数据再写入缓存的时间。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679234426479.png)

延迟删除这种同步淘汰策略，吞吐量降低怎么办? 延迟删除使用异步方式即可。

**4）先更新数据库再删除缓存**

A进行更新数据库后在删除缓存前，其它线程操作命中读取的数据仍然是旧的。（如果一定要保证实时一致性，那要在Redis缓存客户端暂停并发读请求但这在生产中是不推荐的。）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679235798008.png)

还有一个问题是，如果“A删除缓存”失败了，那读取的一直是旧的数据，想要解决这个问题，要引用消息队列，当失败时重试，如果超过一定次数通知运维人员。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/19/1679235948854.png)

### 3.3 缓存又写一致性：使用alibaba Canal

Github：[https://github.com/alibaba/canal](https://github.com/alibaba/canal "https://github.com/alibaba/canal")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/20/1679280896336.png)

工作原理：

-   canal 模拟 MySQL slave 的交互协议，伪装自己为 MySQL slave ，向 MySQL master 发送dump 协议
-   MySQL master 收到 dump 请求，开始推送 binary log 给 slave (即 canal )
-   canal 解析 binary log 对象(原始为 byte 流)

利用mysql的salve身份实现数据改变监听 → redis

下面开始演示一下java程序集成canal 监听mysql的数据变化，最终更新到redis：

#### 准备mysql

需要在mysql做两件事：

-   开启 MySQL的binlog写入功能：

    先查看是否开启：`SHOW VARIABLES LIKE 'log_bin';` , 如果是`off`,那在`[mysqld]` 下追加配置，如下。
    ```java
    [mysqld]
    log-bin=mysql-bin #开启 binlog
    binlog-format=ROW #选择 ROW 模式
    server_id=1

    ```
    然后重启\~
-   添加一个账号

    先查看mysql的账号：`SELECT * FROM mysql.user;` , 开启创建一个`canal`的账号。
    ```java

    DROP USER IF EXISTS 'canal'@'%';
    CREATE USER 'canal'@'%' IDENTIFIED BY 'canal';  
    GRANT ALL PRIVILEGES ON *.* TO 'canal'@'%' IDENTIFIED BY 'canal';  
    FLUSH PRIVILEGES;
     
    SELECT * FROM mysql.user;
    ```

#### 准备canal

1）下载：[https://github.com/alibaba/canal/releases/tag/canal-1.1.6](https://github.com/alibaba/canal/releases/tag/canal-1.1.6 "https://github.com/alibaba/canal/releases/tag/canal-1.1.6")

选择`canal.deployer-1.1.6.tar.gz` 下载。

创建一个目录，将压缩包放在该目录下，然后在该目录下解压（会直接将内容释放在该目录下）。

2）配置

canal目录下 → conf/example/instance.properties :&#x20;

```bash
# 配置mysql ip与Port
canal.instance.master.address=192.168.87.101:3306
# 配置mysql的访问账号与密码
canal.instance.dbUsername=canal
canal.instance.dbPassword=canal

```

3）启动

在 canal目录下 → bin

执行`./restart.sh`

4）验证是否成功启动

canal目录下 → /logs/canal/canal.log

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/20/1679312114527.png)

canal目录下 → /logs/example/example.log

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/20/1679312062847.png)

结合springboot测试：

测试代码已上传至：[https://github.com/18476305640/canal-plus](https://github.com/18476305640/canal-plus "https://github.com/18476305640/canal-plus") ，clone下来 ，然后

解析：

-   application.properties : 需要配置mysql信息与canal的连接信息
-   com.alibaba.canal.canal.listen.CanalApplicationRunner.java ：核心分析
    1.  `run()` 方法：异步执行运行Canal主方法
    2.  `canalMain()` 方法：获取所有加了@CanalListen("canal\_test.t\_user") 注解的全类名并映射为 Map （全类名，bean实例）  。

        注意加入@CanalListen("canal\_test.t\_user") 注解的也相当加了@Component,所以可以从容器中获取对应实例 。 然后调用sub()
    3.  `sub()` 方法：订阅，这是Canal的核心逻辑，有消息后映射后之前加了@CanalListen注解的类方法上(handle)

## 4. HyperLogLog/GEO/Bitmap 的应用场景

### 4.1 HyperLogLog

HyperLogLog可以用来统计`UA`、`PV`、`DAU` 、`MAU` , 这些分别是：

-   UA：全称Unique Visitor（独立访问），其实也就是用户量。
-   PV：Page View ，表示页面浏览器
-   DAU：日活跃用户量。
-   MAU：月活跃用户量。

HyperLogLog：可以用来统计集合中不重复的用户基数。

通过牺牲准确率来换取空间（误差仅了0.81%左右），对于不要求绝对准确率的场景下可以使用，因为概率算法不直接存储数据本身，通过一定的概率统计方法预估基数值，同时保证误差在一定范围内，由于又不储存数据故此可以大大节约内存。

HyperLogLog就是一种概率算法的实现。

#### 4.1.1 HyperLogLog的底层实现原理：**阶段一Log**

下面分三个阶段来讲解HyperLogLog的改进过程`Log`、`LogLog`、`HyperLogLog` 来了解HyperLogLog。

**探索：**

抛硬币1抛出100正面，可能抛了200次（相当于你抛了一个正面，你可能抛了2次）

**核心原理：**

如果1表示下面，0表示反面
想要抛出“0”，概率上要抛2轮（50%+50%）
想要抛出“00”，要2x2=4轮 # 简单理解为：由于前面已经抛了2轮，所以2+(4-2)=4轮；
如果你要抛出连续的（00），那你要抛4轮（在概率上）= 2^length 轮（可以估算2^length个基数），每轮要抛length次。

**实现说明：**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/22/1679489537207.png)

\*\*python实现： \*\*

```python
# 导入 hashlib 和 random 模块
import hashlib
import random


# 定义一个函数，将哈希字符串转换为包含0和1的二进制字符串
def convert_hash_to_binary(hash_hex):
    """
    将哈希字符串表示为十六进制格式，再将其转换成包含0和1的二进制字符串
    """
    return bin(int(hash_hex, 16))


# 定义一个函数，用来统计二进制字符串中从右往左连续的0的个数
def num_trailing_zeros(hash_bin):
    """
    从右到左统计0的个数 一直到遇见1停止，返回 0 的个数加一
    """
    # 将字符串翻转
    reverse = hash_bin[::-1]
    count = 0
    for i in range(len(reverse)):
        # 统计从右起 0 的个数
        if reverse[i] == '0':
            count += 1
        else:
            break

    # 将零的个数加一返回
    return count + 1


# 定义一个函数，估算数组中不同元素的数量
def probability_counting(array):
    """
    估算数组中不同元素的数量
    """
    # 初始化 p_max 为 0
    p_max = 0
    for a in array:
        # 使用 SHA256 哈希算法将其转换为哈希值
        hash_str = hashlib.sha256(str(a).encode()).hexdigest()
        # 将哈希值转换为二进制字符串
        bin_str = convert_hash_to_binary(hash_str)
        # 计算二进制字符串中连续的零的个数（从右到左统计0的个数）
        p = num_trailing_zeros(bin_str)
        if p > p_max:
            p_max = p

    # 返回不同元素的估计计数
    return 2 ** p_max


# 将随机生成的整数存储在一个数组中，随机整数的数量为 ELEMENT_COUNT
ELEMENT_COUNT = 100000
def generate_random_array():
    """
    生成随机数组以进行概率计数
    """
    # 初始化变量
    count = 0
    array = []
    diff_count = 0
    diff_map = {}
    same_count = 0
    # 生成随机整数，并在 diff_map 中记录不同整数的数量，same_count 则跟踪出现的重复整数的数量
    while count < ELEMENT_COUNT:
        num = random.randint(0, 10000)
        array.append(num)
        if num not in diff_map:
            diff_map[num] = True
            diff_count += 1
        else:
            same_count += 1
        count += 1

    # 输出不同整数的数量和相同整数的数量
    # print(f"diff count: {diff_count}, same count : {same_count}")
    return array, diff_count


# 生成随机数组和这个数组不重复的个数
array, differ_count = generate_random_array()

# 使用概率计数函数估算不同元素的数量
probability_count = probability_counting(array)

# 输出不同元素的数量和概率估算的数量
print(f"实际不同元素个数: {differ_count}")
print(f"通过算法估算的元素个数: {probability_count}")


```

如何看懂？

先看上面每个函数的作用，然后看最下面的：（然后追踪probability\_counting方法内部实现）

```python
# 生成随机数组和这个数组不重复的个数
array, differ_count = generate_random_array()

# 使用概率计数函数估算不同元素的数量
probability_count = probability_counting(array)
```

#### **4.1.2 HyperLogLog的底层实现原理：阶段二LogLog**

在阶段一上，加上桶的概念：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/22/1679489182706.png)

二进制每到一个桶相当于轮抛硬币，在Redis中的**HyperLogLog**，每个桶用64位（2^6，占用6位），所以12k=12\*1024\*8/6=16384个桶。每个桶都会计算出`p_max` , 计算随机平均

`A = (p_1_max + p_2_max +… + p_m_max)/m` ,  最后估算的值就是`m * (2 ^ A)` 。

4.1.3 **HyperLogLog的底层实现原理：阶段二HyperLogLog**

**LogLog** 使用的是随机平均数，而**HyperLogLog**使用的是调和平均数。

```python
import hashlib
import random
import math
bucket_map = {}
def get_bits_val(bin_str, b):
    # 例如 1001011, 取前边4个比特位，1001，其对应数值就是9
    b_bit_str = bin_str[0:b]
    b_bit_val = int(b_bit_str, 2)
    return b_bit_val

def first_bits(h, b):
    # h 将h对应的哈希值转换为只包含0，1的二进制字符串，然后去最右边b个比特位，并计算他们形成的数值
    bin_str = convert_hash_to_binary(h)
    bit_val = get_bits_val(bin_str, b)
    return bit_val
def convert_hash_to_binary(hash_hex):
    # 将哈希字符串转换为包含0和1的字符串
    return bin(int(hash_hex, 16))


def num_trailing_zeros(hash_bin):
    # 从右到左统计0的个数一直到遇见1停止
    reverse = hash_bin[::-1]
    count = 0
    for i in range(len(reverse)):
        if reverse[i] == '0':
            count += 1
        else:
            break

    return count + 1
def get_alpha(m):
    if m <= 16:
        return 0.673
    elif 16 < m <= 32:
        return 0.697
    elif 32 < m <= 64:
        return 0.709
    else:
        return 0.7213 / (1 + 1.079 / m)

b = 11 #不同取值对结果影响较大，原因在于我们的实验数据没能达到"海量"标准
def hyper_log_log(array):
    bucket_count = 0
    for a in array:
        hash_str = hashlib.sha256(str(a).encode()).hexdigest()
        bin_str = convert_hash_to_binary(hash_str)
        p = num_trailing_zeros(bin_str)

        # 将哈希结果转换为二进制，取最左边b个比特值计算当前元素哈希值所在的桶
        bucket = first_bits(hash_str, b)
        if bucket in bucket_map:
            # 记录每个桶元素从右边算起0做多的个数
            if p > bucket_map[bucket]:
                bucket_map[bucket] = p
        else:
            bucket_map[bucket] = p
            bucket_count += 1

    compute_sum = 0
    # 计算调和平均数
    for key in bucket_map:
        compute_sum += (2 ** (-1 * bucket_map[key]))

    harmonic_avg = bucket_count / compute_sum
    result = get_alpha(bucket_count) * bucket_count * harmonic_avg
    '''
    最后还需要根据结果做一些调整，这些调整主要基于比较复杂的数理统计推导，我们暂时忽略
    '''
    if result < 5 * bucket_count / 2:
        print(f"small correction")
    if result > 2 ** 32 / 30:
        result = -2 ** 32 * math.log(1 - result / 2 ** 32)
    return result
ELEMENT_COUNT = 100000  # 随机创建给定个取值位于(0, 10000)之间的整数
def generate_random_array():
    count = 0
    array = []
    diff_count = 0
    diff_map = {}
    same_count = 0
    while count < ELEMENT_COUNT:
        num = random.randint(0, 10000)
        array.append(num)
        if num not in diff_map:
            diff_map[num] = True
            diff_count += 1
        else:
            same_count += 1
        count += 1

    # print(f"diff count: {diff_count}, same count : {same_count}")
    return array, diff_count
array, differ_count = generate_random_array()
print(f"实际不同元素个数: {differ_count}")
print(f"result of hyperloglog {hyper_log_log(array)}")
```

学习自：[https://www.bilibili.com/video/BV1dR4y1b7YQ](https://www.bilibili.com/video/BV1dR4y1b7YQ "https://www.bilibili.com/video/BV1dR4y1b7YQ")

#### 4.1.3 使用HyperLogLog实现亿级UA统计方案

Service层：准备一个方法，用于模拟用户访问

```java
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class HyperLogLogService {
    @Resource
    private RedisTemplate redisTemplate;
    /**
     * 模拟后台有用户点击首页，每个用户来自不同ip地址
     */
    public void init(){
        log.info("------模拟后台有用户点击首页，每个用户来自不同ip地址");
        new Thread(() -> {
            String ip = null;
            for (int i = 1; i <=200; i++) {
                // 生成随机访问ip
                Random r = new Random();
                ip = r.nextInt(256) + "." + r.nextInt(256) + "." + r.nextInt(256) + "." + r.nextInt(256);

                Long hll = redisTemplate.opsForHyperLogLog().add("hll", ip);
                log.info("ip={},该ip地址访问首页的次数={}",ip,hll);
                //暂停几秒钟线程
                try { TimeUnit.SECONDS.sleep(3); } catch (InterruptedException e) { e.printStackTrace(); }
            }
        },"t1").start();
    }

}
```

Controller层：向外部提供两个API

-   模拟用户访问
-   获得IP去重后的首页访问量

```java
import com.zhuangjie.common.conduit.R;
import com.zhuangjie.template.service.impl.HyperLogLogService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;

@Api(description = "淘宝亿级UV的Redis统计方案")
@RestController
@Slf4j
public class HyperLogLog {
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private HyperLogLogService hyperLogLogService;
    @ApiOperation("获得IP去重后的首页访问量")
    @RequestMapping(value = "/uv",method = RequestMethod.GET)
    public R uv()
    {
        HashMap<String, Object> data = new HashMap<>();
        data.put("ua",redisTemplate.opsForHyperLogLog().size("hll"));
        return R.ok().data(data);
    }
    @ApiOperation("模拟用户访问")
    @RequestMapping(value = "/access",method = RequestMethod.GET)
    public R access()
    {
        hyperLogLogService.init();
        return R.ok();
    }

}
```

启动后，测试：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/22/1679491998925.png)

### 4.2 GEO

**面试题说明：**

移动互联网时代LBS应用越来越多，交友软件中附近的小姐姐、外卖软件中附近的美食店铺、打车软件附近的车辆等等。

> 美团app附近的酒店&#x20;
> 摇个妹子，附近的妹子&#x20;
> 高德地图附近的人或者一公里以内的各种营业厅、加油站、理发店、超市.....

那这种附近各种形形色色的XXX地址位置选择是如何实现的？

下面实现的API:

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/22/1679497874289.png)

Service层：

```java
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.geo.Metrics;
import org.springframework.data.geo.Point;
import org.springframework.data.geo.Circle;
import org.springframework.data.redis.connection.RedisGeoCommands;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @auther zzyy
 * @create 2022-12-25 12:11
 */
@Service
@Slf4j
public class GeoService
{
    public static final String CITY ="city";

    @Autowired
    private RedisTemplate redisTemplate;

    public String geoAdd()
    {
        Map<String, Point> map= new HashMap<>();
        map.put("天安门",new Point(116.403963,39.915119));
        map.put("故宫",new Point(116.403414 ,39.924091));
        map.put("长城" ,new Point(116.024067,40.362639));

        redisTemplate.opsForGeo().add(CITY,map);

        return map.toString();
    }

    public Point position(String member) {
        //获取经纬度坐标
        List<Point> list= this.redisTemplate.opsForGeo().position(CITY,member);
        return list.get(0);
    }


    public String hash(String member) {
        //geohash算法生成的base32编码值
        List<String> list= this.redisTemplate.opsForGeo().hash(CITY,member);
        return list.get(0);
    }


    public Distance distance(String member1, String member2) {
        //获取两个给定位置之间的距离
        Distance distance= this.redisTemplate.opsForGeo().distance(CITY,member1,member2, RedisGeoCommands.DistanceUnit.KILOMETERS);
        return distance;
    }

    public GeoResults radiusByxy() {
        //通过经度，纬度查找附近的,北京王府井位置116.418017,39.914402
        Circle circle = new Circle(116.418017, 39.914402, Metrics.KILOMETERS.getMultiplier());
        //返回50条
        RedisGeoCommands.GeoRadiusCommandArgs args = RedisGeoCommands.GeoRadiusCommandArgs.newGeoRadiusArgs().includeDistance().includeCoordinates().sortAscending().limit(50);
        GeoResults<RedisGeoCommands.GeoLocation<String>> geoResults= this.redisTemplate.opsForGeo().radius(CITY,circle, args);
        return geoResults;
    }

    public GeoResults radiusByMember() {
        //通过地方查找附近
        String member="天安门";
        //返回50条
        RedisGeoCommands.GeoRadiusCommandArgs args = RedisGeoCommands.GeoRadiusCommandArgs.newGeoRadiusArgs().includeDistance().includeCoordinates().sortAscending().limit(50);
        //半径10公里内
        Distance distance=new Distance(10, Metrics.KILOMETERS);
        GeoResults<RedisGeoCommands.GeoLocation<String>> geoResults= this.redisTemplate.opsForGeo().radius(CITY,member, distance,args);
        return geoResults;
    }
}
```

Controller层：

```java
import com.atguigu.redis7.service.GeoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.geo.*;
import org.springframework.data.redis.connection.RedisGeoCommands;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @auther zzyy
 * @create 2022-12-25 12:12
 */
@Api(tags = "美团地图位置附近的酒店推送GEO")
@RestController
@Slf4j
public class GeoController
{
    @Resource
    private GeoService geoService;

    @ApiOperation("添加坐标geoadd")
    @RequestMapping(value = "/geoadd",method = RequestMethod.GET)
    public String geoAdd()
    {
        return geoService.geoAdd();
    }

    @ApiOperation("获取经纬度坐标geopos")
    @RequestMapping(value = "/geopos",method = RequestMethod.GET)
    public Point position(String member)
    {
        return geoService.position(member);
    }

    @ApiOperation("获取经纬度生成的base32编码值geohash")
    @RequestMapping(value = "/geohash",method = RequestMethod.GET)
    public String hash(String member)
    {
        return geoService.hash(member);
    }

    @ApiOperation("获取两个给定位置之间的距离")
    @RequestMapping(value = "/geodist",method = RequestMethod.GET)
    public Distance distance(String member1, String member2)
    {
        return geoService.distance(member1,member2);
    }

    @ApiOperation("通过经度纬度查找北京王府井附近的")
    @RequestMapping(value = "/georadius",method = RequestMethod.GET)
    public GeoResults radiusByxy()
    {
        return geoService.radiusByxy();
    }

    @ApiOperation("通过地方查找附近,本例写死天安门作为地址")
    @RequestMapping(value = "/georadiusByMember",method = RequestMethod.GET)
    public GeoResults radiusByMember()
    {
        return geoService.radiusByMember();
    }

}
```

### 4.3 Bitmap

常用来做什么？

日活统计
连续签到打卡
最近一周的活跃用户
统计指定用户一年之中的登陆天数
某用户按照一年365天，哪几天登陆过? 哪几天没有登陆? 全年中登录的天数共计多少?

### 4.4 布隆过滤器

是什么？

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679501134963.png)

实质由一个初值都为零的bit数组和多个不同的无偏hash函数(无偏表示分布均匀)构成用来快速判断集合中是否存在某个元素。

跟 HyperLogLog 一样，它也一样有那么一点点不精确，也存在一定的误判概率，一个元素如果判断结果存在时，元素不一定存在，但是判断结果为不存在时，则一定不存在。

布隆过滤器可以添加元素，但是不能删除元素由于涉及hashcode判断依据，删掉元素会导致误判率增加。

添加/查询原理：

-   添加：使用多个不同的hash函数对key进行运算，得到一个整数索引。每个hash函数都会得到一个不同的位置，将这几个位置都置1就完成了add操作。

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679501199229.png)
-   查询，而降过滤器不会存储数据，只判断元素是否存在，且当得到元素存在时，不一定存在。查询是将这个元素经过与add相同的哈希函数得到多个哈希值，然后查看这些哈希值对应的位在位向量上是否都为1。如果有任意一个哈希值对应的位为0，则说明这个元素不存在于集合中（肯定）；否则，可能存在于集合中（可能）；

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679501252095.png)

为什么是是可能（极大可能），而不是当判断位都是1，只能判断是可能存在呢？

因为hash会hash冲突，所以就不能保证是为hash的位都是1就一定存在。

布隆过滤器能做什么？

解决缓存穿透的问题，和redis结合bitmap使用
黑名单校验，识别垃圾邮件
安全连接网址，全球上10亿的网址判断

布隆过滤器在业务中的位置：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679553885867.png)

为了解决布隆过滤器不能删除元素的问题，布谷鸟过滤器横空出世。

在下一章，还会讲布隆过滤器的实现——Google开源的Guava布隆过滤器。

下面是布隆过滤器的简单实现：

```java
package com.zhuangjie.template.config.redis;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigInteger;

/**
 * 布隆过滤器工具
 * @author zhuangjie
 * @date 2023/03/23
 */
@Component
public class BloomFilterUtils {
    @Resource
    private RedisTemplate redisTemplate;
    // 加入布隆过滤器
    public void add(String key,String item) {
        long index = Long.valueOf (((long)item.hashCode() << 16) % (long) Math.pow (2,32)) ;
        redisTemplate.opsForValue().setBit(key,index,true);
    }
    // 检查是否存在
    public boolean check(String key,String item) {
        long index = Long.valueOf (((long)item.hashCode() << 16) % (long) Math.pow (2,32)) ;
        Boolean isExist = redisTemplate.opsForValue().getBit(key, index);
        return isExist;
    }

}

```

## 5. 缓存预热/缓存击穿/缓存穿透/缓存雪崩

### 5.1 缓存预热

在程序启动时，自动将mysql的数据加载到redis，例如：`@PostConstruct`初始化白名单数据。

### 5.2 缓存雪崩

发生的原因及解决方法：

Redis主机挂了，偏硬件运维：

-   实现Redis高可用
-   服务降级

Redis中大量的key大面积失效

-   redis永不过期&#x20;
-   过期时间错开
-   加入本地缓存错开过期时间，防止导致的多模块流量的挤压。

以上都是对于普通玩家，人民币玩家`阿里云-云数据库Redis版` ：[https://www.aliyun.com/product/kvstore](https://www.aliyun.com/product/kvstore "https://www.aliyun.com/product/kvstore")

### 5.3 缓存穿透

什么是缓存穿透？

一个不存在的key，在redis中没有去查mysql 也没有。

redis相当于被穿透了一样（缓存成了摆设）。

**那如何解决缓存穿透问题呢？**

方案一：使用布隆过滤器，但也不能完全解决，布隆过滤器当存在时，极有可能存在，也就是存在误判率，不存在的可以会被认为是存在的，这时候会查询数据库，当数据库没有的时候可以做个缓存空值，进而防止该key导致的缓存穿透。

如果后面被缓存为null的key的在数据库中有了呢？

由于缓存穿透一般是由黑客引出的，所以我们设置的null值最好设置有过期时间，这样虽然该key仍然会导致的缓存穿透，但频率会非常低。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679557081470.png)

如果上面没有布隆过滤器而是只有查询数据库没有缓存null来应对缓存穿透，那如果每个key不同呢？

那这种方式就不能防止缓存穿透了，所以使用而降过滤器，还可以防止`key不同且不存在`的缓存穿透, 应对的缓存穿透只是误判的那部分。

在上面的布隆过滤器时，除了我们自研，我们还可以采用第三方成熟的布隆过滤器——Google开源的Guava布隆过滤器。

下面我们就来讲讲布隆过滤器：

[https://github.com/google/guava/blob/master/guava/src/com/google/common/hash/BloomFilter.java](https://github.com/google/guava/blob/master/guava/src/com/google/common/hash/BloomFilter.java "https://github.com/google/guava/blob/master/guava/src/com/google/common/hash/BloomFilter.java")

**Guava布隆过滤器基本使用：**

引入Guava依赖：

```java
<!--guava Google 开源的 Guava 中自带的布隆过滤器-->
<dependency>
    <groupId>com.google.guava</groupId>
    <artifactId>guava</artifactId>
</dependency> 
```

使用

```java
@Service
@Slf4j
public class GuavaBloomFilterService{
    public static final int _1W = 10000;
    //布隆过滤器里预计要插入多少数据
    public static int size = 100 * _1W;
    //误判率,它越小误判的个数也就越少(思考，是不是可以设置的无限小，没有误判岂不更好)
    //fpp the desired false positive probability
    public static double fpp = 0.03;
    // 构建布隆过滤器
    private static BloomFilter<Integer> bloomFilter = BloomFilter.create(Funnels.integerFunnel(), size,fpp);
    public void guavaBloomFilter(){
        //1 先往布隆过滤器里面插入100万的样本数据
        for (int i = 1; i <=size; i++) {
            bloomFilter.put(i);
        }
        //故意取10万个不在过滤器里的值，看看有多少个会被认为在过滤器里
        List<Integer> list = new ArrayList<>(10 * _1W);
        for (int i = size+1; i <= size + (10 *_1W); i++) {
            if (bloomFilter.mightContain(i)) {
                log.info("被误判了:{}",i);
                list.add(i);
            }
        }
        log.info("误判的总数量：:{}",list.size());
    }
}
 
```

> 我们可以设置要操作的量，与设置误判率，这会决定生成的bit数组大小与使用的hash函数个数
>
> 验证：通过debug BloomFilter类
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679564298175.png)

通过测试，也确实能确保误判率！

**布隆过滤器应用场景：**

白名单使用（正向使用）：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679564567395.png)

黑名单使用（反向使用）：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679564502590.png)

### 5.4 缓存击穿

缓存击穿是什么？

缓存击穿表示某个热点key失效了，同一时刻大量请求挤到mysql上。

般技术部门需要知道热点key是那些个?做到心里有数防止击穿。

那技术部门如何防止缓存击穿呢？

-   不设置过期时间：既然是过期时间引起的，那干碎不设置过期时间
-   双检锁：在加锁前后都检查缓存是否有数据

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679565476902.png)
-   差异失效时间：“mysql穿两个防弹衣（redis）” ，要严格按照更新与查询的顺序！

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679565551523.png)

> 本章总结：
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/23/1679576143819.png)

## 6. 分布式锁

什么是分布式系统？

由于单台机器无法满足要求，扩展出多台机器一起完成相同的事件，它们之前为了数据一致肯定要进行通信同步，这就会导致出现CAP问题。

-   C：一致性：节点间数据的同步，在单体上数据都是一致的，在多节点上，就要进行数据的同步，自然会出现数据的不一致，这是由于同一时刻会访问到不同数据来说的。如果想要实现多节点间的一致性，那就要加锁，在访问未同步的节点时就会阻塞，同步完成数据一致后可以访问。
-   A：可用性：同一时刻，所以节点都可用。
-   P：分区容错性：当两个节点无法进行网络通信，不管是网络问题还是机器宕机导致的无法通信，都是产生了分区，比如主节点宕机了，从节点上位了，那分区容错性就能保证，且从节点越多，分区容错性越强，但与一致性成反比。保证分区容错性自然就不能是单机结构。

CAP理论：分布式系统默认有分区容错性，在保证分区容错性P下，当保证一致性时，就要进行同步，就不能保证可用性。而如果要保证可用性，那就表示当数据出现不一致时，仍然可用，那就无法保证数据一致性。

单机下是CA，但CAP是在分布式系统下的（有多个相同的节点一起完成相同的事），CAP对于单机自然没有意义，也不适用。

### 6.1 自研分布锁演进阶段

#### v1 本地锁版

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/25/1679709331638.png)

说明：通过Nginx作负载均衡打到两个java程序上，java程序使用本地锁来一个请求当有检查redis中有库存时，`库存-1`再存到redis中。

存在的问题：java程序使用的是本地锁，只能对使用同一jvm有效，只能对同一java服务的其它线程有效，只能保证同一时刻该java服务对redis只有一个线程进行操作，当对于多个java服务时，那就无法防止了，自然会导致超卖（重复卖）。

上面架构的java核心代码：

```java
@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private Lock lock = new ReentrantLock();
    @Autowired
    private Environment env;
    public R sale() {
        String key = "inventory001";
        lock.lock();
        try {
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            lock.unlock();
        }

    }

}

```

#### v2 分布式锁-宕机无法保证

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/25/1679712325550.png)

解析：nginx打开多个java服务中，java通过从redis中获取锁（通过`setnx`）, 当自己能将自己的id设置为锁的值时，表示占用，就会退出自旋while，去执行逻辑，执行完扣减库存后，在finally 后将锁删除，表示锁空闲。

存在的问题：虽然是放在finally中将锁删除，这只能防止程序异常情况下也能删除锁，但如果是机器宕机，当删除锁的操作仍然无法保证，一旦锁无法删除，那就会导致死锁，这是非常严重的。

以下是本次版本的实现核心代码：

```java
@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private String key = "inventory001";
    private String lockKey = "lockKey";
    @Autowired
    private Environment env;
    public R sale() {
        long threadId = Thread.currentThread().getId();
        while (! redisTemplate.opsForValue().setIfAbsent(lockKey,threadId)) {
            try {  Thread.sleep(10); } catch (InterruptedException e) { throw new RuntimeException(e);}
        }
        try {
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            redisTemplate.delete(lockKey);
        }

    }

}
```

#### v3 分布式锁-解决死锁，引出过期时间问题

先保证v2会产生死锁：下面代码中，表示当库存为200条时，让程序模拟宕机，此时程序获取的锁会无法释放掉，而导致其它线程执行时产生自旋（阻塞）。

```java
@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private String key = "inventory001";
    private String lockKey = "lockKey";
    @Autowired
    private Environment env;
    public R sale() {
        long threadId = Thread.currentThread().getId();
        while (! redisTemplate.opsForValue().setIfAbsent(lockKey,threadId)) {
            try {  Thread.sleep(10); } catch (InterruptedException e) { throw new RuntimeException(e);}
        }
        try {
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            // 模拟程序挂掉，只能一个挂
            if (surplus == 200 && redisTemplate.opsForValue().setIfAbsent("errorKey",threadId)) {
                System.exit(0);
            }
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            redisTemplate.delete(lockKey);
        }

    }

}
```

已验证，程序宕机后无法释放锁，会导致其它线程的阻塞。

v3版开始：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/25/1679713638522.png)

解析：给锁加一个过期时间，只算某个服务器由于宕机导致锁无法释放，最后也会因为锁过期自动清理。

存在的问题：给锁加了过期，当在该时间内，由于网络等原因，不能在指定时间内完成业务逻辑，锁过期后，会自动清理，那下一个线程会获取到之前线程未释放的锁，之前线程会将后面进来上的锁给删除。

v3版本实现核心代码：下面代码中加了锁的过期时间，下面代码在售卖200号时，会让第一个售卖200号的程序宕机，经演示，其它线程等待锁过期后，不会再阻塞。

```java
@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private String key = "inventory001";
    private String lockKey = "lockKey";
    @Autowired
    private Environment env;
    public R sale() {
        long threadId = Thread.currentThread().getId();
        while (! redisTemplate.opsForValue().setIfAbsent(lockKey,threadId,30,TimeUnit.SECONDS)) {
            try {  Thread.sleep(10); } catch (InterruptedException e) { throw new RuntimeException(e);}
        }
        try {
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            // 模拟程序挂掉，只能一个挂
            if (surplus == 200 && redisTemplate.opsForValue().setIfAbsent("errorKey",threadId)) {
                System.exit(0);
            }
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            redisTemplate.delete(lockKey);
        }

    }

}

```

#### v4 分布式锁-解决张冠李戴问题（误删锁）

为了解决锁过期，但业务未处理完业务，而导致自己的锁过期，后面完成业务后造成的锁乱删问题，添加一个判断，必须是自己的锁才删。

存在的问题：判断是否是自己的锁与解锁不是原子的，会导致当最开始的线程A在判断与删除线程之间，锁过期了，并且其它线程B判断没有锁了成功获取到了锁，那A会误删掉B上的锁。也就是v4版本还是无法彻底解决误删锁问题。

v4版实现的核心逻辑代码：在业务代码中加入睡眠模拟处理业务时间过大，锁自动清理后，业务执行，会发现当前不是自己的锁，就不删除。

```java
@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private String key = "inventory001";
    private String lockKey = "lockKey";
    @Autowired
    private Environment env;
    public R sale() {
        long threadId = Thread.currentThread().getId();
        while (! redisTemplate.opsForValue().setIfAbsent(lockKey,threadId,30,TimeUnit.SECONDS)) {
            try {  Thread.sleep(10); } catch (InterruptedException e) { throw new RuntimeException(e);}
        }
        try {
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            // 模拟程序挂掉，只能一个挂
            if (surplus == 200 && redisTemplate.opsForValue().setIfAbsent("errorKey",threadId)) {
                // 模拟耗时操作
                try {  Thread.sleep(35*1000); } catch (InterruptedException e) { throw new RuntimeException(e);}
            }
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            // 只能删掉自己的锁
            if ( String.valueOf(threadId).equals( String.valueOf( redisTemplate.opsForValue().get(lockKey)) )) {
                redisTemplate.delete(lockKey);
            }else {
                System.out.println("不是自己的锁，不删除！");
            }

        }

    }
```

#### v4分布式锁：优化v4，让判断是否是自己的锁与删除锁是原子的

**Lua脚本**

Lua编程语言最初的设计初衷是为了实现一种可嵌入的脚本语言，方便程序开发者在其它应用程序中进行定制化开发，并且具有高度的灵活性和可扩展性。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/25/1679747000818.svg)

那脚本怎么写呢？

if语法：

```lua
192.168.87.107:6384> EVAL "if KEYS[1]-0==1 then return 1314 elseif KEYS[1]-0==2 then return 2345  else return 520  end" 1 2
(integer) 2345
```

代码实现：下面使用了Lua，在java中调用Redis提供的方法执行Lua，从而借助Lua实现判断与删除的原子性。因为Lua里面包含的两条语句是一体的。其它命令不会在中间插足。

```java
package com.zhuangjie.template.service.impl;

import com.zhuangjie.common.conduit.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private String key = "inventory001";
    private String lockKey = "lockKey";
    @Autowired
    private Environment env;
    public R sale() {
        long threadId = Thread.currentThread().getId();
        while (! redisTemplate.opsForValue().setIfAbsent(lockKey,threadId,30,TimeUnit.SECONDS)) {
            try {  Thread.sleep(10); } catch (InterruptedException e) { throw new RuntimeException(e);}
        }
        try {
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            String luaScript =
                    "if (redis.call('get',KEYS[1]) == ARGV[1]) then " +
                        "return redis.call('del',KEYS[1]) " +
                    "else " +
                        "return 0 " +
                    "end";
            redisTemplate.execute(new DefaultRedisScript<>(luaScript, Boolean.class), Arrays.asList(lockKey), threadId);
        }

    }

}

```

#### v5 分布式锁：可重入锁

之前版本想要设置可重入锁，必须要修改存储在Redis中“锁”，由`String` → `Hash`  :

String :  固定锁的key  :  线程当前生成的UUID

Hash:    固定锁的key  :  ( 线程当前生成的UUID : 重入次数 )

现在开始锁封装为Lock对象，我们创建的锁类继承自Lock，实现Lock的方法，该锁是我们实现的分布式锁。

实现可重入锁的核心代码：最核心的其实是代码中使用的`Lua script` , 上锁与解锁都有对应的Lua脚本。

```java
package com.zhuangjie.template.utils;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;

import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class ClusterLock implements Lock {
    private RedisTemplate redisTemplate;
    private String lockName;
    private long expireTime;
    private String uuId;
    {
        uuId = UUID.randomUUID().toString();
    }
    public ClusterLock(RedisTemplate redisTemplate,String lockName,long expireTime) {
        this.redisTemplate = redisTemplate;
        this.lockName = lockName;
        this.expireTime = expireTime;
    }
    public ClusterLock(RedisTemplate redisTemplate,String lockName) {
        this(redisTemplate,lockName, 30);
    }

    @Override
    public void lock() {
        tryLock();
    }
    @Override
    public boolean tryLock() {
        try {
            return tryLock(-1,TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            System.out.println("[ERROR] tryLock~");
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
        if (time == -1) {
            String script = "if redis.call('exists',KEYS[1]) == 0 or redis.call('hexists',KEYS[1],ARGV[1]) == 1 then " +
                                "redis.call('hincrby',KEYS[1],ARGV[1],1) " +
                                "redis.call('expire',KEYS[1],ARGV[2]) " +
                                "return 1 " +
                            "else " +
                                "return 0 " +
                            "end";
            while ( ! (Boolean)redisTemplate.execute(new DefaultRedisScript<>(script, Boolean.class), Arrays.asList(lockName), uuId, expireTime)) {
                TimeUnit.MICROSECONDS.sleep(50);
            }
            return true;

        }
        return false;
    }

    @Override
    public void unlock() {
        String script = "if redis.call('HEXISTS',KEYS[1],ARGV[1]) == 0 then " +
                            "return nil " +
                        "elseif redis.call('HINCRBY',KEYS[1],ARGV[1],-1) == 0 then " +
                            "return redis.call('del',KEYS[1]) " +
                        "else " +
                            "return 0 " +
                        "end";
        if ( redisTemplate.execute(new DefaultRedisScript(script,Long.class),Arrays.asList(lockName),uuId) == null ) {
            throw new RuntimeException("This lock doesn't EXIST");
        }
    }
    // ===下面的redis分布式锁暂时用不到===
    @Override
    public void lockInterruptibly() throws InterruptedException {

    }
    @Override
    public Condition newCondition() {
        return null;
    }
}

```

使用可重入锁：

```java
package com.zhuangjie.template.service.impl;

import com.zhuangjie.common.conduit.R;
import com.zhuangjie.template.utils.ClusterLock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private String key = "inventory001";
    private String lockKey = "lockKey";
    @Autowired
    private Environment env;
    public R sale() {
        Lock lock = new ClusterLock(redisTemplate,lockKey);
        lock.lock();
        try {
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);

            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);

        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            System.out.println("解锁");
            lock.unlock();
        }

    }

}
```

#### v6 分布式锁：自动续期

在上面可重入锁的基础上实现自动续期，其实只需要加入一个方法与在上锁后调用这个方法。

```java
    /**
     * 自动续期
     */
    private void renewExpire() {
        String script = "if redis.call('HEXISTS',KEYS[1],ARGV[1]) == 1 then " +
                            "return redis.call('expire',KEYS[1],ARGV[2]) " +
                        "else " +
                            "return 0 " +
                        "end";
        // 续期的定时器              
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                if ((Boolean) redisTemplate.execute(new DefaultRedisScript(script,Boolean.class),Arrays.asList(lockName),uuId,expireTime)) {
                    // 如果成功了，表示程序还没有完成，会执行下一个订时器
                    renewExpire();
                }
                // 如果已经完成，退出
            }
        }, (this.expireTime * 1000) / 3); // 30 -> 20 -> 查看是否还拥有锁 Y-> 续期到30 
    }
```

完整代码：

```java
package com.zhuangjie.template.utils;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;

import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class ClusterLock implements Lock {
    private RedisTemplate redisTemplate;
    private String lockName;
    private long expireTime;
    private String uuId;
    {
        uuId = UUID.randomUUID().toString();
    }
    public ClusterLock(RedisTemplate redisTemplate,String lockName,long expireTime) {
        this.redisTemplate = redisTemplate;
        this.lockName = lockName;
        this.expireTime = expireTime;
    }
    public ClusterLock(RedisTemplate redisTemplate,String lockName) {
        this(redisTemplate,lockName, 30);
    }

    @Override
    public void lock() {
        tryLock();
    }
    @Override
    public boolean tryLock() {
        try {
            return tryLock(-1,TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            System.out.println("[ERROR] tryLock~");
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
        if (time == -1) {
            String script = "if redis.call('exists',KEYS[1]) == 0 or redis.call('hexists',KEYS[1],ARGV[1]) == 1 then " +
                                "redis.call('hincrby',KEYS[1],ARGV[1],1) " +
                                "redis.call('expire',KEYS[1],ARGV[2]) " +
                                "return 1 " +
                            "else " +
                                "return 0 " +
                            "end";
            while ( ! (Boolean)redisTemplate.execute(new DefaultRedisScript<>(script, Boolean.class), Arrays.asList(lockName), uuId, expireTime)) {
                TimeUnit.MICROSECONDS.sleep(50);
            }
            // 在执行任务前，先在后台运行续期程序
            renewExpire();
            return true;

        }
        return false;
    }

    /**
     * 自动续期
     */
    private void renewExpire() {
        String script = "if redis.call('HEXISTS',KEYS[1],ARGV[1]) == 1 then " +
                            "return redis.call('expire',KEYS[1],ARGV[2]) " +
                        "else " +
                            "return 0 " +
                        "end";
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                if ((Boolean) redisTemplate.execute(new DefaultRedisScript(script,Boolean.class),Arrays.asList(lockName),uuId,expireTime)) {
                    // 如果成功了，表示程序还没有完成，会继续看着
                    renewExpire();
                }
                // 如果已经完成，退出
            }
        }, (this.expireTime * 1000) / 3);
    }

    @Override
    public void unlock() {
        String script = "if redis.call('HEXISTS',KEYS[1],ARGV[1]) == 0 then " +
                            "return nil " +
                        "elseif redis.call('HINCRBY',KEYS[1],ARGV[1],-1) == 0 then " +
                            "return redis.call('del',KEYS[1]) " +
                        "else " +
                            "return 0 " +
                        "end";
        if ( redisTemplate.execute(new DefaultRedisScript(script,Long.class),Arrays.asList(lockName),uuId) == null ) {
            throw new RuntimeException("This lock doesn't EXIST");
        }
    }
    // ===下面的redis分布式锁暂时用不到===
    @Override
    public void lockInterruptibly() throws InterruptedException {

    }
    @Override
    public Condition newCondition() {
        return null;
    }
}

```

在使用上与可重入锁版本的一样。

使用Redis实现的分布式锁是AP，而使用zookeeper是CP（会等节点同步完成，与子节点数据一致才返回成功）。

其它在我们自研的最后一个版本还是有问题的，不管是主从、主从+哨兵又或者是redis集群都会存在一个问题，当master的锁还未同步到副本（slave）就挂了，slave上位后，此时是没锁的，其它线程抢到后，这是比较危险的，就会存在一锁被多建多用。

解决见`6.2` Redisson.

### 6.2 Redisson

官网Wiki：[https://github.com/redisson/redisson/wiki/Table-of-Content](https://github.com/redisson/redisson/wiki/Table-of-Content "https://github.com/redisson/redisson/wiki/Table-of-Content")

#### 6.2.1 Redisson的简单使用（单锁）

为了解决我们自研的最后一个脚本还存在的问题，就是使用传统的Redis主从集群方式是AP的，无法保证A（一致性），这个问题将在Redisson的多重锁也就是“多机案例”中解决。我们先用Redisson的单锁（单master）演示简单使用Redisson   相当于我们自研的v6版，拥有可重入、自动续期等：

配置：在这里redisson使用的redis与之前使用的redis集群分开。

1）向原来的RedisConfig配置中添加：

```java
@Bean
    public Redisson redisson()
    {
        Config config = new Config();
        config.useSingleServer().setAddress("redis://192.168.87.105:6479").setDatabase(0).setPassword("3333");
        return (Redisson) Redisson.create(config);
    }
```

完整RedisConfig如下：

```java
@Configuration
public class RedisConfig {
    @Bean
    public RedisTemplate<String,Object> redisTemplate(LettuceConnectionFactory lettuceConnectionFactory)
    {
        // StringRedisTemplate stringRedisTemplate = new StringRedisTemplate(lettuceConnectionFactory);
        RedisTemplate<String,Object> redisTemplate = new RedisTemplate<>();

        redisTemplate.setConnectionFactory(lettuceConnectionFactory);
        //设置key序列化方式string
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        //设置value的序列化方式json，使用GenericJackson2JsonRedisSerializer替换默认序列化
        redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());

        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
        redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());

        redisTemplate.afterPropertiesSet();

        return redisTemplate;
    }
    //单Redis节点模式
    @Bean
    public Redisson redisson()
    {
        Config config = new Config();
        config.useSingleServer().setAddress("redis://192.168.87.105:6479").setDatabase(0).setPassword("3333");
        return (Redisson) Redisson.create(config);
    }
}
```

2）redisson的简单使用：

```java
    @Autowired
    private Redisson redisson;
    
    
    RLock lock = redisson.getLock(lockKey);
    lock.lock();
    try {...}
    finally{
       // 这里需要加判断再解锁，不然会出现问题,这是Redisson的BUG!
       if(lock.isLocked() && lock.isHeldByCurrentThread()) {
          lock.unlock();
       }
    }
    
    
```

完整如下：

```java
package com.zhuangjie.template.service.impl;

import com.zhuangjie.common.conduit.R;
import com.zhuangjie.template.utils.ClusterLock;
import lombok.extern.slf4j.Slf4j;
import org.redisson.Redisson;
import org.redisson.RedissonLock;
import org.redisson.api.RLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
@Slf4j
public class LockLogService {
    @Resource
    private RedisTemplate redisTemplate;
    private String key = "inventory001";
    private String lockKey = "lockKey";

    @Autowired
    private Redisson redisson;
    @Autowired
    private Environment env;
    public R sale() {
//        Lock lock = new ClusterLock(redisTemplate,lockKey);
        RLock lock = redisson.getLock(lockKey);
        lock.lock();
        try {
            TimeUnit.SECONDS.sleep(2000000);
            String value = String.valueOf( redisTemplate.opsForValue().get(key));
            Integer surplus = Integer.valueOf(value);
            if(surplus == 0) return R.ok().message("已经卖完了");
            redisTemplate.opsForValue().set(key,String.valueOf(--surplus));
            System.out.println(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);
            return R.ok().message(env.getProperty("server.port")+"已卖出，剩余票数："+surplus);

        }catch (Exception e) {
            return R.error().message("出错了");
        }finally {
            System.out.println("解锁");
            // 这里需要加判断再解锁，不然会出现问题
            if(lock.isLocked() && lock.isHeldByCurrentThread())
            {
                lock.unlock();
            }
        }

    }

}

```

#### 6.2.2 Redisson的多机案例（多重锁）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/27/1679923294239.jpg)

解析：Redisson的多机案例使用的redis都是master的，这些都是容错主机，计算公式是，如果希望挂掉两台还能正常工作，要部署2N+1 台，也就是5台。这是因为只有**一半以上**主机正常工作,才能正常获取与释放锁。

比如部署5台，就算两台不能用了，只要剩下的3台（满足一半以上）能正常工作，那就是OK的，也就是当部署5台时，能容错2台。

使用多机案例，要用到对象如下：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/27/1679926996772.png)

```java
RLock 
  - RedissonMultiLock 推荐使用
    - RedissonRedLock  已弃用

```

下面使用RedissonMultLock来实现多机实现具有容错的Redis分布式锁：

1）创建若干相关联的配置类：

RedisProperties.java ： 对应application.yml中的配置

```java
package com.zhuangjie.template.config.redis.redisson;

import lombok.Data;
import lombok.ToString;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@EnableConfigurationProperties(RedisProperties.class)
@ConfigurationProperties(prefix = "spring.redis.distributed-cp-lock")
@Data
public class RedisProperties {
    private int database;
    /**
     * 等待节点回复命令的时间。该时间从命令发送成功时开始计时
     */
    private int timeout;

    private String password;

    private String mode;

    /**
     * 池配置
     */
    private RedisPoolProperties pool;

    /**
     * 单机信息配置
     */
    private List<String> nodes;
}
```

RedisPoolProperties.java :  配置中的对象

```java
package com.zhuangjie.template.config.redis.redisson;


import lombok.Data;

@Data
public class RedisPoolProperties {

    private int maxIdle;

    private int minIdle;

    private int maxActive;

    private int maxWait;

    private int connTimeout;

    private int soTimeout;
    /**
     * 池大小
     */
    private  int size;

}
```

RLockFactory.java ：这是个委托创建RLock的工厂类，会传入创建的key与期望使用的实例数

```java
package com.zhuangjie.template.config.redis.redisson;

import com.alibaba.excel.util.StringUtils;
import org.redisson.Redisson;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.config.SingleServerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


@Component
public class RLockFactory {

    private List<RedissonClient> redissonClients;
    @Autowired
    private RLockFactory(RedisProperties redisProperties) {
        // 根据redisProperties配置初始化映射成redissonClients
        if (redissonClients == null) {
            redissonClients = new ArrayList<>();
            List<String> nodes = redisProperties.getNodes();
            for (String node : nodes) {
                Config config = new Config();
                node = node.startsWith("redis://") ? node : "redis://" + node;
                SingleServerConfig serverConfig = config.useSingleServer()
                        .setAddress(node)
                        .setTimeout(redisProperties.getPool().getConnTimeout())
                        .setConnectionPoolSize(redisProperties.getPool().getSize())
                        .setConnectionMinimumIdleSize(redisProperties.getPool().getMinIdle());
                if (StringUtils.isNotBlank(redisProperties.getPassword())) {
                    serverConfig.setPassword(redisProperties.getPassword());
                }
                RedissonClient redissonClient = Redisson.create(config);
                if (redissonClient != null) {
                    redissonClients.add(redissonClient);
                }
            }
        }
    }

    public RLock[] getRLock(String lockKey, int expectedCount) {
        // 利用客户端创建锁
        if (redissonClients == null || redissonClients.size() == 0 ) {
            Exception e = new Exception("无法创建锁对象");
            e.printStackTrace();
        }
        List<RLock> rLocks = new ArrayList<>();
        for (RedissonClient redissonClient : redissonClients) {
            if (rLocks.size() >= expectedCount) break;
            RLock lock = redissonClient.getLock(lockKey);
            rLocks.add(lock);
        }
        RLock[] locks = rLocks.toArray(new RLock[rLocks.size()]);
        return locks;

    }
}


```

2）application.yml配置：

```java
spring:
  redis:
    # 分布式锁配置
    distributed-cp-lock:
      database: 0
      mode: single
      nodes:
        - 192.168.87.105:6479
        - 192.168.87.105:6579
        - 192.168.87.105:6679
      password: 3333
      pool:
        conn-timeout: 3000
        size: 10
        so-timeout: 3000
      timeout: 3000
```

3）使用：

```java
@Service
@Slf4j
public class LockLogService {
    private String LOCK_KEY = "lockKey1";
    @Autowired
    private RLockFactory rLockFactory;

    public R sale() {
        RLock[] rLocks =  rLockFactory.getRLock(LOCK_KEY,3);
        RedissonMultiLock lock = new RedissonMultiLock(rLocks);
        lock.lock();
        try {
            ...
        }finally {
            // 注意这里解锁不要像之前那样加判断，不要加！！会报错
            lock.unlock();
        }

    }

}

```

## 7. 缓存淘汰策略

### 7.1 **Redis的过期策略** （如何删除过期键的问题）

Redis是key-value[数据库](https://cloud.tencent.com/solution/database?from=10680 "数据库")，在程序中可以设置Redis中缓存的key的过期时间。Redis的过期策略就是指当Redis中缓存的key过期了以后，Redis是如何处理的。

过期策略通常有以下三种：

**定时过期（立即删除）：** 每个设置过期时间的key都需要创建一个`定时器`，到过期时间就会`立即清除`。该策略可以立即清除过期的数据，对内存很友好；但是会占用大量的CPU资源去处理过期的数据，从而影响缓存的响应时间和吞吐量(`对CPU不友好`)。

Redis并没有采用这种方式。

**惰性过期：** 只有当访问/操作一个key时，才会判断该key是否已过期（通过在执行命令前调用`expireIfNeeded函数` 对输入的键进行检查），过期则清除。该策略可以最大化地节省CPU资源，却对内存非常不友好。极端情况可能出现大量的过期key没有再次被访问，从而不会被清除，占用大量内存（`对内存不友好`）。

```bash
# 表示开启惰性过期
azyfree-lazy-eviction=yes
```

**定期过期：**`每隔一定的时间`，`随机抽取`指定数量的key，清除其中已过期的key。该策略是前两者的一个折中方案。通过调整定时扫描的时间间隔和每次扫描的限定耗时，可以在不同情况下使得CPU和内存资源达到最优的平衡效果。(expires字典会保存所有设置了过期时间的key的过期时间数据，其中key是指向键空间中的某个键的指针，value是该键的毫秒精度的UNIX时间戳表示的过期时间。键空间是指该Redis集群中保存的所有键。)

定期删除的实现：

```c
#默认每次检查的数据库数量
DEFAULT_DB_NUMBERS = 16
#默认每个数据库检查的键数量
DEFAULT_KEY_NUMBERS = 20
#“全局变量”，记录检查进度，多次调用activeExpireCycle函数共用
current_db = 0
def activeExpireCycle():
    # 初始化要检查的数据库数量
    # 如果服务器的数据库数量比 DEFAULT_DB_NUMBERS 要小
    # 那么以服务器的数据库数量为准
    if server.dbnum < DEFAULT_DB_NUMBERS:
        db_numbers = server.dbnum
    else:
        db_numbers = DEFAULT_DB_NUMBERS
    # 遍历各个数据库
    for i in range(db_numbers):
        # 如果current_db 的值等于服务器的数据库数量
        # 这表示检查程序已经遍历了服务器的所有数据库一次
        # 将current_db 重置为0 ，开始新的一轮遍历
        if current_db == server.dbnum:
            current_db = 0       
        # 获取当前要处理的数据库
        redisDb = server.db[current_db] 
        # 将数据库索引增1 ，指向下一个要处理的数据库
        current_db += 1 
        # 检查数据库键
        for j in range(DEFAULT_KEY_NUMBERS):
            # 如果数据库中没有一个键带有过期时间，那么跳过这个数据库
            if redisDb.expires.size() == 0: break
            #随机获取一个带有过期时间的键
            key_with_ttl = redisDb.expires.get_random_key()
            # 检查键是否过期，如果过期就删除它
            if is_expired(key_with_ttl):
                delete_key(key_with_ttl)
            # 已达到时间上限，停止处理
            if reach_time_limit(): return
```

activeExpireCycle 函数的工作模式可以总结如下：

-   函数每次运行时，都从一定数量的数据库中取出一定数量的随机键进行检查，并删除其中的过期键。
-   全局变量 current\_db 会记录当前 activeExpireCycle 函数检查的进度，并在下一次 activeExpireCycle 函数调用时，接着上一次的进度进行处理。比如说，如果当前 activeExpireCycle 函数在遍历 10 号数据库时返回了，那么下次 activeExpireCycle 函数执行时，将从 11 号数据库开始查找并删除过期键。
-   随着 activeExpireCycle 函数的不断执行，服务器中的所有数据库都会被检查一遍，这时函数将 current\_db 变量重置为 0，然后再次开始新一轮的检查工作。

注意：

-   如果定期删除操作执行得太频繁，或者执行的时间太长，定期删除策略就会退化成定时删除策略，以至于将CPU时间过多地消耗在删除过期键上面。
-   如果定期删除操作执行得太少，或者执行的时间太短，定期删除策略又会和惰性删除策略一样，出现浪费内存的情况

配置：

```c
# 下面配置表示，一秒进行10次检查，第次检查16个数据库，每个数据库随机抽取20个键检查
hz 10
```

***Redis同时使用了惰性过期和定期过期两种过期策略***。但是Redis定期删除是随机抽取机制，不可能扫描删除掉所有的过期Key。因此需要内存淘汰机制。

### **7.2 Redis的内存淘汰策略** (内存不足如果释放内存问题)

Redis的内存淘汰策略是指在Redis的用于缓存的内存不足时，怎么处理需要新写入且需要申请额外空间的数据。

缓存淘汰算法说明：

`LRU`（Least Recently Used）： 淘汰最近最久不使用的，key的lru在对应的value中存储，也就是RedisObject对象中 ，lru值是最近访问的时间戳，Redis中当内存不足时，会随机抽取指定数据（`maxmemory-samples <个数>`）进行排序，最小的，也就是最近最久不使用的会被淘汰。

`LFU`（Least Frequently Used）：淘汰最不经常使用（总使用频率）, lfu的值的指针被包含RedisObject中，指向了全局的LFU信息，它是一个稀疏表（类似hash），key是指针地址，值是统计的计数。当内存不足会，会淘汰表中访问计数最小的（访问频率）对应的key。

两个配置项：

1.  `maxmemory <bytes>` : 用于设置Redis实例使用内存的上限, 默认是0表示实例使用内存没有限制。
2.  `maxmemory-policy noeviction` : 默认值是`noeviction` ，全部如下
    -   **no-eviction**：当内存不足以容纳新写入数据时，新写入操作会报错。
    -   **allkeys-lru**：当内存不足以容纳新写入数据时，在键空间中，移除最近最少使用的key。
    -   **allkeys-random**：当内存不足以容纳新写入数据时，在键空间中，随机移除某个key。
    -   **volatile-lru**：当内存不足以容纳新写入数据时，在设置了过期时间的键空间中，移除最近最少使用的key。
    -   **volatile-random**：当内存不足以容纳新写入数据时，在设置了过期时间的键空间中，随机移除某个key。
    -   **volatile-ttl**：当内存不足以容纳新写入数据时，在设置了过期时间的键空间中，有更早过期时间的key优先移除。

总结：**2种维度**（过期键、所有键）、4个方面（LRU、LFU、random、ttl）

如何选择？&#x20;

在所有的 key 都是最近最经常使用，那么就需要选择 allkeys-lru 进行置换最近最不经常使用的key; 如果你不确定使用哪种策略，那么推荐使用 allkeys-lru; 如果所有的 key 的访问概率都是差不多的，那么可以选用 allkeys-random 策略去置换数据如果对数据有足够的了解，能够为 key 指定 hint (通过expire/ttl指定)，那么可以选择 volatile-ttl 进行置换

### 7.3 AOF/RDB对过期键的处理

#### 7.3.1 AOF对过期键的处理

**AOF文件写入**

如果数据库中的某个键已经过期，并且服务器开启了AOF持久化功能，当过期键被定期删除或者惰性删除后，程序会向AOF文件追加一条DEL命令，显式记录该键已被删除。

以惰性删除为例：

-   获取名称为test的key
-   检查发现该key设置了过期时间并已经过期
-   从内存中删除该key
-   追加一条删除该key的命令到AOF文件
-   返回空

**AOF文件重写**

在执行AOF文件重写时，程序会对数据库中的键进行检查，已过期的键不会被保存到重写后的AOF文件中。

#### 7.3.2 RDB对过期键的处理

**生成RDB：** 在将数据持久化为RDB文件时，会对键进行检查，如果已经过期就不会被保存到持久化文件中。（举个例子，如果数据库中包含三个键k1、k2、k3，并且k2已经过期，rdb会保存k1/k3 ,而k2会被忽略）

**载入RDB：** 在载入RDB时会对文件中保存的键进行检查，如果过期就不会被载入到数据中。但如果是主服务器，不论是否过期，都会被载入到数据库中。从服务器与主服务完成同步后，从服务器过期的键也会被清除，所以过期的键不会对从服务器有影响。

详细请看下面的`7.3`&#x20;

#### 7.3.3主从复制对过期键的处理

-   主服务器在删除一个过期键后，会显式地向所有从服务器发送一个DEL命令，告知从服务器删除这个过期键。
-   从服务器在执行客户端发送的读命令时，即使发现该键已过期也不会删除该键，照常返回该键的值。
-   从服务器只有接收到主服务器发送的DEL命令后，才会删除过期键。

### 7.4 相关面试题

-   生产上你们的redis内存设置多少?
-   如何配置、修改redis的内存大小
-   如果内存满了你怎么办
-   redis清理内存的方式?&#x20;
-   定期删除和惰性删除了解过吗redis缓存淘汰策略有哪些? 分别是什么? 你用那个?
-   redis的LRU了解过吗? 请手写LRU
-   lru和lfu算法的区别是什么
