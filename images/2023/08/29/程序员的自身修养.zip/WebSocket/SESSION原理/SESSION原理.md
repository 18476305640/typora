# SESSION原理

SESSION在第一次访问请求（jsp，请求）,非静态资源时，会通知浏览器创建SESSIONID，使用cookie存储，后面的每次请求都会带着（同host:ip）。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16708928707951670892869346.png)

我们使用 `request.getSession()`的时候，就会使用`jsessionid` 取出 session 对象。

注意：当不同域（host:ip）时，每次请求的sessionid都不一样。

`ws://127.0.0.1:5910`与`http://127.0.0.1:5910` 是同源的。如果host:ip不一致，那会导致websocket操作失败，建立的ws与之前的http请求的session不一致，就会导致无法确认用户身份。
