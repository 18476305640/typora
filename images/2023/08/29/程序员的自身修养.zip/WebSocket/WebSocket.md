# WebSocket

使用websocket技术写的聊天室

[https://github.com/18476305640/websocket-chat](https://github.com/18476305640/websocket-chat "https://github.com/18476305640/websocket-chat")

WebSocket 协议在2008年诞生，2011年成为国际标准。所有浏览器都已经支持了。

它的最大特点就是，服务器可以主动向客户端推送信息，客户端也可以主动向服务器发送信息，是真正的双向平等对话，属于[服务器推送技术](https://en.wikipedia.org/wiki/Push_technology "服务器推送技术")的一种。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16708564207961670856420376.png)

[SESSION原理](SESSION原理/SESSION原理.md "SESSION原理")
