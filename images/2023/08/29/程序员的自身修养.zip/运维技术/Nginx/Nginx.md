# Nginx

## \[1] 虚拟机准备

下载虚拟机：[http://mirrors.ustc.edu.cn/centos/7.9.2009/isos/x86\_64/](http://mirrors.ustc.edu.cn/centos/7.9.2009/isos/x86_64/ "http://mirrors.ustc.edu.cn/centos/7.9.2009/isos/x86_64/")

选择`Minimal` 最新的iso下载。

然后在vmware虚拟机软件中进行安装。虚拟机安装好后，我们需要对虚拟机的网络进行配置。

执行 `ip addr` 命令，可以知道是有两个网卡的。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672303994701.png)

```bash
vi /etc/sysconfig/network-scripts/ifcfg-ens33

TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=static
DEFROUTE=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_FAILURE_FATAL=no
IPV6_ADDR_GEN_MODE=stable-privacy
NAME=ens33
UUID=dfa7d865-e1b6-4e46-baf9-42694e634849
DEVICE=ens33
ONBOOT=yes

IPADDR=192.168.87.201
NETMASK=225.225.225.0
GATEWAY=192.168.87.2
DNS1=8.8.8.8

```

> **配置网络的方案：**
>
> 方案一：ip地址由DHCP自动分配，那只需要在初次编辑的基础上
>
> 配置 `ONBOOT=yes` 表示开机将自动启动该网卡。然后重启`systemctl restart network` 即可。
>
> **方案二：** ip地址设置为静态，在初次编辑的基础上修改
>
> 配置 `ONBOOT=yes` 表示开机将自动启动该网卡
>
> 配置 `BOOTPROTO=static` 表示ip地址使用静态ip
>
> 再配置下面（依次：静态ip地址、子网掩码、网关、DNS服务器地址）：
>
> ```bash
> IPADDR=192.168.87.201
> NETMASK=225.225.225.0
> GATEWAY=192.168.87.2
> DNS1=8.8.8.8
> ```

网络配置好后，我们就可以在虚拟机上安装nginx了

## \[2] nginx

### 2.1 nginx介绍

-   Nginx开源版 [http://nginx.org/en/](http://nginx.org/en/ "http://nginx.org/en/")

    官方原始的Nginx版本
-   Nginx plus商业版

    开箱即用，集成了大量功能
-   Open Resty [https://openresty.org/cn/](https://openresty.org/cn/ "https://openresty.org/cn/")

    OpenResty是一个基于Nginx与 Lua 的高性能 Web 平台，其内部集成了大量精良的 Lua 库、第三方模块以及大多数的依赖项。**更适用于需要大量二次开发的场景，有极强的扩展性**
-   Tengine [https://tengine.taobao.org/](https://tengine.taobao.org/ "https://tengine.taobao.org/")

    由淘宝网发起的Web服务器项目。它在[Nginx (opens new window)](http://nginx.org/ "Nginx (opens new window)")的基础上，针对大访问量网站的需求，添加了很多高级功能和特性。Tengine的性能和稳定性已经在大型的网站如[淘宝网 (opens new window)](http://www.taobao.com/ "淘宝网 (opens new window)")，[天猫商城 (opens new window)](http://www.tmall.com/ "天猫商城 (opens new window)")等得到了很好的检验。相比于Open Resty，扩展性不够强，但是能够满足绝多数使用场景

### 2.2 nginx安装

**下载Nginx包**

[官网下载地址](http://nginx.org/en/download.html "官网下载地址")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672305128801.png)

右击复制下载链接

```bash
yum install -y wget
# 下载
wget http://nginx.org/download/nginx-1.23.3.tar.gz
# 解压
tar -xvf nginx-1.23.3.tar.gz



cd nginx-1.23.3
# 安装库 （依次是C编译器、pcre库、zlib）
yum install -y gcc
yum install -y pcre pcre-devel
yum install -y zlib zlib-devel
# 安装
./configure --prefix=/usr/local/nginx #使用prefix选项指定安装的目录
make
make install
# 启动
cd /usr/local/nginx/sbin
ls # 里面是一个nginx的可执行文件
./nginx # 启动这个可执行
# 关闭防火墙
systemctl stop firewalld
systemctl disable firewalld
# 访问测试：http://192.168.87.201
# 设置为开机自启
yum install -y vim
vim /usr/lib/systemd/system/nginx.service
```

```java
[Unit] 
Description=nginx
After=network.target remote-fs.target nss-lookup.target

[Service]
Type=forking
PIDFile=/usr/local/nginx/logs/nginx.pid
ExecStartPre=/usr/local/nginx/sbin/nginx -t -c /usr/local/nginx/conf/nginx.conf
ExecStart=/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf
ExecReload=/usr/local/nginx/sbin/nginx -s reload
ExecStop=/usr/local/nginx/sbin/nginx -s stop
ExecQuit=/usr/local/nginx/sbin/nginx -s quit 
PrivateTmp=true
   
[Install]   
WantedBy=multi-user.target
```

```bash
systemctl enable nginx
systemctl daemon-reload
```

> **nginx命令补充：**
>
> ./nginx -s stop #快速停止
>
> ./nginx -s quit #完成已接受的请求后，停止
>
> ./nginx -s reload #重新加载配置
>
> ./nginx -t #检查nginx配置是否正确

### 2.3 nginx配置文件介绍

在了解配置文件时，我们先来看一个nginx的目录

Nginx一般安装在`/usr/local/nginx`目录下（安装时--prefix可指定安装目录）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672320196443.png)

```bash
conf #配置文件
  ｜-nginx.conf # 主配置文件
  ｜-其他配置文件 # 可通过那个include关键字，引入到了nginx.conf生效
  
html #静态页面

logs
  ｜-access.log #访问日志(每次访问都会记录)
  ｜-error.log #错误日志
  ｜-nginx.pid #进程号
  
sbin
  ｜-nginx #主进程文件
  
*_temp #运行时，生成临时文件
```

Nginx 采用的是多进程（单线程） & 多路IO复用模型。使用了 I/O 多路复用技术的 Nginx，就成了”并发事件驱动“的服务器。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672320455735.png)

直观图

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672320500724.png)

现在正式来说配置文件  `nginx.conf`

下面是最简化的nginx.conf

```bash
# 表示工作的进程数 worker进程
worker_processes  1;
events {
    # 一个worker的连接数
    worker_connections  1024;
}
http {
    # 里面是后缀与响应格式，可以查看conf目录下的mime.types文件
    include       mime.types;
    # 如果 mime.types 文件没有的，按 application/octet-stream 进行响应
    default_type  application/octet-stream;
    # 详情见下
    sendfile        on;
    # 长链接超时时间
    keepalive_timeout  65;

    # 虚拟服务器（一个nginx可以启用多个server）
    server {
        # 监听的端口
        listen       80;
        # 匹配的域名
        server_name  localhost;
        location / {
            # 根目录
            root   html;
            # 默认访问
            index  index.html index.htm;
        }
        # 服务器错误码为500 502 503 504，转到"域名/50x.html"
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }

    }

}

```

> **sendfile**
>
> 打开sendfile，用户请求的数据不用再加载到nginx的内存中，而是直接发送
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672321267883.png)

### 2.4 nginx虚拟主机配置

方式一：一个端口对应一个虚拟主机, 下面两个 `server` 监听的端口不同，根目录也不同。

```bash
server {
    # 监听的端口
    listen       80;
    # 匹配的域名
    server_name  localhost;
    location / {
        # 根目录
        root   html;
        # 默认访问
        index  index.html index.htm;
    }
    # 服务器错误码为500 502 503 504，转到"域名/50x.html"
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   html;
    }

}
 server {
    listen       88;
    server_name  localhost;

    location / {
        root   www;
        index  index.html index.htm;
    }

    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   html;
    }

}


```

方式二：一个域名对应一个虚拟主机, `server_name` 指定的两个域名都是解析ip为`192.168.87.201` 的nginx服务器ip，根据域名不同，访问的虚拟主机不同。

```bash
    server {
        listen       80;
        server_name  root.uplog.top;

        location / {
            root   html;
            index  index.html index.htm;
        }

        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }

    }
    server {
        listen       80;
        server_name  vod.uplog.top;

        location / {
            root   www;
            index  index.html index.htm;
        }

        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }

    }
```

> 不管是哪种，反正 `listen` 与 `server_name` 连一起不能相同，否则将报错。

### 2.5 servername的多种匹配方式

```bash
        # server_name  www6.uplog.top vod.uplog.top;
        server_name  *.goto.top;
        # server_name  ~[0-9]+.uplog.top;
```

第一个是配置多个

第二个是泛匹配

第三个是正则匹配

## \[3] 反向代理与负载均衡

> **什么是反向代理什么又是正向代理？**
>
> 普通说的代理就是正向代理，上外网的，由Client端主动设置的代理是正向代理。面反向代理是由Server上主动设置的，比如网站的网关，就是反向代理。

### 3.1 普通反向代理

普通反向代理，只需要在 nginx.conf 配置文件下，server标签下配置`proxy` 即可。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672476913168.png)

效果：通过nginx反向代理访问了www\.atguigu.com  (注意，如果你前面不加www，将会被重定向，url栏就不是下面的 192.168.87.202 了)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672477132290.png)

### 3.2 负载均衡

现在已经准备了两台 192.168.87.202:80 、192.168.87.203:80 他们的功能都是一样的。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672477525128.png)

当用户访问 192.168.87.201:80时会被负载均衡到后面两台机器。下面我们就配置 192.168.87.201 机器 的nginx&#x20;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672477670326.png)

然后我们访问 192.168.87.201:80 的nginx，效果如下：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672477999974.gif)

### 3.3 负载均衡的权重、下线、备用

有的机器虽然都是做同样的事，如果之间性能宽带等方面不同，我们可以用`weight` 改变其权重。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672479243148.png)

如果某个机器宕机了，我们可以设置为`down` ，那该服务器项就不起作用了

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672479444743.png)

如果想要将一台机器作为备用器，当其它机器不可用的，他就会生效。使用`backup` 修饰。

（当下面  192.168.87.203 机器不能提供服务时，备用机器 192.168.87.202 才会提供服务）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672479511372.png)

### 3.4 负载均衡的几种策略（很少用）

**ip\_hash**：根据ip保持与指定的服务器交互 （保持会话的一种方式）

**url\_hash**：根据url 请求指定的服务器  （保持会话的一种方式）

**least\_conn**：谁连接少就给谁

fair：fair采用的不是内建[负载均衡](https://so.csdn.net/so/search?q=负载均衡\&spm=1001.2101.3001.7020 "负载均衡")使用的轮换的均衡算法，而是可以根据页面大小、加载时间长短智能的进行负载均衡。fair是第三方模块的负载均衡策略。

## \[4] 动静分离

写一个简单的页面

demo

├── index.html

└── static（静态资源目录）

└── css

└── index.css

准备两个服务器 192.168.87.201、192.168.87.202&#x20;

在 192.168.87.202 机器上部署着`demo` 项目网站（存放 index.html），使用 192.168.87.201  代理 192.168.87.202  且实现动静分离，

首先将demo网站的静态目录`static` 目录放到   192.168.87.201 机器的 nginx > html 目录下

然后配置 nginx > conf > nginx.conf

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672490892021.png)

这样就完成了demo项目的动静分离了。

> `location  正则 { ... }` 可以写正则匹配。如
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672491677394.png)
>
> 上面的"\~"表示要开始正则了，" \*" 表示不区分大小写。后面才是正则。

## \[5] 路径重写

<http://192.168.87.201/4.html>  →  [https://bbs.leyuxyz.com/?pn=4](https://bbs.leyuxyz.com/?pn=4 "https://bbs.leyuxyz.com/?pn=4")

配置nginx：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/31/1672493047178.png)

第一步：代理 [https://bbs.leyuxyz.com/](https://bbs.leyuxyz.com/ "https://bbs.leyuxyz.com/") 网站。

第二步：对路径进行重写。上图的 `$1` 就是rewrite 正则捕获的页数。

> 不知道你有没有注意`rewrite` 行最后面还有一个`break`&#x20;
>
> 不写last和break - 那么流程就是依次执行这些rewrite &#x20;
>
> 1.  rewrite break - url重写后，直接使用当前资源，不再执行location里余下的语句，完成本次请求，地址栏url不变 &#x20;
> 2.  rewrite last - url重写后，马上发起一个新的请求，再次进入server块，重试location匹配，超过10次匹配不到报500错误，地址栏url不变 &#x20;
> 3.  rewrite redirect – 返回302临时重定向，地址栏显示重定向后的url，爬虫不会更新url（因为是临时） &#x20;
> 4.  rewrite permanent – 返回301永久重定向, 地址栏显示重定向后的url，爬虫更新url

## \[6] 防盗链

防盗链是通过查看请求的`Referer` 请求头参数操作的（Referer表示请求来自的网站）。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672556594165.png)

通过配置nginx.conf 的下面，可以让 /static/满足的进行防盗链，只允许 `Referer` 是**192.168.87.201** 或者\*\*none \*\*（比如图片链接单独在新标签打开时）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672556811848.png)

如果不是上面两种，就会返回403 ;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672557624874.png)

> 注意 `if` 右边必须有一个空格，否则报错！

我们还可以自定义错误页面

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672560942709.png)

下面的 192.168.87.201 自然是不符合防盗链规则的，就会被拦截。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672561017865.png)

如果想让防盗链拦截访问的图片资源，可以将其替换为指定提示非法图片。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672561670049.png)

实现方式是结合路径重写来实现： nginx.conf&#x20;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672561784100.png)

## \[7] 高可用场景（keepalived ）

我们在使用nginx做网关时，nginx就一台，当nginx网关宕机了，那怎么办？解决方法如下，我们可以使用keepalived 软件的虚拟ip,外界访问虚拟ip，而在内部虚拟ip给谁是动态了。（IP漂移）

同时存活时看谁优先级高

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672564403416.png)

准备两台Nginx，都是网站的nginx网关，给两台nginx机器都安装上 keepalived&#x20;

```bash
yum install -y keepalived
```

修改keepalived配置

-   配置文件在/etc/keepalived/keepalived.conf
-   `vrrp_instance`、`authentication`、`virtual_router_id`、`virtual_ipaddress`这几个一样的机器，才算是同一个组里。这个组才会选出一个作为Master机器

主nginx：

```bash
! Configuration File for keepalived

global_defs {
   router_id lb0 # 名字与其他配置了keepalive的机器不重复就行
}

vrrp_instance heyingjie {#vrrp实例名可以随意取
    state BACKUP #只能有一个默认的Master，其他写BACKUP
    interface ens33 # ip addr查看下网卡名，默认时ens33
    virtual_router_id 51
    priority 100 # 多台安装了keepalived的机器竞争成为Master的优先级
    advert_int 1 #通信时间
    authentication {
        auth_type PASS
        auth_pass 1111
    }
    virtual_ipaddress {
        192.168.87.200 #虚拟IP
    }
}

```

备用nginx配置：

```bash
! Configuration File for keepalived

global_defs {
   router_id lb1 # 名字与其他配置了keepalive的机器不重复就行
}

vrrp_instance heyingjie {#vrrp实例名可以随意取
    state MASTER #只能有一个默认的Master，其他写BACKUP
    interface ens33 # ip addr查看下网卡名，默认时ens33
    virtual_router_id 51
    priority 50 # 多台安装了keepalived的机器竞争成为Master的优先级
    advert_int 1 #通信时间
    authentication {
        auth_type PASS
        auth_pass 1111
    }
    virtual_ipaddress {
        192.168.87.200 #虚拟IP
    }
}
```

配置好后，两台机器重启 keepalived软件

```bash
systemctl restart keepalived
```

然后在主nginx机器上 ip addr 查看Ip就会发现配置的虚拟ip  192.168.87.200

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672564871834.png)

在备用nginx上是没有的。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/01/1672564919689.png)

## \[8] SSL 证书配置

两个文件，一个是 `xxx.key`（私钥）和`xxx.pem`（证书）

**配置**

将两个文件上传到Nginx目录中，记得放置的位置。我这里直接放在nginx.conf配置文件所在的目录（`/user/local/nginx/conf`），所以写的都是相对路径

```bash
server {
  listen 443 ss1;
  
  ssl certificate  xxx.pem; #这里是证书路径
  ssl_ certificate_key  xxx.key  #这里是私钥路径
}
```

> http跳转https
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/02/1672645325093.png)

## \[9] 会话维持

### 9.1 ip\_hash

请求的ip相同时，多次请求只到同一个服务器。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/02/1672652955645.png)

缺点：可能会造成由于ip集中（局域网共用ip）而造成的流量顷斜。

### 9.2 url\_hash

同一url，多次请求只到同一个服务器。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/02/1672653381109.png)

### 9.3 cookie\_hash

对请求携带的cookie进行hash。

比如下面是，根据名为`jsessionid` 的cookie  hash，值不同自然访问的upstream服务器也不同。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/02/1672653618685.png)

### 9.4 sticky&#x20;

Sticky是nginx的一个模块，它是基于cookie的一种nginx的负载均衡解决方案，通过分发和识别cookie，来使同一个客户端的请求落在同一台服务器上，默认标识名为route

github：[https://github.com/bymaximus/nginx-sticky-module-ng/tags](https://github.com/bymaximus/nginx-sticky-module-ng/tags "https://github.com/bymaximus/nginx-sticky-module-ng/tags")

**升级nginx**

1、需要nginx包，下载，解压

```bash
wget http://nginx.org/download/nginx-1.22.1.tar.gz
tar -xvf nginx-1.22.1.tar.gz
```

2、下载sticky，解压

```bash
wget https://github.com/bymaximus/nginx-sticky-module-ng/archive/refs/tags/1.2.6.tar.gz
tar -xvf 1.2.6.tar.gz

```

3、尝试编译

```bash
cd nginx-1.22.1
./configure --prefix=/usr/local/nginx/ --add-module=/root/nginx-sticky-module-ng-1.2.6/
make
```

发现问题一

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672735504734.png)

解决：

```bash
# 去sticky目录下编辑一下 ngx_http_sticky_misc.h 文件
vim ../nginx-sticky-module-ng-1.2.6/ngx_http_sticky_misc.h

```

添加如下内容：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672735621122.png)

再进行编译

```bash
./configure --prefix=/usr/local/nginx/ --add-module=/root/nginx-sticky-module-ng-1.2.6/
make
```

出现问题二：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672735775245.png)

安装 openssl

```bash
yum install -y openssl-devel
```

再进行编译。

```bash
./configure --prefix=/usr/local/nginx/ --add-module=/root/nginx-sticky-module-ng-1.2.6/
make
```

如下表示成功：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672736147204.png)

那么现在就可以将刚才编译所在的nginx > objs  > nginx 覆盖到之前安装的 /usr/local/nginx/sbin/nginx

然后重新启动Nginx

```bash
systemctl restart nginx
```

配置

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672737351244.png)

效果：访问nginx，控制台（就会有一个route的cookie，这是sticky生成的，用于维持会话的）：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672737401801.png)

## \[10] 配置与调优

**第一块**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672759861876.png)

**第二块：能极大优化响应速度, 提高QPS，吞吐量**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/03/1672759945813.png)

> **使用ab进行压测**
>
> **安装：**
>
> yum -y install httpd httpd-tools
>
> **使用：**
>
> ab -n 100000 -c 30 [http://192.168.87.201/](http://192.168.87.201/ "http://192.168.87.201/") &#x20;

### UpStream工作流程

proxy\_pass 向上游服务器请求数据共有6个阶段

-   初始化
-   与上游服务器建立连接
-   向上游服务器发送请求
-   处理响应头
-   处理响应体
-   结束

**set\_header**

设置header

**proxy\_connect\_timeout**&#x20;

与上游服务器连接超时时间、快速失败

**proxy\_send\_timeout**

定义nginx向后端服务发送请求的间隔时间(不是耗时)。默认60秒，超过这个时间会关闭连接

**proxy\_read\_timeout**

后端服务给nginx响应的时间，规定时间内后端服务没有给nginx响应，连接会被关闭，nginx返回504 Gateway Time-out。默认60秒

#### 缓冲区

**proxy\_requset\_buffering**

是否完全读到请求体之后再向上游服务器发送请求

**proxy\_buffering**&#x20;

是否缓冲上游服务器数据

**proxy\_buffers 32 64k;**

缓冲区大小 32个 64k大小内存缓冲块

**proxy\_buffer\_size**

header缓冲区大小

```bash
proxy_requset_buffering on;
proxy_buffering on;

proxy_buffer_size 64k;

proxy_buffers 32 128k;
proxy_busy_buffers_size 8k;
proxy_max_temp_file_size 1024m;
```

**proxy\_temp\_file\_write\_size 8k**

当启用从代理服务器到临时文件的响应的缓冲时，一次限制写入临时文件的数据的大小。 默认情况下，大小由proxy\_buffer\_size和proxy\_buffers指令设置的两个缓冲区限制。 临时文件的最大大小由proxy\_max\_temp\_file\_size指令设置。 &#x20;

**proxy\_max\_temp\_file\_size 1024m;**

临时文件最大值

**proxy\_temp\_path**&#x20;

> proxy\_temp\_path /spool/nginx/proxy\_temp 1 2;

a temporary file might look like this:

> /spool/nginx/proxy\_temp/7/45/00000123457

#### 对客户端的限制

可配置位置

-   http
-   server
-   location

**client\_body\_buffer\_size**

对客户端请求中的body缓冲区大小

默认32位8k 64位16k

如果请求体大于配置，则写入临时文件

**client\_header\_buffer\_size**

设置读取客户端请求体的缓冲区大小。 如果请求体大于缓冲区，则将整个请求体或仅将其部分写入临时文件。 默认32位8K。 64位平台16K。 &#x20;

**client\_max\_body\_size 1000M;**

默认1m，如果一个请求的大小超过配置的值，会返回413 (request Entity Too Large)错误给客户端

将size设置为0将禁用对客户端请求正文大小的检查。 &#x20;

**client\_body\_timeout**

指定客户端与服务端建立连接后发送 request body 的超时时间。如果客户端在指定时间内没有发送任何内容，Nginx 返回 HTTP 408（Request Timed Out）

**client\_header\_timeout**

客户端向服务端发送一个完整的 request header 的超时时间。如果客户端在指定时间内没有发送一个完整的 request header，Nginx 返回 HTTP 408（Request Timed Out）。

**client\_body\_temp\_path** *path*` [`*level1*` [`*level2*` [`*level3*\`]]]

在磁盘上客户端的body临时缓冲区位置

**client\_body\_in\_file\_only on;**

把body写入磁盘文件，请求结束也不会删除

**client\_body\_in\_single\_buffer**

尽量缓冲body的时候在内存中使用连续单一缓冲区，在二次开发时使用`$request_body`读取数据时性能会有所提高

**client\_header\_buffer\_size**&#x20;

设置读取客户端请求头的缓冲区大小

如果一个请求行或者一个请求头字段不能放入这个缓冲区，那么就会使用large\_client\_header\_buffers

**large\_client\_header\_buffers**

默认8k

### 反向代理中的容错机制

#### 参考文档

[https://docs.nginx.com/nginx/admin-guide/load-balancer/http-load-balancer/](https://docs.nginx.com/nginx/admin-guide/load-balancer/http-load-balancer/ "https://docs.nginx.com/nginx/admin-guide/load-balancer/http-load-balancer/")

[http://nginx.org/en/docs/stream/ngx\_stream\_proxy\_module.html#proxy\_bind](http://nginx.org/en/docs/stream/ngx_stream_proxy_module.html#proxy_bind "http://nginx.org/en/docs/stream/ngx_stream_proxy_module.html#proxy_bind")

**proxy\_timeout**&#x20;

#### 重试机制

**proxy\_next\_upstream**

作用：

当后端服务器返回指定的错误时，将请求传递到其他服务器。

`error`与服务器建立连接，向其传递请求或读取响应头时发生错误;

`timeout`在与服务器建立连接，向其传递请求或读取响应头时发生超时;

`invalid_header`服务器返回空的或无效的响应;

`http_500`服务器返回代码为500的响应;

`http_502`服务器返回代码为502的响应;

`http_503`服务器返回代码为503的响应;

`http_504`服务器返回代码504的响应;

`http_403`服务器返回代码为403的响应;

`http_404`服务器返回代码为404的响应;

`http_429`服务器返回代码为429的响应;

不了解这个机制，在日常开发web服务的时候，就可能会踩坑。

比如有这么一个场景：一个用于导入数据的web页面，上传一个excel，通过读取、处理excel，向数据库中插入数据，处理时间较长（如1分钟），且为同步操作（即处理完成后才返回结果）。暂且不论这种方式的好坏，若nginx配置的响应等待时间（proxy\_read\_timeout）为30秒，就会触发超时重试，将请求又打到另一台。如果处理中没有考虑到重复数据的场景，就会发生数据多次重复插入！（当然，这种场景，内网可以通过机器名访问该服务器进行操作，就可以绕过nginx了，不过外网就没办法了。）

## \[12] 获取客户端真实IP

#### X-Real-IP

额外模块，不推荐使用

#### setHeader

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/04/1672824769488.png)

```bash
proxy_set_header X-Forwarded-For $remote_addr;
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/04/1672824458128.png)

## \[13]Gzip

### 13.1 普通使用gzip

作用域 `http, server, location`

完整实例

```bash
gzip on;
gzip_buffers 16 8k; #缓冲区大小
gzip_comp_level 6;  #压缩等级 1-9，数字越大压缩比越高
gzip_http_version 1.1;  #使用gzip的最小版本
gzip_min_length 256;  #设置将被gzip压缩的响应的最小长度。 长度仅由“Content-Length”响应报头字段确定。
gzip_proxied any;
gzip_vary on;  #增加一个header，适配老的浏览器 Vary: Accept-Encoding
gzip_types text/plain application/x-javascript text/css application/xml;
gzip_types  #哪些mime类型的文件进行压缩
  text/xml application/xml application/atom+xml application/rss+xml application/xhtml+xml image/svg+xml
  text/javascript application/javascript application/x-javascript
  text/x-json application/json application/x-web-app-manifest+json
  text/css text/plain text/x-component
  font/opentype application/x-font-ttf application/vnd.ms-fontobject
  image/x-icon;
gzip_disable "MSIE [1-6]\.(?!.*SV1)";  #禁止某些浏览器使用gzip
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/04/1672825346079.png)

### 13.2 扩展使用gzip

模块：**ngx\_http\_gunzip\_module**

为不支持"gzip"编码方式的客户端解压缩头"Content-Encoding:gzip"提供的过滤器。

说的通俗一点，就是为某些不支持gzip压缩的浏览器提供的，如果浏览器不支持gzip压缩文件的话，用gunzip这种方式来解决即可。

模块：**http\_gzip\_static\_module**

预读gzip功能，允许发送.gz扩展名文件进行响应。

预读gzip功能，实际是减轻服务器压力、提高应用性能的一种方式。将静态自己预先进行gzip压缩，压缩后文件存储在源文件同级目录下，例如：index.html目录下同时存储index.html.gz。此时，若访问index.html，Ngnix会首先访问index.html.gz，index.html.gz存在的话，直接返回index.html.gz，如果index.html.gz不存在，则转而访问index.html。

由于预先进行了gzip压缩，省去了服务器对资源进行gzip压缩的过程，可以减少服务响应时间以及服务器CPU的消耗。预读gzip并非只此一种实现，还有一种实现是代理层缓存，可以达到一样的效果。但无论哪种方式，预读都只针对静态资源，因为动态资源是无法预读的。

Nginx默认未构建此模块，需要使用–with-http\_gzip\_static\_module配置使用它。

开启(**on**)或禁用(**off**)会检查预压缩文件是否存在。下列指令也会被影响到 [gzip\_http\_verson](/nginx-docs/he-xin-gong-neng/http/ngx_http_gzip_module#gzip_http_version "gzip_http_verson")， [gzip\_proxied](/nginx-docs/he-xin-gong-neng/http/ngx_http_gzip_module#gzip_proxied "gzip_proxied")， [gzip\_disable](/nginx-docs/he-xin-gong-neng/http/ngx_http_gzip_module#gzip_disable "gzip_disable")， [gzip\_vary](/nginx-docs/he-xin-gong-neng/http/ngx_http_gzip_module#gzip_vary "gzip_vary")。

值为 **always** (1.3.6)，在所有情况下都会使用压缩文件，不检查客户端是否支持。如果磁盘上没有未被压缩的文件或者 [ngx\_http\_gunzip\_module](/nginx-docs/he-xin-gong-neng/http/ngx_http_gunzip_module "ngx_http_gunzip_module") 模块被启用，这个参数非常有用。

文件可以使用`gzip`命令，或者任何兼容文件进行压缩。建议压缩文件和源文件的修改日期和时间保持一致。

> 两个模块配合：将 **http\_gzip\_static\_module** 模块设置为 `gzip_static always; ` 表示总是会将.gz后缀的文件发送到客户端，不管客户端是否支持。而  **ngx\_http\_gunzip\_module** 模块可以判断客户端是否支持，如果不支持帮助客户端解压再发送过去。这样我们就可以删掉`原文件`，保留`原文件.gz` 即可。

全部配置: 可配置在`location`下

```bash
            gunzip on;
            gzip_static always;       
            gzip on;
            gzip_buffers 16 8k;
            gzip_comp_level 6;
            gzip_http_version 1.1;
            gzip_min_length 256;
            gzip_proxied any;
            gzip_vary on;
            gzip_types text/html text/plain application/x-javascript text/css application/xml;
            gzip_types
              text/xml application/xml application/atom+xml application/rss+xml application/xhtml+xml image/svg+xml
              text/javascript application/javascript application/x-javascript
              text/x-json application/json application/x-web-app-manifest+json
              text/css text/plain text/x-component
              font/opentype application/x-font-ttf application/vnd.ms-fontobject
              image/x-icon;
            #gzip_disable "MSIE [1-6]\.(?!.*SV1)";
```

## \[14] Brotli

在web应用中，为了节省流量，降低传输数据大小，提高传输效率，常用的压缩方式一般都是gzip，今天我们来介绍另外一种更高效的压缩方式brotli。 &#x20;
Brotli 是基于LZ77算法的一个现代变体、霍夫曼编码和二阶上下文建模。Google软件工程师在2015年9月发布了包含通用无损数据压缩的Brotli增强版本，特别侧重于HTTP压缩。

注意：使用算法的前提是启用了 https，因为 http 请求中 **request header** 里的 **Accept-Encoding: gzip, deflate** 是没有 br 的。

下载两个文件：

-   `https://github.com/google/ngx_brotli`
-   `https://codeload.github.com/google/brotli/tar.gz/refs/tags/v1.0.9`

得到两个文件`v1.0.0rc.tar.gz` 、`brotli-1.0.9.tar.gz`，将两个压缩包解压。

得到两个目录`ngx_brotli-1.0.0rc`、`brotli-1.0.9`

将brotli-1.0.9目录重命名 brotli放到 ngx\_brotli-1.0.0rc/deps下

```bash
mv brotli-1.0.9 ngx_brotli-1.0.0rc/deps/brotli
```

最后结合到一个 /root/ngx\_brotli-1.0.0rc ,到nginx源目录下

```bash
./configure --with-compat --add-dynamic-module=/root/ngx_brotli-1.0.0rc --prefix=/usr/local/nginx/
make
```

将编译好的 so、nginx执行文件放到 /usr/local/nginx 下

```bash
mv objs/*.so /usr/local/nginx/modules/
rm -rf /usr/local/nginx/sbin/nginx
cp -r objs/nginx /usr/local/nginx/sbin/

# 重启
systemctl restart nginx
# 如果启动失败，查看一下nginx为什么启动失败，如果nginx的配置文件还有gzip的，要去掉，因为我们新编译的nginx没有gzip
systemctl status nginx
```

-   配置文件中添加

```bash
load_module "/usr/local/nginx/modules/ngx_http_brotli_filter_module.so";
load_module "/usr/local/nginx/modules/ngx_http_brotli_static_module.so";
```

location下：

```bash
  brotli on;
  brotli_static on;
  brotli_comp_level 6;
  brotli_buffers 16 8k;
  brotli_min_length 20;
  brotli_types text/plain text/css text/javascript application/javascript text/xml application/xml application/xml+rss application/json image/jpeg image/gif image/png;
```

测试

```bash
[root@localhost sbin]# curl -H 'accept-encoding:br' -I http://192.168.87.201
HTTP/1.1 200 OK
Server: nginx/1.22.1
Date: Wed, 04 Jan 2023 07:02:33 GMT
Content-Type: text/html
Last-Modified: Tue, 03 Jan 2023 23:58:42 GMT
Connection: keep-alive
ETag: W/"63b4c132-a78"
Content-Encoding: br

```

## \[15] 合并请求：使用 Tengine concat模块

模块介绍：[https://www.nginx.com/resources/wiki/modules/concat/](https://www.nginx.com/resources/wiki/modules/concat/ "https://www.nginx.com/resources/wiki/modules/concat/")

从gitub中下载:  [https://github.com/alibaba/nginx-http-concat](https://github.com/alibaba/nginx-http-concat "https://github.com/alibaba/nginx-http-concat")

下载下来zip包，上传到服务器，解压&#x20;

```bash
yum install -y unzip
unzip nginx-http-concat-master.zip
```

现在开始编译，进入nginx原始开源版（不用Tengine也可以整合concat模块）：

```bash
./configure --prefix=/usr/local/nginx/ --add-module=/root/nginx-http-concat-master
make
```

将编译好的执行文件nginx覆盖到 /usr/local/nginx/sbin下

```bash
 rm /usr/local/nginx/sbin/nginx
 cp ./objs/nginx /usr/local/nginx/sbin/

```

清除掉之前其它未引入模块的配置，然后重启

```bash
systemctl restart nginx
```

开始使用：

准备文件结构

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/06/1672983910645.png)

配置nginx, 的concat模块配置

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/06/1672983977096.png)

然后重启

```bash
systemctl restart nginx
```

然后打开页面，看字体与背景是否应用了引入的css样式。

> 除了concat模块合并请求，还有一种类似的，就是精灵图了, 也能有效地合并请求。都是要求前端配合实现。
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/06/1672984180469.png)

## \[16] rsync同步

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/06/1673010330538.png)

在两台机器上，进行如下操作

```bash
yum install -y rsync
```

然后编辑/创建上图的三个文件...，然后给予权限&#x20;

```bash
chmod 600 /etc/rsyncd.password
chmod 600 /etc/rsyncd.password.client
```

然后启动 (两台机器都要)

```bash
rsync --daemon
```

然后在源机器上，创建 `/tmp/source` 目录，在目录机器上创建`/tmp/target` 目录，在源机器上的 `/tmp/source` 随便创建一些文件。

进行同步进行  源机器`/tmp/source` ⇒ 目标机器`/tmp/source`

```bash
# 使用--password-file来指定免密文件（登录不要再输入密码）， nor是目标机器上rsync账号（目标机器上配置文件上配置的auth users上写的密码，可以写多个
rsync -az --delete --password-file=/etc/rsyncd.password.client /tmp/source/ nor@192.168.87.204::ftp/
```

设置开机启动

在`/etc/rc.local`文件中添加

```bash
rsync --daemon
```

关闭进程

```bash
ps -aux | grep rsync
kill -9 <rsync进程>
```

### 16.1自动脚本

推送端安装inotify

依赖

```bash
yum install -y automake
```

```bash
wget http://github.com/downloads/rvoicilas/inotify-tools/inotify-tools-3.14.tar.gz
./configure --prefix=/usr/local/inotify
cd inotify-tools-3.14
make && make install
```

监控目录 (测试inotify)

```bash
/usr/local/inotify/bin/inotifywait -mrq --timefmt '%Y-%m-%d %H:%M:%S' --format '%T %w%f %e' -e close_write,modify,delete,create,attrib,move //tmp/source

```

简单自动化脚本 （整合rsync）

```bash
#!/bin/bash

/usr/local/inotify/bin/inotifywait -mrq --timefmt '%d/%m/%y %H:%M' --format '%T %w%f %e' -e close_write,modify,delete,create,attrib,move //tmp/source | while read file
do  
        rsync -az --delete --password-file=/etc/rsyncd.password.client /tmp/source nor@192.168.87.204::ftp/
done

```

你可以能觉得更好的sh脚本：[https://cloud.tencent.com/developer/article/1373541](https://cloud.tencent.com/developer/article/1373541 "https://cloud.tencent.com/developer/article/1373541")

## &#x20;\[17] 多级缓存

### 17.1 强制缓存与协商缓存

**cache-contro 或 expires 强制缓存**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/07/1673094954353.png)

页面首次打开，直接读取缓存数据，刷新，会向服务器发起请求。

注意，如果设置时间比较短，那是没有生效的，因为时区时间不一样，导致的，所以要设置时间长才有效。

**etag lastmodify 协商缓存**

请求时，发送

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/07/1673095427575.png)

nginx响应

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/07/1673095464907.png)

,没发生变化 返回304 不发送数据，nginx上不用任何配置，默认就有协商缓存。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/07/1673093688317.png)

### 17.2 CDN缓存

使用GeoIP2 对不同国家或地区进行区分访问。

[https://www.bilibili.com/read/cv18082692](https://www.bilibili.com/read/cv18082692 "https://www.bilibili.com/read/cv18082692")

### 17.3 正向代理与反向代理

#### 17.3.1 正向代理

普通进行正向代理的话，是不能进行http请求的，普通的正向代理如下 :&#x20;

> 只需要加入两行：
>
> ```纯文本
> resolver 8.8.8.8;
> proxy_pass https://$host$request_uri;
> ```
>
> 位置：
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/08/1673157944655.png)

然后在电脑设置中，配置代理

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/08/1673158080849.png)

这样配置后，打开浏览器，就可以访问一些网站了，<http://atguigu.com> ,当如果是Https就不行了。如果需要，需要 `ngx_http_proxy_connect_module` 第三方模块：

[https://github.com/chobits/ngx\_http\_proxy\_connect\_module](https://github.com/chobits/ngx_http_proxy_connect_module "https://github.com/chobits/ngx_http_proxy_connect_module")

编译

```bash
cd /root
wget https://nginx.org/download/nginx-1.23.3.tar.gz
wget https://github.com/chobits/ngx_http_proxy_connect_module/archive/refs/tags/v0.0.4.tar.gz
# 解压
tar -xvf nginx-1.23.3.tar.gz
tar -xvf v0.0.4.tar.gz
cd nginx-1.23.3
# 这里不同版本的nginx  补丁也不同，请查看：https://github.com/chobits/ngx_http_proxy_connect_module#install 
patch -p1 < /root/ngx_http_proxy_connect_module-0.0.4/patch/proxy_connect_rewrite_102101.patch

./configure --add-module=/root/ngx_http_proxy_connect_module-0.0.4
make
# 将编译得到的nginx文件替换 /usr/local/nginx/sbin下的nginx
cp -r objs/nginx /usr/local/nginx/sbin/
# 尝试重新启动 nginx
systemctl restart nginx

```

如果nginx启动成功，配置nginx (下面的server位置： http > server )

```bash
...    
    server {
        listen       9090;
        resolver 8.8.8.8;
        proxy_connect;
        proxy_connect_allow            443 563;
        proxy_connect_connect_timeout  10s;
        proxy_connect_read_timeout     10s;
        proxy_connect_send_timeout     10s;
        location / {
              proxy_pass https://$host$request_uri;
              proxy_buffer_size 64k;
              proxy_buffers 32 32k;
              proxy_busy_buffers_size 128k;

              proxy_set_header Content-Type $http_content_type;
              proxy_set_header Host $http_host;
              proxy_set_header Authorization $http_Authorization;
        }
    }

...
```

重新启动nginx

```bash
systemctl restart nginx
```

设置代理

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/08/1673158080849.png)

测试，发现上网的ip是云服务器，也是服务器上的nginx，成功！

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/08/1673158669628.png)

#### 17.3.2 反向代理

### 17.4 proxy缓存

官网解释

[http://nginx.org/en/docs/http/ngx\_http\_proxy\_module.html#proxy\_cache](http://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_cache "http://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_cache")

配置

```bash
http模块：
  proxy_cache_path /ngx_tmp levels=1:2 keys_zone=nginx_cache:100m inactive=1d max_size=10g;

location模块：
  # 添加响应头，可以从浏览器“网络”中查看是否使用了proxy缓存
  add_header  Nginx-Cache "$upstream_cache_status";
  # 使用上面哪个缓存配置
  proxy_cache nginx_cache;
  # 资源使用过多少次后才被缓存
  proxy_cache_min_uses 10;
  # 缓存后，多少时间内有效
  proxy_cache_valid 30s;


```

真实配置：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/08/1673171960551.png)

说明，配置后，Nginx只缓存`GET`和`HEAD`的客户端请求。当然如果你需要Nginx可以缓存任何请求。你可使用`proxy_cache_methods`指令设置需要缓存客户端那些请求。

配置后会造成，查看的内容不及时问题，比如你修改了头像，但不管你怎么刷新，还是那个头像，但其实已经在数据库中修改了。

推荐缓存后端传过来的静态资源\~

**proxy\_cache\_use\_stale**&#x20;

默认off

在什么时候可以使用过期缓存

可选`error` | `timeout` | `invalid_header` | `updating` | `http_500` | `http_502` | `http_503` | `http_504` | `http_403` | `http_404` | `http_429` | `off`

**proxy\_cache\_background\_update**&#x20;

默认off

运行开启子请求更新过期的内容。同时会把过期的内容返回给客户端

**proxy\_no\_cache**  **proxy\_cache\_bypass**&#x20;

指定什么时候不使用缓存而直接请求上游服务器

```bash
proxy_no_cache $cookie_nocache $arg_nocache$arg_comment;
proxy_no_cache $http_pragma    $http_authorization;
```

如果这些变量如果存在的话不为空或者不等于0，则不使用缓存

**proxy\_cache\_convert\_head**&#x20;

默认 on

是否把head请求转换成get请求后再发送给上游服务器 以便缓存body里的内容

如果关闭 需要在 `cache key` 中添加 \$request\_method 以便区分缓存内容

**proxy\_cache\_lock**&#x20;

默认off

缓存更新锁

**proxy\_cache\_lock\_age**&#x20;

默认5s

缓存锁超时时间

#### 17.4.1 Nginx代理服务器缓存清理模块purge

如果开启了Nginx的代理服务器缓存，缓存失效的时间是通过proxy\_cache\_valid定义的多长时间失效，以及上游服务发来的响应一些头部，比如[cache-control](https://so.csdn.net/so/search?q=cache-control\&spm=1001.2101.3001.7020 "cache-control")来定义缓存什么时候失效。但是这些失效时间都是固定的，如果后端服务器的信息更新了，希望nginx代理服务器的缓存能够立刻生效，要怎么做呢？ngx\_cache\_purge这个nginx模块可以实现通过浏览器访问指定URL（我们知道nginx的代理服务器缓存是以url作为key）来删除这个url对应的缓存信息。

**purge模块安装**

1、下载purge模块

官方地址：

[GitHub - FRiCKLE/ngx\_cache\_purge: nginx module which adds ability to purge content from FastCGI, proxy, SCGI and uWSGI caches.](https://github.com/FRiCKLE/ngx_cache_purge "GitHub - FRiCKLE/ngx_cache_purge: nginx module which adds ability to purge content from FastCGI, proxy, SCGI and uWSGI caches.")

2、解压下载的文件

3、然后配置

./configure --prefix=/usr/local/nginx --add-module=/root/ngx\_cache\_purge-2.3

4、执行编译

make

5、备份原nginx主程序

mv /usr/local/nginx/sbin/nginx /usr/local/nginx/sbin/nginx.old

6、停止nginx

./nginx -s quit

7、拷贝

然后配置Nginx

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673246324316.png)

注意上面的红色块不要把顺序弄乱！！

ngx\_cache\_purge核心匹配：

```bash

        location ~ /purge(/.*) {
            proxy_cache_purge  ngx_cache  $1$is_args$args;
        }
        # location模块内：自定义cachekey
        proxy_cache_key $uri$is_args$args;
```

请求：[http://124.222.229.234/purge/](http://124.222.229.234/purge/apis/dj/upload/2023/01/08/80C84DBD2E044F38891E62B6E3E769E0.png "http://124.222.229.234/purge/")\<uri> 可以删除存储在nginx上的后端的缓存数据。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673246837479.png)

### 17.5断点续传缓存 range

当有完整的content-length之后即可断点续传

在反向代理服务器中需向后传递header

```bash
proxy_set_header Range $http_range;
```

proxy\_cache\_key中增加range

**proxy\_cache\_max\_range\_offset**&#x20;

range最大值，超过之后不做缓存，默认情况下 不需要对单文件较大的资源做缓存

**proxy\_cache\_methods**&#x20;

默认 head get

**proxy\_cache\_min\_uses**&#x20;

默认1

被请求多少次之后才做缓存

**proxy\_cache\_path**&#x20;

path 指定存储目录

以cache\_key取md5值

-   **levels=1:2**

目录层级数及目录名称位数

取mdb5后几位

TMPFS

-   **use\_temp\_path**

默认创建缓存文件时，先向缓冲区创建临时文件，再移动到缓存目录

是否使用缓冲区

-   **inactive**&#x20;

指定时间内未被访问过的缓存将被删除

### 17.6 Nginx内存缓存

使用**strace** 工具 &#x20;

```bash
yum install -y strace
```

配置了 `sendfile on` 时 （如果是off, 那下面将没有sendfile输出）

查看nginx进程

```bash
[root@localhost ~]# ps -aux | grep nginx
root      48161  0.0  0.0  20580   640 ?        Ss   02:44   0:00 nginx: master process /usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf
nobody    48162  0.0  0.0  20940  1328 ?        S    02:44   0:00 nginx: worker process
root      48188  0.0  0.0 112824   988 pts/1    S+   02:44   0:00 grep --color=auto nginx
[root@localhost ~]# strace -p 48162  # worker进程id
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673257720389.png)

`sendfile on` + 如下配置

```bash
# location模块：
open_file_cache max=500 inactive=60s
open_file_cache_min_uses 1; 
open_file_cache_valid 60s; 
open_file_cache_errors on
```

再查看, 第二次后没有再`open` 了，这就是配置了**open\_file\_cache** 的效果。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673257348893.png)

### 17.7 外置缓存

#### 17.7.1 前置知识：**error\_page**

-   普通error\_page

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673265590204.png)
-   error\_page 302到其它页面

    指定状态码
    ```bash
    error_page 404 =302 http://www.atguigu.com;
    ```
    默认指向location
-   这是匿名location

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673265349046.png)

#### 17.7.2 案例：nginx + memcached

memcached安装

```bash
yum -y install memcached
```

> 默认配置文件在 `/etc/sysconfig/memcached`

```bash
# 启动memcached
systemctl start memcached
# 查看memcached状态
memcached-tool 127.0.0.1:11211  stats
# 安装telnet
yum install -y telnet
# 用telnet连接memcached
telnet 127.0.0.1 11211

```

telnet操作memcached的基本使用

```bash
Escape character is '^]'.
# 设置memcachedkv格式：set <key> <flags> <exptime> <bytes>
set name 0 0 3  
abc
STORED
# 获取存储在memcached上的kv， 格式: get <key>
get name
VALUE name 0 3
abc
END

```

nginx 整合上memcached

工作流程：请求到nginx后，nginx会根据 `$uri?$args` 查看memcached上是否有值，如果有，会将返回的数据按配置好的Content-Type 一起返回，如果memcached没有找到，会走404逻辑，404会走我们配置好的匿名location上的upstream上流服务器。 同时我们的上流服务器也可以操作memcached设置新缓存。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673269500059.png)

在nginx配置文件上配置memcached

nginx.conf

```bash
   upstream webs {
      server 192.168.87.202:80;
   }
   server {
        listen       80;
        server_name  localhost;

        location / {
            set            $memcached_key "$uri?$args";
            memcached_pass 127.0.0.1:11211;

            add_header X-Cache-Satus HIT;
            add_header Content-Type 'text/html; charset=utf-8'; # 强制响应数据格式为html

        }
        error_page   404 = @fallback;
        location @fallback {
             add_header memcached_key $memcached_key;
             proxy_pass http://webs;

        }
    }


```

配置好后，重启nginx服务器，请求nginx服务器。发现会走我们上流服务器。因为我们还没有往memcached上设置缓存，在这里我们使用telnet往memcached上设置值。

```bash
[root@localhost ~]# telnet 127.0.0.1 11211
Trying 127.0.0.1...
Connected to 127.0.0.1.
Escape character is '^]'.
set /? 0 0 3
abc
STORED

```

设置好后，我们再请求，发现会走我们memcached返回的内容。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/09/1673270013228.png)

#### 17.7.3 案例：nginx + redis

redis2-nginx-module是一个支持 Redis 2.0 协议的 Nginx upstream 模块，它可以让 Nginx 以非阻塞方式直接防问远方的 Redis 服务，同时支持 TCP 协议和 Unix Domain Socket 模式，并且可以启用强大的 Redis 连接池功能。

github: [https://github.com/openresty/redis2-nginx-module](https://github.com/openresty/redis2-nginx-module "https://github.com/openresty/redis2-nginx-module")

编译模块

```bash
cd /root
wget https://github.com/openresty/redis2-nginx-module/archive/refs/tags/v0.15.tar.gz
tar -xvf v0.15.tar.gz
#此时进入nginx目录
cd nginx-1.22.1/
./configure --add-module=/root/redis2-nginx-module-0.15/
rm -rf /usr/local/nginx/sbin/nginx
cp ./objs/nginx /usr/local/nginx/sbin/

```

redis快速安装

```bash
yum install epel-release 
yum install -y redis
```

配置Nginx,  nginx.conf

```bash
        location ~ (/.*) {
                default_type text/html;
                redis2_query get $1;
                redis2_pass 127.0.0.1:6379;
        }
```

更多：[https://github.com/openresty/redis2-nginx-module](https://github.com/openresty/redis2-nginx-module "https://github.com/openresty/redis2-nginx-module")

重启nginx

```bash
systemctl restart nginx
```

向redis中设置k-v

```bash
[root@localhost nginx-1.22.1]# redis-cli
127.0.0.1:6379> set / hello
OK

```

访问[http://192.168.87.201/](http://192.168.87.201/ "http://192.168.87.201/")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/10/1673330175918.png)

## \[18] Stream流

### 18.1 使用Stream流做mysql负载均衡

首先需要有两台上流mysql服务器（主主互备）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/11/1673438713940.png)

搭建主主互备mysql, 准备两台机器（192.168.87.202、192.168.87.202）

192.168.87.202 在`/etc/my.cnf`文件中的“`[mysqld]`”段添加如下内容：

```text
server-id = 1
log-bin=mysql-bin
relay-log = mysql-relay-bin
replicate-wild-ignore-table=mysql.%
replicate-wild-ignore-table=test.%
replicate-wild-ignore-table=information_schema.%
```

192.168.87.203 在`/etc/my.cnf`文件中的“`[mysqld]`”段添加如下内容：

```纯文本
server-id = 2
log-bin=mysql-bin
relay-log = mysql-relay-bin
replicate-wild-ignore-table=mysql.%
replicate-wild-ignore-table=test.%
replicate-wild-ignore-table=information_schema.%
```

分别重启mysql, 然后执行

```bash
# master机器上执行
grant replication slave on *.* to 'repl_user'@'192.168.87.%' identified by '3333';
show master status;
# 在非master机器上执行（下面192.168.87.202是master机器ip地址）
# 注意下面 “mysql-bin.000003”与“master_log_pos” 的值取自 上面的 show master status; 命令输出
change master to master_host='192.168.87.202',master_user='repl_user',master_password='3333',master_log_file='mysql-bin.000003',master_log_pos=1512;
start slave;
show slave status \G;
```

最终两台机器 的show slave status\G; 输出为以下，表示成功！

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/11/1673441176681.png)

这样我们在两台中任意一台的操作，都会同步到另一台机器了。

在 nginx机器 192.168.87.201 上，nginx从1.9.0后引入模块ngx\_stream\_core\_module，模块是没有编译的，需要用到编译，编译时需添加--with-stream配置参数。

编译命令

```bash
./configure  --with-stream
```

nginx配置

```纯文本
# stream与http模块同级
stream{
    upstream mysql{
        server 192.168.87.202:3306 weight=1;
        server 192.168.87.203:3306 weight=1;
    }

    server{
        listen 3306;
        proxy_pass mysql;
    }
}

```

然后重启，这样我们就可以去用navicat连接 192.168.87.201了。

> 注意：那两台上流mysql服务器需要可以远程连接！

## \[19] 限流

限流有两种算法，一种是漏桶算法，一种是令牌算法

### 19.1 限流算法（限制请求）：漏桶算法

漏桶算法(Leaky Bucket)是网络世界中流量整形（Traffic Shaping）或速率限制（Rate Limiting）时经常使用的一种算法，它的主要目的是控制数据注入到网络的速率，平滑网络上的突发流量。漏桶算法提供了一种机制，通过它，突发流量可以被整形以便为网络提供一个稳定的流量。

漏桶可以看作是一个带有常量服务时间的单服务器队列，如果漏桶（包缓存）溢出，那么数据包会被丢弃。 在网络中，漏桶算法可以控制端口的流量输出速率，平滑网络上的突发流量，实现流量整形，从而为网络提供一个稳定的流量。

如图所示，把请求比作是水，水来了都先放进桶里，并以限定的速度出水，当水来得过猛而出水不够快时就会导致水直接溢出，即拒绝服务。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/12/1673519954327.png)

nginx配置

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/12/1673531480735.png)

`limit_req_zone $binary_remote_addr zone=perip:10m rate=1r/s;`&#x20;

`$binary_remote_addr` ：是根据用户ip进行限流

`perip` : 是这个规则的名字

`10m`：是用10M大小存储ip

`1r/s` : 是QPS限制在 1

`limit_req zone=perip burst=1000 nodelay;`

在location模块使用，`zone`的值是上面的zone值，burst是桶大小（是一个用户的桶，不是全部用户的桶） `nodelay`是溢出的快速失败，不要放在等待队列中。

**配置与效果**

配置

```纯文本
limit_req_zone $binary_remote_addr zone=perip:10m rate=1r/s;
limit_req zone=perip burst=5 nodelay;

```

效果：一开始可以执行好多次都不会出现503 (拒绝请求)，然后开始503与正常访问相间，等一下后（桶中空了），再请求又好多次都不会出现503 。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/12/1673534397071.gif)

### 19.2 限流算法（限制宽带）：令牌算法&#x20;

对于很多应用场景来说，除了要求能够限制数据的平均传输速率外，还要求允许某种程度的突发传输。这时候漏桶算法可能就不合适了，令牌桶算法更为适合。

令牌桶算法的原理是系统以恒定的速率产生令牌，然后把令牌放到令牌桶中，令牌桶有一个容量，当令牌桶满了的时候，再向其中放令牌，那么多余的令牌会被丢弃；当想要处理一个请求的时候，需要从令牌桶中取出一个令牌，如果此时令牌桶中没有令牌，那么则拒绝该请求。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/12/1673534745041.png)

nginx配置

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/13/1673599533015.png)

效果：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/13/1673599666400.png)

### 19.3 限制同一ip并发（计数器算法）

nginx配置：

对单个ip、单个会话同时存在的连接数的限制。这里定义一个存储区`conn_zone`，conn\_zone的容量是`1m`，该存储区针对于变量\$binary\_remote\_add生效，这里是针对单个IP生效。该模块只是一个定义，配置在http配置段，需要配合limit\_conn指令使用才生效， `limit_conn one 1`表示该location段使用conn\_zone定义的 limit\_conn\_zone ，对单个IP限制同时存在一个连接。

先查看一个请求大小（用于限制宽带大小）：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/13/1673603663487.png)

nginx配置：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/13/1673603542281.png)

测试效果：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/13/1673604475265.gif)

## \[20] 日志

### 20.1 普通日志配置

```纯文本
1. http模块:  全局定义  log_format 日志格式
 log_format aaa '$remote_addr - $remote_user [$time_local]'
                    '"$request" $status $body_bytes_sent'
                    '"$http_referer" "$http_user_agent"';

2. http模块： server配置 
 access_log /application/nginx/logs/access_81.log aaa buffer=64k flush=1m;

##解释:
buffer=64k   #日志文件缓存在内存中的大小，达到后写到指定的缓存文件中
flush=1m     #固定刷盘时间


```

> `open_log_file_cache` 说明
>
> ```纯文本
> open_log_file_cache
> 使用open_log_file_cache来设置日志文件缓存(默认是off)。
>
> inactive=20s  #日志文件在缓存中没有被使用就会被取消   
> min_uses=1   #在存活时间内日志被写入几次才会记录到缓存
> max:设置缓存中的最大文件描述符数量，如果缓存被占满，采用LRU算法将描述符关闭。
> min_uses:设置在inactive时间段内，日志文件最少使用多少次后，该日志文件描述符记入缓存中，默认是1次
> valid:设置检查频率，默认60s
> off：禁用缓存
> 语法格式:  open_log_file_cache max=N [inactive=time] [min_uses=N] [valid=time];
>                      open_log_file_cache off;
> 默认值:   open_log_file_cache off;
> 作用域:   http, server, location
> 实例一
> ```

### 20.2 日志压缩

按以下配置后，生成的日志文件是压缩文件

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/13/1673613596452.png)

gunzip 解压生成的文件（没有后缀），就是明文的普通日志文件了。

### 20.3 配置生成json日志

http模块下配置：

```纯文本
    # json日志格式
    log_format log_json '{"@timestamp": "$time_local", '
                        '"remote_addr": "$remote_addr", '
                        '"referer": "$http_referer", '
                        '"request": "$request", '
                        '"status": $status, '
                        '"bytes": $body_bytes_sent, '
                        '"agent": "$http_user_agent", '
                        '"x_forwarded": "$http_x_forwarded_for", '
                        '"up_addr": "$upstream_addr",'
                        '"up_host": "$upstream_http_host",'
                        '"up_resp_time": "$upstream_response_time",'
                        '"request_time": "$request_time"'
                        ' }';
    access_log  logs/access.log log_json;
    

```

输出的日志：

```json
...

{"@timestamp": "13/Jan/2023:11:37:58 +0800", "remote_addr": "192.168.87.1", "referer": "-", "request": "GET / HTTP/1.1", "status": 200, "bytes": 0, "agent": "Apache-HttpClient/4.5.13 (Java/1.8.0_351)", "x_forwarded": "-", "up_addr": "-","up_host": "-","up_resp_time": "-","request_time": "0.000" }
{"@timestamp": "13/Jan/2023:11:37:58 +0800", "remote_addr": "192.168.87.1", "referer": "-", "request": "GET / HTTP/1.1", "status": 200, "bytes": 0, "agent": "Apache-HttpClient/4.5.13 (Java/1.8.0_351)", "x_forwarded": "-", "up_addr": "-","up_host": "-","up_resp_time": "-","request_time": "0.000" }
{"@timestamp": "13/Jan/2023:11:37:58 +0800", "remote_addr": "192.168.87.1", "referer": "-", "request": "GET / HTTP/1.1", "status": 200, "bytes": 0, "agent": "Apache-HttpClient/4.5.13 (Java/1.8.0_351)", "x_forwarded": "-", "up_addr": "-","up_host": "-","up_resp_time": "-","request_time": "0.000" }
{"@timestamp": "13/Jan/2023:11:37:58 +0800", "remote_addr": "192.168.87.1", "referer": "-", "request": "GET / HTTP/1.1", "status": 200, "bytes": 0, "agent": "Apache-HttpClient/4.5.13 (Java/1.8.0_351)", "x_forwarded": "-", "up_addr": "-","up_host": "-","up_resp_time": "-","request_time": "0.000" }

```

### 20.4 错误日志errorlog

[http://nginx.org/en/docs/ngx\_core\_module.html#error\_log](http://nginx.org/en/docs/ngx_core_module.html#error_log "http://nginx.org/en/docs/ngx_core_module.html#error_log")

### 20.5日志分割

1.脚本

2.Logrotate

## \[21] 重试机制 (被动)

[http://nginx.org/en/docs/http/ngx\_http\_proxy\_module.html#proxy\_next\_upstream](http://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_next_upstream "http://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_next_upstream")

**配置：**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/13/1673623700909.png)

**配置说明：**

**max\_fails**

最大失败次数

0为标记一直可用，不检查健康状态

**fail\_timeout**

失败时间

当fail\_timeout时间内失败了max\_fails次，标记服务不可用

fail\_timeout时间后会再次激活次服务

**proxy\_next\_upstream**

**proxy\_next\_upstream\_timeout**

重试最大超时时间

**proxy\_next\_upstream\_tries**

重试次数，包括第一次

proxy\_next\_upstream\_timeout时间内允许proxy\_next\_upstream\_tries次重试

## \[22] 主动建康检查 （主动）

主动建康检查用到 `nginx_upstream_check_module`模块，这是tengine 的模块，我们想要在开源版本上使用该模块，需要`path` 才可以。

现在我们去`nginx_upstream_check_module`  github上看一下可以path哪些nginx版本:

[https://github.com/yaoweibin/nginx\_upstream\_check\_module](https://github.com/yaoweibin/nginx_upstream_check_module "https://github.com/yaoweibin/nginx_upstream_check_module")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/14/1673626452994.png)

所以我们需要下载1.20.1+的nginx开源版本

```bash
cd /root
wget http://nginx.org/download/nginx-1.20.2.tar.gz
# 将上图的文件下载下来（可以手动复制）
wget https://raw.githubusercontent.com/yaoweibin/nginx_upstream_check_module/master/check_1.20.1%2B.patch
tar -xvf nginx-1.20.2.tar.gz
yum install -y patch
cd nginx-1.20.2
# 打补丁
patch -p1 < /root/check_1.20.1+.patch
# 编译
./configure --add-module=/root/nginx_upstream_check_module-0.4.0/

cp objs/nginx /usr/local/nginx/sbin/

```

配置nginx

```纯文本
upstream backend {
  server 192.168.44.104:8080;
  server 192.168.44.105:8080;
  # 每3秒查看一次，如果成功2次表示节点正常，如果失败5次表示节点不可用
   check interval=3000 rise=2 fall=5 timeout=1000 type=http;
  check_http_send "HEAD / HTTP/1.0\r\n\r\n";
  check_http_expect_alive http_2xx http_3xx; 
}
 location /status {
  check_status;
  access_log off;
} 
location / {
  proxy_pass http://backend;
  root html;
}
```

重启nginx

访问：[http://192.168.87.201/status](http://192.168.87.201/status "http://192.168.87.201/status")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/14/1673627017025.png)

## \[23] 二次开发

### 23.1 Lua环境与基本语法

**1）安装Lua环境(windows)**：[https://github.com/rjpcomputing/luaforwindows/releases](https://github.com/rjpcomputing/luaforwindows/releases "https://github.com/rjpcomputing/luaforwindows/releases")

**2）在IDEA上安装插件：**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/14/1673689318511.png)

> **Eclipse上编写Lua**
>
> LDT 基于eclipse：[https://www.eclipse.org/ldt/](https://www.eclipse.org/ldt/ "https://www.eclipse.org/ldt/")

重启IDEA

**3）使用IDEA新建一个Lua项目**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/14/1673689471715.png)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/14/1673689500183.png)

**4）Lua基本语法**

#### hello world

```lua
print("hello world!")
```

#### 保留关键字

`and`       `break`     `do   ` `else`      `elseif`      `end`       `false`    ` for`       `function  if`      `in`        `local`     `nil`      `not`      `or`      `repeat`    `return`    `then`     ` true`      `until`    ` while`

#### 注释

```lua
-- 两个减号是行注释

--[[
 这是块注释
 这是块注释.
 --]]
```

#### 变量

**数字类型**

Lua的数字只有double型，64bits

你可以以如下的方式表示数字

```lua
num = 1024

num = 3.0

num = 3.1416

num = 314.16e-2

num = 0.31416E1

num = 0xff

num = 0x56
```

**字符串**

可以用单引号，也可以用双引号

也可以使用转义字符‘\n’ （换行）， ‘\r’ （回车）， ‘\t’ （横向制表）， ‘\v’ （纵向制表）， ‘\\\’ （反斜杠）， ‘\”‘ （双引号）， 以及 ‘\” （单引号)等等

下面的四种方式定义了完全相同的字符串（其中的两个中括号可以用于定义有换行的字符串）

```text
a = 'alo\n123"'

a = "alo\n123\""

a = '\97lo\10\04923"'

a = [[alo

123"]]
```

**空值**

C语言中的NULL在Lua中是nil，比如你访问一个没有声明过的变量，就是nil

**布尔类型**

只有nil和false是 false

数字0，‘’空字符串（’\0’）都是true

#### 作用域

lua中的变量如果没有特殊说明，全是全局变量，那怕是语句块或是函数里。

变量前加local关键字的是局部变量。

#### 控制语句

#### while循环

```lua
local i = 0;
local max = 10;
while i < max do
    print("输出"..i)
    i = i + 1
end
```

#### if-else

```lua
local function scoreLevel(score)
    if score >= 90 and score <= 100 then
        print("成绩优异！")
    elseif score >= 60 then
        print("成绩合格")
    else
        print("成绩不合格")
    end
end
-- 调用
scoreLevel(90)

```

#### for循环

```lua
for i = 10, 0 ,-1 do -- 相当于for(int i = 10; i >= 0; i--){}
    print("输出"..i)
end
```

#### 函数

1\. 普通函数

```lua
function myPower(x,y)

  return      y+x

end

power2 = myPower(2,3)

 print(power2)
```

2\. 闭包

```lua
function newCounter()

   local i = 0
   return function()     -- anonymous function

        i = i + 1

        return i

    end
end

 

c1 = newCounter()

print(c1())  --> 1

print(c1())  --> 2

print(c1())
```

#### 返回值

\-- 批量赋值

```lua
name, age,bGay = "yiming", 37, false, "yimingl@hotmail.com"
print(name,age,bGay)
```

\-- 可以返回多个值 （联系上面的批量赋值）

```lua
function isMyGirl(name)
  return name == 'xiao6' , name
end

local bol,name = isMyGirl('xiao6')

print(name,bol)
```

#### 对象（Table）

key，value的键值对 类似 map

```lua
dog = {name="旺财",age=2}
dog.age = dog.age + 1
print(dog.name..","..dog.age.."岁！")

```

#### 数组

```lua
arr = {"三国演义","红楼梦","水浒传","西游记",function() print("真好看!") return 1 end} -- 可多种类型，甚至是函数
print(arr[1]) -- 三国演义（索引从1开始）

```

#### 遍历

```lua
arr = {"三国演义","红楼梦","水浒传","西游记",function() print("真好看!") return 1 end} -- 可多种类型，甚至是函数
for k,v in pairs(arr) do
    print(k,v)
end

--[[ 输出：
lua.exe Main.lua
1  三国演义
2  红楼梦
3  水浒传
4  西游记
5  function: 00AEBAD8
]]

```

#### 成员函数&#x20;

如果上面的函数不直接定义，想在后面的代码中定义？

```lua
local function main()
    person = { name = '旺财', age = 18 }

    function person.eat(food)
        print(person.name .. " eating " .. food)
    end
    person.eat("骨头")
end
main()

```

### 23.2 Openresty Nginx + Lua  基本环境

Nginx是一个主进程配合多个工作进程的工作模式，每个进程由单个线程来处理多个连接。

在生产环境中，我们往往会把cpu内核直接绑定到工作进程上，从而提升性能。

#### 安装

**预编译安装**

以CentOS举例 其他系统参照：[http://openresty.org/cn/linux-packages.html](http://openresty.org/cn/linux-packages.html "http://openresty.org/cn/linux-packages.html")

你可以在你的 CentOS 系统中添加 openresty 仓库，这样就可以便于未来安装或更新我们的软件包（通过 yum update 命令）。运行下面的命令就可以添加我们的仓库：

```bash
yum install yum-utils
yum-config-manager --add-repo [https://openresty.org/package/centos/openresty.repo](https://openresty.org/package/centos/openresty.repo)
# 然后就可以像下面这样安装软件包，比如 openresty
yum install openresty
# 如果你想安装命令行工具 resty，那么可以像下面这样安装 openresty-resty 包：
sudo yum install openresty-resty
```

**源码编译安装**

下载: [http://openresty.org/cn/download.html](http://openresty.org/cn/download.html "http://openresty.org/cn/download.html")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/01/14/1673698508478.png)

进入：/usr/local/openresty/nginx

默认 `--prefix=/usr/local/openresty` 程序会被安装到`/usr/local/openresty`目录。

依赖 `gcc openssl-devel pcre-devel zlib-devel`

安装：`yum install gcc openssl-devel pcre-devel zlib-devel postgresql-devel`

您可以指定各种选项，比如

```bash
# 编译
./configure --prefix=/usr/local/openresty  --with-luajit --without-http_redis2_module    --with-http_iconv_module  --with-http_postgres_module
# 安装
make && make install

```

测试：(需要停止80端口)

```bash
# 启动
systemctl start openresty
# 查看已安装模块和版本号
nginx -V

```

#### 测试lua脚本

cd /usr/local/openresty/nginx/conf

vim nginx.conf

```nginx
   # 在Nginx.conf 中写入
   location /lua {

        default_type text/html;
        content_by_lua '
           ngx.say("<p>Hello, World!</p>")
         ';
      }
```

**导入式**：创建配置文件lua.conf , 再导入

```nginx
server {
    listen 80;
    server_name localhost;

    location /lua {
        default_type text/html;
        content_by_lua_file conf/lua/hello.lua;
    }
}
```

conf/lua/hello.lua

```lua
ngx.say("<p>Hello, World!</p>")
```

### 23.3 nginx+lua 操作http请求

#### 在Nginx.conf下引入lua配置

`include       lua.conf;`

#### 创建外部lua脚本

`conf/lua/hello.lua`

内容：

`ngx.say("<p>Hello, World!</p>")`

#### 获取Nginx uri中的单一变量

```nginx
location /nginx_var {

     default_type text/html;

    content_by_lua_block {

        ngx.say(ngx.var.arg_a)

    }
}
```

#### 获取Nginx uri中的所有变量

```lua
local uri_args = ngx.req.get_uri_args()  

for k, v in pairs(uri_args) do  

    if type(v) == "table" then  

        ngx.say(k, " : ", table.concat(v, ", "), "<br/>")  

    else  

        ngx.say(k, ": ", v, "<br/>")  

    end  
end
```

#### 在处理http请求时还可以使用

-   set\_by\_lua

修改nginx变量

-   rewrite\_by\_lua

修改uri

-   access\_by\_lua

访问控制

-   header\_filter\_by\_lua

修改响应头

-   boy\_filter\_by\_lua

修改响应体

-   log\_by\_lua

日志

#### 代码热部署

```bash
lua_code_cache off
```

#### 获取Nginx请求头信息

```lua
local headers = ngx.req.get_headers()                         

ngx.say("Host : ", headers["Host"], "<br/>")  

ngx.say("user-agent : ", headers["user-agent"], "<br/>")  

ngx.say("user-agent : ", headers.user_agent, "<br/>")

for k,v in pairs(headers) do  

    if type(v) == "table" then  

        ngx.say(k, " : ", table.concat(v, ","), "<br/>")  

    else  

        ngx.say(k, " : ", v, "<br/>")  

    end  

end  
```

#### 获取post请求参数

```lua
ngx.req.read_body()  

ngx.say("post args begin", "<br/>")  

local post_args = ngx.req.get_post_args()  

for k, v in pairs(post_args) do  

    if type(v) == "table" then  

        ngx.say(k, " : ", table.concat(v, ", "), "<br/>")  

    else  

        ngx.say(k, ": ", v, "<br/>")  

    end  
end
```

#### http协议版本

```lua
ngx.say("ngx.req.http_version : ", ngx.req.http_version(), "<br/>")
```

#### 请求方法

```lua
ngx.say("ngx.req.get_method : ", ngx.req.get_method(), "<br/>")  
```

#### 原始的请求头内容 &#x20;

```lua
ngx.say("ngx.req.raw_header : ",  ngx.req.raw_header(), "<br/>")  
```

#### body内容体 &#x20;

```lua
ngx.say("ngx.req.get_body_data() : ", ngx.req.get_body_data(), "<br/>")
```

### 23.4 Nginx缓存

#### Nginx全局内存缓存

```lua
lua_shared_dict shared_data 1m;

local shared_data = ngx.shared.shared_data  

  

local i = shared_data:get("i")  

if not i then  

    i = 1  

    shared_data:set("i", i)  

    ngx.say("lazy set i ", i, "<br/>")  
end  
 

i = shared_data:incr("i", 1)  

ngx.say("i=", i, "<br/>")
```

#### lua-resty-lrucache

Lua 实现的一个简单的 LRU 缓存，适合在 Lua 空间里直接缓存较为复杂的 Lua 数据结构：它相比 ngx\_lua 共享内存字典可以省去较昂贵的序列化操作，相比 memcached 这样的外部服务又能省去较昂贵的 socket 操作

[https://github.com/openresty/lua-resty-lrucache](https://github.com/openresty/lua-resty-lrucache "https://github.com/openresty/lua-resty-lrucache")

引用lua文件

```bash
content_by_lua_block {
  require("my/cache").go()
}
```

自定义函数

```bash
local _M = {}


lrucache = require "resty.lrucache"

c, err = lrucache.new(200)  -- allow up to 200 items in the cache
ngx.say("count=init")


if not c then
    error("failed to create the cache: " .. (err or "unknown"))
end

function _M.go()

count = c:get("count")


c:set("count",100)
ngx.say("count=", count, " --<br/>")


if not count then  


    c:set("count",1)

    ngx.say("lazy set count ", c:get("count"), "<br/>")  

else


c:set("count",count+1)
 


ngx.say("count=", count, "<br/>")
end


end
return _M


```

打开lua\_code\_cache

### 23.5 lua-resty-redis访问redis

[https://github.com/openresty/lua-resty-redis](https://github.com/openresty/lua-resty-redis "https://github.com/openresty/lua-resty-redis")

#### 常用方法

```lua
local res, err = red:get("key")

local res, err = red:lrange("nokey", 0, 1)

ngx.say("res:",cjson.encode(res))
```

#### 创建连接

```lua
red, err = redis:new()

ok, err = red:connect(host, port, options_table?)
```

#### timeout

```lua
red:set_timeout(time)
```

#### keepalive

```lua
red:set_keepalive(max_idle_timeout, pool_size)
```

#### close

```bash
ok, err = red:close()
```

#### pipeline

```nginx
red:init_pipeline()

results, err = red:commit_pipeline()
```

#### 认证

```nginx
local res, err = red:auth("foobared")

if not res then

    ngx.say("failed to authenticate: ", err)

    return
end
```

```bash
local redis = require "resty.redis"
              local red = redis:new()

              red:set_timeouts(1000, 1000, 1000) -- 1 sec

local ok, err = red:connect("127.0.0.1", 6379)
if not ok then
                  ngx.say("failed to connect: ", err)
                  return
              end

              ok, err = red:set("dog", "an animal")
              if not ok then
                  ngx.say("failed to set dog: ", err)
                  return
              end

              ngx.say("set result: ", ok)

              local res, err = red:get("dog")
              if not res then
                  ngx.say("failed to get dog: ", err)
                  return
              end

              if res == ngx.null then
                  ngx.say("dog not found.")
                  return
              end


            ngx.say("dog: ", res)
```

#### redis-cluster支持

[https://github.com/steve0511/resty-redis-cluster](https://github.com/steve0511/resty-redis-cluster "https://github.com/steve0511/resty-redis-cluster")

### 23.6 redis2-nginx-module&#x20;

redis2-nginx-module是一个支持 Redis 2.0 协议的 Nginx upstream 模块，它可以让 Nginx 以非阻塞方式直接防问远方的 Redis 服务，同时支持 TCP 协议和 Unix Domain Socket 模式，并且可以启用强大的 Redis 连接池功能。

#### test

```nginx
location = /foo {

default_type text/html;

     redis2_query auth 123123;

     set $value 'first';

     redis2_query set one $value;

     redis2_pass 192.168.199.161:6379;

 }
```

#### get

```nginx
location = /get {

default_type text/html;

     redis2_pass 192.168.199.161:6379;

     redis2_query auth 123123;

     set_unescape_uri $key $arg_key;  # this requires ngx_set_misc

     redis2_query get $key;

}
```

#### set

```nginx
# GET /set?key=one&val=first%20value

location = /set {

default_type text/html;

redis2_pass 192.168.199.161:6379;

redis2_query auth 123123;
 

     set_unescape_uri $key $arg_key;  # this requires ngx_set_misc

     set_unescape_uri $val $arg_val;  # this requires ngx_set_misc

     redis2_query set $key $val;

 }
```

#### pipeline

```nginx
set $value 'first';

redis2_query set one $value;

redis2_query get one;

redis2_query set one two;

redis2_query get one;

redis2_query del key1;
```

#### list

```lua
redis2_query lpush key1 C;

redis2_query lpush key1 B;

redis2_query lpush key1 A;

redis2_query lrange key1 0 -1;
```

#### 集群

```nginx
upstream redis_cluster {

     server 192.168.199.161:6379;

     server 192.168.199.161:6379;

 }

location = /redis {

default_type text/html;

         redis2_next_upstream error timeout invalid_response;

         redis2_query get foo;

         redis2_pass redis_cluster;
   }
```

### 23.7 lua-resty-mysql

[https://github.com/openresty/lua-resty-mysql](https://github.com/openresty/lua-resty-mysql "https://github.com/openresty/lua-resty-mysql")

```bash
local mysql = require "resty.mysql"
                local db, err = mysql:new()
                if not db then
                    ngx.say("failed to instantiate mysql: ", err)
                    return
                end

                db:set_timeout(1000) -- 1 sec


                local ok, err, errcode, sqlstate = db:connect{
                    host = "192.168.44.211",
                    port = 3306,
                    database = "zhangmen",
                    user = "root",
                    password = "111111",
                    charset = "utf8",
                    max_packet_size = 1024 * 1024,
                }


                ngx.say("connected to mysql.<br>")



                local res, err, errcode, sqlstate = db:query("drop table if exists cats")
                if not res then
                    ngx.say("bad result: ", err, ": ", errcode, ": ", sqlstate, ".")
                    return
                end


                res, err, errcode, sqlstate =
                    db:query("create table cats "
                             .. "(id serial primary key, "
                             .. "name varchar(5))")
                if not res then
                    ngx.say("bad result: ", err, ": ", errcode, ": ", sqlstate, ".")
                    return
                end

                ngx.say("table cats created.")



                res, err, errcode, sqlstate =
                    db:query("select * from t_emp")
                if not res then
                    ngx.say("bad result: ", err, ": ", errcode, ": ", sqlstate, ".")
                    return
                end

                local cjson = require "cjson"
                ngx.say("result: ", cjson.encode(res))


                local ok, err = db:set_keepalive(10000, 100)
                if not ok then
                    ngx.say("failed to set keepalive: ", err)
                    return
                end
 

```

## \[24] 二次开发： 模板实时渲染 lua-resty-template

[https://github.com/bungle/lua-resty-template](https://github.com/bungle/lua-resty-template "https://github.com/bungle/lua-resty-template")

如果学习过JavaEE中的servlet和JSP的话，应该知道JSP模板最终会被翻译成Servlet来执行；

而lua-resty-template模板引擎可以认为是JSP，其最终会被翻译成Lua代码，然后通过ngx.print输出。  &#x20;

lua-resty-template大体内容有：&#x20;

l   模板位置：从哪里查找模板；&#x20;

l   变量输出/转义：变量值输出；&#x20;

l   代码片段：执行代码片段，完成如if/else、for等复杂逻辑，调用对象函数/方法；&#x20;

l   注释：解释代码片段含义；&#x20;

l   include：包含另一个模板片段；&#x20;

l   其他：lua-resty-template还提供了不需要解析片段、简单布局、可复用的代码块、宏指令等支持。

基础语法

l   {(include\_file)}：包含另一个模板文件；

l   {\* var \*}：变量输出；

l   {{ var }}：变量转义输出；

l   {% code %}：代码片段；

l   {# comment #}：注释；

l   {-raw-}：中间的内容不会解析，作为纯文本输出；

### lua代码热加载

在http模块中加入

```bash
lua_code_cache off;
```

reload后Nginx会提示影响性能，记得在生产环境中关掉。

### 测试

### 一、初始化

```bash
-- Using template.new
local template = require "resty.template"
local view = template.new "view.html"
view.message = "Hello, World!"
view:render()

-- Using template.render
-- template.render("view.html", { message = "Hel11lo, Worl1d!" })


```

### 二、执行函数，得到渲染之后的内容

```bash
local func = template.compile("view.html")  

local content = func(context)  

ngx.say("xx:",content) 
```

#### 模板文件存放位置

#### nginx.conf中配置

```bash
set $template_root /usr/local/openresty/nginx/tmp;
```

### resty.template.html

```lua
local template = require("resty.template")
local html = require "resty.template.html"

template.render([[
<ul>
{% for _, person in ipairs(context) do %}
    {*html.li(person.name)*} --
{% end %}
</ul>
<table>
{% for _, person in ipairs(context) do %}
    <tr data-sort="{{(person.name or ""):lower()}}">
        {*html.td{ id = person.id }(person.name)*}
    </tr>
{% end %}
</table>]], {
    { id = 1, name = "Emma"},
    { id = 2, name = "James" },
    { id = 3, name = "Nicholas" },
    { id = 4 }
})

```

### 模板内容

```html
<!DOCTYPE html>
<html>
<body>
  <h1>{{message}}</h1>
</body>
</html>

```

### 多值传入

```lua
template.caching(false)
local template = require("resty.template")
local context = {
    name = "lucy",
    age = 50,
}
template.render("view.html", context)

```

### 模板内容

```lua
<!DOCTYPE html>
<html>
<body>
  <h1>name:{{name}}</h1>
  <h1>age:{{age}}</h1>
</body>
</html>

```

### 模板管理与缓存

模板缓存：默认开启，开发环境可以手动关闭

`template.caching(true)`

模板文件需要业务系统更新与维护，当模板文件更新后，可以通过模板版本号或消息通知Openresty清空缓存重载模板到内存中

`template.cache = {}`

### 完整页面

```lua
local template = require("resty.template")
template.caching(false)
local context = {
    title = "测试",
    name = "lucy",
    description = "<script>alert(1);</script>",
    age = 40,
    hobby = {"电影", "音乐", "阅读"},
    score = {语文 = 90, 数学 = 80, 英语 = 70},
    score2 = {
        {name = "语文", score = 90},
        {name = "数学", score = 80},
        {name = "英语", score = 70},
    }
}

template.render("view.html", context)

```

### 模板

```html
{(header.html)}  
   <body>  
      {# 不转义变量输出 #}  
      姓名：{* string.upper(name) *}<br/>  
      {# 转义变量输出 #}  
      简介：{{description}}
           简介：{* description *}<br/>  
      {# 可以做一些运算 #}  
      年龄: {* age + 10 *}<br/>  
      {# 循环输出 #}  
      爱好：  
      {% for i, v in ipairs(hobby) do %}  
         {% if v == '电影' then  %} - xxoo
            
              {%else%}  - {* v *} 
{% end %}  
         
      {% end %}<br/>  
  
      成绩：  
      {% local i = 1; %}  
      {% for k, v in pairs(score) do %}  
         {% if i > 1 then %}，{% end %}  
         {* k *} = {* v *}  
         {% i = i + 1 %}  
      {% end %}<br/>  
      成绩2：  
      {% for i = 1, #score2 do local t = score2[i] %}  
         {% if i > 1 then %}，{% end %}  
          {* t.name *} = {* t.score *}  
      {% end %}<br/>  
      {# 中间内容不解析 #}  
      {-raw-}{(file)}{-raw-}  
{(footer.html)}  

```

### layout 布局统一风格

使用模板内容嵌套可以实现全站风格同一布局

#### lua

`local template = require "resty.template"`

一、

```bash
local layout   = template.new "layout.html"

layout.title   = "Testing lua-resty-template"

layout.view    = template.compile "view.html" { message = "Hello, World!" }

layout:render()
```

二、

```bash
template.render("layout.html", {

  title = "Testing lua-resty-template",

  msg = "type=2",

  view  = template.compile "view.html" { message = "Hello, World!" }

})
```

三、

此方式重名变量值会被覆盖

```bash
local view     = template.new("view.html", "layout.html")

view.title     = "Testing lua-resty-template"

view.msg = "type=3"

view.message   = "Hello, World!"

view:render()
```

四、

可以区分一下

```bash
local layout   = template.new "layout.html"

layout.title   = "Testing lua-resty-template"

layout.msg = "type=4"

local view     = template.new("view.html", layout)

view.message   = "Hello, World!"

view:render()
```

#### layout.html

```bash
<!DOCTYPE html>

<html>

<head>

    <title>{{title}}</title>

</head>

<h1>layout</h1>

<body>

    {*view*}

</body>

</html>
```

#### view\.html·

`msg:{{message}}`

#### 多级嵌套

lua

```bash
local view     = template.new("view.html", "layout.html")

view.title     = "Testing lua-resty-template"

view.message   = "Hello, World!"

view:render()

view.html

{% layout="section.html" %}
```
