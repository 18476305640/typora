# HTTP 测试

首先vscode上安装插件“Rest Client ”， 在项目中新建 XXX.http 

以这种方式，更加直接，很多开发工具也是有插件支持的。

![2022-10-16](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/16/1665924443470.png "2022-10-16")
