# nodeJs

> 概述 :  擅长处理高并发，当有用户连接，就触发一个内部事件，通过非阻塞I/O、事件驱动机制，让Node.js程序宏观上也是并行的，使用Node.js，可以让并发量提高10倍左右。且基于js语法。其它后端语言能做的，它也能做。

> 环境搭建

下载：[http://nodejs.cn/download/](http://nodejs.cn/download/ "http://nodejs.cn/download/")     验证( cmd )： node -v

开发工具： VSCode：[https://code.visualstudio.com/](https://code.visualstudio.com/ "https://code.visualstudio.com/")   汉化：安装chinese插件

> 第一个web 程序 : 首先需要http，然后用http创建一个web程序入口，当然需要调用listen设置运行端口，createServer里面是一个函数，这就是web程序的入口，接收两个参数，request与response，刚进来我们需要做两件最基本的事件，第一在头部解决中文乱码，在函数尾部结束请求。不懂？？也就是头部两句都是解决中文乱码的，而尾部就单纯结束请求。

```javascript
const http = require('http'); //获取http
http.createServer(function(request,response)  //利用http创建一个server
{ response.writeHead(200,{"Content-type": "text/html;charset='utf-8'"}); response.write("<head><meta charset='UTF-8' /></head>");  //两句都是解决中文乱码

    console.log(request.url);
    response.write("你好");


response.end() }).listen(3003);  console.log("server url: http://127.0.0.1:3003")
//结束请求与设置server 端口
```

> 获取url上的参数： 需要引入一个url模块，然后调用url上的parse方法解析url, 再获取query即可。 不懂？？也就是需要模块中的一个解决方法，解析完后获取参数部分的数据即query

你可能不懂：

环境塔建

web服务如何创建

```javascript
const http = require('http');
const url = require('url'); //1、引入模块
http.createServer(function(request,response)
{ response.writeHead(200,{"Content-type": "text/html;charset='utf-8'"}); response.write("<head><meta charset='UTF-8' /></head>"); 

    let parans = url.parse(request.url,true).query;  //2、解析成query数据
    console.log(`${parans.username}--${parans.password}`); //3、获取具体数据体


 response.end() }).listen(3003);  console.log("server url: http://127.0.0.1:3003")
```

> supervisor 热部署： 因为我们更改程序后，需要重启才会生效，加了它，安装supervisor后，保存后，它会自动重启，省去了我们手动重启的麻烦，不懂？？也就是我们保存它就生效

以下步骤：安装 -> 用supervisor代替node命令启动程序 -> 测试效果

`安装supervisor`

npm install -g supervisor    重启VSCode

`用supervisor启动程序`

supervisor app.js

ps:   如果在VSCode上提示 系统禁止使用该命令，是因为没有权限，你可能需要设置VSCode.exe 右击属性，勾选选择以管理启动，打开”蓝窗口的powerShell“ 执行set-ExecutionPolicy RemoteSigned ，选择A

`测试`

改变程序，保存，查看终端改变

> CommonJs ： 是模块化标准，CommonJs规范的提出，主要是为也卡弥补当前JavaScript没有标准库的缺陷，它的终极目录就是：提供一个类似Python ,java 语言的标准库，而不是让JavaScript停留在小脚本程序阶段。nodejs就是CommonJs的实现，不懂？？CommonJs就是一个模块化标准。nodeJs是CommonJs的实现

> Node.js是怎么实现模块化的？ Node.js有两种模块，核心模块（系统模块）与文件模块（用户编写），而模块化的实现就是创建模块让模块存在，然后require导入使用的过程。

以下步骤：创建模块文件（位置说明）->  书写模块 (export的说明)-> 导入使用模块（require的说明）-> 使用模块

`创建文件`

创建一个与我们启动文件同级的固定名称文件件”node\_modules“ ，再在node\_modules-> 模块名 -> index.js

，不懂？？这样创建就是为了导入模块方便。

如果模块名目录下不想写index.js的话，如果不影响下面的导入使用，我们必须使用配置文件来指定，配置文件package.json 生成：进入模块名目录下，执行`npm init --yes`即可！ 配置文件main属性会指定入口, 不懂？？也就是配置导入 模块名下的index.js 如果没有index.js 了，我们要指引吧，那就是用配置文件package.json文件了。

```json
{
  "name": "axios",
  "version": "1.0.0",
  "description": "",
  "main": "axios.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "keywords": [],
  "author": "",
  "license": "ISC"
}

```

`书写模块`

书写文件，主要是说明怎么导出，有两种exports 与module.exports ,区别是比如 有一个箱子里面有若干物品，exports是导出物品，而module.exports是直接导出箱子，而关系是exports导出的所有物品 == module。exports导出箱子。不懂？？也就是exports导出到一个箱子里，而module.exports就是这个箱子。

exports导出：

```javascript
function get() {
    console.log("get请求~");
}
function post() {
    console.log("port请求~");
}
exports.get = get;
exports.post = post;
```

module.exports导出：

```javascript
var axios = {
    get() {
        console.log("get请求~");
    },
    post() {
        console.log("post请求~");
    }
}
module.exports = axios;
```

最终结束是一样的，如下：

...

{ get: \[Function: get], post: \[Function: post] }

...

`导入`

如果按上面的

创建规则

，创建模块文件，我们引入时，在启动文件引入中只需，`const axion = require('axiox')`即可。不懂？？ 也就是直接写模块名。

`使用`

因为导出的是一个包含若干函数的对象，所以我们直接调用里面的函数即可。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/img/image-20210423182847672.png)

​

> NodeJs使用第三方包: 我们写的模块包与第三模块包都是文件模块，要使用第三方即别人的包，我们要通过npm包管理工具，npm包管理工具在我们安装node的时候就已经安装好了，即node安装包携带有npm包管理工具。不懂？？就是第三方包与我们写的包一样，只不过这不是你写的或说在npm上管理的包，要使用要通过npm包管理工具。

以下步骤：在工具根路径，加一个package.json ，即使用`npm init --yes`它存储着项目的信息，比如入口信息，依赖信息等，同时没有它是不能安装/卸载第三方包的，因为安装完第三方包，要写入项目的依赖信息。 -->

使用命令安装第三方包， 即使用`npm install XXX --save` 加--save的原因是会在配置文件package.json 中加依赖信息。分为两种开发时（devDependencies）依赖与生产时依赖（dependencies）。且 依赖信息前面有修饰符，如\*版本不锁定，即安装最新版本 ，^代表版本第一位锁定， \~代表前两位锁定。但现在不加--save也默认加入配置信息，但介意还是加上 ，安装完后，就像我们之前写好模块一样，使用方法与以前一样，进行·`require('XXX')`-->

如果我们要将项目发给别人，我们不用发node\_modules，因为package.json 就存储着依赖信息，我们只需在根目录执行 `npm install`  即可将npm 里面的依赖进行安装回来。-->

卸载：`npm uninstall xxx` package.json上对应的依赖配置会被删除，且node\_modules会对应删除。

`加入配置`

在根目录下创建一个入口文件，然后 npm init --yes

`安装依赖`

在根目录下 npm install XXX --save

更多第三模块：[https://www.npmjs.com/，使用方式看里面的文档。](https://www.npmjs.com/，使用方式看里面的文档。 "https://www.npmjs.com/，使用方式看里面的文档。")

`使用`

var xxx = request('xxx');

...

`发送`

删除node\_modules，再 npm install

`卸载`

在根目录下 npm uninstall xxx

`备注`

md5加密

silly-datetime 时间格式化工具，我们知道js原生没有时间格式化，安装这个模块可以使用。

你可能需要知道：&#x20;

怎么进行node模块化开发

> 系统模块： 我们知道模块有两种，系统模块与文件模块，上面已经说了文件模块，那么接下我们一起学习一下系统模块。

以下步骤：我们会逐一学习系统模块，因为系统模块是非常重要的。

> fs 系统模块:  因为是甜丝丝主模块，所以我们直接引入使用即可，且fs系统㮜就是对文件与文件夹的CURD 操作，总结过来，常用就除回调函数最多就两个参数，与回调函数最多二个参数（err,data）。不懂？？也就 是fs是对文件与文件夹的操作，使用方式比较相近。

以下步骤：对fs 模块的方法进行逐一讲解

```javascript
var fs = require('fs');
//1、文件还是文件夹的判断，因为判断成功后，我们还需要知道它是文件还是文件夹，所以回调函数需要加第二个参数
fs.stat('./js/test.js',(err,ai) => {
    if(! err) {
        console.log(ai.isFile()+"是文件");
        console.log(ai.isDirectory()+"是文件夹");
    }
})
//2、创建文件夹
fs.mkdir('./css',err => {
    if(! err) {
        console.log("文件夹创建成功");
    }else {
        console.log("文件夹创建失败");
    }

});
//3、将内容写入文件，不存在可创建文件，但不能创建路径下不存在的文件夹
fs.writeFile('./js/nav.js','你好',err => {  //只能创建文件，存在会进行覆盖
    if(! err) {
        console.log("文件创建成功");
    }else {
        console.log("文件创建失败");
    }
})
//4、与writeFile相似，只不过这是追加内容
fs.appendFile('./css/base.css','p {color:#ffffff;}',err => {  //可将内容追加指定文件，不存在可创建
    if(! err) {
        console.log("文件追加成功");
    }else {
        console.log("文件追加失败");
    }
})
//5、读取文件，读取文件，肯定返回数据，所以回调需要加了第二参数接收
fs.readFile('./css/base.css',(err,content) => {
    if(! err) {
        console.log(data.toString());
    }else {
        console.log("读取失败");
    }
})
//6、读取文件夹下的文件或文件夹，返回的是一个数且
fs.readdir('./css',(err,data) => {  //读取成功会返回一个数组
    if(! err) {
        console.log(data);
    }else {
        console.log("文件夹读取失败");
    }
})
//7、对文件或文件夹进行重命名 ，可改变重命名文件存储路径
fs.rename('./css/base.css','./js/common.js', err => {
    if(! err) {
        console.log("位置与形态改变成功");
    }else {
        console.log("文件位置与形态改变失败");
    }
})
//8、删除空文件夹
fs.rmdir('./css', err => { //必须是空文件夹
    if(! err) {
        console.log("删除文件夹成功！");
    }else {
        console.log("删除文件夹失败");
    }
});
//9、删除文件
fs.unlink('./js/common.js', err => {
    if(! err) {
        console.log("删除文件成功");
    }else {
        console.log("删除文件失败");
    }
})
```

> fs的使用： 多级目录的创建, fs.mkdir无法创建多级目录，所以才有了以下的方法，以下问题是：
> 1）如何知道有几级目录，不然我们不能进行一级一级的创建，即想要创建后面的目录，必要要创建前面的目录路径，下面我们用的是split字符串进行切割，成数组。再自外向内进行创建。
> 2）如果我们在创建目录的时候存在同名的文件，这时使用mkdir是无法创建的，我们必要使用unlink将文件删除，才能进行创建。

```javascript
function mkdirs(path,fun) {
  var arr = path.split('/').reverse();
  var path = '.';
  switch(true) {
    case (arr[arr.length-1] && arr[arr.length-1] =='.'):
        arr.pop();
        break;
    case (!arr[arr.length-1]):
        fun(true,null);
        return;
  }
  //将所有目录封装成数组并反序
  (function xy() {
    var item = arr.pop();
    if(item) {
        //有弹出，准备创建
        path += "/"+item;
        fs.stat(path, (err,data) => {
            if(err || data.isFile()) {
                var isFile = true;
                fs.unlink(path, err_y => {
                    isFile =false;
                })
                var cIn = setInterval(() => {
                    if(! isFile) {
                        fs.mkdir(path, err_x => {
                            if(! err_x) {
                                xy();
                            }
                            clearInterval(cIn);
                        });
                    }
                },50)
            }else { xy() }
        });
    }else {
        //无弹出，创建已完成
        fun(false);
        return;
    }
  })();

}
```

> let/const与var区别： let与const都有块级作用域,而var 没有，不懂块级作用域是什么？？有块级作用域与无块级作用块区别是，比如for与if中，你在里面声明一个变量，for或if外部是可以访问的，这就没块级作用域。

> ES6的模版字符串， `${namex}是大聪明，${namey}是大傻逼` ,\`\`里面的\${XXX}会被解析。
> ES6属性与方法的简写：比如在对象{} 中，我们可以直接在里面写name 属性与属性值相同的属性名'name': name与写xxx() {} 的方法。即两者可直接写在对象里面{}这就是ES6对对象内属性与对象的简写。
> ES6的Promise：

```javascript
//ES6：Promise
function run(resolve,reject) {
    let is = true;
    if(is) {
        resolve('success');
    }else {
        reject('fail');
    }
}
let o = new Promise(run);
o.then(msg => {
    console.log(msg);
})
o.catch( msg => {
    console.log(msg);
})
```

> async 与await :async会声明一个函数是异步函数，await会等待右边调用函数返回的Promise 且通过接收await，得到的是resolve或reject里面的参数值。

```javascript
var a =false;
(async function() {
    a = await (function() {
        return new Promise((resolve,reject) => {
            setTimeout(() => {
                resolve(true);
            },1000)
        })
        
    })();
    console.log(a);
})();
```

> Promise:  then会等待Promise回调参数执行完再执行。且可得到resolve或reject 返回的结果。

```javascript
function mkdirs(path,fun) {
    var arr = path.split('/').reverse();
    var path = '.';
    switch(true) {
      case (arr[arr.length-1] && arr[arr.length-1] =='.'):
          arr.pop();
          break;
      case (!arr[arr.length-1]):
          fun(true,null);
          return;
    }
    //将所有目录封装成数组并反序
    (function xy() {
      var item = arr.pop();
      if(item) {
          //有弹出，准备创建
          path += "/"+item;
          fs.stat(path, (err,data) => {
            if(err || data.isFile()) {
                //当不存在时，或是一个文件时
                new Promise((resolve,reject) => {
                  fs.unlink(path, err_y => {
                      resolve(err_y);
                  })
                }).then(pack => {
                  //确保删除文件后
                  fs.mkdir(path, err_x => {
                      if(! err_x) {
                          xy();
                      }
                  });
                })
            }else { xy() /* 已经存在时*/} 
          });
      }else {
          //无弹出，创建已完成
          fun(false);
          return;
      }
    })();
  
  }
```

> fs 以流的方式读取： 也就是fs创建完文件读取流后，就可以进行监听了。可以监听data、读取结束end，读取出错error事件。
> fs 以流的方式写入：也就是fs创建一个流的写对象，然后进行写操作，但在监听写操作完成时，需要打个标记，即writeStream.end() 再进行监听'firish' 写入完成。
> fs管道流： 通过fs读取流的管通道用于文件的复制操作

以下步骤：使用fs流进行流的读操作与写操作 -> rs读取流的管道进行文件复制 -> 文件读取

`流读取`

```javascript
var fs = require('fs');
var stream = fs.createReadStream('./package.json');
var backage = '';
stream.on('data', data => { 
    backage += data;
});
stream.on('end', () => {
    console.log("读取完成，package: ");
    console.log(backage);
});
stream.on('error', err => {
    console.log(err);
}); 
```

```纯文本
`流写入`
```

```javascript
  var b ='520';
  var write = fs.createWriteStream('./write.txt');
    write.write(b);
    //标记写入完成
    write.end();
    write.on('finish', () => {
        console.log('写入完成！');
    })
```

`管道流复制文件`

```javascript
var fs = require('fs');
var readStream = fs.createReadStream('C:/jdk-8u281-linux-x64.tar.gz');
var writeStream = fs.createWriteStream('D:/jdk-8u281-linux-x64.tar.gz');
//管道
readStream.pipe(writeStream);
```

`文件读取`

相比与流读取，文件读取是读取文本文件，且一次读取。使用的都是fs里面的方法。

**同步方法**

```javascript
var data = fs.readFileSync('./app.js');
console.log(data.toString());
```

异步方法

```javascript
fs.readFile('./node_modules/mime/mime.json', (err, data) => {
     if(! err) {
         console.log("读取成功");
     }else {
         console.log("读取失败");
     }
            
})
```

### 简单的web服务器

简述： 想在node构建一个web服务器，首先需要文件格式文件`mime.json` 用于查询文件对应的响应头上下文类型。响应头设置好后，我们需要将传过来的uri进行分析，利用readFile或readFileSync 读取文本内容，并返回到前端。

以下步骤：安装url解码器，作用是还原中文 -> 创建一个`mime`模块获取文件对应的响应类型 -> 获取app.js利用这两个上模块创建一个静态web服务器

开始：

`解码器`

安装 `npm install urlencode` url解码器。

`mime模块`

创建一个`mime`模块 ，调用里面的方法用于获取并设置响应头，或使用命令安装些模块（别人的），但里面的方法就不一样了，且下面的方法需要修改，因为使用了。`async  await return new Promise(...)`

创建mime模块，index.js内容为：

```javascript
const fs = require('fs');
exports.mime =function (y) {
    
    return new Promise((resolve, reject) => {
        fs.readFile('./node_modules/mime/mime.json', (err, data) => {
            if(! err) {
                
                var x =JSON.parse(data.toString());
                resolve(x[y]);
            }else {
                reject('');
            }
            
        })
    })
}
```

附加mime.json ：获取.json的内容 ->   [https://blog.csdn.net/qq\_33174548/article/details/104254575](https://blog.csdn.net/qq_33174548/article/details/104254575 "https://blog.csdn.net/qq_33174548/article/details/104254575")

`app.js 创建静态web服务`

app.js 使用和模块构建一个web服务器:

```java
const http = require('http');
const url = require('url');
const fs = require('fs');
const mime = require('mime');
const urlencode = require('urlencode');
http.createServer(function(request,response)
{ 
    var path = url.parse(request.url).pathname=="/"?"/index.html": urlencode.decode(url.parse(request.url).pathname, 'utf-8'); //w3cnote/es6-promise.html
    var path_arr = path.split('.'); //后缀名：path_arr[path_arr.length-1]
    fs.readFile('./state/'+path,async (err,data) => {
        if(! err) {
            var xm = await mime.mime('.'+path_arr[path_arr.length-1]);
            response.writeHead(200,{"Content-type": xm+";charset='utf-8'"});
            response.end(data);
        }else {
            response.writeHead(404,{"Content-type":"text/html;charset='utf-8'"});
            response.end('404页面不存在') 
        }
    });
 }).listen(3003);  console.log("server url: http://127.0.0.1:3003")
```

使用方法：  [http://127.0.0.1:3003](http://127.0.0.1:3003 "http://127.0.0.1:3003")  访问app同级目录下的state目录下的.html  .css 等静态文件。如：[http://127.0.0.1:3003/index.html](http://127.0.0.1:3003/index.html "http://127.0.0.1:3003/index.html")

默认就是访问`state`目录下的文件。

你可能不懂&#x20;

如何初始化

> 封装静态web：在node\_modules创建一个router模块用来封装,模块接收服务器的request与response，静态文件夹名根路径，负责读取静态文件并返回到页面。

以下步骤： 封装成router模块- ->  使用模块实现静态web功能

开始：

`封装router模块`

封装成router模块，你可能需要知道怎么

创建一个模块

、

创建静态web模块

、创建一个node\_modules > router -> index.js后，打开index.js, 模块文件内容如下：

```javascript
const url = require('url');
const fs = require('fs');
const mime = require('mime');
const urlencode = require('urlencode');
exports.static = function(request,response,staticPath) {

    var path = url.parse(request.url).pathname=="/"?"/index.html": urlencode.decode(url.parse(request.url).pathname, 'utf-8'); //w3cnote/es6-promise.html
    var path_arr = path.split('.'); //后缀名：path_arr[path_arr.length-1]
    fs.readFile('./'+staticPath+'/'+path,async (err,data) => {
        console.log('读取文件',err);
        
        if(! err) {
            var xm = await mime.mime('.'+path_arr[path_arr.length-1]);
            response.writeHead(200,{"Content-type": xm+";charset='utf-8'"});
            response.end(data);
        }else {
            response.writeHead(404,{"Content-type":"text/html;charset='utf-8'"});
            response.end('404页面不存在')
        }
    });
}
```

`app.js 使用静态web模块`

```javascript
const http = require('http');
const router = require('router');
http.createServer(function(request,response)
{ 
    router.static(request,response,'state');
 }).listen(3003);  console.log("server url: http://127.0.0.1:3003")
```

> EJS 模版引擎： 通过EJS进行后端页面的渲染, ejs的使用最简单就是逻辑与替换，即<%%>与<%=XXX%>  ,具体使用请参考[https://www.npmjs.com/package/ejs](https://www.npmjs.com/package/ejs "https://www.npmjs.com/package/ejs")   .ejs文件通过ejs模板引擎解析后形成模板+数据的结合体，最终 返回客户端显示

以下步骤：安装ejs -> 在app.js使用ejs解析使用对应ejs模版 ->  在ejs布局数据

`安装ejs`

npm install  ejs --save

` 在app.js使用ejs解析使用对应ejs模版`

```javascript
...
ejs.renderFile('./views/login.ejs',{ msg: [ //向左边的ejs传递数据
                {title: '新闻1',content: 'content'},
                {title: '新闻2',content: 'content'},
                {title: '新闻3',content: 'content'}
]}, (err,data) => { //将ejs解析后页面（模板+数据）返回显示
       response.writeHead(200, { "Content-type": "text/html;charset='utf-8'" });
       response.end(data);
});
...
```

`在ejs布局数据`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>今日新闻</h2>
    <ul>
        <% for(var i=0; i< msg.length; i++) { %>
            <li><%=msg[i].title%> : <%= msg[i].content%></li>
        <%}%>
    </ul>
</body>
</html>
```

> GET与POST: 下面是对GET与POST的小说明

以下步骤：获取请求方式与获取GET与POST中的参数

```javascript
//1、获取请求方式
let method = request.method;            
// let postData = '';
//2、参数POST参数
// request.on('data', chunk => {
//     postData += chunk;
// })
// request.on('end', () => {
//     console.log('post数据：', postData);
// })
//3、参数GET参数
var query = url.parse(request.url,true).query;
console.log('get',query.user,query.pass);
response.end(method);
```

> 封装路由： 路由就是经过web过滤后，依然无法处理该请求时，那么上面封装web服务器会返回一个布尔值，如果为false 时就会尝试路由处理，在封装前路由处理是获取`url.parse(request.url).pathname`
> 即无参数（query）,比如 ’/login‘ 等。获取进行字符相等判断执行对应代码块返回对应信息到前端，比如可以返回ejs+数据解析后的`data` 。
> 而封装路由是在router中加入并导出`exports.xxx` 路由映射对象。当web服务器返回false时，利用`try catch` 来完成路由功能。

以下步骤： 路由封装前 -> 路由封装后

开始：

`路由封装前`

```javascript
const http = require('http');
const router = require('router');
const url = require('url');
const ejs = require('ejs');
http.createServer(function (request, response) {
    //1、尝试读取资源
    var rstatic = router.static(request, response, 'state');
    //2、无对应资源时，尝试路由
    if (!rstatic) {
        let path = url.parse(request.url).pathname;
        if (path == '/login') {
            ejs.renderFile('./views/login.ejs', {}, (err, data) => {
                response.writeHead(200, { "Content-type": "text/html;charset='utf-8'" });
                response.end(data);
            });

        } else if (path == '/logon') {
            response.writeHead(200, { "Content-type": "text/html;charset='utf-8'" });
            response.end("注册页面");
        } else if (path == '/dologin') {

            response.writeHead(200, { "Content-type": "text/html;charset='utf-8'" });
            var query = url.parse(request.url,true).query;
            console.log('get',query.user,query.pass);
            response.end(method);
        } else {
            response.writeHead(404, { "Content-type": "text/html;charset='utf-8'" });
            response.end('404页面不存在')
        }
    }

}).listen(3005); console.log("server url: http://127.0.0.1:3005")
```

`路由封装后`

在router模块中，即静态web模块中加入并导出(追加) mapper 路由映射对象。

router  模块

```javascript
const url = require('url');
const fs = require('fs');
const mime = require('mime');
const urlencode = require('urlencode');
const ejs = require('ejs');
exports.static = function(request,response,staticPath) {
    
    let path = url.parse(request.url).pathname=="/"?"/index.html": urlencode.decode(url.parse(request.url).pathname, 'utf-8'); //w3cnote/es6-promise.html
    let path_arr = path.split('.'); //后缀名：path_arr[path_arr.length-1]
    try {
        let data = fs.readFileSync('./'+staticPath+'/'+path);
        if(data) {
            let xm = mime.mime('.'+path_arr[path_arr.length-1]);
            response.writeHead(200,{"Content-type": xm+";charset='utf-8'"});
            response.end(data);
            return true;
        }else {
            return false;
        }
    }catch(error) {
    }
    
}
//路由
exports.mapper = {
    login(request,response){
        ejs.renderFile('./views/login.ejs', {}, (err, data) => {
            response.writeHead(200, { "Content-type": "text/html;charset='utf-8'" });
            response.end(data);
        });
    },
    dologin(request,response){
        response.writeHead(200, { "Content-type": "text/html;charset='utf-8'" });
        response.end("dologin~");
    },
    error(request,response) {
        response.writeHead(404, { "Content-type": "text/html;charset='utf-8'" });
        response.end('404页面不存在')
    }

}
```

app.js

```javascript
const http = require('http');
const router = require('router');
const url = require('url');
const ejs = require('ejs');
http.createServer(function (request, response) {
    //1、尝试读取资源
    var rstatic = router.static(request, response, 'state');
    //2、无对应资源时，尝试路由
    if(!rstatic) {
        try {
            let pathname = url.parse(request.url).pathname.replace("/","");
            router.mapper[pathname](request, response);
        }catch(error) {
            router.mapper['error'](request, response);
        }
    }

}).listen(3005); console.log("server url: http://127.0.0.1:3005")
```

代码下载：[https://github.com/18476305640/fileBox/raw/master/杂项/nodeJs-master.zip](https://github.com/18476305640/fileBox/raw/master/杂项/nodeJs-master.zip "https://github.com/18476305640/fileBox/raw/master/杂项/nodeJs-master.zip")
