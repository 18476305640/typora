# ES6

### \[\_1\_] let

-   var声明的变量能跳出作用域
    ```javascript
            // var 声明的变量往往会越域
            // let 声明的变量有严格局部作用域
            if (true) {
                var a = 4;
                let b = 2;
            }
            console.log(a);  // 4
            console.log(b);  // ReferenceError: b is not defined
    ```
-   var可以声明多次
    ```javascript
            // var 可以声明多次
            // let 只能声明一次
            var m = 1
            var m = 2
            let n = 3
            let n = 4
            console.log(m)  // 2
            console.log(n)  // Identifier 'n' has already been declared
    ```
-   var 变量提升
    ```javascript
            // var 会变量提升
            // let 不存在变量提升
            console.log(x);  // undefined
            var x = 10;
            console.log(y);   //ReferenceError: y is not defined
            let y = 20;
    ```

### \[\_2\_] const

const:
&#x20;       1\. 声明之后不允许改变
&#x20;       2\. 一但声明必须初始化，否则会报错

```javascript
        
        const a = 1;
        a = 3; //Uncaught TypeError: Assignment to constant variable. 
```

### \[\_3\_] 解构表达式

#### \[\_3.1\_] 数组解构

```javascript
       //数组解构
        let arr = [1, 2, 3];
        //以前
        // let a = arr[0];
        // let b = arr[1];
        // let c = arr[2];

        let [a, b, c] = arr;

        console.log(a, b, c)
```

#### \[\_3.2\_] 对象解构

```javascript
        const person = {
            name: "jack",
            age: 21,
            language: ['java', 'js', 'css']
        }


        //         const name = person.name;
        //         const age = person.age;
        //         const language = person.language;


        //对象解构
        const { name: abc, age, language } = person;

        console.log(abc, age, language)
```

### \[\_4\_] 字符串扩展

```javascript
        let str = "hello_es6.vue";
        console.log(str.startsWith("hello"));//true
        console.log(str.endsWith(".vue"));//true
        console.log(str.includes("es6"));//true
```

### \[\_5\_] 模板字符串

```javascript
        // 2、字符串插入变量和表达式。变量名写在 ${} 中，${} 中可以放入 JavaScript 表达式。
        let name = "小庄"
        let age = 22
        function fun() {
            return "这是一个函数"
        }

        let info = `我是${name}，今年${age + 10}了, 我想说： ${fun()}`;
        console.log(info);
```

### \[\_6\_] 函数优化

#### \[\_6.1\_] 参数默认值

```javascript
        //现在可以这么写：直接给参数写上默认值，没传b,b就会自动使用默认值
        function add2(a, b = 1) {
            return a + b;
        }
        console.log(add2(20));
```

#### \[\_6.2\_] 不定参数

```javascript
        //不定参数
        function fun(...values) { //values在函数中是一个数组
            console.log(values.length)
        }
        fun(1, 2)      //2
        fun(1, 2, 3, 4)  //4
```

#### \[\_6.3\_] 箭头函数

```javascript
        //箭头函数
        //以前声明一个方法
        // var print = function (str) {
        //     console.log(str);
        // }
        var print = str => console.log(str);
        print("hello");
```

str => console.log(str)

就相当于

function (str) {
&#x20;  console.log(str);
}

箭头函数与解构的综合应用

```javascript
        const person = {
            name: "jack",
            age: 21,
            language: ['java', 'js', 'css']
        }
        //箭头函数+解构
        var hello2 = ({ name }) => console.log("hello," + name);
        hello2(person);
```

### \[\_7\_] 对象优化

#### \[\_7.1\_] 对象扩展

```javascript
        const person = {
            name: "jack",
            age: 21,
            language: ['java', 'js', 'css']
        }

        console.log(Object.keys(person));//["name", "age", "language"]
        console.log(Object.values(person));//["jack", 21, Array(3)]
        console.log(Object.entries(person));//[Array(2), Array(2), Array(2)]
```

还有

```javascript
        const target = { a: 1 };
        const source1 = { b: 2 };
        const source2 = { c: 3 };

        //{a:1,b:2,c:3}
        Object.assign(target, source1, source2);
```

#### \[\_7.2\_] 声明对象的简写

```javascript
        //声明对象简写
        const age = 23
        const name = "张三"
        //const person1 = { age: age, name: name }

        const person2 = { age, name }
        console.log(person2);
```

还有一种：如果属性值是函数

```javascript
        let person3 = {
            // 以前：
            eat: function (food) {
                console.log(this.name + "在吃" + food);
            },
            //现在
            eat3(food) {
                console.log(this.name + "在吃" + food);
            }
        }
```

#### \[\_7.3\_] 对象的拷贝与合并

拷贝

```javascript
        let arr = { "name": "小庄", "age": 22 }
        let new_arr = { ...arr }
        console.log(new_arr)
```

合并

```javascript
        // 合并对象
        let arr1 = { age: 15 }
        let arr2 = { name: "Amy" }
        let arr3 = { tag: "官方", ...arr1, ...arr2 }
        console.log(arr3)
```

### \[\_8\_] map和reduce

map：接收一个函数，将原数组中的所有元素用这个函数处理后放入新数组返回。

```javascript
        let arr = ['1', '20', '-5', '3'];
        arr = arr.map(item => item * 2);
```

reduce：为数组中的每一个元素依次执行回调函数，不包括数组中被删除或从未被赋值的元素

```javascript
        let sum = 0;
        let result = arr.reduce((sum, item) => {
            return sum + item;
        }, sum)
```

### \[\_9\_] Promise

```javascript
        new Promise((resolve, reject) => {
            console.log("请求1");
            resolve("data1")
        }).then(data => {
            console.log("请求2: 得到", data);
            return new Promise((resolve, reject) => {
                //发请求2
                reject("data2")
            })
        }).then(data => {
            console.log("请求3: 得到", data);
            return new Promise((resolve, reject) => {
                //发请求2
                resolve("data3")
            })
        }).then(data => {
            console.log("请求4: 得到", data);
            return new Promise((resolve, reject) => {
                //发请求2
                resolve("data4")
            })
        }).catch(err => {
            //上面不管哪个出错了，都会到这里
            console.log("出错了~");
        })
```

**Promise静态方法之all**： promise 如果是reject就会报错，除非对这个promise进行catch

```javascript
let promise1 = new Promise((resolve, reject) => {
            resolve(1);
        })
        let promise2 = new Promise((resolve, reject) => {
            reject(2);
        }).catch(err => 22)
        let promise3 = new Promise((resolve, reject) => {
            resolve(3);
        })
        Promise.all([promise1, promise2, promise3]) //如果有 reject 且没有catch 进行return就会报错
            .then(values => {
                console.log(values)
            })
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16586377366261658637736516.png)

**Promise静态方法之allSettled**：不管 promise 是resolve还是reject都会收集

```javascript
let promise1 = new Promise((resolve, reject) => {
    resolve(1);
})
let promise2 = new Promise((resolve, reject) => {
    reject(2);
})
let promise3 = new Promise((resolve, reject) => {
    resolve(3);
})
Promise.allSettled([promise1, promise2, promise3]) //如果有 reject 且没有catch 进行return就会报错
    .then(values => {
        console.log(values)
    })
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16586374986131658637497895.png)

**Promise静态方法之race**： 获取promise数组中得到结果最快的那个，value就是最快的返回的值 ，promise 如果是reject就会报错，除非对这个promise进行catch

```javascript
let promise1 = new Promise((resolve, reject) => {
            setTimeout(function () {
                resolve(1);
            }, 20)

        })
        let promise2 = new Promise((resolve, reject) => {
            setTimeout(function () {
                reject(2);
            }, 10)
        }).catch(err => 22)
        let promise3 = new Promise((resolve, reject) => {
            setTimeout(function () {
                resolve(3);
            }, 30)

        })
        Promise.race([promise1, promise2, promise3]) //如果有 reject 且没有catch 进行return就会报错
            .then(value => {
                console.log(value)
            })
```

### \[\_10\_] 模块化

#### \[\_10.1\_] 模块的导出

普通导出：

```javascript
var name = "jack"
var age = 21
function add(a, b) {
    return a + b;
}

export { name, age, add }
//其它模块想要导入：import { name, add } from "./user.js"
```

默认导出

```javascript
export default {
    sum(a, b) {
        return a + b;
    }
}

//其它模块想要导入：import abc from "./hello.js"
```

#### \[\_10.2\_] 模块的导入

普通导入：与上面的普通导出相对应

```javascript
import { name, add } from "./user.js"
```

默认导入：与上面的默认导出相对应

```javascript
import abc from "./user.js" //abc这块是任意的名
```

无值导入

```javascript
import './xv.js'  //特点是没值名
```

xv.js：

```javascript
 window.zhuangjie = function () { //放在window上后，在导入 xv.js的模块就可以直接使用了 即:zhuangjie()
    console.log("你叫我干什么~");
}
```
