# Vue

### \[ *+*] Vue的简介

-   Vue 是一套用来动态构建用户界面的渐进式JavaScript框架 &#x20;
    -   构建用户界面：把数据通过某种办法变成用户界面 &#x20;
    -   渐进式：Vue可以自底向上逐层的应用，简单应用只需要一个轻量小巧的核心库，复杂应用可以引入各式各样的Vue插件 &#x20;
-   作者：尤雨溪

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587173272631658717327053.png)

#### \[\_1.1\_] Vue的特点

-   遵循MVVM模式&#x20;
-   编码简洁，体积小，运行效率高，适合移动/PC端开发&#x20;
-   它本身只关注 UI，可以引入其它第三方库开发项目
-   采用**组件化**模式，提高代码复用率、且让代码更好维护

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587175256151658717525534.png)
-   **声明式**编码，让编码人员无需直接操作DOM，提高开发效率

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587175488341658717548750.png)
-   使用**虚拟DOM**和** Diff算法**，尽量复用DOM节点

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587182314601658718231307.png)

#### \[\_1.2\_] Vue与其它框架

-   借鉴 angular 的 模板 和 数据绑定 技术 &#x20;
-   借鉴 react 的 组件化 和 虚拟DOM 技术

#### \[\_1.3\_] Vue周边库

-   vue-cli：vue 脚手架 &#x20;
-   vue-resource(axios)：ajax 请求 &#x20;
-   vue-router：路由 &#x20;
-   vuex：状态管理（它是 vue 的插件但是没有用 vue-xxx 的命名规则） &#x20;
-   vue-lazyload：图片懒加载 &#x20;
-   vue-scroller：页面滑动相关 &#x20;
-   mint-ui：基于 vue 的 UI 组件库（移动端） &#x20;
-   element-ui：基于 vue 的 UI 组件库（PC 端）

### \[\_1\_] 初识Vue（Vue模板）

**前置工作**

1.  给浏览器安装 [Vue Devtools](https://cn.vuejs.org/v2/guide/installation.html#Vue-Devtools "Vue Devtools") 插件
2.  标签引入Vue包
3.  （可选）阻止vue在启动时生成生产提示Vue.config.productionTip = false

\*\*初识Vue （Vue模板） \*\*

1.  想让Vue工作，就必须创建一个Vue实例，且要传入一个配置对象 &#x20;
2.  root 容器里的代码依然符合html规范，只不过混入了一些特殊的Vue语法 &#x20;
3.  root 容器里的代码被称为Vue模板 &#x20;
4.  Vue 实例与容器是一一对应的 &#x20;
5.  真实开发中只有一个Vue实例，并且会配合着组件一起使用 &#x20;

### \[\_2\_] 数据绑定

单向绑定v-bind数据只能从 data 流向页面 &#x20;
双向绑定v-model数据不仅能从 data 流向页面，还可以从页面流向 data

#### \[\_3.1\_] 单向绑定

插值与v-bind:

插值：{{xxx}}中的 xxx 要写 js 表达式，且 xxx 可以自动读取到data中的所有属性，当然也可以是windows中的方法与变量
注意区分：js 表达式（有返回值） 和 js代码（语句）

v-bind:  如果属性值想要动态地改变或说想要在标签中像插值一样动态地从Vue中获取数据动态地显示，那么就是用v-bind: ，可以简写:XXX（ 比如v-bind:href="url"  => :href="url"）,表达双引号内写的是表达式。

```javascript
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>

<body>
    <div id="app">
        <h1>{{ name }}</h1>
        <a :href="url">点我跳转>> </a>
    </div>
    <script src="./js/vue.js"></script>
    <script>
        new Vue({
            el: "#app",
            data: {
                name: '小庄',
                url: "https://baidu.com"
            }
        })
    </script>
</body>

</html>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587214669901658721466765.png)

> 一旦data中的数据发生变化，那么模板中用到该数据的地方也会自动更新

#### \[\_3.2\_] 双向绑定

`v-model` 指令可以实现双向绑定，v-model应用在表单元素的`value` 属性上，不像v-bind可以用到任何标签的任何属性上。

v-model普通写法：`<input v-model:value="name" />`

v-model简写形式：`<input v-model="name" />`

```javascript
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>

<body>
    <div id="app">
        双向绑定：<input v-model="name" />
        <br />
        双向绑定-简写：<input v-model:value="name" />
    </div>
    <script src="./js/vue.js"></script>
    <script>
        new Vue({
            el: "#app",
            data: {
                name: '小庄'
            }
        })
    </script>
</body>

</html>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587214936031658721493145.png)

### \[ *+*] el与data的两种写法

\*\*`el`有2种写法  \*\*​

-   创建Vue实例对象的时候配置el属性&#x20;
-   先创建Vue实例，随后再通过vm.\$mount('#root')指定el的值 &#x20;
-   演示：el的两种写法
    ```javascript
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

    </head>

    <body>
        <div id="app">
            <h1>{{name }}</h1>
        </div>
        <script src="./js/vue.js"></script>
        <script>
            let vm = new Vue({
                //el: "#app",
                data: {
                    name: '小庄',
                }
            })
            setTimeout(() => {
                vm.$mount("#app")
            }, 500)

        </script>
    </body>

    </html>
    ```

\*\*`data`有2种写法  \*\*​

-   对象式：data： { } &#x20;
-   函数式：data() { return { } } &#x20;
    > 如何选择：目前哪种写法都可以，以后到组件时，data必须使用函数，否则会报错 &#x20;
    > 一个重要的原则 &#x20;
    > 由Vue管理的函数，一定**不要写箭头函数**，否则 this 就不再是Vue实例了
-   演示：data的两种写法
    ```javascript
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

    </head>

    <body>
        <div id="app">
            <h1>{{name }}</h1>
        </div>
        <script src="./js/vue.js"></script>
        <script>
            let vm = new Vue({
                el: "#app",
                // data: { //第一种
                //     name: '小庄',
                // }
                data: function () { //第二种：只要涉及组件的开发必须使用这一种，且不能使用前头函数！！
                    return {
                        name: '小庄'
                    }
                }
            })


        </script>
    </body>

    </html>
    ```

### \[ *+*] MVVM模型

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587324025451658732402317.png)

MVVM模型 &#x20;

-   M：模型 Model，data中的数据 &#x20;
-   V：视图 View，模板代码 &#x20;
-   VM：视图模型 ViewModel，Vue实例

### \[ *+*] Vue中的数据代理

数据代理更像是创建快捷方式的一种行为或说软链接

`Object.defineProperty(...)`：下面解析，对person中的age进行数据代理，即`person.age => number`  我们可以在该defineProperty内写`get` 与`set`方法，当我们进行`person.age = 18` 时，如果我们没有写set方法，这样操作是无意义的，如果我们写了，进行赋值时在set方法中就会被调用，然后只需number = value即可实现绑定赋值。

```javascript
let number = 18
let person = {
  name: '张三',
  sex: '男',
}

Object.defineProperty(person, 'age', {
  // value:18,
  // enumerable:true,    // 控制属性是否可以枚举，默认值是false
  // writable:true,      // 控制属性是否可以被修改，默认值是false
  // configurable:true  // 控制属性是否可以被删除，默认值是false

  // 当有人读取person的age属性时，get函数(getter)就会被调用，且返回值就是age的值
  get() {
    console.log('有人读取age属性了')
    return number
  },

  // 当有人修改person的age属性时，set函数(setter)就会被调用，且会收到修改的具体值
  set(value) {
    console.log('有人修改了age属性，且值是', value)
    number = value
  }

})
// console.log(Object.keys(person))
console.log(person)
```

我们声明的data，将之创建快捷方式到vm.\_data; data中的属性 => vm.\<data中的属性>。&#x20;

发现：我们可以在插值（`{{}}`）中使用vm中的属性和原型中的属性。如果我们不把data中的属性放在vm上，然后我们需要在DOM模板上`{{ _data.<属性名>}}`  而不是`{{ 属性名 }}`

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16587335373741658733537201.png)

### \[\_3\_] methods 方法的声明

1.  使用**v-on:xxx**或@xxx绑定事件，其中 xxx 是事件名 &#x20;
2.  事件的回调方法是 methods对象中的方法，在methods中声明的方法最终会在vm上 &#x20;
3.  methods中配置的函数，不要用箭头函数，否则 this 就不是vm了 &#x20;
4.  methods中配置的函数，都是被 Vue所管理的函数，this 的指向是`vm`或`组件实例对象`
    ```javascript
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

    </head>

    <body>
        <div id="app">
            <button v-on:click="showMsg()">开始会话</button>
        </div>

        <script src="./js/vue.js"></script>
        <script>
            let vm = new Vue({
                el: "#app",
                data: function () {
                    return {
                        name: '大聪明'
                    }
                },
                methods: {
                    showMsg() {
                        console.log(this.name + "，吃饭了吗？");
                    }
                }
            })


        </script>
    </body>

    </html>
    ```

### \[\_4\_] 事件

说到`事件`,那么就要提到`event`了，事件触发后，如何获取呢？

我们只需要`<button v-on:click="showMsg($event)">开始会话</button>` ，即使用`$event` 作为参数传入即可\~

`v-on`的双引号内，可以是一些表达式

#### \[\_7.1\_] 事件修饰符

1.  prevent 阻止默认事件（常用） &#x20;
    -   演示：`v-on:click.prevent="..."`
        ```javascript
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>

        </head>

        <body>
            <div id="app">
                <a href="https://www.baidu.com" v-on:click.prevent="showMsg()">默认事件</a>
            </div>

            <script src="./js/vue.js"></script>
            <script>
                let vm = new Vue({
                    el: "#app",
                    data: function () {
                        return {
                        }
                    },
                    methods: {
                        showMsg(e) {
                            alert("大聪明，干饭了吗？");
                        },
                        response() {
                            alert("我吃了，你呢？");
                        }
                    }
                })


            </script>

        </body>

        </html>
        ```
2.  stop 阻止事件冒泡（常用） &#x20;
    -   演示: `v-on:click.stop="..."`
        ```javascript
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>

        </head>

        <body>
            <div id="app">
                <div class="box" v-on:click="response()">
                    <div v-on:click.stop="showMsg()">
                        大聪明
                    </div>
                </div>
            </div>

            <script src="./js/vue.js"></script>
            <script>
                let vm = new Vue({
                    el: "#app",
                    data: function () {
                        return {
                        }
                    },
                    methods: {
                        showMsg(e) {
                            alert("大聪明，干饭了吗？");
                        },
                        response() {
                            alert("我吃了，你呢？");
                        }
                    }
                })


            </script>
            <style>
                .box {
                    width: 200px;
                    height: 100px;
                    padding: 20px;
                    background-color: blue;
                }

                .box>div {
                    width: 100%;
                    height: 100%;
                    background-color: aqua;
                }
            </style>
        </body>

        </html>
        ```
3.  once 事件只触发一次（常用） &#x20;
    -   演示：`v-on:click.once=="..."`
        ```javascript
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>

        </head>

        <body>
            <div id="app">
                <button v-on:click.once="showMsg()">默认事件</button>
            </div>

            <script src="./js/vue.js"></script>
            <script>
                let vm = new Vue({
                    el: "#app",
                    data: function () {
                        return {
                        }
                    },
                    methods: {
                        showMsg(e) {
                            alert("大聪明，干饭了吗？");
                        },
                        response() {
                            alert("我吃了，你呢？");
                        }
                    }
                })


            </script>

        </body>

        </html>
        ```
4.  capture 使用事件的捕获模式
5.  self 只有event.target是当前操作的元素时才触发事件 &#x20;
6.  passive 事件的默认行为立即执行，无需等待事件回调执行完毕

#### \[\_7.2\_] 键盘事件

> 键盘上的每个按键都有自己的`名称`和`编码`，例如：Enter（13）。而Vue还对一些常用按键起了别名方便使用

**Vue中常用的按键别名**
回车enter &#x20;
删除delete捕获“删除”和“退格”键 &#x20;
退出esc &#x20;
空格space &#x20;
换行tab特殊，必须配合keydown去使用 &#x20;
上up &#x20;
下down &#x20;
左left &#x20;
右right

**Vue未提供别名的按键：**

-   可以使用按键原始的key 值（比如tab、enter）去绑定，但注意要转为kebab-case（多单词小写短横线写法）,比如Caps键，key值为`CapsLock ` 就要转为`caps-lock` ，使用时`v-on:keyup.caps-lock="..."`
-   也可以直接使用`keyCode`来代替,比如Caps键的keyCode为20,我们也可以这样`v-on:keyup.20="..."` , 和 `v-on:keyup.caps-lock="..."` 是一样的。

**系统修饰键**（用法特殊）：ctrl、alt、shift、meta（meta就是win键） &#x20;

-   按下修饰键的同时，再按下其他键，随后释放其他键，事件才被触发 &#x20;
    指定 ctr+y 使用 @keyup.ctr.y="..."  ，如果直接 @keyup.ctr="..."是没效果的。

    注：特殊修饰键的 @keyup与@keydown可能有区别

> Vue.config.keyCodes.自定义键名 = 键码，可以去定制按键别名

### \[\_5\_] 计算属性

**性能区别：**

计算属性完全可以使用方法替换，而计算属性又可以在DOM模板中代替，但这不符合Vue的风格要求，但如果使用方法，是没有缓存机制的，即只要我们DOM刷新 ，在DOM中使用n次，就会调用n次。

而如果使用计算属性，有缓存机制，只有计算属性依赖的属性变化了，才会重新计算。

**使用区别：**

函数：

```javascript
全名：{{ fullName() }} <br />
全名：{{ fullName() }} <br />
全名：{{ fullName() }} <br />
```

计算属性：跟data属性的用法一样

```javascript
全名：{{ fullName }} <br />
全名：{{ fullName }} <br />
全名：{{ fullName }} <br />
```

**使用方法：**

```javascript
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>

<body>
    <div id="app">
        姓：<input v-model:value="firstName" /><br />
        名：<input v-model:value="lastName" /><br />
        全名：{{ fullName }} <br />
        全名：{{ fullName }} <br />
        全名：{{ fullName }} <br />
    </div>
    <script src="./js/vue.js"></script>
    <script>
        const vm = new Vue({
            el: "#app",
            data() {
                return {
                    firstName: 'zhuang',
                    lastName: 'jie',
                    test: ""
                }
            },
            computed: {
                //简写：如果确定不写set，那么就可以用简写
                fullName() {
                    console.log("fullName计算属性函数被调用了~");
                    return this.firstName + "-" + this.lastName
                },
                //传统写法
                // fullName: {
                //     get() {
                //         return this.firstName + "-" + this.lastName;
                //     },
                //     set(value) {
                //         this.firstName = value.split("-")[0]
                //         this.lastName = value.split("-")[1]
                //     }

                // }

            }

        })

    </script>
</body>

</html>
```

### \[\_6\_] 属性侦听

首先`属性侦听` 是侦听属性的改变，侦听的属性有任何改变，都能知道。

属性侦听与计算属性的区别：

-   computed能完成的功能，watch都可以完成 &#x20;
-   watch能完成的功能，computed不一定能完成，例如watch可以进行异步操作

普通侦听：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588013959651658801395758.png)

-   演示
    ```javascript
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

    </head>

    <body>
        <div id="app">
            姓：<input v-model:value="firstName" /><br />
            名：<input v-model:value="lastName" /><br />
            全名：{{ fullName }} <br />
            全名：{{ fullName }} <br />
            全名：{{ fullName }} <br />
        </div>
        <script src="./js/vue.js"></script>
        <script>
            const vm = new Vue({
                el: "#app",
                data() {
                    return {
                        firstName: 'zhuang',
                        lastName: 'jie',
                        fullName: "zhuang-jie"
                    }
                },
                watch: {
                    firstName(newValue, oldValue) {
                        this.fullName = newValue + "-" + this.lastName
                    },
                    lastName(newValue, oldValue) {
                        this.fullName = this.firstName + "-" + newValue
                    }
                }

            })

        </script>
    </body>

    </html>
    ```

深度侦听：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588020111981658802011084.png)

-   演示
    ```javascript
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>

    </head>

    <body>
        <div id="app">
            姓：<input v-model:value="fullName.firstName" /> <br />
            名：<input v-model:value="fullName.lastName" /> <br />
        </div>
        <script src="./js/vue.js"></script>
        <script>
            const vm = new Vue({
                el: "#app",
                data() {
                    return {
                        fullName: {
                            firstName: 'zhuang',
                            lastName: 'jie'
                        }
                    }
                },
                watch: {
                    fullName: {
                        deep: true,
                        handler(newValue, oldValue) {
                            console.log("==>fullName改变了,", newValue, oldValue);
                        }
                    }
                }

            })






        </script>
    </body>

    </html>
    ```

### \[\_7\_] this与箭头函数&#x20;

两个重要的小原则 &#x20;

-   所有被Vue管理的函数，最好写成普通函数，这样 this 的指向才是vm或组件实例对象 &#x20;
-   所有不被Vue所管理的函数（定时器的回调函数、ajax 的回调函数等、Promise 的回调函数），最好写成箭头函数，这样 this 的指向才是vm或组件实例对象

### \[\_8\_] 绑定样式

**style**

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588035833771658803583300.png)

-   代码
    ```javascript
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>

    <body>
        <div id="app">
            <p :style="[ca1,ca2]">样式绑定</p>
        </div>
        <script src="/js/vue.js"></script>
        <script>
            const vm = new Vue({
                el: '#app',
                data: {
                    ca1: {
                        color: 'red',
                    },
                    ca2: {
                        backgroundColor: 'pink'
                    }
                }
            })
        </script>

    </body>

    </html>
    ```
    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588036851501658803684602.png)

**class**

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588030971621658803096988.png)

-   代码：
    ```javascript
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>

    <body>
        <div id="app">
            <p :class="[ca ,ca2]">样式绑定</p>
        </div>
        <script src="/js/vue.js"></script>
        <script>
            const vm = new Vue({
                el: '#app',
                data: {
                    ca: ['basic'],
                    ca2: {
                        text_red: true,
                        text_back: true
                    }
                }
            })
        </script>
        <style>
            .basic {
                border: 1px solid red;
                width: 200px;
                padding: 20px 0px;
                text-align: center;
            }

            .text_red {
                color: red;
            }

            .text_back {
                background-color: pink;
            }
        </style>
    </body>

    </html>
    ```
    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588031461581658803145750.png)

### \[\_9\_] 条件渲染

**`v-if`**

-   写法跟 if else 语法类似

    `v-if`="表达式" &#x20;
    `v-else-if`="表达式" &#x20;
    `v-else`
-   适用于：切换频率较低的场景，因为不展示的DOM元素直接被移除
-   注意：`v-if`可以和`v-else-if`  `v-else`一起使用，但要求结构不能被打断

**`v-show`**

-   写法：`v-show="表达式"  `
-   适用于：切换频率较高的场景 &#x20;
-   特点：不展示的DOM元素未被移除，仅仅是使用样式隐藏掉display: none &#x20;

**`template`**

-   使用v-if的时，元素可能无法获取到，而使用v-show一定可以获取到\*\*`template`\*\***标签不影响结构**，页面html中不会有此标签，但只能配合v-if，不能配合v-show
    ```javascript
    <div id="app">
            <button v-on:click.once="showNewYear()">过年啦！</button>
            <template>
                <div v-if="isShow">
                    新年快乐！
                </div>
                <div v-else>
                    还没到新年呢~
                </div>
            </template>
        </div>
    ```
    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588131785841658813177948.png)

### \[\_10\_] 列表渲染

#### \[\_10.1\_] 使用

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588141903441658814190175.png)

#### \[\_10.2\_] key的作用

为什么需要`:key` 呢？如果不写呢？

底层为了DOM复用，用了Diff算法，如果我们不写key，或用了与数据顺序有关的，比如index，即`:key="index"` 跟没写是一样的，没写的结果就是:key值为index, 那么如果我们对数据顺序进行了破解，如

```javascript
persons: [
    { id: '001', name: '张三', age: 18 },
    { id: '002', name: '李四', age: 19 },
    { id: '003', name: '王五', age: 20 }
]
```

在最上面追加了一行变为：

```javascript
persons: [
    { id: '004', name: '老刘', age: 30 },
    { id: '001', name: '张三', age: 18 },
    { id: '002', name: '李四', age: 19 },
    { id: '003', name: '王五', age: 20 }
]
```

那么就会出现问题了，什么问题呢？

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588145825871658814582420.png)

看上图中间右边新虚拟DOM 老刘这行，会找到左边key为0的第个`li`比较：

老刘-30 ≠ 张三-18  → 创建老刘

`<input type="text">`  ==`<input type="text">`   复用

得到：&#x20;

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588152046261658815204555.png)

新虚拟DOM的张三、李四、王五都是这样。最终得到上图右下角的那个图效果。

```javascript
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div id="app">
        <button v-on:click.once="add()">追加</button>
        <ul>
            <li v-for="(item,index) of persons" :key="item.id">
                {{item.name}}-{{item.age}} <input />
            </li>
        </ul>

    </div>
    <script src="/js/vue.js"></script>
    <script>
        const vm = new Vue({
            el: '#app',
            data() {
                return {
                    persons: [
                        { id: '001', name: '张三', age: 18 },
                        { id: '002', name: '李四', age: 19 },
                        { id: '003', name: '王五', age: 20 }
                    ]
                }
            },
            methods: {
                add() {
                    console.log("add");
                    this.persons.unshift({ id: '004', name: '老刘', age: 30 })
                }
            },
        })
    </script>

</body>

</html>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588148245851658814823727.png)

继续学习：[https://www.bilibili.com/video/BV1Zy4y1K7SH?p=35](https://www.bilibili.com/video/BV1Zy4y1K7SH?p=35 "https://www.bilibili.com/video/BV1Zy4y1K7SH?p=35")

### \[\_11\_] Vue 数据响应式

Vue中大量使用了`数据代理` `Object.defineProperty(...)` ，vue对data中所以数据进行数据代理（数据劫持），可以认为被劫持的属性，都是响应式的

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588418072551658841807028.png)

**那有种情况是没有响应的呢**

1.  **数组**：arr\[0] = obj  ， 直接操作数据元素（说的不是操作数据元素内部），因为没有进行数据代理，所以是不行的。应该使用Vue提供的数组操作方法，才是有响应式的 （`push` 、`pop`、`unshift` 、`shift`、`splice` 、`sort` 、`reverse` ）
2.  **对象：** 已经有的k-v已经有数据代理了，但如果你向对象中添加属性是没有响应的。你应该使用`Vue.set(<元素所在对象>,<操作的属性>,<新的属性值>)`或 `this.$set(<元素所在对象>,<操作的属性>,<新的属性值>)` 来操作

```javascript
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div id="app">

        <a>兴趣：</a>
        <button v-on:click="addHabby()">追加一个兴趣项</button>
        <ul>
            <li v-for="(item,index) of habbys" :key="item.index">
                {{ item }}
            </li>
        </ul>

        <a>一个人：</a>
        <button v-on:click="update()">更新这个人的一些信息</button> <br />
        {{person.name}}-{{person.age}}-{{person.sex}}

    </div>
    <script src="/js/vue.js"></script>
    <script>


        const vm = new Vue({
            el: '#app',
            data() {
                return {
                    person: {
                        name: 'zhuangjie',
                        age: 22
                    },
                    habbys: ['吃饭', '工作']

                }
            },
            methods: {
                addHabby() {
                    /*【数组-无响应】数组元素是没有响应的，的如果我们直接操作数组，是没有响应的，需要使用vue包装的操作方法
                        push    //追加一个元素
                        pop     //从后面弹出一个元素
                        unshift //从前面添加
                        shift   //从删除前面第一个元素
                        splice(target_index, 个数,[要替换的值])  //指定位置：删除/添加/修改
                        sort   //排序  
                        reverse   //反转
                    */
                    this.habbys.splice(1, 1, "打电动") //删掉指定index的元素
                    // this.habbys[0] = '打游戏' //无响应  
                    // ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588423307421658842330663.png)
                    Vue.set(this.habbys, 4, '学习') //用法2： this.$set() 
                },
                update() {
                    //【对象无响应】
                    // this.person.sex = '男' //这样向对象添加一个属性，是无响应的，因为本来就没这个属性，更不用说有这个属性的数据代理（get,set）
                    //Vue.set() //用法2： this.$set() 是不能给vm或vm.data添加属性的，会报错,比如：Vue.set(this,'go','ok') //this是vm
                    Vue.set(this.person, 'sex', '男') 

                }
            },
        })

    </script>

</body>

</html>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588450891231658845089025.png)

### \[\_12\_] 收集表单数据

若：\<input type="text" />, 则v-model收集的是value值，用户输入的就是value值
若：\<input type="radio"  />, 则v-model收集的是value值，且要给标签配置value值
若：\<input type="checkbox"  />, 有配置input的value属性，那么收集的就是checked(勾选or未勾选，是布尔值）
**配置input的value属性：**

(1) v-model的初始值是非数组，那么收集的就是checked(勾选or未勾选，是布尔值）
(2) v-model的初始值是数组，那么收集的的就是value组成的数组

**备注：**

v-model的三个修饰符
lazy:失去焦点再收集数据
number:输入字符串转为有效的数字
trim:输入首尾空格过滤

```javascript
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>

<body>
    <div id="app">
        <form v-on:submit.prevent="submit()">
            账号：<input type="text" name="username" v-model="profile.username" /><br /><br />
            密码：<input type="password" name="username" v-model="profile.password" /> <br /><br />
            年龄：<input type="number" v-model.number="profile.age" /><br /><br />
            性别：
            男<input type="radio" v-model="profile.sex" value='男' />
            女<input type="radio" v-model="profile.sex" value="女" /> <br /><br />
            爱好：
            吃饭<input type="checkbox" v-model="profile.hobby" value="eat">
            打游戏<input type="checkbox" v-model="profile.hobby" value="games"> <br /><br />
            所属地区：
            <select v-model="profile.city">
                <option value="">请选择地区</option>
                <option value="北京">北京</option>
                <option value="深圳">深圳</option>
                <option value="广州">广州</option>

            </select>
            <br /><br />
            其它信息：<textarea v-model.lazy="profile.other"></textarea> <br /><br />
            <input type="checkbox" v-model="profile.agree" /> 阅读并授受 <a href="www.baidu.com">《用户协议》</a>
            <br /><br />
            <button>提交</button>
        </form>

    </div>
    <script src="./js/vue.js"></script>
    <script>
        const vm = new Vue({
            el: "#app",
            data() {
                return {
                    profile: {
                        username: "",
                        password: "",
                        age: 18,
                        sex: "male",
                        hobby: [],
                        city: "",
                        other: "",
                        agree: ""
                    }
                }
            },
            methods: {
                submit() {
                    console.log("收集的表单数据=>", JSON.stringify(this.profile))
                }
            },


        })
    </script>
</body>

</html>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588490493111658849049231.png)

### \[\_13\_] 内置指令 ＆ 自定义指令

#### \[\_13.1\_] 内置指令

之前学过的指令：

`v-bind` 单向绑定解析表达式，可简写为: &#x20;
`v-model` 双向数据绑定 &#x20;
`v-for` 遍历数组 / 对象 / 字符串 &#x20;
`v-on `绑定事件监听，可简写为@ &#x20;
`v-show` 条件渲染 (动态控制节点是否展示) &#x20;
`v-if `条件渲染（动态控制节点是否存存在） &#x20;
`v-else-if` 条件渲染（动态控制节点是否存存在） &#x20;
`v-else` 条件渲染（动态控制节点是否存存在）

**v-text**

`v-text`指令 &#x20;
作用：向其所在的节点中渲染文本内容 &#x20;
与插值语法的区别：v-text会替换掉节点中的内容，{{xxx}}则不会，更灵活

**v-html**

`v-html`指令 &#x20;
作用：向指定节点中渲染包含html结构的内容 &#x20;
与插值语法的区别： &#x20;

ⅰv-html会替换掉节点中所有的内容，{{xxx}}则不会 &#x20;
ⅱv-html可以识别html结构 &#x20;

严重注意v-html有安全性问题！！！ &#x20;

ⅰ在网站上动态渲染任意html是非常危险的，容易导致 XSS 攻击 &#x20;
ⅱ一定要在可信的内容上使用v-html，永远不要用在用户提交的内容上！！

**v-cloak**

`v-cloak` 指令  （没有值） &#x20;

a本质是一个特殊属性，Vue实例创建完毕并接管容器后，会删掉v-cloak属性 &#x20;
b使用css配合v-cloak可以解决网速慢时页面展示出{{xxx}}的问题

```javascript
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        [v-cloak] {
            display: none;
        }
    </style>
</head>

<body>
    <div id="app">
        <div v-cloak>
            公告：<span v-html="msg"></span>
        </div>
    </div>

    <script src="./js/vue.js"></script>
    <script>
        //模拟 加载vue依赖 慢
        setTimeout(() => {

            const vm = new Vue({
                el: "#app",
                data() {
                    return {
                        msg: '<span style="color:red">今天不上班！</span>',
                    }
                }
            })

        }, 1500)

    </script>
</body>

</html>
```

**v-once**

v-once 指令 &#x20;

v-once所在节点在初次动态渲染后，就视为静态内容了 &#x20;
以后数据的改变不会引起v-once所在结构的更新，可以用于优化性能

\*\*v-pre \*\*

v-pre 指令 &#x20;

1、跳过v-pre所在节点的编译过程 &#x20;

2、可利用它跳过：没有使用指令语法、没有使用插值语法的节点，会加快编译

#### \[\_13.2\_] 自定义指令

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16588930609061658893060420.png)

示例：

```javascript
<title>自定义指令</title>
<script type="text/javascript" src="../js/vue.js"></script>

<div id="root">
  <h2>{{ name }}</h2>
  <h2>当前的n值是：<span v-text="n"></span> </h2>
  <!-- <h2>放大10倍后的n值是：<span v-big-number="n"></span> </h2> -->
  <h2>放大10倍后的n值是：<span v-big="n"></span> </h2>
  <button @click="n++">点我n+1</button>
  <hr />
  <input type="text" v-fbind:value="n">
</div>

<script type="text/javascript">
  Vue.config.productionTip = false

  // 定义全局指令
  /* Vue.directive('fbind',{
    // 指令与元素成功绑定时（一上来）
    bind(element,binding){
      element.value = binding.value
    },
    // 指令所在元素被插入页面时
    inserted(element,binding){
      element.focus()
    },
    // 指令所在的模板被重新解析时
    update(element,binding){
      element.value = binding.value
    }
  }) */

  new Vue({
    el: '#root',
    data: {
      name: '尚硅谷',
      n: 1
    },
    directives: {
      // big函数何时会被调用？
      // 1.指令与元素成功绑定时（一上来） 2.指令所在的模板被重新解析时
      /* 'big-number'(element,binding){
        // console.log('big')
        element.innerText = binding.value * 10
      }, */
      big(element, binding) {
        console.log('big', this) // 🔴注意此处的 this 是 window
        // console.log('big')
        element.innerText = binding.value * 10
      },
      fbind: {
        // 指令与元素成功绑定时（一上来）
        bind(element, binding) {
          element.value = binding.value
        },
        // 指令所在元素被插入页面时
        inserted(element, binding) {
          element.focus()
        },
        // 指令所在的模板被重新解析时
        update(element, binding) {
          element.value = binding.value
        }
      }
    }
  })
</script>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1658893159900image.png)

### \[\_14\_] Vue的生命周期

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1658993270531生命周期.png)

beforeCreate：创建前

created：创建后

beforeMount：挂载前

**mounted**：挂载后，常用来发送请求

beforeUpdate：DOM更新前

updated：DOM更新后

beforeDestroy：被销毁前  (当调用this.\$destroy() 时)

destroyed：被销毁前

> DOM模板，我们可以使用el来指定，或者el指定一个空容器，然后使用`template` 配置项，值为字符串，两者区别是，如果使用template来指定dom，那么必须 要有一个根标签用来替换el的容器指向，到时候template的根标签会替换el的domument对象。

### \[ *+*] 模块化与组件化

模块化：是对js进行模块化开发，得到模块化应用，本质是复用了js

组件化：是对功能进行模块化形成组件树，本质是以组件的形式复用了所有文件。

### \[\_15\_] 非单文件组件

> 非单文件组件：一个文件中包含有 n 个组件 &#x20;
> 单文件组件：一个文件中只包含有 1 个组件

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16590131922281659013191545.png)

**组件嵌套：**

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16590135801291659013580041.png)

```javascript
  <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div id="app">

    </div>
    <script src="./js/vue.js"></script>
    <script>
        //【4】
        const student = Vue.extend({
            template: `
                <div>
                    学生：{{studentName}}
                </div>经·
            `,
            data() {
                return {
                    studentName: '大聪明'
                }
            }
        })
        //【3】
        const school = Vue.extend({
            template: `
                <div>
                    学校：{{schoolName}}
                    <Student></Student>
                </div>
            `,
            data() {
                return {
                    schoolName: '尚硅谷'
                }
            },
            components: {
                Student: student
            }
        })
        //【2】
        const app = Vue.extend({
            template: `
                <div id="boss">
                    应用~
                    <School></School>
                </div>
            `,
            components: {
                School: school
            }
        })
        //【1】
        const vm = new Vue({
            el: '#app',
            template: "<app></app>",
            components: {
                app: app
            }
        })

    </script>
    <style>
        #boss {
            width: 200px;
            height: 200px;
            background-color: pink;
            border: 1px solid red;
        }

        #boss div {
            width: 75%;
            height: 75%;
            border: 1px solid blue;
        }
    </style>
</body>

</html>
```

要说的：

`关于组件名` &#x20;

一个单词组成 &#x20;

第一种写法（首字母小写）：school &#x20;
第二种写法（首字母大写）：School &#x20;

多个单词组成 &#x20;

第一种写法（kebab-case 命名）：my-school &#x20;
第二种写法（CamelCase 命名）：MySchool（需要Vue脚手架支持） &#x20;
备注 &#x20;
组件名尽可能回避HTML中已有的元素名称，例如：h2、H2都不行 &#x20;
可以使用name配置项指定组件在开发者工具中呈现的名字 &#x20;

`关于组件标签` &#x20;

第一种写法：\<school>\</school> &#x20;
第二种写法：\<school/>（需要Vue脚手架支持） &#x20;
备注：不使用脚手架时，\<school/>会导致后续组件不能渲染 &#x20;
一个简写方式：const school = Vue.extend(options)可简写为const school = {...options}，因为父组件components引入的时候会自动创建

`创建组件`&#x20;

**创建一个组件=>**

```javascript
const app = {
    template: `
        <div id="app">
            应用~
            <School></School>
        </div>
    `,
    components: {
        School: school
    }
}
```

**注册组件=>**

要该组件的父组件或页面配置`components` 配置项：

```javascript
const vm = new Vue({
    el: '#app',
    template: "<app></app>",
    components: {
        app: app
    }
})
```

**然后使用=>**

在DOM中，写`<app></app>` 标签

**说明**=>

template被解析后一定要有一个最外围节点，用来替换`el`或`组件标签`。

### \[ *+*] Vue中一个重要的内置关系

Vue.extend **创建的是一个组件构造器**VueComponent，而不是一个具体的组件实例，然后注册到其它组件后写 \<school/> 或 \<school>\</school>，Vue 解析时会帮我们创建 school 组件的实例对象，即Vue帮我们执行的new VueComponent(options) 。

> 注意事项：在Vue中我们的methods、watch、computed的this是vm，如果在组件中这些则是vc（VueComponent）的实例对象。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16590807852561659080784569.png)

一个重要的内置关系：`VueComponent.prototype.`**`proto`**` === Vue.prototype`

为什么要有这个关系：让组件实例对象vc可以访问到 Vue原型上的属性、方法

### \[\_17\_] 单文件组件

> 非单文件组件：一个文件中包含有 n 个组件 &#x20;
> 单文件组件：一个文件中只包含有 1 个组件

School.vue (Student.vue也是一样)

```vue
<template>
  <div id="SchoolRoot">
    {{ SchooltName }}
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "School",
  data() {
    return {
      SchooltName: "尚硅谷",
    };
  },
};
</script>

<style>
.SchoolRoot {
  border: 1px solid blue;
  padding: 20px;
}
</style>
```

App.vue

```javascript
<template>
  <div id="studentRoot">
    <School></School>
    <Student></Student>
  </div>
</template>

<script>
import Student from "./components/Student.vue";
import School from "./components/School.vue";
export default {
  name: "App",
  components: {
    School: School,
    Student: Student,
  },
};
</script>

```

main.js：中导入App.vue, 最后将全部的东西放在`index.html`容器上

```javascript
import App from 'App.vue'
export default new Vue({
    el: '#app',
    template: '<App></App>',
    components: {
        App: App
    }
})
```

index.html

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script type="model" src="../js/vue.js"></script>
    <script type="model" src="main.js"></script>
</head>

<body>

</body>

</html>
```

### \[\_18\_] Vue脚手架

&#x20;Vue版本与Vue CLI版本是不一样的

Vue 最新是3.X

Vue CLI是 5.X

Vue CLI是向下兼容的，也就是Vue CLI5.X是兼容2.X 3.X的，所以用最新的或兼容你使用的Vue版本的Vue CLI即可。

初始化Vue  CLI的上具体步骤：

1.  如果下载缓慢请配置npm淘宝镜像npm config set registry [http://registry.npm.taobao.org](http://registry.npm.taobao.org "http://registry.npm.taobao.org") &#x20;
2.  全局安装 @vue/cli :   npm install -g @vue/cli &#x20;
3.  切换到创建项目的目录，使用命令创建项目vue create xxx &#x20;
4.  选择使用vue的版本 &#x20;
5.  启动项目npm run serve &#x20;
6.  打包项目npm run build &#x20;
7.  暂停项目 Ctrl+C

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16591060833591659106083205.png)

```javascript
.文件目录
├── node_modules 
├── public
│   ├── favicon.ico: 页签图标
│   └── index.html: 主页面
├── src
│   ├── assets: 存放静态资源
│   │   └── logo.png
│   │── component: 存放组件
│   │   └── HelloWorld.vue
│   │── App.vue: 汇总所有组件
│   └── main.js: 入口文件
├── .gitignore: git版本管制忽略的配置
├── babel.config.js: babel的配置文件
 ├── package-lock.json: 使 npm install 安装得更快，（可以删掉，但会在下次npm install完成后自动生成）
├── package.json: 应用包配置文件  
└── README.md: 应用描述文件

```

> package.json与package-lock.json  :    查询`package.json`文件中要下载的包的下载地址，并下载，然后从当前下载后的包的`package.json`文件去查询还需要下载的依赖包，根据依赖包的地址再去下载依赖包。而这个查找的过程在有很多依赖包的情况下，下载的速度会明显下降，而此时，`package-lock.json`就派上了用途，这个文件保存了`node_modules`中所有的包（包括当前下载的包以及依赖包）的信息：版本、下载地址（这个信息在一开始第一次安装包时就写入了`package-lock.json`文件中）。这样当`npm install` 的时候直接从当前文件根据下载地址直接下载，而不再每次都先下载当前的包，再查询当前包的`package.json`文件再去下载。从而下载速度大大提升。

1.  vue.js与vue.runtime.xxx.js的区别

    a. `vue.js` 是完整版的Vue，包含：核心功能+模板解析器

    b. `vue.runtime.xxx.js` 是运行版的Vue，只包含核心功能，没有模板解析器esm 就是 ES6 module
    > 因为 vue.runtime.xxx.js 没有模板解析器，所以不能使用template配置项，需要使用render函数接收到的createElement函数去指定具体内容
2.  `vue.config.js`  可以对脚手架的默认配置进行修改， 执行vue inspect > output.js可以查看到Vue脚手架的默认配置使用，`vue.config.js` 要放在与package.json同级目录。

    详见 [配置参考 | Vue CLI](https://cli.vuejs.org/zh/config/#vue-config-js "配置参考 | Vue CLI")
    ```javascript
    const { defineConfig } = require('@vue/cli-service')
    module.exports = defineConfig({
      transpileDependencies: true,
      lintOnSave: false //禁用语法检查

    })

    ```

### \[\_19\_] ref vs 元素选择器

ref被用来给元素或子组件注册引用信息（id的替代者）

-   应用在html标签上获取的是真实DOM元素，应用在组件标签上获取的是组件实例对象vc
-   使用方式
    -   a打标识：`<h1 ref="xxx"></h1>`或`<School ref="xxx"></School>`
    -   b获取：`this.$refs.xxx`

```javascript
<template>
  <div id="studentRoot">
    <p ref="p">你好，我是大聪明~</p>
    <School ref="school"></School>
    <Student></Student>
  </div>
</template>

<script>
import Student from "./components/Student.vue";
import School from "./components/School.vue";
export default {
  name: "App",
  components: {
    School: School,
    Student: Student,
  },
  mounted() {
    console.log(this.$refs.p);
    console.log(this.$refs.school);
  },
};
</script>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16591656326621659165631990.png)

### \[\_20\_] props实现组件“父传子”

props让组件接收外部传过来的数据 &#x20;

-   **传递数据**`<Demo name="xxx" :age="18"/>` 给组件加属性，就是向子组件传值，这里age前加v-bind可以丰富类型，否则就只是`String` 类型。
-   \*\*接收数据 \*\*

    第一种方式（只接收）`props:['name', 'age'] `&#x20;
    第二种方式（限制类型）`props:{name:String, age:Number}  `
    第三种方式（限制类型、限制必要性、指定默认值）
    ```vue
      props: {
        a: {
          type: String,
          required: true,
          default: "no data",
        }
      },
    ```
    > 第二种方式与第三种方式可以混写， `required` 与 `default` 是互斥的。既然是一定要有，那为什么还要默认值呢。

> **备注**：props是只读的，Vue底层会监测你对props的修改，如果进行了修改，就会发出警告，若业务需求确实需要修改，那么请复制props的内容到data中，然后去修改data中的数据  （想修改父组件中的那个值 ？往下看）

```vue
  data() {
    return {
      myI: this.i,  //如果要修改i，我们进行复制，我们操作myI
    };
  },
  methods: {
    add() {
      this.myB++;
    },
  },
  //接收的属性 i是不可变的
  props: {
    i: Number,
  },
```

**想要修改父组件中的那个？**

在给子组件值时：

```javascript
<search-params :message.sync="message" >
```

这样我们就可以在子组件中，使用下面来修改了，但注意父组件的改了，子组件的还是这个。

```javascript
this.$emit("update:message",null);
```

### \[\_21\_] mixin混入实现组件配置复用（data,methods,生命周期函数 ....）

定义一个混入对象：

mixin.js

```javascript
export const commonData = {
    data: {
        name: '大聪明'
    },
    methods: {
        showName() {
            alert("大聪明")
        }
    },
    mounted() {
        console.log("mixin：挂载完成了~");
    }
}
```

在组件中引用：

```javascript
import { commonData } from "./mixin.js"; //【1】导入对象

export default {
  name: "App",
  data() {
    return {
    };
  },
  methods: {
  },
  
  mixins: [commonData],  //【2】混入
};

```

> 混入后，这个组件就有了混入对象的name值，showName方法，mounted生命周期函数，注意如果组件的与混入对象冲突了就按组件的，唯独生命周期函数，且都执行，顺序是先混入再组件的。

混入分为局部混入与全局混入，上面是局部混入。全局混入:

main.js：全局混入 `Vue.mixin({<混入对象>})`

```javascript
import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false
Vue.mixin({
  data() {
    return {
      name: '小庄'
    }
  },
  mounted() {
    console.log('mixin：挂载完成~')
  }
})

new Vue({
  render: h => h(App),
}).$mount('#app')

```

### \[\_22\_] 使用“插件”丰富Vue功能

1.  功能：用于增强Vue &#x20;
2.  本质：包含install方法的一个对象，install的第一个参数是Vue，第二个以后的参数是插件使用者传递的数据 &#x20;
3.  定义插件（见下 src/plugin.js） &#x20;
4.  使用插件：Vue.use()

plugin.js ：写一个插件

```javascript
import { mixin } from './mixin'
export default {
    install(Vue, a, b, c) {//接收Vue构造函数与use时传入的其它参数 2~
        console.log(a, b, c) //1 2 3
        //全局混入
        Vue.mixin(mixin)
        //往Vue的原型对象中加入一个方法（vm,vc就都能用了）
        Vue.prototype.showMsg = function() {}
        

    }
} 
```

main.js：使用插件

```javascript
import Vue from 'vue'
import App from './App.vue' 
import plugin from './plugin'  //导入
Vue.config.productionTip = false

Vue.use(plugin, 1, 2, 3); //安装
new Vue({
  render: h => h(App),
}).$mount('#app')

```

### \[\_23\_] scoped 样式域

1.  作用：让样式在局部生效，防止冲突 &#x20;
2.  写法：\<style scoped> &#x20;
    Vue中的webpack并没有安装最新版，导致有些插件也不能默认安装最新版，如 npm i less-loader\@7，而不是最新版

演示：组件A与组件B内容是一样的，但style中样式的颜色不一样，将这两个组件都注册在App组件中，如果组件 的style标签不加`scoped`属性，那么后面的会覆盖前面组件有冲突的样式，假设在组件B加了，该在B中的style样式只会在B组件中起作用，实现方法如下：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16591729206591659172919714.png)

> 如何在组件的style中声明写的是less呢，首先默认是不支持的，我们需要安装`less-loader`,   Vue中的webpack并没有安装最新版，导致有些插件也不能默认安装最新版，如 npm i less-loader\@7，而不是最新版。&#x20;
>
> ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16591739939371659173993817.png)

### \[ *+*] Todo-List案例

-   src/App.vue
    ```vue
    <template>
      <div id="root">
        <div class="todo-container">
          <div class="todo-wrap">
            <MyHeader :addTodo="addTodo" />
            <MyList
              :todos="todos"
              :updateTodo="updateTodo"
              :deleteTodo="deleteTodo"
            />
            <MyFooter :todos="todos" :allCheck="allCheck" :clearDone="clearDone" />
          </div>
        </div>
      </div>
    </template>

    <script>
    import MyHeader from "./components/MyHeader";
    import MyList from "./components/MyList";
    import MyFooter from "./components/MyFooter.vue";

    export default {
      name: "App",
      data() {
        return {
          todos: [
            { id: "001", title: "吃饭", done: false },
            { id: "002", title: "睡觉", done: true },
            { id: "003", title: "打豆豆", done: false },
          ],
        };
      },
      methods: {
        //添加todo
        addTodo(todoObj) {
          this.todos.unshift(todoObj);
        },
        //修改todo完成状态
        updateTodo(todoId) {
          for (let i = 0; i < this.todos.length; i++) {
            if (this.todos[i].id == todoId) {
              this.todos[i].done = !this.todos[i].done;
              // console.log(this.todos[i]);
              console.log(this.todos);
              break;
            }
          }
        },
        //删除某个todo
        deleteTodo(todoId) {
          let delIndex = -1;
          //找在todo中的index
          for (let i = 0; i < this.todos.length; i++) {
            if (this.todos[i].id == todoId) {
              delIndex = i;
              break;
            }
          }
          if (delIndex != -1) {
            //找到了，准备删掉
            this.todos.splice(delIndex, 1);
          }
          // console.log("app del todo: ", this.todos);
        },
        //全选或全取消操作
        allCheck() {
          let countDone = this.todos.reduce(
            (sum, item) => sum + (item.done ? 1 : 0),
            0
          );
          let isAllDone = countDone == this.todos.length && this.todos.length != 0;
          if (!isAllDone) {
            this.todos.map((item) => {
              item.done = true;
            });
          } else {
            this.todos.map((item) => {
              item.done = false;
            });
          }
        },
        //清除已完成任务
        clearDone() {
          let newTodos = [];
          this.todos.map((item) => {
            if (!item.done) {
              newTodos.push(item);
            }
          });
          this.todos = newTodos;
        },
      },
      components: { MyHeader, MyList, MyFooter },
    };
    </script>

    <style>
    /*base*/
    body {
      background: #fff;
    }
    .btn {
      display: inline-block;
      padding: 4px 12px;
      margin-bottom: 0;
      font-size: 14px;
      line-height: 20px;
      text-align: center;
      vertical-align: middle;
      cursor: pointer;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2),
        0 1px 2px rgba(0, 0, 0, 0.05);
      border-radius: 4px;
    }
    .btn-danger {
      color: #fff;
      background-color: #da4f49;
      border: 1px solid #bd362f;
    }
    .btn-danger:hover {
      color: #fff;
      background-color: #bd362f;
    }
    .btn:focus {
      outline: none;
    }
    .todo-container {
      width: 600px;
      margin: 0 auto;
    }
    .todo-container .todo-wrap {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    </style>
    ```
-   src/components/MyHeader.vue
    ```vue

    <template>
      <div class="todo-header">
        <input
          type="text"
          placeholder="请输入你的任务名称，按回车键确认"
          v-on:keyup.enter="genTodo($event)"
        />
      </div>
    </template>

    <script>
    import { nanoid } from "nanoid";
    export default {
      name: "MyHeader",
      props: {
        addTodo: Function,
      },
      methods: {
        genTodo(e) {
          //添加，  需要 npm i nanoid
          let newTodo = { id: nanoid(), title: e.target.value, done: false };
          this.addTodo(newTodo);
          e.target.value = "";
        },
      },
    };
    </script>

    <style scoped>
    /*header*/
    .todo-header input {
      width: 560px;
      height: 28px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
      padding: 4px 7px;
    }
    .todo-header input:focus {
      outline: none;
      border-color: rgba(82, 168, 236, 0.8);
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075),
        0 0 8px rgba(82, 168, 236, 0.6);
    }
    </style>
    ```
-   src/components/MyList.vue
    ```vue
    <template>
      <ul class="todo-main">
        <MyItem
          v-for="todo in todos"
          :key="todo.id"
          :todo="todo"
          :updateTodo="updateTodo"
          :deleteTodo="deleteTodo"
        />
      </ul>
    </template>

    <script>
    import MyItem from "./MyItem";

    export default {
      name: "MyList",
      components: { MyItem },
      props: {
        todos: Array,
        updateTodo: Function,
        deleteTodo: Function,
      },
    };
    </script>

    <style scoped>
    /*main*/
    .todo-main {
      margin-left: 0px;
      border: 1px solid #ddd;
      border-radius: 2px;
      padding: 0px;
    }
    .todo-empty {
      height: 40px;
      line-height: 40px;
      border: 1px solid #ddd;
      border-radius: 2px;
      padding-left: 5px;
      margin-top: 10px;
    }
    </style>
    ```
-   src/components/MyItem.vue
    ```vue
    <template>
      <li>
        <label>
          <!-- 如下代码也能实现功能，但是不太推荐，因为有点违反原则，因为修改了props -->
          <!-- <input type="checkbox" v-model="todo.done"/> -->
          <input
            type="checkbox"
            :checked="todo.done"
            v-on:change="todoChange(todo.id)"
          />
          <span>{{ todo.title }}</span>
        </label>
        <button class="btn btn-danger" v-on:click="goDel()">删除</button>
      </li>
    </template>

    <script>
    export default {
      name: "MyItem",
      props: {
        todo: Object,
        updateTodo: Function,
        deleteTodo: Function,
      },
      methods: {
        todoChange(todoId) {
          this.updateTodo(todoId);
        },
        //deleteTodo
        goDel() {
          this.deleteTodo(this.todo.id);
        },
      },
    };
    </script>

    <style scoped>
    /*item*/
    li {
      list-style: none;
      height: 36px;
      line-height: 36px;
      padding: 0 5px;
      border-bottom: 1px solid #ddd;
    }
    li label {
      float: left;
      cursor: pointer;
    }
    li label li input {
      vertical-align: middle;
      margin-right: 6px;
      position: relative;
      top: -1px;
    }
    li button {
      float: right;
      display: none;
      margin-top: 3px;
    }
    li:before {
      content: initial;
    }
    li:last-child {
      border-bottom: none;
    }
    li:hover {
      background-color: #ddd;
    }
    li:hover button {
      display: block;
    }
    </style>
    ```
-   src/components/MyFooter.vue
    ```vue
    <template>
      <div class="todo-footer">
        <label>
          <!-- <input type="checkbox" :checked="isAll" @change="checkAll"/> -->
          <input type="checkbox" :checked="isAllDone" v-on:change="allControl()" />
        </label>
        <span>
          <span>已完成{{ countDone }}</span> / 全部{{ todos.length }}
        </span>
        <button class="btn btn-danger" @click="clearDone()">清除已完成任务</button>
      </div>
    </template>

    <script>
    export default {
      name: "MyFooter",
      props: {
        todos: Array,
        allCheck: Function,
        clearDone: Function,
      },
      computed: {
        countDone() {
          return this.todos.reduce((sum, item) => sum + (item.done ? 1 : 0), 0);
        },
        isAllDone() {
          return this.countDone == this.todos.length && this.todos.length != 0;
        },
      },
      methods: {
        allControl() {
          this.allCheck();
        },
      },
    };
    </script>

    <style scoped>
    /*footer*/
    .todo-footer {
      height: 40px;
      line-height: 40px;
      padding-left: 6px;
      margin-top: 5px;
    }
    .todo-footer label {
      display: inline-block;
      margin-right: 20px;
      cursor: pointer;
    }
    .todo-footer label input {
      position: relative;
      top: -1px;
      vertical-align: middle;
      margin-right: 5px;
    }
    .todo-footer button {
      float: right;
      margin-top: 5px;
    }
    </style>
    ```

### \[ *+*] 本地存储XXXStorage

存储内容大小一般支持 5MB 左右（不同浏览器可能还不一样） &#x20;
浏览器端通过`sessionStorage`和`localStorage`属性来实现本地存储机制，两者统称为WebStorage &#x20;
相关API &#x20;

-   `xxxStorage.setItem('key', 'value')`该方法接受一个键和值作为参数，会把键值对添加到存储中，如键名存在，则更新其对应的值 &#x20;
-   `xxxStorage.getItem('key')`该方法接受一个键名作为参数，返回键名对应的值 &#x20;
-   `xxxStorage.removeItem('key')`该方法接受一个键名作为参数，并把该键名从存储中删除 &#x20;
-   `xxxStorage.clear()`该方法会清空存储中的所有数据 &#x20;

备注 ：

-   SessionStorage存储的内容会随着浏览器窗口关闭而消失 &#x20;
-   LocalStorage存储的内容，需要手动清除才会消失 &#x20;
-   xxxStorage.getItem(xxx)如果 xxx 对应的 value 获取不到，那么getItem()的返回值是null &#x20;
-   JSON.parse(null)的结果依然是null

**使用本地存储优化Todo-List案例**

todos来源于localStorage

深度侦测todos，当改变时将todos保存到localStorage中

app.vue：

```vue
<template>
  <div id="root">
    <div class="todo-container">
      <div class="todo-wrap">
        <MyHeader :addTodo="addTodo" />
        <MyList
          :todos="todos"
          :updateTodo="updateTodo"
          :deleteTodo="deleteTodo"
        />
        <MyFooter :todos="todos" :allCheck="allCheck" :clearDone="clearDone" />
      </div>
    </div>
  </div>
</template>

<script>
import MyHeader from "./components/MyHeader";
import MyList from "./components/MyList";
import MyFooter from "./components/MyFooter.vue";

export default {
  name: "App",
  data() {
    return {
      //如果没有要给一个空数组，不然为null，那是会报错的
      todos: JSON.parse(localStorage.getItem("todos")) || [],
    };
  },
  methods: {
    //添加todo
    addTodo(todoObj) {
      this.todos.unshift(todoObj);
    },
    //修改todo完成状态
    updateTodo(todoId) {
      for (let i = 0; i < this.todos.length; i++) {
        if (this.todos[i].id == todoId) {
          this.todos[i].done = !this.todos[i].done;
          // console.log(this.todos[i]);
          console.log(this.todos);
          break;
        }
      }
    },
    //删除某个todo
    deleteTodo(todoId) {
      let delIndex = -1;
      //找在todo中的index
      for (let i = 0; i < this.todos.length; i++) {
        if (this.todos[i].id == todoId) {
          delIndex = i;
          break;
        }
      }
      if (delIndex != -1) {
        //找到了，准备删掉
        this.todos.splice(delIndex, 1);
      }
      // console.log("app del todo: ", this.todos);
    },
    //全选或全取消操作
    allCheck() {
      let countDone = this.todos.reduce(
        (sum, item) => sum + (item.done ? 1 : 0),
        0
      );
      let isAllDone = countDone == this.todos.length && this.todos.length != 0;
      if (!isAllDone) {
        this.todos.map((item) => {
          item.done = true;
        });
      } else {
        this.todos.map((item) => {
          item.done = false;
        });
      }
    },
    //清除已完成任务
    clearDone() {
      let newTodos = [];
      this.todos.map((item) => {
        if (!item.done) {
          newTodos.push(item);
        }
      });
      this.todos = newTodos;
    },
  },
  components: { MyHeader, MyList, MyFooter },
  watch: {
    //使深度侦测属性，不然勾选todo不会侦测到，就不会存储，就不会完成保存todos的数据
    todos: {
      deep: true,
      handler(newTodos) {
        localStorage.setItem("todos", JSON.stringify(newTodos));
      },
    },
  },
};
</script>

<style>
/*base*/
body {
  background: #fff;
}
.btn {
  display: inline-block;
  padding: 4px 12px;
  margin-bottom: 0;
  font-size: 14px;
  line-height: 20px;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2),
    0 1px 2px rgba(0, 0, 0, 0.05);
  border-radius: 4px;
}
.btn-danger {
  color: #fff;
  background-color: #da4f49;
  border: 1px solid #bd362f;
}
.btn-danger:hover {
  color: #fff;
  background-color: #bd362f;
}
.btn:focus {
  outline: none;
}
.todo-container {
  width: 600px;
  margin: 0 auto;
}
.todo-container .todo-wrap {
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
}
</style>
```

### \[\_24\_] 自定义事件（子传父）

1.  一种组件间通信的方式，适用于：子组件 ===> 父组件
2.  使用场景：子组件想给父组件传数据，那么就要在父组件中给子组件绑定自定义事件（事件的回调在A中）
3.  绑定自定义事件

    a 第一种方式，在父组件中`<Demo @事件名="方法"/>`或`<Demo v-on:事件名="方法"/>`

    b 第二种方式，在父组件中 `this.$refs.Xxx.$on('事件名',方法)`
    ```vue
    <Demo ref="demo"/>
    ......
    mounted(){
       this.$refs.demo.$on('atguigu',this.test)
    }
    ```
    c 若想让自定义事件只能触发一次，可以使用`once`修饰符，或`$once`方法(\$on = > \$once)&#x20;
4.  触发自定义事件`this.$emit('事件名',数据) `
5.  解绑自定义事件`this.$off('事件名') `
6.  组件上也可以绑定原生DOM事件，需要使用native修饰符  `@click.native="show"`
    上面绑定自定义事件，即使绑定的是原生事件也会被认为是自定义的，需要加native，加了后就将此事件给组件的根元素
7.  &#x20;注意：通过`this.$refs.XXX.$on('事件名',回调函数)` 绑定自定义事件时，回调函数要么配置在methods中，要么用箭头函数，否则 this 指向会出问题

使用自定义事件事件优化Todo-List案例

只要是子父传的（A→B），而不是多级的这种（A→B→C），就使用自定义事件（子传父）。

### \[\_25\_] Bus & 消息订阅与发布 （多级与兄弟传递）

#### \[\_25.1\_] Bus

一种可以在任意组件间通信的方式，本质上就是一个对象，它必须满足以下条件 &#x20;

1.  所有的组件对象都必须能看见他
2.  这个对象必须能够使用`$on`、`$emit`、`$off`方法去绑定、触发和解绑事件

**1）定义全局事件总线Bus**

**方式一：使用vc**

main.js

```javascript
import Vue from 'vue'
import App from './App.vue'
Vue.config.productionTip = false
//将vc 放在 Vue的原型对象上 作为bus
Vue.use(plugin, 1, 2, 3);
const VC = Vue.extend({});
let vc = new VC();
Vue.prototype.$bus = vc;

new Vue({
  render: h => h(App)
}).$mount('#app')

```

**方式二：使用vm**

```javascript
import Vue from 'vue'
import App from './App.vue'
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
  beforeCreate() { //将vm 在beforeCreate这个时机放在Vue的原型对象上
    Vue.prototype.$bus = this;
  }

}).$mount('#app')

```

**2）使用Bus**（请看下图）

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16593461964381659346195721.png)

**使用Bus解决 “Todo-List案例”孙组件给App组件发送事件问题**

。。。

#### \[\_25.2\_] 发布与订阅（用的不多）

消息订阅(subscribe )与发布（pubsub）消息订阅与发布是一种组件间通信的方式，适用于任意组件间通信&#x20;

使用步骤：

1.  安装pubsub：`npm i pubsub-js`
2.  引入：`import pubsub from 'pubsub-js'`
3.  订阅（接收数据）：A组件想接收数据，则在A组件中订阅消息，订阅的回调留在A组件自身`pubsub.subscribe('xxx',this.demo)`
    ```vue
    export default {
        methods: {
            //第一个参数是订阅名，但不用
            demo(msgName, data) {...}
        }
        ...
        mounted() {
          this.pid = pubsub.subscribe('xxx',this.demo)
        }
    }
    ```
4.  发布（改送数据）：`pubsub.publish('xxx',data)  ` //注意只能有data一个参数数据项！！
    最好在beforeDestroy钩子中，使用`pubsub.unsubscribe(pid)` 取消订阅

> 为什么在Vue的比较少用，首先Vue已经有Bus了，完全可以不用"发布与订阅"这个。

### \[\_26\_] \$nextTick

`this.$nextTick(<回调函数>)`在下一次DOM更新结束后执行其指定的回调 &#x20;
使用时机：当改变数据后，要基于更新后的新DOM进行某些操作时，要在nextTick所指定的回调函数中执行。

使用示例：

使用 \$nextTick 优化 Todo-List

```javascript
edit() {
      this.isEdit = true;
      // console.log(this.$refs.inputEdit.value);
      this.$nextTick(function () {
        this.$refs.inputEdit.focus();
      });
    },
```

解析：`this.isEdit = true;` 会让文本==> input, 紧接着要获取该input的焦点，但有一个问题，DOM的渲染是函数执行完再一起渲染的，但`this.$refs.inputEdit.focus();`要在input显示后就需要执行。我们可以使用`setTimeout` 也可以实现，但不推荐，推荐使用`$nextTick` ，它会在下次DOM更新完成后执行，所以`$nextTick`也算是一个生命周期勾子了。

### \[\_27\_] 过渡与动画

Vue封装的过度与动画：在插入、更新或移除DOM元素时，在合适的时候给元素添加样式类名

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16594023194621659402319243.png)

写法 &#x20;

1）写好标签

1.  使用`<transition>`包裹要过度的元素，如果有多个元素，则需要使用`<transition-group>`，且每个元素都要指定`key`值，
2.  配置`name`属性
3.  要让页面一开始就显示动画，需要添加`appear`

```vue
//给多个添加相同的动画, 一定要用 <transition-group>标签 
<transition-group
  name="todo"
  appear
>
  <MyItem v-for="todo in todos" :key="todo.id" :todo="todo" />
</transition-group>
//给一个添加动画, 用 <transition>标签即可 

<transition
  name="todo"
  appear
>
  <li>todo-title</li>
</transition>
```

2）准备好样式 &#x20;

-   元素进入的样式 &#x20;
    ⅰ`v-enter` 进入的起点 &#x20;
    ⅱ`v-enter-active` 进入过程中 &#x20;
    ⅲ`v-enter-to` 进入的终点 &#x20;
-   元素离开的样式ⅰv-leave 离开的起点 &#x20;
    ⅱ`v-leave-active` 离开过程中 &#x20;
    ⅲ`v-leave-to` 离开的终点

注意事项：如果写了name的值，就是`XXX-enter-active`或`XXX-leave-active`否则，使用默认的`v-enter-active`或`v-leave-active`

```css
.todo-enter-active {
  animation: 1s todo linear;
}
.todo-leave-active {
  animation: 1s todo reverse;
}
@keyframes todo {
  from {
    transform: translateX(100%);
  }
  to {
    transform: translateX(0px);
  }
}
```

3）效果演示：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659403023814动画.apng)

**使用第三方动画库Animate.css**

[官网](https://animate.style/ "官网")

1.  依赖
    ```bash
    npm install animate.css --save
    ```
2.  在要使用的文件中
    ```vue
    import 'animate.css';
    ```
3.  使用：`name="animate__animated animate__bounce"`是固定的，然后`enter-active-class`与`leave-active-class`属性是固定要有的，值就是效果。且遵循多组使用`<transition-group>` ，单个使用`<transition>`即可。

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16594035003121659403500174.png)
    ```vue
    <ul class="todo-main">
        <transition-group
          name="animate__animated animate__bounce"
          appear
          enter-active-class="animate__backInRight"
          leave-active-class="animate__backOutRight"
        >
          <MyItem v-for="todo in todos" :key="todo.id" :todo="todo" />
        </transition-group>
      </ul>
    ```
4.  演示效果

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659403649162动画.apng)

### \[\_28\_] axios & 跨域

异步请求介绍：

`XHR`：现代浏览器，最开始与服务器交换数据，都是通过XMLHttpRequest对象。它可以使用JSON、XML、HTML和text文本等格式发送和接收数据。

好处： 不重新加载页面的情况下更新网页 在页面已加载后从服务器请求/接收数据 在后台向服务器发送数据。

缺点： 使用起来也比较繁琐，需要设置很多值。 早期的IE浏览器有自己的内置对象，这样需要写兼容代码判断是否为XMLHttpRequest对象。

-   演示：
    ```javascript
    if (window.XMLHttpRequest) { // model browser
      xhr = new XMLHttpRequest()
    } else if (window.ActiveXObject) { // IE 6 and older
      xhr = new ActiveXObject('Microsoft.XMLHTTP')
    }
    xhr.open('POST', url, true)
    xhr.send(data)
    xhr.onreadystatechange = function () {
      try {
        // TODO 处理响应
        if (xhr.readyState === XMLHttpRequest.DONE) {
          // XMLHttpRequest.DONE 对应值是 4
          // Everything is good, the response was received.
          if (xhr.status === 200) {
            // Perfect!
          } else {
            // There was a problem with the request.
            // For example, the response may hava a 404 (Not Found)
            // or 500 (Internal Server Error) response code.
          }
        } else {
          // Not ready yet
        }
      } catch (e) {
        // 通信错误的事件中（例如服务器宕机）
        alert('Caught Exception: ' + e.description)
      }
    }
    ```

`ajax`：jQuery里的\$.ajax。 为了方便操作dom并避免一些浏览器兼容问题，产生了jquery， 它里面的AJAX请求也兼容了不同的浏览器，可以直接使用.get、.pist。它就是对XMLHttpRequest对象的一层封装

优点： 对原生XHR的封装，做了兼容处理，简化了使用。 增加了对JSONP的支持，可以简单处理部分跨域。

缺点： 如果有多个请求，并且有依赖关系的话，容易形成回调地狱。 本身是针对MVC的编程，不符合现在前端MVVM的浪潮。 ajax是jQuery中的一个方法。如果只是要使用ajax却要引入整个jQuery非常的不合理。

**`axios`**:Axios是一个基于promise的HTTP库，可以用在浏览器和 node.js 中。它本质也是对原生XMLHttpRequest的封装，只不过它是Promise的实现版本，符合最新的ES规范。

优点：

1.  从浏览器中创建XMLHttpRequests
2.  从 node.js 创建 http 请求
3.  支持 Promise API
4.  拦截请求和响应
5.  转换请求数据和响应数据
6.  取消请求
7.  自动转换 JSON 数据
8.  客户端支持防止CSPRF
9.  提供了一些并发请求的接口

缺点： 只持现代代浏览器.

> `async/await ` 将`async`放在函数前面，会将函数返回的结果封装在promise中，`await ` 等待的是promise的结果。`await ` 必须配合promise使用。
>
> ```javascript
> let fun = new Promise((resolve, reject) => {
>   resolve("11")
> })
>
> let fun2 = async function () {
>   return "22";
> }
>
> let data1 = await fun; //直接是promise
> let data2 = await fun2(); //将"async"放在前面，会将函数返回的结果封装在promise中，调用后返回promise
> console.log(data1, data2)
> ```

**演示**：

使用axios要引入库

axios库`npm install axios`

然后使用：

```javascript
axios({
    method: 'post',
    url: '/userlist/all',
    data: {
      id: '1',
      page:1,
      limit: 20
    }
  })
  .then(res => console.log(res))
  .catch(err => console.log(err))
```

`fetch` fetch跟axios都是promise风格

get请求

```javascript
fetch('http://example.com/movies.json')
  .then(response => response.json())
  .then(data => console.log(data));

```

post请求

```javascript
const update = {
  title: 'A blog post by Kingsley',
  body: 'Brilliant post on fetch API',
  userId: 1,
};

const options = {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify(update),
};

fetch('https://jsonplaceholder.typicode.com/posts', options)
  .then(data => {
    if (!data.ok) {
      throw Error(data.status);
    }
    return data.json();
  }).then(update => {
    console.log(update);
    // {
    //
    // title: 'A blog post by Kingsley',
    //
    // body: 'Brilliant post on fetch API',
    //
    // userId: 1,
    //
    // id: 101
    // };
  }).catch(e => {
    console.log(e);
  });

```

`vue-resource` 是一个与axios非常相似的插件。（不推荐，因为axios更好，至少在vue中）

安装：`npm i vue-resource`

安装插件：在main.js中写`Vue.use(vueResource)`

\# 这样，Vue与VueComponent的实例都有了一个对象 `$http` 相当于axios

axios的用法：

```javascript
import axios from "axios";
...
axios.get(...)

```

vue-resource的用法：

```vue
this.$http.get(...)  //其中this是Vue或VueComponent的实例
```

#### \[ *+*] github Search Users案例

`public/index.html`：

```javascript
<!DOCTYPE html>
<html lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link rel="icon" href="<%= BASE_URL %>favicon.ico">
  <link rel="stylesheet" href="<%= BASE_URL %>css/bootstrap.css">
 
  <title>
    <%= htmlWebpackPlugin.options.title %>
  </title>
</head>

<body>
  <noscript>
    <strong>We're sorry but <%= htmlWebpackPlugin.options.title %> doesn't work properly without JavaScript enabled.
        Please enable it to continue.</strong>
  </noscript>
  <div id="app"></div>
  <!-- built files will be auto injected -->
</body>

</html>
```

`src/main.js`

```javascript
import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
  beforeCreate() {
    Vue.prototype.$bus = this
  }
}).$mount('#app')

```

`src/App.vue`

```vue
<template>
  <div id="app">
    <Search></Search>
    <List></List>
  </div>
</template>

<script>
import Search from "./components/Search";
import List from "./components/List";
export default {
  name: "App",
  components: { Search: Search, List: List },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

```

`src/components/Search.vue`

```vue
<template>
  <section class="jumbotron">
    <h3 class="jumbotron-heading">Search Github Users</h3>
    <div>
      <input v-model="keyWord" v-on:keyup.enter="search()" />&nbsp;
      <button v-on:click="search()">Search</button>
    </div>
  </section>
</template>

<script>
import axios from "axios";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Search",
  data() {
    return {
      keyWord: "",
    };
  },
  methods: {
    search() {
      //搜索中
      this.$bus.$emit("searchDataAndStatus", {
        items: [],
        status: {
          init: false,
          loading: true,
          error: "",
        },
      });
      //搜索成功或失败
      axios.get(`https://api.github.com/search/users?q=${this.keyWord}`).then(
        (resources) => {
          this.$bus.$emit("searchDataAndStatus", {
            items: resources.data.items,
            status: {
              loading: false,
              error: "",
            },
          });
        },
        (error) => {
          this.$bus.$emit("searchDataAndStatus", {
            items: [],
            status: {
              loading: false,
              error: error.message,
            },
          });
        }
      );
    },
  },
};
</script>
```

`src/components/List.vue`

```vue
<template>
  <div class="row">
    <!-- 展示用户列表 -->
    <div class="card" v-for="item in items" :key="item.login">
      <a target="_blank" :href="item.html_url">
        <img :src="item.avatar_url" style="width: 100px" />
      </a>
      <p class="card-text">{{ item.login }}</p>
    </div>
    <!-- 展示欢迎词 -->
    <p v-show="status.init">你好，吊毛~</p>
    <!-- 展示加载中 -->
    <p v-show="status.loading">数据加载中...</p>
    <!-- 展示错误信息 -->
    <p v-show="status.error.length">{{ status.error }}</p>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "List",
  data() {
    return {
      items: [],
      status: {
        init: true,
        loading: false,
        error: "",
      },
    };
  },
  mounted() {
    //接收搜索组件给的数据
    this.$bus.$on("searchDataAndStatus", (searchDataAndStatus) => {
      this.items = searchDataAndStatus.items;
      this.status = { ...this.status, ...searchDataAndStatus.status };
    });
  },
};
</script>

<style scoped>
.album {
  min-height: 50rem; /* Can be removed; just added for demo purposes */
  padding-top: 3rem;
  padding-bottom: 3rem;
  background-color: #f7f7f7;
}
.card {
  float: left;
  width: 33.333%;
  padding: 0.75rem;
  margin-bottom: 2rem;
  border: 1px solid #efefef;
  text-align: center;
}
.card > img {
  margin-bottom: 0.75rem;
  border-radius: 100px;
}
.card-text {
  font-size: 85%;
}
</style>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659527393963动画.apng)

#### \[\_28.1\_]  CORS 跨域问题

> 同源策略：
>
> 对于同源策略，在这里我就不多累赘叙述了，简单来说，如果以下三项：**同一协议**、**同一域名**、**同一端口**但凡有一项不满足，浏览器就会把 `No 'Access-Control-Allow-Origin' header is present on the requested resource`甩你一脸。

解决方法：

1.  `cors` 在后端解决，在请求头加一些东西
2.  `jsonp` 利用script标签src，这种方式只能get请求
3.  使用代理服务器

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16595262869681659526286450.png)
    -   nginx
    -   vue-cli  [点击去学习>>](https://cli.vuejs.org/zh/config/#devserver "点击去学习>>")

        **方式一：**

        在vue.config.js中添加如下配置
        ```javascript
        module.exports = {
          devServer:{
            proxy:"http://localhost:5000"
          }
        }
        ```
        说明 &#x20;
        1\. 优点：配置简单，请求资源时直接发给前端（8080）即可 &#x20;
        2\. 缺点：不能配置多个代理，不能灵活的控制请求是否走代理 &#x20;
        3\. 工作方式：若按照上述配置代理，当请求了前端不存在的资源时，才会将请求会转发给服务器 （优先匹配前端资源）

        **方式二：**

        编写vue.config.js配置具体代理规则
        ```javascript
        module.exports = {
          devServer: {
              proxy: {
              '/api1': {                          // 匹配所有以 '/api1'开头的请求路径
                target: 'http://localhost:5000',  // 代理目标的基础路径
                pathRewrite: {'^/api1':''},        // 代理往后端服务器的请求去掉 /api1 前缀
                ws: true,                          // WebSocket
                changeOrigin: true,
                
              },
              '/api2': {
                target: 'http://localhost:5001',
                pathRewrite: {'^/api2': ''},
                changeOrigin: true
              }
            }
          }
        }
        /*
           changeOrigin设置为true时，服务器收到的请求头中的host为：localhost:5000
           changeOrigin设置为false时，服务器收到的请求头中的host为：localhost:8080
           changeOrigin默认值为true
        */
        ```
        说明 &#x20;
        1\. 优点：可以配置多个代理，且可以灵活的控制请求是否走代理 &#x20;
        2\. 缺点：配置略微繁琐，请求资源时必须加前缀
        > 实战版：注意，在使用axios时，不要配置，就“/” 就好，否则配置的“前端跨域代理无效”
        >
        > ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/images/16681742318621668174231481.png)
        >
        > vue.config.js:  在这里再配置baseURL
        >
        > 下面将`ws: false`就可以解决报错：WebSocketClient.js?5586:16 WebSocket connection to 'ws\://10.117.4.114:8080/ws' failed: Invalid frame header
        >
        > ```javascript
        > const { defineConfig } = require('@vue/cli-service')
        > module.exports = defineConfig({
        >   transpileDependencies: true,
        >   lintOnSave:false,
        >   // 配置代理跨域
        >   devServer: {
        >     proxy: {
        >       '/': {
        >         target: 'http://127.0.0.1:8081',
        >         ws: false, // 设置为flase后控制台就不会一直请求报错  
        >         changeOrigin: true
        >       }
        >     }
        >   }
        > })
        > ```
        \`\`\`java

### \[\_29\_] 插槽-允许组件差异

> **插槽**
>
> 在子组件内可以定义 `<slot>`插槽：让父组件可以向子组件指定位置插入html结构，也是一种组件间通信的方式，  适用于 父组件 ===> 子组件 &#x20;
>
> **分类：**
>
> 默认插槽、具名插槽、作用域插槽

#### \[\_29.1\_] 默认插槽

> 默认插槽：这很简单，就是在子组件中写个插槽，用来占位，然后父组件在该子组件的标签内写一些html，就会替换子组件的的默认插槽。

子组件：

```vue
<template>
  <div id="type">
    <h1>游戏</h1>
     <slot>这是默认内容1</slot> 
  </div>
</template>
```

父组件：数据来源是父组件

```vue
<template>
  <div id="app">
    <Type>
       <ul>
        <li v-for="game in games" :key="game">{{ game }}</li>
      </ul> 
    </Type>
  </div>
</template>

<script>
import Type from "./components/Type";
export default {
  name: "App",
  data() {
    return {  games: ["红色警戒", "忍者神龟"]  };
  },
  components: { Type: Type },
};
</script>



```

> **可能要解决的问题**:  error  Component name "Nav" should always be multi-word  vue/multi-word-component-names &#x20;
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/07/1667802390801.png)

#### \[\_29.2\_] 具名插槽-允许定义多个插槽

> 具名插槽：允许定义多个插槽，但父组件html的插入，但如果没有一个名字，那就乱，所以在子组件定义插槽时，给插槽起一个名字
>
> 在子组件中：
>
> `<slot name="XXX">这是默认内容1</slot>`
>
> 在父组件中：
>
> 在组件标签根标签下，写`slot="XXX"`

子组件：有多个具有名字的插槽

```vue
<template>
  <div id="type">
    <h1>游戏</h1>
     <slot name="list">这是默认内容1</slot>
    <slot name="msg">这是默认内容2</slot> 
  </div>
</template>
```

父组件：这里数据来源是父组件

```vue
<template>
  <div id="app">
    <Type>
       <ul slot="list">
        <li v-for="game in games" :key="game">{{ game }}</li>
      </ul>
      <a href="http://www.baidu.com" slot="msg">更多>></a> 
    </Type>
  </div>
</template>

<script>
import Type from "./components/Type";
export default {
  name: "App",
  data() {
    return {  games: ["红色警戒", "忍者神龟"]  };
  },
  components: { Type: Type },
};
</script>



```

#### \[\_29.3\_] 作用域插槽-让数据来源于子组件

> 作用域插槽：在子组件插槽标签`<slot >`中，可以 `:数据名="数据"`
>
> 父组件：请看下面的父组件代码

下面写的是作用域插槽同时也是具有插槽

子组件：数据来源于子组件

```vue
<template>
  <div id="type">
    <h1>游戏</h1>
     <slot name="list" :games="games">这是默认内容1</slot>
    <slot name="msg" :msg="msg">这是默认内容2</slot>
    <slot name="tag" tag="游戏">这是默认内容3</slot> 
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Type",
  data() {
    return {
       games: ["红色警戒", "忍者神龟"],
      msg: "更多游戏~", 
    };
  },
};
</script>

<style>
#type {
  width: 150px;
  height: 200px;
  border: 1px solid red;
  background: pink;
  text-align: center;
}
</style>
```

父组件：

```vue
<template>
  <div id="app">
    <Type>
       <!---第一种：作用域插槽，使用slot & slot-scope -->
      <template slot="list" slot-scope="{ games }">
        <ul>
          <li v-for="game in games" :key="game">{{ game }}</li>
        </ul>
      </template>
      
      <!---第二种：作用域插槽，使用 v-slot  -->
      <template v-slot:msg="{ msg }">
        <a href="http://www.baidu.com">{{ msg }}</a>
      </template>
      
      <!---第三种：作用域插槽，不使用<templatte>标签实现  -->
      <a href="" slot="tag" slot-scope="{ tag }">{{ tag }}</a> 
    </Type>
  </div>
</template>

<script>
import Type from "./components/Type";
export default {
  name: "App",
  data() {
    return {};
  },
  components: { Type: Type },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
```

### \[\_30\_] Vuex 状态管理

> \*\*Vuex 是什么  \*\*
> 概念：专门在Vue中实现`集中式状态（数据）管理`的一个`Vue插件`，对Vue应用中多个组件的共享状态进行集中式的管理（读/写），也是一种`组件间通信的方式`，且适用于任意组件间通信

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16596271530641659627152450.png)

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16596271760641659627175199.png)

> **Vuex的工作原理**：安装Vuex后，在Vue与VueComponent的实例中有一个`$store`的对象，里面就有`Actions` 、`Mutations` 、`State` 这三个对象 `{}`  ,不过Actions与Mutations对象存放的是方法，而State存放的才是k-v数据（状态），直接操作Store中的任意对象。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16596274360631659627435229.png)

#### \[\_30.1\_] Vuex的基本使用

1.  初始化数据`actions`，配置`mutations`、`state`

    安装Vuex：`npm i vuex`

    创建文件`src/store/index.js `
    ```javascript
    import Vue from 'vue'
    import Vuex from 'vuex'  // 引入Vuex

    Vue.use(Vuex)  // 这个不能在main.js中执行（不管放在main.js的哪里都不行），因为要在创建vuex实例时执行

    // 准备actions——用于响应组件中的动作
    const actions = {}
    // 准备mutations——用于操作数据（state）
    const mutations = {}
    //相当于vue中的计算属性，只不过这操作的是state中的数据
    const getters = {}
    // 准备state——用于存储数据
    const state = {}

    // 创建并暴露store
    export default new Vuex.Store({
        actions,
        mutations,
        state,
        getters
    })
    ```
    main.js：将Vuex放在所有vue以及VueComponent的实例中
    ```javascript
    import Vue from 'vue'
    import App from './App.vue'
     import store from './store'  // 引入store （默认引入里面的index.js）
     
    Vue.config.productionTip = false


    new Vue({
      el: '#app',
       store,   
      render: h => h(App),

    })
    ```
2.  创建 `actions`与`mutations`的操作方法，与`state`、`getters`数据
    ```javascript
    import Vue from 'vue'
    import Vuex from 'vuex'  // 引入Vuex

    Vue.use(Vuex)  // 应用Vuex插件

    // 准备actions——用于响应组件中的动作
    const actions = {
        _addItem(context, value) {
            context.commit('addItem', value)
        }
    }
    // 准备mutations——用于操作数据（state）
    const mutations = {
        addItem(state, value) {
            state.items.unshift(value)
        }
    }
    const getters = {
        _items(state) {
            return state.items
        }
    }
    // 准备state——用于存储数据
    const state = {
        items: [{ id: "001", name: "大聪明" }],
    }

    // 创建并暴露store
    export default new Vuex.Store({
        actions,
        mutations,
        state,
        getters
    })
    ```
3.  操作
    -   组件中读取vuex中的数据
        -   `$store.state.数据`      相当于vue中的data数据
        -   `$store.getters.数据`  相当于vue中的计算属性
    -   组件中修改vuex中的数据：
        -   `$store.dispatch('action中的方法名',数据)`  相当于后端的service层，若有网络请求或其他业务逻辑，即不知道操作量时。
        -   `$store.commit('mutations中的方法名',数据) ` 相当于后端的dao层，如果知道要修改的具体值时，直接操作这个。
        > 若没有网络请求或其他业务逻辑，组件中也可越过actions，即不写dispatch，直接编写commit
4.  映射在组件：组件如何快速地将上面四项内容（state、getters、actions、mutations）映射到组件中使用呢？

    那就需要用到vue提供的四个map映射函数了。
    ```vue
    import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
    export default {
      // eslint-disable-next-line vue/multi-word-component-names
      name: "List",
      computed: {
        ...mapState(["items"]),  //数组方式，在这里与在store的名字一致时
        ...mapGetters({ items_: "_items" }), //对象方式，如果想要与store中的名字不一样
      },
      methods: {
        ...mapActions(["_addItem"]),
        ...mapMutations(["addItem"]),
      }
    };
    ```

#### \[\_30.2\_] 模块化+名称空间&#x20;

> 即将store的内容进行数据隔离

1.  创建`store对象`  ，下面创建两个store对象

    `src/store/stores/countAbout.js`
    ```javascript
    export default {
        namespaced: true,  // 开启命名空间
        state: { msg: '' },
        mutations: {
            toMsg(state, value) {
                state.msg = value
            }
        },
        actions: {

        },
        getters: {
            bigSum(state) { return state.sum * 10 }
        }
    }
    ```
    `src/store/stores/presonAbout.js`
    ```javascript
    import axios from "axios"
    import { nanoid } from 'nanoid'
    export default {
        namespaced: true,  // 开启命名空间
        state: {
            //this.$store.state.personAbout.items;
            items: []
        },
        mutations: {
            /*
                this.$store.commit("personAbout/_randomItem", {
                    id: nanoid(),
                    name: "测试",
                });
            */
            _randomItem(state, value_item) {
                state.items.unshift(value_item)
            }
        },
        actions: {
            /*this.$store.dispatch(
                "personAbout/randomItem",
                "http://api.uixsj.cn/hitokoto/get?type=social"
            );*/
            randomItem(context, value_url) {
                axios.get(value_url).then(resource => {
                    let item = { id: nanoid(), name: resource.data }
                    context.commit('_randomItem', item)
                }, error => {
                    alert("Add item faild!", error);
                })
            }
        },
        getters: {
            //this.$store.getters["personAbout/_items"];
            _items(state) {
                console.log('getters')
                return state.items
            }
        }
    }
    ```
2.  将store对象放在Vuex中

    `src/store/index.js`
    ```javascript
    import Vue from 'vue'
    import Vuex from 'vuex'  // 引入Vuex
    Vue.use(Vuex)  // 应用Vuex插件

    import countAbout from './stores/countAbout'
    import personAbout from './stores/personAbout'

    // 创建并暴露store
    export default new Vuex.Store({
        modules: {
            countAbout, personAbout
        }
    }) 
    ```
3.  将Vuex放在Vue中

    `src/main.js`
    ```javascript
    import Vue from 'vue'
    import App from './App.vue'
    import store from './store'  // 引入store

    Vue.config.productionTip = false


    new Vue({
      el: '#app',
      store,
      render: h => h(App),

    })
    ```
4.  组件操作指定的store

    操作state：`this.$store.state.<名称空间>.<数据名>;`

    操作getter：`this.$store.getters["名称空间/数据名"];`

    操作actions：

    `this.$store.dispatch("名称空间/方法名",[方法参数])`

    操作mutations：

    `this.$store.commit("名称空间/方法名",[方法参数])`
5.  快速将store映射到组件中
    ```javascript
    import { mapActions, mapMutations,mapState, mapGetters  } from "vuex";
    ...
    export default {
      methods: {
        ...mapMutations("personAbout", { _add: "_randomItem" }),
        ...mapActions("personAbout", { add: "randomItem" }),
      },
      computed: {
        ...mapState("personAbout", ["items"]),
        ...mapGetters("personAbout", ["_items"]),
      },
    }

    ```

案例：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16596919988381659691998466.png)

[下载代码>>](https://github.com/18476305640/fileBox/raw/master/%E6%9D%82%E9%A1%B9/vuex-demo.zip "下载代码>>")

### \[\_31\_] VueRouter 路由

> VueRouter：vue是一个插件库，专为用来实现SPA应用（single page web application， 单页面应用），
>
> 单页面应用：
>
> 1、整个应用只有一个完整的页面 &#x20;
> 2、点击页面中的导航链接不会刷新页面，只会做页面的局部更新 &#x20;
> 3、数据需要通过ajax请求获取
>
> 路由（route）与路由器(router)：
>
> 1、一个路由就是一组映射关系（key - value），key是路径，value可能是component或者function
>
> 2、路由器就是管理路由的，是VueRouter的实例
>
> 3、抛开vue，路由有前端路由与后端路由

#### \[\_31.1\_] **VueRouter的基本使用**

1.  安装vue-router，命令`npm i vue-router` 注意版本高vue一个版本（使用vue 2.X时  npm i vue-router\@3）
2.  编写`src/router/index.js`&#x20;
    ```javascript
    import Vue from 'vue'
    import VueRouter from 'vue-router'
    Vue.use(VueRouter)


    export default new VueRouter({
        routes: [
            {
                path: '/about',
                component: About
            },

        ]
    })
    ```
3.  放在Vue中

    `src/main.js`
    ```javascript
    import Vue from 'vue'
    import App from './App.vue'
    import router from './router'
    Vue.config.productionTip = false

    new Vue({
      render: h => h(App),
      router
    }).$mount('#app')

    ```
4.  开始使用

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659778216921动画.apng)

    编写`src/router/index.js` 该文件专门用于创建整个应用的路由器
    ```javascript
    import Vue from 'vue'
    import VueRouter from 'vue-router'
    Vue.use(VueRouter)

    import About from '../pages/About'
    import Home from '../pages/Home'
    export default new VueRouter({
        routes: [
            {
                path: '/home',
                component: Home,
            },
            {
                path: '/about',
                component: About
            },

        ]
    })
    ```
    `src/App.vue`:
    1.  `<router-link></router-link>`浏览器会被替换为`a`标签 &#x20;
        `active-class`可配置高亮样式
    2.  `<router-view></router-view>` 就是路由k-v的v对应的组件容器。
    ```vue
    <template>
      <div id="app">
        <div id="nav">
          <router-link class="nav-item" active-class="active" to="/home"
            >Home</router-link
          >
          <router-link class="nav-item" active-class="active" to="/about"
            >About</router-link
          >
        </div>
        <div>
          <router-view></router-view>
        </div>
      </div>
    </template>

    <script>
    export default {
      name: "App",
      components: {},
    };
    </script>

    <style scoped>
    #nav {
      width: 100%;
      height: 40px;
      line-height: 37px;
      background: #f3f3f3;
      text-align: left;
      margin-bottom: 10px;
    }
    .nav-item {
      text-decoration: none;
      display: inline-block;
      margin: 0px 5px;
      color: rgb(150, 150, 150);
    }
    .active {
      border-bottom: 3px solid #d9d9d9;
      color: black;
    }
    </style>

    ```
    `src/pages/About.vue`：
    1.  路由组件通常存放在`pages`文件夹，一般组件通常存放在`components`文件夹
    2.  通过切换，“隐藏”了的路由组件，默认是被销毁掉的，需要的时候再去挂载
    3.  每个组件都有自己的\$route属性，里面存储着自己的路由信息，整个应用只有一个router，可以通过组件的\$router属性获取到
    ```vue
    <template>
      <div>About 关于我们</div>
    </template>

    <script>
    export default {
      // eslint-disable-next-line vue/multi-word-component-names
      name: "About",
    };
    </script>

    <style>
    </style>
    ```
    `src/pages/Home.vue`
    ```vue
    <template>
      <div>
        <a>新闻</a>
      </div>
    </template>

    <script>
    export default {
      // eslint-disable-next-line vue/multi-word-component-names
      name: "Home",
    };
    </script>

    <style scoped>
    </style>
    ```

> 默认路由：/ 时就重定向到 home 路由上
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/11/07/1667800150802.png)

#### \[\_31.2\_] 多级路由

> 多级路由又叫嵌套路由，一般不超过4，5层

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659780087947动画.apng)

在上面案例的基本上修改：

修改：`src/router/index.js`，配置路由规则，使用children配置项

```javascript
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import About from '../pages/About'
import Home from '../pages/Home'
import News from '../pages/News'
import Message from '../pages/Message'
export default new VueRouter({
    routes: [
        {
            path: '/home',
            component: Home,
            children: [ //添加子路由
                {
                    name: 'news',
                    path: 'news',
                    component: News


                },
                {
                    path: 'message',
                    component: Message
                },
            ]
        },
        {
            path: '/about',
            component: About
        },

    ]
})
```

修改：`src/pages/Home.vue`

主要是改变url，让VueRouter侦测到，使` <router-view>`视图组件改变。

```vue
<template>
  <div>
    <a>新闻</a>
    <div class="left-nav">
      <router-link active-class="active" to="/home/news">新闻</router-link>

      <router-link active-class="active" to="/home/message">消息</router-link>
    </div>
    <div class="right-content">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Home",
};
</script>

<style scoped>
.active {
  background: pink;
}
.left-nav {
  display: flex;
  flex-direction: column;
  width: 100px;
  border-right: 1px solid #f3f3f3;
  position: absolute;
  bottom: 0px;
  top: 50px;
  background: #f2f2f2;
}
.left-nav > * {
  text-decoration: none;
  margin: 2.5px 5px 2.5px 5px;
  padding: 2px;
}
.right-content {
  position: absolute;
  bottom: 0px;
  top: 50px;
  left: 120px;
  right: 0px;
  border-left: 1px solid #f3f3f3;
}
</style>
```

新增：`src/pages/News.vue`

```vue
<template>
  <div>
    <div>新闻</div>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "News"
};
</script>

<style>
</style>
```

新增：`src/pages/Message.vue`

```vue
<template>
  <div>消息</div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Message",
};
</script>

<style>
</style>
```

#### \[\_31.3\_] 命名路由

1.  作用：可以简化路由的跳转 &#x20;
2.  如何使用

    a. 给路由命名
    ```vue
    {
      path:'/demo',
      component:Demo,
      children:[
        {
          path:'test',
          component:Test,
          children:[
            {
              name:'hello' // 给路由命名
              path:'welcome',
              component:Hello,
            }
          ]
        }
      ]
    }
    ```
    b. 简化跳转
    ```vue
    <!--简化前，需要写完整的路径 -->
    <router-link to="/demo/test/welcome">跳转</router-link>

    <!--简化后，直接通过名字跳转 -->
    <router-link :to="{name:'hello'}">跳转</router-link>

    ```

#### \[\_31.4\_] 传参：query传参

根据url的传统方式传参，http\://localhost:8080/#/home/news?XXX=XXX

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659781648057动画.apng)

1.  对`<router-link>` 标签的`to`进行修改。加入query参数，跳转到News组件中。
    ```vue
    <!--普通方式 -->
    <router-link active-class="active" :to="`/home/news?title=${title}`">
    新闻</router-link>

     
    <!--对象的方式-->
    <router-link active-class="active" 
    :to="{
    name:'hello',
    query:{
        title:title
    }" >
     新闻</router-link>  

    ```
2.  在News组件中可以这样获取title参数
    ```vue
    $route.query.title
    ```

#### \[\_31.5\_] 传参：params传参

作为路径的一部分进行传参，如：[http://localhost:8080/#/home/news/台湾被包围演习！](http://localhost:8080/#/home/news/台湾被包围演习！ "http://localhost:8080/#/home/news/台湾被包围演习！")

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659780087947动画.apng)

1、配置路由：路由的`path`修改为 `path: 'news/:title',` title就是参数

```javascript
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import About from '../pages/About'
import Home from '../pages/Home'
import News from '../pages/News'
import Message from '../pages/Message'
export default new VueRouter({
    routes: [
        {
            path: '/home',
            component: Home,
            children: [
                {
                    name: 'news',
                    path: 'news/:title',
                    component: News
                },
                {
                    path: 'message',
                    component: Message
                },
            ]
        },
        {
            path: '/about',
            component: About
        },

    ]
})
```

2、参数传递：

```vue
<router-link active-class="active" :to="`/home/news/${title}`" >新闻</router-link>
```

注意：使用这种方式，会存在，你active 失效问题。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659795822070动画.apng)

or

使用对象的形式，但在params方式中这种，必须要使用`命名路由` ,否则是不行。

```vue
      <router-link
        active-class="active"
        :to="{
          name: 'news',
          params: {
            title: title,
          },
        }"
        >新闻</router-link>
```

#### \[\_31.6\_] 路由props配置——简化在模板中获取\$route中的属性值

1.  配置路由
    ```javascript
    {
        name: 'news',
        path: 'news/:title',
        component: News,
        //第一种写法：props值为对象，该对象中所有的key-value的组合最终都会通过props传给Detail组件
        //但这样不好，值是固定的！！
        // props:{title:'台湾被包围演习！'}
      
        //第二种写法：props值为布尔值，为true时，则把路由收到的所有params参数通过props传给Detail组件
        // props:true
        
        //第三种写法：props值为函数，该函数返回的对象中每一组key-value都会通过props传给Detail组件
        props($route) {
            return {
                title: $route.params.title
            }
        }
    },
    ```
2.  组件中获取
    ```vue
    <template>
      <div>
        <!-- 简化前-->
        <!-- <div>新闻：{{ $route.params.title }}</div> -->
        
        <!-- 简化后-->
        <div>新闻：{{ title }}</div>
      </div>
    </template>

    <script>
    export default {
      // eslint-disable-next-line vue/multi-word-component-names
      name: "News",
      props: ["title"]
    };
    </script>

    <style>
    </style>
    ```

#### \[\_31.7\_] Vue Router replace &  Vue Router push

作用：控制路由跳转时操作浏览器历史记录的模式

1、浏览器的历史记录有两种写入方式：push和replace

push是追加历史记录 &#x20;
replace是替换当前记录，路由跳转时候默认为push方式

2、使用 **：**

a. 非编程式：

```vue
<!-- push模式，默认-->
<router-link ...>News</router-link>

<!-- 开启replace -->
<router-link replace ...>News</router-link>
```

b. 编程式/编程式导航：

作用：不借助\<router-link>实现路由跳转，让路由跳转更加灵活

`this.$router.push({})`	内传的对象与\<router-link>中的to相同

`this.$router.replace({})`&#x9;

`this.$router.forward()`	前进

`this.$router.back()`		后退

`this.$router.go(n)`		可前进也可后退，n为正数前进n，为负数后退

```javascript
this.$router.push({
  name:'xiangqing',
  params:{
    id:xxx,
    title:xxx
  }
})

this.$router.replace({
  name:'xiangqing',
  params:{
    id:xxx,
    title:xxx
  }
})
```

> 总结：浏览记录本质是一个栈，默认push，点开新页面就会在栈顶追加一个地址，后退，栈顶指针向下移动，改为replace就是不追加，而将栈顶地址替换

#### \[\_31.8\_] 缓存路由组件

作用：让不展示的路由组件保持挂载，不被销毁

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659788988838动画.apng)

加入 `<keep-alive>` 标签后

```vue
// 缓存一个路由组件
<keep-alive include="News"> // include中写想要缓存的组件名，不写表示全部缓存
    <router-view></router-view>
</keep-alive>

// 缓存多个路由组件
<keep-alive :include="['News','Message']"> 
    <router-view></router-view>
</keep-alive>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659789183125动画.apng)

#### \[\_31.9\_] VueRouter两个生命周期函数

```vue
<template>
  <div>
    <div>新闻：{{ $route.params.title }}</div>

    缓存测试：<input type="text" />
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "News",
  activated() {
    console.log("News激活了");
  },
  deactivated() {
    console.log("News切换了");
  },
};
</script>

<style>
</style>
```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659796806971动画.apng)

#### \[\_31.10\_] 路由守卫：全局路由守卫

> 作用：对路由进行权限控制&#x20;

全局路由守卫在路由配置中写，全局路由守卫有`全局前置路由守卫` 、`全局后置路由守卫`：

`router.beforeEach((to, from, next) => {...})`

`router.afterEach((to, from) => {...})`

`src/router/index.js`

```javascript
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import About from '../pages/About'
import Home from '../pages/Home'
import News from '../pages/News'
import Message from '../pages/Message'

const router = new VueRouter({
    routes: [
        {
            path: '/home',
            component: Home,
            children: [
                {
                    name: 'news',
                    path: 'news/:title',
                    component: News,
                    props($route) {
                        return {
                            title: $route.params.title
                        }
                    }
                },
                {
                    path: 'message',
                    component: Message,
                    meta: {
                        isAuth: true, //是否进行权限访问控制
                        title: '消息' //该路由的标题名
                    },
                },
            ]
        },
        {
            path: '/about',
            component: About
        },

    ]
})
router.beforeEach((to, from, next) => {//全局前置守卫！
    console.log("全局前置守卫！");
    if (to.meta.isAuth) {
        if (localStorage.getItem('token') == 'token123') {
            next()
        } else {
            alert("401禁止访问！");
        }

    } else {
        next();
    }

})
router.afterEach((to, from) => {//全局后置守卫！
    console.log("全局后置守卫！");
    console.log("afterEach=>", from, to);
    document.title = to.meta.title || to.name || 'VueRouter'
})
export default router
```

#### \[\_31.11\_] 路由守卫：独享守卫

> 作用：对路由进行权限控制&#x20;

在路由配置中写，独享守卫只有`前置路由守卫` ：

`beforeEnter(to, from, next) {...}`

`src/router/index.js`

```javascript
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import About from '../pages/About'
import Home from '../pages/Home'
import News from '../pages/News'
import Message from '../pages/Message'

const router = new VueRouter({
    routes: [
        {
            path: '/home',
            component: Home,
            children: [
                {
                    name: 'news',
                    path: 'news/:title',
                    component: News,
                    props($route) {
                        return {
                            title: $route.params.title
                        }
                    }
                },
                {
                    path: 'message',
                    component: Message,
                    meta: {
                        isAuth: true,
                        title: '消息'
                    },
                    beforeEnter(to, from, next) { //独享守卫，只有前置
                        console.log("独享守卫！（只有前置）");
                        console.log('beforeEnter', to, from)
                        if (localStorage.getItem('token') === 'token123') {
                            next()
                        } else {
                            alert('暂无权限查看')
                        }
                        next();
                    }
                },
            ]
        },
        {
            path: '/about',
            component: About
        },

    ]
})
export default router
```

#### \[\_31.12\_] 路由守卫：组件内路由守卫

组件内路由守卫分为`进入组件前`、`离开组件前`

`beforeRouteEnter(to, from, next) {...}`

`beforeRouteLeave(to, from, next) {...}`

XXX.vue

```javascript
<template>
  <div>
    <div>新闻：{{ $route.params.title }}</div>

    缓存测试：<input type="text" />
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "News",
  props: ["title"],

  beforeRouteEnter(to, from, next) {
    console.log("News：组件内守卫——进入组件前");
    console.log(to, from);
    next();
  },
  beforeRouteLeave(to, from, next) {
    console.log("News：组件内守卫——离开组件前");
    console.log(to, from);
    next();
  },
};
</script>

<style>
</style>
```

#### \[\_31.13\_] VueRouter的两种工作模式

1.  对于一个`ur1`来说，什么是`hash`值？

    \# 及其后面的内容就是hash值
2.  `hash`值不会包含在HTTP请求中，即：hash值不会带给服务器
3.  **两种工作模式**
    -   hash模式（默认）
        a. 地址中永远带着#号，不美观
        b. 若以后将地址通过第三方手机app分享，若app校验严格，则地址会被标记为不合法
        c. 兼容性较好
    -   history模式
        a. 地址干净，美观
        b. 兼容性和hash模式相比略差
        c. 应用部署上线时需要后端人员支持，解决刷新页面服务端404的问题

`src/router/index.js` router配置文件中：

```javascript
const router =  new VueRouter({
  mode:'history',
  routes:[...]
})

export default router
```

### \[\_32\_] Vue项目部署

1.  npm run build  #dist目录就是打包来的将 vue转为html+css+js
2.  创建服务器
    1.  创建并进入一个文件夹
    2.  npm init
    3.  npm i express&#x20;
    4.  在目录创建一个`server.js` 文件
        ```javascript
        const express = require('express')
        const app = express();
        app.use(express.static(__dirname + "/static"))

        app.get("/hello", (req, res) => {
            res.send({
                msg: '你好呀！兄弟，欢迎访问！'
            })
        })
        app.listen(5200, (err) => {
            if (!err) console.log("服务准备就绪！");
        })
        ```
    5.  创建一个static目录，将vue项目打包的`dist`下 目录文件放在 该目录下。
    6.  `node ./server.js `启动服务器。即可访问 [http://localhost:5200/](http://localhost:5200/ "http://localhost:5200/")
3.  存在的问题

    history工作模式时，会出现如下问题：

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/1659837950137动画.apng)

    解决：

    npm install --save connect-history-api-fallback

    修改`server.js`
    ```javascript
    const express = require('express')
    var history = require('connect-history-api-fallback');
    const app = express();
    app.use(history())
    app.use(express.static(__dirname + "/static"))

    app.get("/hello", (req, res) => {
        res.send({
            msg: '你好呀！兄弟，欢迎访问！'
        })
    })
    app.listen(5200, (err) => {
        if (!err) console.log("服务准备就绪！");
    })
    ```
    刷新的问题解决了！

[接着学Vue>>](https://www.bilibili.com/video/BV1Zy4y1K7SH?p=136 "接着学Vue>>")

[Vue的干货](Vue的干货/Vue的干货.md "Vue的干货")
