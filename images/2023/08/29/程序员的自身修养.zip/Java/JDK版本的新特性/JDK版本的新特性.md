# JDK版本的新特性

### <1> JDK1.8的新特性

[https://www.bilibili.com/video/BV184411x7XA](https://www.bilibili.com/video/BV184411x7XA?spm_id_from=333.337.search-card.all.click "https://www.bilibili.com/video/BV184411x7XA")

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16552595822561655259581983.png)

#### \[\_1\_] Lambda表达式

Lambda的本质：作为接口的实例

Lambda的语法：参数列表( () ) 操作符(->) 方法体( {} )

Lambda的适用接口：函数式接口（只包含一个抽象方法的接口，称为函数式接口）

Lambda的示例说明：

```java
    @Test
    public void lamdba03() {
        //第一种：如果只有一个语句，直接写即可，不用写大括号{}；特别的，如果只有一个返回语句，那么就需要写值的表达式即可。
        Runnable runnable = ()-> System.out.println("Hello,world~");
        runnable.run();

        //第二种：由于类型推断，我们可以不用写参数的类型，只需要写参数名即可,且参数只有一个的时候，小括号也可以不用写
        Consumer<String> consumer = (str) -> {
            System.out.println(str);
        };
        consumer.accept("恭喜发财！");

    }
```

#### \[\_2\_] 函数式接口

1、只包含一个抽象方法的接口，称为函数式接口。

2、在java.util.function包下定义了Java8的丰富的函数式接口

3、函数式接口可以使用Lambda创建接口实例

4、加入`@FunctionalInterface` 声明的类，作用是检查是否当前接口是否为函数式接口

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16552828065091655282806151.png)

示例：以断定 型接口作示例

```java
package com.zhuangjie.jdk_study;
import org.junit.Test;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * 一个方法，传入一个字符数组，进行筛选符合的组成一个新数组返回
 */
public class _2_函数式接口 {
    @Test
    public void _函数式接口01() {
        List<String> strings = Arrays.asList("京东", "普京","鲸鱼");
        List<String> lisst = new _2_函数式接口().choose(strings, str -> str.contains("京"));
        System.out.println(lisst);


    }
    public List<String> choose(List<String> list, Predicate<String> consumer) {
        ArrayList<String> arrayList = new ArrayList<>();
        for (String unit:list ) {
            if (consumer.test(unit)) {
                arrayList.add(unit);
            }
        }
        return arrayList;
    }
}


```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16552922745091655292273588.png)

#### \[\_3\_] 方法引用

方法引用其实就是Lambda式，Lambda表达式，是直接写函数式接口的方法； 而方法引用是已经有适合的方法了，我们直接引用过来就好。引用的类与该函数式接口可以没有关系。但引用的方法是有要求的：

引用的方法与函数式接口的方法参数列表一致，在返回值上，如果接口方法有返回值，那要求一定引用的方法的返回值类型一致，但如果接口没有返回值，引用的方法的返回值就随便了

&#x20;<1>.使用格式：类（或对象）::方法名
&#x20;<2>.具体分为如下的三种情况：

```java
/**
          
         *1*      对象::非静态方法
         *2*      类::静态方法
                    1、方法引用：是为函数式接口创建一个实例，引用的方法作为函数式接口的唯一方法，来创建实例
                    2、引用的方法与函数式接口的方法没有必然的联系，但有一定的要求，就是引用的方法与函数式接口的方法参数列表一致，在返回值上，如果接口方法有返回值，那要求一定引用的方法的返回值类型一致，但如果接口没有返回值，引用的方法的返回值就随便了
                        示例1：普通引用
                             interface A {
                                void ingA(String str);
                             }
                             class B {
                                 //构造引用
                                 public void ingB(String str) {
                                 System.out.println(str);
                                 }
                             }
                             引用：
                             A study = new B()::ingB;
                        示例2：构造引用
                             interface A {
                                void ingA(String str);
                             }
                             class B {
                                 //构造引用
                                 public B(String str) {
                                 System.out.println(str);
                                 }
                             }
                             引用：
                             A study = B::new;

         *3*      类::非静态方法
                     interface A {
                        void ingA(B b1,B b2);
                     }
                     class B {
                         public void ingB(B b) {
                             System.out.println("大聪明正在学习");
                         }
                     }
                     引用：
                     A study = B::ingB;


         */
```

#### \[\_4\_] StreamAPI

像操作数据库一样操作集合，数组，I/O channel， 产生器generator 等。

Java 8 API添加了一个新的抽象称为流Stream，可以让你以一种声明的方式处理数据。

Stream 使用一种类似用 SQL 语句从数据库查询数据的直观方式来提供一种对 Java 集合运算和表达的高阶抽象。

Stream API可以极大提高Java程序员的生产力，让程序员写出高效率、干净、简洁的代码。

这种风格将要处理的元素集合看作一种流， 流在管道中传输， 并且可以在管道的节点上进行处理， 比如筛选， 排序，聚合等。

元素流在管道中经过中间操作（intermediate operation）的处理，最后由最终操作(terminal operation)得到前面处理的结果。

```text
+--------------------+       +------+   +------+   +---+   +-------+
| stream of elements +-----> |filter+-> |sorted+-> |map+-> |collect|
+--------------------+       +------+   +------+   +---+   +-------+
```

每一种操作都用线隔开了，方便看懂。

```java
package com.zhuangjie.jdk_study;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 获取流 - 中间操作 - 终止操作略略略-哈哈哈
 */
public class _4_Stream流 {
    public static void main(String[] args) {
        Staff user01 = new Staff("001", 23,20000.2);
        Staff user02 = new Staff("002",22, 40000.2);
        Staff user03 = new Staff("003", 23,50000.2);
        Staff user04 = new Staff("003", 33,50000.2);
        Staff[] users = {user01,user02,user03,user04};




        //数组创建流,在操作前要获取流
        Stream<Staff> array_stream = Arrays.stream(users); //数组获取流
        Stream<String> collection_stream = new ArrayList<String>().stream();//集合获取流

        //跳过第一个，找出2、3这二个——分页
        array_stream.skip(1).limit(2).forEach(System.out::println);
        System.out.println("----------------");
        //filter
        Arrays.stream(users).filter(e->e.getName()=="002").forEach(e -> System.out.println(e));

        System.out.println("----------------");
        //去重
        Stream<Staff> stream02 = Arrays.stream(users);
        stream02.distinct().forEach(System.out::println);
        System.out.println("----------------");
        //去重
        Stream<Staff> stream04 = Arrays.stream(users);
        //跳过第一个，找出2、3这二个——分页
        stream04.map(Staff::getName).forEach(System.out::println);

        System.out.println("----------------");
        //map与flatMap
        ArrayList<String> list1 = new ArrayList<>();
        list1.add("A组小张");
        list1.add("A组小王");
        ArrayList<String> list2 = new ArrayList<>();
        list2.add("B组小张");
        list2.add("B组小王");

        Stream<ArrayList<String>> nb = Stream.of(list1, list2);
        Stream<Stream<String>> streamStream1 = Stream.of(list1, list2).map(i -> i.stream()); //只是将String的数组转为
        Stream<String> stringStream2 = Stream.of(list1, list2).flatMap(i -> i.stream()); //合并

        System.out.println("----------------");
        //排序
        ArrayList<Staff> aList = new ArrayList<>();
        aList.add(new Staff("002",39,60000));
        aList.add(new Staff("003",45,90000));
        aList.add(new Staff("001",22,20000));

        aList.stream().sorted((o1,o2)-> o1.getAge() - o2.getAge()).forEach(e-> System.out.println(e));
        System.out.println("----------------");
        //聚合操作
        ArrayList<Staff> aList2 = new ArrayList<>();
        aList2.add(new Staff("002",39,60000));
        aList2.add(new Staff("003",45,90000));
        aList2.add(new Staff("001",22,20000));
        long count = aList2.stream().filter(e -> e.getAge() > 30).count(); //统计
        Staff staff01 = aList2.stream().max((o1, o2) -> o1.getAge() - o2.getAge()).get();//取最大
        Staff staff02 = aList2.stream().min((o1, o2) -> o1.getAge() - o2.getAge()).get();//取最大
        System.out.println(staff01);
        System.out.println("----------------");
        ArrayList<Staff> aList3 = new ArrayList<>();
        aList3.add(new Staff("002",39,60000));
        aList3.add(new Staff("003",45,90000));
        aList3.add(new Staff("001",22,20000));
        List<Staff> collect = aList3.stream().filter(e -> e.getAge() > 30).collect(Collectors.toList()); //收集成List中
        Set<Staff> collect02 = aList3.stream().filter(e -> e.getAge() > 30).collect(Collectors.toSet()); //收集成Set中
        System.out.println(collect02);
        System.out.println("-----------");
        //匹配
        boolean b = aList3.stream().anyMatch(e -> e.getName().contains("001"));
        System.out.println(b);

    }
}
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
class Staff {
    private String name;
    private int age;
    private double salary;

}


```

#### \[\_5\_] Optional

调用一个对象方法，如果这个对象为空时，会报空指针，我们使用Optional可以设置一个兜底的对象，当要调用的为空时，使用兜底的对象——尽量地防止空指针异常

```java
package com.zhuangjie.jdk_study;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Optional;

public class _5_Optional {
    public static void main(String[] args) {
        User user01 = null; //我们要调用的
        User user02 = new User("小庄"); //兜底的
        Optional<User> user1 = Optional.ofNullable(user01); //将要调用的对象进行包装为Optional
        User user = user1.orElse(user02); //加入兜底的
        System.out.println(user.getName());
    }

}
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
class User{
    private String name;
}

```

用法2：

```java
Optional
        .ofNullable(childNode) //放入对象
        .ifPresent(handle -> {handle.test();}); //如果存在，就调用对象的test方法
```
