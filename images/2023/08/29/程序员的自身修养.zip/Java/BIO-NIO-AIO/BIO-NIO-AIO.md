# BIO/NIO/AIO

## 1. BIO 一个连接一个线程

**BIO：** 一个连接一个线程，且是同步阻塞，即使客户端不做任何操作时，也要进行等待，这就造成了不必要的线程开销。也可以通过线程池来改善。

## 2. NIO轻操作：一对多（不像AIO考虑重操作）

**NIO**：一个请求一个线程，是同步非阻塞的，即客户端发送的连接请求都会注册到多路复用器上，多路复用器轮询到连接有I/O请求时才启动一个线程进行处理。

NIO方式适用于连接数目多且连接比较短（轻操作）的架构，比如聊天服务器，并发局限于应用
中，编程比较 复杂，JDK1 .4开始支持。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672294038092.png)

> **选择器：** Java NIO的选择器允许一个单独的线程来监视多个输入通道，你可以注册多个通道使用一个选择器，然后使用一个单独的线程来“选择”通道：这些通道里已经有可以处理的输入，或者选择已准备写入的通道。这种选择机制，使得一个单独的线程很容易来管理多个通道。

## 3. AIO重操作：多对多（异步耗时IO/主线程）

**AlO**：方式AIO是异步非阻塞，基于NIO，可以称之为NIO2.0

AIO适用于连接数目多且连接比较长（重操作）的架构，比如相册服务器，充分调用OS参与并
发操作，编程比较复杂，JDK7开始支持

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/1672294437422.png)

教程：[https://www.bilibili.com/video/BV1gz4y1C7RK](https://www.bilibili.com/video/BV1gz4y1C7RK "https://www.bilibili.com/video/BV1gz4y1C7RK")

学习文档：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/bio、nio、aio.pdf](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/bio、nio、aio.pdf "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/12/29/bio、nio、aio.pdf")

基本使用代码：[https://raw.githubusercontent.com/18476305640/typora/master/images/2022/12/29/IOs.zip](https://raw.githubusercontent.com/18476305640/typora/master/images/2022/12/29/IOs.zip "https://raw.githubusercontent.com/18476305640/typora/master/images/2022/12/29/IOs.zip")
