# JVM

### 黑马程序员JVM完整教程

## 前言

> 黑马程序员JVM完整教程
> b站链接：[https://www.bilibili.com/video/BV1yE411Z7AP?spm\_id\_from=333.337.search-card.all.click\&vd\_source=a1565026d150073a042e4cd0cc263851](https://www.bilibili.com/video/BV1yE411Z7AP?spm_id_from=333.337.search-card.all.click\&vd_source=a1565026d150073a042e4cd0cc263851 "https://www.bilibili.com/video/BV1yE411Z7AP?spm_id_from=333.337.search-card.all.click\&vd_source=a1565026d150073a042e4cd0cc263851")
> 配套资料：[https://pan.baidu.com/s/167mob33EfeD-on6dWrEWGQ](https://pan.baidu.com/s/167mob33EfeD-on6dWrEWGQ "https://pan.baidu.com/s/167mob33EfeD-on6dWrEWGQ") 提取码：bqob
>
> 快速下载：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/01/资料 解密JVM.zip](<https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/01/资料 解密JVM.zip> "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/01/资料 解密JVM.zip")
>
> **深入理解Java虚拟机 (周志明) (**[**z-lib.org**](http://z-lib.org "z-lib.org")**).epub**：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/03/深入理解Java虚拟机 (周志明) (z-lib.org).epub](<https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/03/深入理解Java虚拟机 (周志明) (z-lib.org).epub> "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/03/深入理解Java虚拟机 (周志明) (z-lib.org).epub")

## 引言

-   什么是JVM？ &#x20;
    &#x20;   Java Virtual Machine - java 程序的运行环境（java 二进制字节码的运行环境）。
-   好处： &#x20;
    -   一次编写，到处运行； &#x20;
    -   自动内存管理，垃圾回收功能； &#x20;
    -   数组下标越界检查； &#x20;
    -   多态。
-   比较：JVM JRE JDK &#x20;

    ![比较](https://img-blog.csdnimg.cn/f76af9c37eea4b7cbc9e5db8487c5ca4.png "比较")

    JVM：java虚拟机， 可以屏蔽java代码与底层虚拟机之间的关系 &#x20;

    JRE：java的运行时环境，在JVM的基础上结合一些基础类库 &#x20;

    JDK：java开发工具包，在JRE的基础上增加编译工具
-   常见的JVM： &#x20;

    ![常见JVM](https://img-blog.csdnimg.cn/3aaca9f8ab8242429ff2f591fbaa7f7a.png "常见JVM")
-   JVM的整体架构： &#x20;

    ![学习路线](https://img-blog.csdnimg.cn/b25fc032856d47d895c543575543f2ca.png "学习路线")

## 1. 内存结构

### 1. 1 程序计数器

-   Program Counter Register 程序计数器 ( 相当于计算机组成原理中的`PC寄存器` )
-   作用：记住下一条jvm指令的执行地址&#x20;

    ![](https://img-blog.csdnimg.cn/0b7e0b8c88ec411292e15b00f796ed94.png)
    > 上图解析：java源代码 通过编译生成class也就是jvm指令，每条指令左边都有一个号，程序计数器要存储的。刚开始时，程序计数器存储的下一条指令是`0`, 解释器去程序计数器中取出0对应的jvm指令，解释器会将该条jvm指令转为机器码，这样CPU就可以转为控制信号进行工作了。然后解释再从程序计数器中取（此时程序计数器存储的下一条是`3`） 重复刚才操作。
-   特点：
    -   是线程私有的
        -   CPU会为每个线程分配时间片，当前线程的时间片使用完以后，CPU就会去执行另一个线程中的代码
        -   程序计数器是每个线程所私有的，当另一个线程的时间片用完，又返回来执行当前线程的代码时，通过程序计数器可以知道应该执行哪一句指令
    -   不会存在内存溢出

### 1.2 虚拟机栈

### 1.2.1 定义与作用

-   Java Virtual Machine Stacks（Java虚拟机栈）
    -   每个线程运行时所需要的内存，称为虚拟机栈
    -   每个栈由多个栈帧（Frame）组成，对应着每次方法调用时所占用的内存
    -   每个线程只能有一个活动栈帧，对应着当前正在执行的那个方法

        ![](https://img-blog.csdnimg.cn/e2729f5352214f58a4496c39eacdc4be.png)

        ![](https://img-blog.csdnimg.cn/9646579aac7740e29a4ab3296c78f0f0.png)
-   问题辨析：
    1.  垃圾回收是否涉及栈内存？
        不需要。栈内存是一次次方法调用所产生的栈帧内存，栈帧内存在每一次方法调用后都会弹出栈，也就是说会被`自动的回收`掉，因此不需要垃圾回收来进行管理。
    2.  栈内存分配越大越好吗？
        不是。`物理内存大小一定，栈内存分配的越大，所能划分的线程越少。` 栈内存分配的大仅仅只能使得能够进行更多次的递归调用。
        > 栈内存大小默认是`1024k` (各平台默认都是一样的大小)  , 可以通过`-Xss1m` 这种进行设置。（官方文档：[https://docs.oracle.com/en/java/javase/11/tools/java.html#GUID-3B1CE181-CD30-4178-9602-230B800D4FAE](https://docs.oracle.com/en/java/javase/11/tools/java.html#GUID-3B1CE181-CD30-4178-9602-230B800D4FAE "https://docs.oracle.com/en/java/javase/11/tools/java.html#GUID-3B1CE181-CD30-4178-9602-230B800D4FAE")）
    3.  方法内的局部变量是否线程安全？
        如果方法内局部变量没有逃离方法的作用范围，它是线程安全的。
        如果是局部变量引用了对象，并逃离方法的作用范围，需要考虑线程安全。如静态变量、方法参数、方法返回值等。

### 1.2.2 栈内存溢出

栈内存溢出：`java.lang.StackOverflowError`

-   `栈帧过多`导致栈内存溢出：如没有终止条件的方法递归调用等。
    > 一个JSON序列化时，要序列化的类是一个部门类(`Dept`) , 部门类有一个员工数组（`List<Emp>`）, 这里关键的来了，每个员工类又有所属的部门类。这样的一个部门类进行序列化时，只会出现栈溢出异常（在Fastjson中默认会用\$进行引用，而不会出现异常）
    >
    > ```json
    > {"emps":[{"dept":{"$ref":"$"},"name":"小庄"},{"dept":{"$ref":"$"},"name":"大聪明"}],"name":"技术部"}
    > ```
    >
    > 在fastjson中想要演示出效果在序列化时：
    >
    > ```java
    > String json = JSON.toJSONString(obj, SerializerFeature.DisableCircularReferenceDetect);
    > ```
-   `栈帧过大`导致栈内存溢出

> 可以通过参数-Xss来控制程序栈的大小
>
> ![](https://img-blog.csdnimg.cn/17b7f6aaad7a4370a56b5c2a2b19c952.png)
>
> ![](https://img-blog.csdnimg.cn/c3cc9c43f80040059d5e8f07a1c73af8.png)

### 1.2.3 线程运行诊断

-   线程诊断：
    -   CPU占用高
        -   用`top`定位哪个进程对cpu的占用过高
        -   `ps H -eo pid,tid,%cpu | grep 进程id` ：用ps命令进一步定位是哪个线程引起的cpu占用过高（可以得到十进制的线程id）
        -   `jstack 进程id`：可以根据线程id（此时的线程id为十六进制，在匹配时需要将上一步得到的十进制的换算为十六进制） 找到有问题的线程，进一步定位到问题代码的源码行号
    -   死锁 （迟迟得不到运行结果）&#x20;
        使用jstack 进程id，在最后会有一些提示信息。

        ![](https://img-blog.csdnimg.cn/b0091a1d1c5349b19a88d09bd50a6d96.png)

### 1.3 本地方法栈

-   在java虚拟机调用一些本地方法时需要`给本地方法提供的内存空间`
    -   本地方法：由于java有限制，不可以直接与操作系统底层交互，所以需要一些用c/c++编写的本地方法与操作系统底层的API交互，java可以间接的通过本地方法来调用底层功能
-   举例：Object的clone()、hashCode()、notify()、notifyAll()、wait()等

    ![](https://img-blog.csdnimg.cn/6353f5a50fa34ea3a2859cb8b5a42340.png)

### 1.4 堆

### 1.4.1 定义

-   Heap堆：通过new关键字创建对象都会使用堆内存
-   特点
    -   它是线程共享的，堆中对象都需要考虑线程安全的问题
    -   有垃圾回收机制

### 1.4.2 堆内存溢出

堆内存溢出：**`Exception in thread "main" java.lang.OutOfMemoryError: Java heap space`**

堆内存大小可以通过`-Xmx8m` 这种方式进行设置。

### 1.4.3 堆内存诊断

#### jps工具

jps工具：查看当前系统中有哪些java进程 &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/b5081bd9fff84699800549938785f014.png "在这里插入图片描述")

#### jmap工具

jmap工具：查看某一时刻堆内存占用情况（基本信息）。

![在这里插入图片描述](https://img-blog.csdnimg.cn/19c969cfa83a4d5382d81f2f3d6e7c80.png "在这里插入图片描述")

![在这里插入图片描述](https://img-blog.csdnimg.cn/8ba7a49e72cc42b8bf3830d18587a3a8.png "在这里插入图片描述")

![在这里插入图片描述](https://img-blog.csdnimg.cn/9b851b5188e245d6ab7eb14cdf1543b1.png "在这里插入图片描述")

#### jconsole工具

jconsole工具：图形界面的，多功能的监测工具，可以`连续监测`  。

![在这里插入图片描述](https://img-blog.csdnimg.cn/91373fd180c149229cbd468a55527ec0.png "在这里插入图片描述")

#### jvisualvm工具 &#x20;

jvisualvm工具 : 可以截取某一时刻的快照（内存、线程），深入查看内存使用情况（可以查看类等信息）。

![在这里插入图片描述](https://img-blog.csdnimg.cn/a944e1bd60264ae0b136e03fdd75fdfe.png "在这里插入图片描述")

可以查看堆内存的具体信息：占用200多M内存 &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/9b0b3533f42544058a608f79cad7eb29.png "在这里插入图片描述")

查看占用内存最大的对象：ArrayList &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/16c168e979124851b5c9ef53da7b46c3.png "在这里插入图片描述")

ArrayList中的元素Student对象中包含的big属性占用1M内存，共有200个元素，占用200M内存 &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/744a1c4384664d7fb1799849518ba107.png "在这里插入图片描述")

对应源码： &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/2428b0bd17fb405d9e5bc593c369c167.png "在这里插入图片描述")

### 1.5 方法区

#### 1.5.1 定义

-   所有java虚拟机线程的共享区域
-   存储类的结构的相关信息，如运行时常量池、成员变量、方法数据、成员方法和构造器的代码等
-   方法区在虚拟机启动时创建，其逻辑上是堆的一个组成部分，但在实现时不同的JVM厂商可能会有不同的实现

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/26/1677373167319.psd)

#### 1.5.2 组成

> **注意：** 方法区是概念，而永久代是实现，在1.8后永久代由本地内存移到系统内存（除字符串常量池外），更名为元空间。 1.8后的方法区（元空间）大小是不限制的（当然我们可以用虚拟机参数设置）。

-   组成：以Oracle的HotSpot为例
    -   jdk1.6：`永久代，占用JVM内存空间`

        ![](https://img-blog.csdnimg.cn/fec2ca5dae4d49b69383b5fd756e1554.png)
    -   jdk1.8：`元空间，移出JVM内存（除StringTable），放入系统内存`

        ![](https://img-blog.csdnimg.cn/a265d968dfaa4eb1abb6db8b4030ef9d.png)

#### 1.5.3 方法区内存溢出

-   1.8以前会导致`永久代`内存溢出\*\*`java.lang.OutOfMemoryError: PernGen space`\*\*

    ![](https://img-blog.csdnimg.cn/c701dc1f38344062bfb7c96ea5590ac7.png)
-   1.8之后会导致`元空间`内存溢出：**`java.lang.OutOfMemoryError: Metaspace`**

    ![](https://img-blog.csdnimg.cn/4173b6ceef4c4485b3edb4097f57ff31.png)

    ![](https://img-blog.csdnimg.cn/4a5d5132d4f54b659e5192874dac6cd8.png)

#### 1.5.4 运行时常量池

![](https://img-blog.csdnimg.cn/52cb62a920344b8bace8aa02560a5d4d.png)

-   `常量池`：常量池，就是一张`表`，存储在 \*.class字节码文件中。，存储在 \*.class字节码文件中。`虚拟机指令根据这张常量表找到要执行的类名、方法名、参数类型、字面量等信息`

### 1.5.5 StringTable

#### StringTable特性

-   常量池(编译期产生)中的字符串仅是符号，第一次（运行时 , String a = "a"; ）用到时才将常量池中的a引用变为实例"a"（*延迟加载*）
-   利用串池的机制，来避免重复创建字符串对象
-   字符串变量拼接的原理是StringBuilder （JDK 1.8）
-   字符串**常量**拼接的原理是编译期优化
-   可以使用intern 方法，主动将串池中还没有的字符串对象放入串池
    -   1.8 intern方法： 将这个字符串对象尝试放入串池，如果有则并不会放入，如果没有则放入串池， 会把串池中的对象返回。
        ```java
        public class Demo1 {
            public static void main(String[] args) {
                String s1 = "a";
                String s2 = "b";
                String s3 = "ab";
                String ss = s1+s2; // (new StringBuilder()).append(s1).append(s2).toString()
                String s4 = ss.intern(); // 这里尝试将ss放入StringTable中，但失败了，因为已经存在“ab”了，返回的s4
                System.out.println(s3 == ss); // false
                System.out.println(s3 == s4); // true
            }
        }
        ```
    -   1.6 interm方法：将这个字符串对象尝试放入串池，如果有则并不会放入，如果没有会把此对象`复制一份`，放入串池， 会把串池中的对象返回
        ```java
        public class Demo2 {
            public static void main(String[] args) {
                String s1 = "a";
                String s2 = "b";
                String ss = s1+s2;
                String s4 = ss.intern(); // 这里ss转复制一份 ss' 放入StringTable中，再返回StringTable中的那份（s4）
                System.out.println(s4 == ss); // false
            }
        }

        ```

小练习：

```java
public class Demo1 {
    public static void main(String[] args) {
        String s1 = "a";  //编译得到的指令量ldc、astore_1 :  ldc就会将符号引用替换为实例，astore_1是存入局部变量
        String s2 = "b";
        String s3 = "ab";
        String s4 = s1+s2; //  (new StringBuilder()).append(s1).append(s2).toString()
        String s5 = "a"+"b"; // 在编译时优化，等同于  String s4 = "ab"
        System.out.println(s3 == s4); // false
        System.out.println(s3 == s5); // true
    }
}
```

#### StringTable位置

![](https://img-blog.csdnimg.cn/03968456d1eb4610b48f9bead9a55683.png)

-   jdk1.6时，StringTable是常量池的一部分，随常量池存储在永久代中；jdk1.7/jdk1.8时StringTable从永久代转移到了堆中。
-   原因：
    `永久代内存回收效率很低`，只有Full GC时才会`触发永久代的垃圾回收`，而Full GC只有在整个老年代的空间不足时才会触发，时机较晚。而StringTable使用频繁，其中存储着大量字符串常量，若其回收效率不高就会占用大量内存，导致永久代内存不足。因此jdk1.7 / jdk1.8开始将StringTable从永久代转移到了堆中，只需要Minor GC就会对用不到的字符串`进行堆垃圾回收`，减轻了字符串对内存的占用。

> **证明**：创建一个普通的java项目（不是maven）
>
> 1.8 配置虚拟机参数：-Xmx8m
>
> 1.6 配置虚拟机参数：-XX:MaxPermSize=8m
>
> 如何修改java版本？首先你有jdk1.6/1.8
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/26/1677396588966.png)
>
> 测试代码：
>
> ```java
> import java.util.ArrayList;
>
> public class Demo {
>     public static void main(String[] args) {
>         ArrayList<String> strings = new ArrayList<String>();
>         try {
>             for (int i = 0; i < 2000000; i++) {
>                 strings.add(String.valueOf(i).intern());
>             }
>         } catch (Exception e) {
>             e.printStackTrace();
>         } finally {
>             System.out.println(strings.size());
>         }
>     }
> }
>
> ```
>
> 测试结果：
>
> 1.8：Exception in thread "main" java.lang.OutOfMemoryError: Java heap space
>
> 1.6：Exception in thread "main" java.lang.OutOfMemoryError: PermGen space
>
> 结论：1.6 StringTable位置是在永久代（方法区），而1.8版本中 是在堆中（不再属于方法区）。

#### StringTable垃圾回收机制

-   StringTable在内存紧张时，会进行垃圾回收。

#### StringTable调优

-   须知：StringTable是一个哈希表，下面说的桶是哈希表中的数组元素。
-   优化1：调整`-XX:StringTableSize=桶个数`&#x20;

    StringTable是由HashTable实现的，所以可以适当增加HashTable桶的个数，来减少字符串放入串池所需要的时间。
-   优化2：考虑将字符串对象是否入池再存储。
    若字符串对象很多且`大量重复`，可以考虑使用`intern方法`将字符串入池，减少重复对象

### 1.6 直接内存

#### 1.6.1 定义

-   直接内存Direct Memory：
    -   常见于NIO操作时，用于数据缓冲区
    -   分配回收成本较高，但读写性能高
    -   不受JVM内存回收管理

#### 1.6.2 使用

-   文件读写流程：

    系统缓冲区的数据java不能直接使用，会再将其读入到java缓冲区，造成了不必要的数据的复制。

    ![](https://img-blog.csdnimg.cn/c219a6233b354e21889d59eac0492bef.png)
-   使用直接缓冲区：
    ```纯文本
    ByteBuffer.allocateDirect(内存大小)
    ```
    操作系统会划分一段内存，此部分内存是系统与java共享的，里边的数据系统与java都可以访问，少了一次缓冲区的复制操作，因此速度得到了成倍的提升。

    ![](https://img-blog.csdnimg.cn/3b35dab215ee47baab12de0c1e5fd862.png)

#### 1.6.3 分配和回收原理

-   直接内存的回收不是通过JVM的垃圾回收来释放的，而是使用了 `Unsafe 对象`完成直接内存的分配回收，并且回收需要`主动调用 freeMemory 方法`
-   ByteBuffer 的实现类内部，使用了 `Cleaner （虚引用）`来`监测 ByteBuffer 对象`，`一旦ByteBuffer 对象被垃圾回收`，那么就会由 `ReferenceHandler 线程`（监测虚引用对象）`通过 Cleaner 的 clean 方法自动调用 freeMemory` 来释放直接内存
-   具体过程：
    1.  使用
        ```java
        ByteBuffer.allocateDirect(内存大小)
        ```
        创建直接内存 &#x20;

        ![在这里插入图片描述](https://img-blog.csdnimg.cn/ac9ee2ddcb1f4e108b71504d72e6e8d5.png "在这里插入图片描述")
    2.  创建DirectByteBuffer对象 &#x20;
        ![在这里插入图片描述](https://img-blog.csdnimg.cn/475d43ae4c5745a8b9870776a897940c.png "在这里插入图片描述")

1.  cleaner的回调任务对象Deallocator中包含主动垃圾回收方法`unsafe.freeMemory` &#x20;

    ![](https://img-blog.csdnimg.cn/efdabda2ff6f498bba065803b2c6efe3.png)
2.  当ReferenceHandler 线程监测到cleaner关联的对象被回收后（this对象，即ByteBuffer），会自动触发cleaner对象的clean方法&#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/b96ffd58faed47229037ec8505b3a667.png "在这里插入图片描述")
3.  cleaner的回调任务对象Deallocator中包含主动垃圾回收方法`unsafe.freeMemory` &#x20;

> 综上，想要回收直接内容，就要回收ByteBuffer对象，但如果ByteBuffer对象一直无法回收，就会导致直接内存无法释放。我们可以手动gc ( `System.gc()` ) 方式回收，也可以 主动调用`unsafe.freeMemory`
>
> 但手动gc会导致性能下降，那如何显式禁用代码中写的System.gc()呢？`-XX:+DisableExplicitGC`

## 2. 垃圾回收

### 2.1 如何判断对象可以回收

### 2.1.1 引用计数

-   记录当前对象的引用次数，当引用次数为0时则进行回收。
-   缺点：当两个对象互相引用但并没有其他对象再引用它们时，其引用次数都为1，无法对其进行回收释放。

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/26/1677411161559.png)
-   java不采用引用计数法，而是采用可达性分析算法

### 2.1.2 可达性分析算法

-   JVM中的垃圾回收器通过可达性分析来探索所有存活的对象
-   扫描堆中的对象，看能否沿着GC Root对象为起点的引用链找到该对象，如果找不到，则表示可以回收
-   哪些对象可以作为GC Root？
    -   System Class：系统类 / 核心类
    -   Native Stack：在本地方法栈中JNI（即通常所说的Native方法）引用的对象。
    -   Thread：活动线程中使用的对象，即栈帧内的变量等引用的对象
    -   Busy Monitor：正在加锁的对象

### 2.1.3 五种引用

![](https://img-blog.csdnimg.cn/b91d1b7093e84d69bfad76e2d82e0d2d.png)

> 实现部分为强引用，虚线为其他引用。

#### 强引用

-   只有GC Root都不通过`强引用`引用该对象时，该对象才能被垃圾回收。
    -   如上图B、C对象都不引用A1对象时，A1对象才会被回收

#### 软引用（SoftReference）

-   没有被强引用直接引用的。
-   仅有软引用引用该对象时，在`垃圾回收后，仍内存不足`时，会`回收软引用所引用的对象`
    -   如上图如果B对象不再引用A2对象且内存不足时，软引用本身不会被清理，软引用所引用的A2对象会被回收
    -   例子：对于4M的byte数组，在`垃圾回收后，仍内存不足`时进行回收

        ![](https://img-blog.csdnimg.cn/ffa6cdc70567443a933c06c399676895.png)
-   若要清理软引用与弱引用本身，需要借助引用队列实现。(下面的remove从数组中删除是为了去除队列中软引用对象的强引用，这样就可以被GC回收了)

    ![](https://img-blog.csdnimg.cn/239da1ae09b848d5844810b968f0678c.png)

#### 弱引用（WeakReference）

-   没有被直接的强引用所引用
-   仅有弱引用引用该对象时，在`垃圾回收时，无论内存是否充足`，都会`回收弱引用所引用的对象`
    -   如上图如果B对象不再引用A3对象，则A3对象会被回收
    -   例子：

        ![](https://img-blog.csdnimg.cn/6eab798125ea4309aa7695be2699025e.png)
-   若要清理软引用与弱引用本身，需要借助引用队列实现（同软引用）。

#### 虚引用（PhantomReference）

个人理解：虚引用对象引用的对象跟没有引用一样。当其它对象没有引用它时（除了虚引用对象的引用），它就会被清理。而一般虚引用对象会配合引用队列使用，当虚引用对象所引用的对象被回收时（没有被除虚引用对象的其它对象引用时，即可回收），就会将虚引用对象放入引用队列中，达到通知的效果。

-   `必须配合引用队列使用`。主要配合ByteBuffer使用被引用对象回收时，会将虚引用入队，由ReferenceHandler线程调用虚引用相关方法释放直接内存。
-   当虚引用对象所引用的对象被回收以后，虚引用对象就会被放入引用队列中，从而间接的用一个线程`调用虚引用对象的方法`。
-   举例：直接内存的回收——Cleaner （虚引用）

    配合引用队列，当引用的对象（`ByteBuffer `对象）被回收，监测线程`ReferenceHandler 线程`会自动调用虚引用Cleaner的clean方法，来释放ByteBuffer对象的直接内存（不能被GC回收）。

    或：

    ByteBuffer 的实现类内部，使用了 `Cleaner （虚引用）`来`监测 ByteBuffer 对象`，`一旦ByteBuffer 对象被垃圾回收`，Cleaner 就回进入引用队列，`ReferenceHandler 线程`会查看引用队列，若其中有Cleaner，就会由 `ReferenceHandler 线程`（监测虚引用对象）`通过 Cleaner 的 clean 方法自动调用 freeMemory` 来释放直接内存。

#### 终结器引用（FinalReference）

-   所有的类都继承自Object类，Object类有一个finalize方法。当某个对象重写了`finalize()`后，此对象不再被其他的对象所强引用时，垃圾回收时会先将终结器引用对象放入引用队列中，然后`Finalizer 线程`会查看引用队列，若其中有终结器引用，则会通过终结器引用找到它所引用的对象并`调用该对象的finalize方法`。调用以后，`再进行一次GC`，该对象才可以被垃圾回收。
-   不推荐使用finalize()方法进行内存释放，其条件过于苛刻。

#### 引用队列

### 2.2 垃圾回收算法

> 三种垃圾回收算法协同工作，并不是单纯的采用某一种。

#### 2.2.1 标记清除（Mark Sweep）

![](https://img-blog.csdnimg.cn/cc30cb1fc201416dbcfc2b7f3d20fbba.png)

-   定义：在虚拟机执行垃圾回收的过程中，先采用标记算法确定可回收对象，然后垃圾收集器根据标识清除相应的内容，给堆内存腾出相应的空间
    -   这里的腾出内存空间并不是将内存空间的字节清0，而是记录下这段内存的起始结束地址，下次分配内存的时候，会直接覆盖这段内存
-   优点：`速度快`，只需要记录起始结束地址
-   缺点：不会对内存进行整理，`容易产生大量的内存碎片`，可能无法满足大对象的内存分配，一旦导致无法分配对象，那就会导致jvm启动gc，一旦启动gc，应用程序就会暂停，导致应用的响应速度变慢

#### 2.2.2 标记整理（Mark Compact）

![](https://img-blog.csdnimg.cn/9f6a4dbd9517408b9468d1d9fe2d8f98.png)

-   定义：先采用标记算法确定可回收对象，然后将不被GC Root引用的对象回收，清除其占用的内存空间，然后整理剩余对象的内存空间。
-   优点：减少内存碎片。
-   缺点：整理需要消耗一定的时间，引用了要整理的对象地址也需要修改。 速度较慢。

#### 2.2.3 复制（Copy）

-   步骤：

    ![](https://img-blog.csdnimg.cn/604fc496b7ee449da84dd552312c2a7c.png)
    1.  标记可回收对象

        ![](https://img-blog.csdnimg.cn/0aefb00c00bc4fd6b94a8bb064656dad.png)
    2.  将不可回收的对象从FROM转移到TO中，并把FROM清空

        ![](https://img-blog.csdnimg.cn/e7ccaadbbcb442508153daf5e1c0c3c0.png)
    3.  交换FROM和TO

        ![](https://img-blog.csdnimg.cn/a2732246abae45b8aa3b75f4107265ad.png)
-   优点：减少内存碎片。
-   缺点：占用双倍的内存空间。

### 2.3 分代垃圾回收

![](https://img-blog.csdnimg.cn/ed467bf990f844f5b395a48030e73691.png)

有没有注意到了，我们前面的表述当中就引入了新生代、老年代的概念。准确来说，是先有了分代收集算法的这种思想，才会将Java堆分为新生代和老年代。这两个概念之间存在着一个先后因果关系。这个算法很简单，就是根据对象存活周期的不同，将内存分块。在Java 堆中，内存区域被分为了新生代和老年代，这样就可以根据各个年代的特点采用最适当的收集算法。就如我们在介绍上面的算法时描述的，在新生代中，每次垃圾收集时都发现有大批对象死去，只有少量存活，那就选用复制算法，只需要付出少量存活对象的复制成本就可以完成收集。而老年代中因为对象存活率高、没有额外空间对它进行分配担保，就必须使用 “标记—清理” 或者 “标记—整理” 算法 来进行回收。

-   新生代：**复制算法**
-   老年代：标记-清除算法、**标记-整理算法**

过程：

-   对象首先分配在伊甸园区域；
-   新生代空间不足时，触发minor gc，清理伊甸园区和from幸存区， `伊甸园和from存活的对象`使用copy复制到`to`中，存活的对象年龄加1并且`from幸存区和to幸存区进行交换`；
-   minor gc会引发stop the world （STW），暂停其它用户的线程，等垃圾回收结束，用户线程才恢复运行；
-   当对象寿命超过阈值时，会晋升至老年代，`最大寿命`是`15`（4bit）；
-   当老年代空间不足，会触发Full GC，且在Full GC前会进行Minor GC, 即它会回收新生代、老年代和永久代的垃圾对象，并且会导致较长时间的STW（Stop-The-World）。
-   Full GC后内存仍不足时，会抛出`java.lang.OutOfMemoryError`异常。

    Full GC与Minor GC日志：
    ```text
    [Full GC (Allocation Failure) [Tenured: 8825K->615K(10240K), 0.0024162 secs] 12922K->615K(19456K), [Metaspace: 3434K->3434K(1056768K)], 0.0024418 secs] [Times: user=0.00 sys=0.00, real=0.00 secs] 

    [GC (Allocation Failure) [DefNew: 4295K->0K(9216K), 0.0012301 secs] 4911K->4712K(19456K), 0.0012581 secs] [Times: user=0.00 sys=0.00, real=0.00 secs] 
    ```
-   相关VM参数 &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/ec0d5f5f29a5485bab2b765c38e3192a.png "在这里插入图片描述")

### 2.4 垃圾回收器

JDK8虚拟机参数（官方说明）：[https://docs.oracle.com/javase/8/docs/technotes/tools/unix/java.html](https://docs.oracle.com/javase/8/docs/technotes/tools/unix/java.html "https://docs.oracle.com/javase/8/docs/technotes/tools/unix/java.html")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/03/1677833715361.png)

#### 2.4.1 串行垃圾回收器

-   单线程&#x20;
-   堆内存较小，适合个人电脑
-   开启：
    ```纯文本
    -XX:+UseSerialGC= Serial + SerialOld
    ```
    ![](https://img-blog.csdnimg.cn/b63ef26ef5f842baa5413769db5d2c92.png)
    -   串行垃圾回收器分为Serial和SerialOld两部分：
        -   Serial工作在新生代，采用复制算法
        -   SerialOld工作在老年代，采用标记整理算法
    -   在进行垃圾回收时，先将所有的线程在安全点暂停，防止垃圾回收过程中内存地址的修改导致程序出错。然后开始垃圾回收线程，其他线程阻塞。等垃圾回收线程结束后，其他用户线程再开始运行。

#### 2.4.2 吞吐量优先垃圾回收器

-   多线程
-   堆内存较大，多核 cpu
-   让单位时间内，STW 的时间最短（0.2 + 0.2 = 0.4），垃圾回收时间占比最低，这样就称吞吐量高
-   开启：

    ![](https://img-blog.csdnimg.cn/3cd7899f9c7f426bb170857dded8d239.png)

    `-XX:+UseParallelGC ~ -XX:+UseParalleloldGC`
    -   UseParallelGC 新生代的并行垃圾回收器，采用采用复制算法
    -   UseParalleloldG 老年代的并行垃圾回收器，采用标记整理算法
    -   两个关联，开启一个时另一个会自动开启
        `-XX:+UseAdaptiveSizePolicy`：采用自适应的调整策略，调整新生代的大小、新生代内部各部分的比例和寿命阈值等
    `-XX:GCTimeRatio=ratio`：根据ratio，计算出垃圾回收时间占总时间的比例（吞吐量 ）= `1/（1+ratio）` ，垃圾回收时间超过时，会尝试调整堆的大小

    `-XX:MaxGCPauseMillis=ms`：最大暂停毫秒数，默认值200ms

    `-XX:ParallelGCThreads=n`：指定并行垃圾回收线程数，一般与CPU核数相同

#### 2.4.3 响应时间优先垃圾回收器

-   多线程
-   堆内存较大，多核 cpu
-   尽可能让单次 STW 的时间最短（0.1 + 0.1 + 0.1 + 0.1 + 0.1 = 0.5）
-   开启：

    ![](https://img-blog.csdnimg.cn/9629db6057d34fb7b1d1abc0338f089f.png)

    上面虚拟机参数说明：

    1、`-XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:+CMSParallelRemarkEnabled `

    该配置使用了ParNew垃圾收集器作为新生代的垃圾收集器，CMS作为老年代的垃圾收集器，并启用了CMS的Parallel Remark阶段。

    2、`-XX:ParallelGCThreads=`*`threads`* :设置用于年轻代和老年代并行垃圾回收的线程数。默认值取决于 JVM 可用的 CPU 数量。

    `-XX:ConcGCThreads=threads` 用于设置 CMS 并发垃圾回收的线程数。threads 的默认值也取决于 CPU 核心数，一般来说，它的默认值是 ParallelGCThreads 的 1/4。

    3、`-XX:CMSInitiatingOccupancyFraction=percent` ：如果将其设置为 `70`，则表示当老年代空间使用率达到 `70%` 时，JVM 将启动 CMS 垃圾回收器进行垃圾回收。

    4、`-XX:+CMSScavengeBeforeRemark` 是CMS垃圾收集器相关的虚拟机参数之一，它表示在执行CMS Remark阶段之前是否执行Young GC（Minor GC）。 开启有有利于减少CMS时标记的时间，从而减少STW时间。

**CMS 收集器**

-   Concurrent Mark Sweep，`并发`的使用`标记清除算法`的垃圾回收器，是一种以`获取最短回收停顿时间`为目标的`老年代`收集器
-   特点：基于`标记-清除算法`实现。并发收集、低停顿，但是`会产生内存碎片`
-   应用场景：适用于注重服务的响应速度，希望系统停顿时间最短，给用户带来更好的体验等场景下。如web程序、b/s服务
-   CMS收集器的运行过程分为下列4步：
    -   `初始标记`：标记GC Roots能直接到的对象。速度很快但是`仍存在Stop The World`问题
    -   `并发标记`：进行GC Roots Tracing 的过程，找出存活对象且用户线程可并发执行
    -   `重新标记`：为了修正并发标记期间因用户程序继续运行而导致标记产生变动的那一部分对象的标记记录。`仍然存在Stop The World`问题
    -   `并发清除`：对标记的对象进行清除回收
-   CMS收集器的内存回收过程是与用户线程一起并发执行的
-   由于CMS采取标记清除算法进行垃圾回收，会产生较多的内存碎片，当内存碎片足够多时会造成并发失败，垃圾回收器会退化为SerialOld进行内存空间整理，此时垃圾回收时间会突然增长，进而导致响应时间优先的垃圾回收器反而耗时很长，带来不好的用户体验。

#### 2.4.4 G1垃圾回收器 （已展开）

-   定义：Garbage First
    -   2004 论文发布
    -   2009 JDK 6u14 体验
    -   2012 JDK 7u4 官方支持
    -   2017 JDK 9 默认，替代CMS 收集器
-   适用场景
    -   `同时注重吞吐量（Throughput）和低延迟（Low latency）`，默认的暂停目标是 200 ms
    -   超大堆内存，会将堆划分为多个大小相等的 Region
    -   `整体`上是 `标记+整理` 算法，两个`区域之间`是`复制`算法
-   相关 JVM 参数
    -   `-XX:+UseG1GC` : 开启G1垃圾回收器
    -   `-XX:G1HeapRegionSize=size` ：Region块大小
    -   `-XX:MaxGCPauseMillis=time` ：最大GC停顿时间

#### G1垃圾回收阶段

![](https://img-blog.csdnimg.cn/02e5908ecd304db4a75d511ed0394c67.png)

#### Full GC

-   SerialGC
    -   新生代内存不足发生的垃圾收集 - minor gc
    -   老年代内存不足发生的垃圾收集 - full gc
-   ParallelGC
    -   新生代内存不足发生的垃圾收集 - minor gc
    -   老年代内存不足发生的垃圾收集 - full gc
-   CMS
    -   新生代内存不足发生的垃圾收集 - minor gc
    -   老年代内存不足 - 当内存碎片足够多时会造成并发失败，并发收集失败时退化为串行收集，此时才会进行full gc
-   G1
    -   新生代内存不足发生的垃圾收集 - minor gc
    -   老年代内存不足 - 老年代占用堆空间比例达到阈值（默认45%）时，进行并发标记（不会 STW）与混合收集，当回收速度快于垃圾产生速度时会进行并发收集，只有当垃圾产生速度快于回收速度时并发收集失败，退化为串行收集，此时才会进行full gc

#### Young Collection 跨代引用

-   新生代回收的跨代引用（老年代引用新生代）问题
    在进行Young Collection时，首先要找到GC Root根对象，根据其进行可达性分析找到存活的对象复制入幸存区，但根对象一部分是来自老年代的，且老年代的存活对象较多，对老年代进行遍历查找效率很低，因此采用卡表技术对老年代进行分区，每个card大小约为512k。若此card中有对象引用了新生代的对象，则将其标记为脏卡。因此在Young Collection查找根对象时只需要关注脏卡，提高效率。
-   Remembered Set：新生代对象记录外部的引用，即对应的脏卡是哪些
-   在引用变更时通过 post-write barrier + dirty card queue
-   concurrent refinement threads 更新 Remembered Set

    ![](https://img-blog.csdnimg.cn/6e227d3bfe8f47e598b1b2ec730d1fd3.png)

#### Remake重新标记

![](https://img-blog.csdnimg.cn/0e5393022c3a4abdad14de0da04cff0c.png)

> 黑色：已被处理，需要保留的

> 灰色：正在处理中的

> 白色：还未处理的

-   在并发标记的过程中其他用户线程在同时进行，当还没处理到C前B与C的引用断掉，此时处理C就是一个需要回收的对象。

    但还有可能处理完C之后其他并发执行的线程又对C进行了引用，如下图的A，此时C的标记已经结束，在回收时会被回收，会导致程序异常，因此需要重新标记。

    ![](https://img-blog.csdnimg.cn/916da7a93ec749f6b51c2788e62fe54a.png)

    ![](https://img-blog.csdnimg.cn/a475d08e8004487eb971614506bb9a42.png)
-   重新标记remark

![](https://img-blog.csdnimg.cn/58f41db376e141e9ab145e9ac01e1d27.png)

-   pre-write barrier + satb\_mark\_queue
    如果对象的引用发生改变，JVM就回给其加入写屏障`pre-write barrier`，并执行写屏障指令，将C加入队列中 `satb_mark_queue`，并把C标记为灰色。并发标记结束后，进入remark阶段，此时会STW，并将`satb_mark_queue`中的对象一个个取出来进行检查，如此对象有强引用引用时，将其修改为黑色，进行对象保留。

#### G1的部分优化 （已展开）

#### JDK 8u20 字符串去重

-   开启：
    ```纯文本
    -XX:+UseStringDeduplication
    ```
    （默认打开）

    ![](https://img-blog.csdnimg.cn/8d2b5cb2835e4a6e9b8d317c76c413b5.png)
    -   将所有新分配的字符串放入一个队列
    -   当新生代回收时，G1并发检查是否有字符串重复
    -   如果它们值一样，让它们引用同一个 char\[]
-   注意：与 String.intern() 不一样
    -   String.intern() 关注的是字符串对象
    -   而字符串去重关注的是 char\[]
    -   在 JVM 内部，使用了不同的字符串表
-   优点：节省大量内存
-   缺点：略微多占用了 cpu 时间，新生代回收时间略微增加

#### JDK 8u40 并发标记类卸载

-   所有对象都经过`并发标记`后，就能知道哪些类不再被使用，当一个`类加载器（自定义）的所有类`都不再使用，则卸载它所加载的所有类
-   开启：
    ```纯文本
    -XX:+ClassUnloadingWithConcurrentMark
    ```
    默认启用

#### JDK 8u60 回收巨型对象

-   一个对象大于 region 的一半时，称之为巨型对象
-   G1 不会对巨型对象进行拷贝
-   G1 回收时被优先考虑
-   G1 会跟踪老年代所有 incoming 引用，这样老年代 incoming 引用为0 的巨型对象就可以在新生代垃圾回收时处理掉

    ![](https://img-blog.csdnimg.cn/10b3eceb3ba843878a16b90779e6ad6e.png)

#### JDK 9 并发标记起始时间的调整

-   `并发标记必须在堆空间占满前完成，否则会退化为 FullGC`
-   JDK 9 之前需要使用
    ```纯文本
    -XX:InitiatingHeapOccupancyPercent
    ```
    对老年代阈值进行调整
-   JDK 9 可以动态调整
    -   进行数据采样并动态调整
    -   总会添加一个安全的空档空间
    ```纯文本
    -XX:InitiatingHeapOccupancyPercent
    ```
    用来设置初始值

#### JDK 9 更高效的回收

-   250+增强
-   180+bug修复
-   [https://docs.oracle.com/en/java/javase/12/gctuning](https://docs.oracle.com/en/java/javase/12/gctuning "https://docs.oracle.com/en/java/javase/12/gctuning")

### 2.5 垃圾回收调优

-   预备知识
    -   掌握 GC 相关的 VM 参数，会基本的空间调整
        查看虚拟机运行参数：
        ```纯文本
        "java_path" -XX:+PrintFlagsFinal -version | findstr "GC"
        ```
        ![](https://img-blog.csdnimg.cn/08dfa037dde64d46907f7d588fabf132.png)
    -   掌握相关工具
    -   明白一点：调优跟应用、环境有关，没有放之四海而皆准的法则

#### 2.5.1 调优领域

-   内存
-   锁竞争
-   cpu 占用
-   io

#### 2.5.2 确定目标

-   【低延迟】还是【高吞吐量】，选择合适的回收器
-   低延迟（适用于B/S）：CMS，G1，ZGC
-   高吞吐量：ParallelGC
-   其他虚拟机：Zing

#### 2.5.3 最快的 GC是不发生 GC

> 查看 FullGC 前后的内存占用，考虑下面几个问题：

-   数据是不是太多？
    ```纯文本
    resultSet = statement.executeQuery("select * from 大表 limit n")
    ```
-   数据表示是否太臃肿？
    -   对象图
    -   对象大小：16 ，`Integer` 24 ，`int`4
-   是否存在内存泄漏？
    -   static Map map =
    -   软引用
    -   弱引用
    -   第三方缓存实现

#### 2.5.4 新生代调优

#### 2.5.5 老年代调优

-   以 CMS 为例
    -   CMS 的老年代内存越大越好，避免浮动垃圾引起的并发失败，退化为SerialOld导致更长的STW
    -   先尝试不做调优，如果没有 Full GC 那么老年代内存已经足够，否则先尝试调优新生代
    -   如调优新生代还是不行，再观察发生 Full GC 时老年代内存占用，将老年代内存在原有基础上调大 1/4 \~ 1/3
        ```纯文本
        -XX:CMSInitiatingOccupancyFraction=percent
        ```
        ：控制老年代的空间占用在到老年代的多少百分比时使用CMS进行垃圾回收

## 3. 类加载与字节码技术

![](https://img-blog.csdnimg.cn/3c1c6f8efc0f44299f9888f753ca9f9c.png)

### 3.1 类文件结构

-   一个简单的 HelloWorld.java
    ```纯文本
    package cn.itcast.jvm.t5; 
    // HelloWorld 示例 
    public class HelloWorld { 
      public static void main(String[] args) { 
        System.out.println("hello world"); 
      } 
    }
    ```
    执行
    ```纯文本
    javac -parameters -d . HellowWorld.java
    ```
    编译为 HelloWorld.class 后是这个样子的：
    ```纯文本
    [root@localhost ~]# od -t xC HelloWorld.class 
    0000000 ca fe ba be 00 00 00 34 00 23 0a 00 06 00 15 09 
    0000020 00 16 00 17 08 00 18 0a 00 19 00 1a 07 00 1b 07 
    0000040 00 1c 01 00 06 3c 69 6e 69 74 3e 01 00 03 28 29 
    0000060 56 01 00 04 43 6f 64 65 01 00 0f 4c 69 6e 65 4e 
    0000100 75 6d 62 65 72 54 61 62 6c 65 01 00 12 4c 6f 63 
    0000120 61 6c 56 61 72 69 61 62 6c 65 54 61 62 6c 65 01 
    0000140 00 04 74 68 69 73 01 00 1d 4c 63 6e 2f 69 74 63 
    0000160 61 73 74 2f 6a 76 6d 2f 74 35 2f 48 65 6c 6c 6f 
    0000200 57 6f 72 6c 64 3b 01 00 04 6d 61 69 6e 01 00 16 
    0000220 28 5b 4c 6a 61 76 61 2f 6c 61 6e 67 2f 53 74 72
    0000240 69 6e 67 3b 29 56 01 00 04 61 72 67 73 01 00 13 
    0000260 5b 4c 6a 61 76 61 2f 6c 61 6e 67 2f 53 74 72 69 
    0000300 6e 67 3b 01 00 10 4d 65 74 68 6f 64 50 61 72 61 
    0000320 6d 65 74 65 72 73 01 00 0a 53 6f 75 72 63 65 46 
    0000340 69 6c 65 01 00 0f 48 65 6c 6c 6f 57 6f 72 6c 64 
    0000360 2e 6a 61 76 61 0c 00 07 00 08 07 00 1d 0c 00 1e 
    0000400 00 1f 01 00 0b 68 65 6c 6c 6f 20 77 6f 72 6c 64 
    0000420 07 00 20 0c 00 21 00 22 01 00 1b 63 6e 2f 69 74 
    0000440 63 61 73 74 2f 6a 76 6d 2f 74 35 2f 48 65 6c 6c 
    0000460 6f 57 6f 72 6c 64 01 00 10 6a 61 76 61 2f 6c 61 
    0000500 6e 67 2f 4f 62 6a 65 63 74 01 00 10 6a 61 76 61 
    0000520 2f 6c 61 6e 67 2f 53 79 73 74 65 6d 01 00 03 6f 
    0000540 75 74 01 00 15 4c 6a 61 76 61 2f 69 6f 2f 50 72 
    0000560 69 6e 74 53 74 72 65 61 6d 3b 01 00 13 6a 61 76 
    0000600 61 2f 69 6f 2f 50 72 69 6e 74 53 74 72 65 61 6d 
    0000620 01 00 07 70 72 69 6e 74 6c 6e 01 00 15 28 4c 6a 
    0000640 61 76 61 2f 6c 61 6e 67 2f 53 74 72 69 6e 67 3b 
    0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01 
    0000700 00 07 00 08 00 01 00 09 00 00 00 2f 00 01 00 01 
    0000720 00 00 00 05 2a b7 00 01 b1 00 00 00 02 00 0a 00 
    0000740 00 00 06 00 01 00 00 00 04 00 0b 00 00 00 0c 00 
    0000760 01 00 00 00 05 00 0c 00 0d 00 00 00 09 00 0e 00 
    0001000 0f 00 02 00 09 00 00 00 37 00 02 00 01 00 00 00 
    0001020 09 b2 00 02 12 03 b6 00 04 b1 00 00 00 02 00 0a 
    0001040 00 00 00 0a 00 02 00 00 00 06 00 08 00 07 00 0b 
    0001060 00 00 00 0c 00 01 00 00 00 09 00 10 00 11 00 00 
    0001100 00 12 00 00 00 05 01 00 10 00 00 00 01 00 13 00 
    0001120 00 00 02 00 14
    ```
-   根据JVM规范，类文件结构如下：

    参考链接：[https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-4.html](https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-4.html "https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-4.html")

    ![](https://img-blog.csdnimg.cn/edf8b887a9934366913acf09d0b7a2a5.png)

#### 3.1.1 魔数

> 0\~3 字节，表示它是否是【class】类型的文件：
> 0000000 ca fe ba be 00 00 00 34 00 23 0a 00 06 00 15 09

#### 3.1.2 版本

> 4\~7 字节，表示类的版本 `00 34`（十六进制，转换为十进制为52） 表示是 Java 8
> 0000000 ca fe ba be 00 00 00 34 00 23 0a 00 06 00 15 09

#### 3.1.3 常量池

![](https://img-blog.csdnimg.cn/dc6d859dcff34245b8ef3c75d7be0585.png)

-   8 \~ 9 字节，表示常量池长度，`00 23 （35）` 表示常量池有 `#1 ~ #34项`，注意 `#0 项不计入，也没有值`
    0000000 ca fe ba be 00 00 00 34 00 23 0a 00 06 00 15 09
    -   第#1项 `0a` 表示一个 `Method 信息`(查上边的表，0a对应十进制为10，则其对应的类型为方法引用)，`00 06` 和 `00 15`（21） 表示它`引用了常量池中` `#6` 和 `#21` 项来获得这个方法的【`所属类`】和【`方法名`】
        0000000 ca fe ba be 00 00 00 34 00 23 0a 00 06 00 15 09
    -   第#2项 09 表示一个 Field 信息，00 16（22）和 00 17（23） 表示它引用了常量池中 #22 和 # 23 项来获得这个成员变量的【所属类】和【成员变量名】
        0000000 ca fe ba be 00 00 00 34 00 23 0a 00 06 00 15 09
        0000020 00 16 00 17 08 00 18 0a 00 19 00 1a 07 00 1b 07
    -   第#3项 08 表示一个字符串常量名称，00 18（24）表示它引用了常量池中 #24 项
        0000020 00 16 00 17 08 00 18 0a 00 19 00 1a 07 00 1b 07
    -   第#4项 0a 表示一个 Method 信息，00 19（25） 和 00 1a（26） 表示它引用了常量池中 #25 和 #26项来获得这个方法的【所属类】和【方法名】
        0000020 00 16 00 17 08 00 18 0a 00 19 00 1a 07 00 1b 07
    -   第#5项 07 表示一个 Class 信息，00 1b（27） 表示它引用了常量池中 #27 项
        0000020 00 16 00 17 08 00 18 0a 00 19 00 1a 07 00 1b 07
    -   第#6项 07 表示一个 Class 信息(查表)，00 1c（28） 表示它引用了常量池中 #28 项
        0000020 00 16 00 17 08 00 18 0a 00 19 00 1a 07 00 1b 07
        0000040 00 1c 01 00 06 3c 69 6e 69 74 3e 01 00 03 28 29
    -   第#7项 01 表示一个 utf8 串，`00 06` 表示`长度`，3c 69 6e 69 74 3e 是【 `<init>` 】
        0000040 00 1c 01 00 06 3c 69 6e 69 74 3e 01 00 03 28 29
    -   第#8项 01 表示一个 utf8 串，`00 03` 表示`长度`，28 29 56 是【`()V`】其实就是表示`无参、无返回值`
        0000040 00 1c 01 00 06 3c 69 6e 69 74 3e 01 00 03 28 29
        0000060 56 01 00 04 43 6f 64 65 01 00 0f 4c 69 6e 65 4e
    -   第#9项 01 表示一个 utf8 串，00 04 表示长度，43 6f 64 65 是【Code】
        0000060 56 01 00 04 43 6f 64 65 01 00 0f 4c 69 6e 65 4e
    -   第#10项 01 表示一个 utf8 串，00 0f（15） 表示长度，4c 69 6e 65 4e 75 6d 62 65 72 54 61 62 6c 65是【LineNumberTable】
        0000060 56 01 00 04 43 6f 64 65 01 00 0f 4c 69 6e 65 4e
        0000100 75 6d 62 65 72 54 61 62 6c 65 01 00 12 4c 6f 63
    -   第#11项 01 表示一个 utf8 串，00 12（18） 表示长度，4c 6f 63 61 6c 56 61 72 69 61 62 6c 65 54 61
        62 6c 65是【LocalVariableTable】
        0000100 75 6d 62 65 72 54 61 62 6c 65 01 00 12 4c 6f 63
        0000120 61 6c 56 61 72 69 61 62 6c 65 54 61 62 6c 65 01
    -   第#12项 01 表示一个 utf8 串，00 04 表示长度，74 68 69 73 是【this】
        0000120 61 6c 56 61 72 69 61 62 6c 65 54 61 62 6c 65 01
        0000140 00 04 74 68 69 73 01 00 1d 4c 63 6e 2f 69 74 63
    -   第#13项 01 表示一个 utf8 串，00 1d（29） 表示长度，是【Lcn/itcast/jvm/t5/HelloWorld;】
        0000140 00 04 74 68 69 73 01 00 1d 4c 63 6e 2f 69 74 63
        0000160 61 73 74 2f 6a 76 6d 2f 74 35 2f 48 65 6c 6c 6f
        0000200 57 6f 72 6c 64 3b 01 00 04 6d 61 69 6e 01 00 16
    -   第#14项 01 表示一个 utf8 串，00 04 表示长度，74 68 69 73 是【main】
        0000200 57 6f 72 6c 64 3b 01 00 04 6d 61 69 6e 01 00 16
    -   第#15项 01 表示一个 utf8 串，00 16（22） 表示长度，是【(\[Ljava/lang/String;)V】其实就是参数为
        字符串数组，无返回值
        0000200 57 6f 72 6c 64 3b 01 00 04 6d 61 69 6e 01 00 16
        0000220 28 5b 4c 6a 61 76 61 2f 6c 61 6e 67 2f 53 74 72
        0000240 69 6e 67 3b 29 56 01 00 04 61 72 67 73 01 00 13
    -   第#16项 01 表示一个 utf8 串，00 04 表示长度，是【args】
        0000240 69 6e 67 3b 29 56 01 00 04 61 72 67 73 01 00 13
    -   第#17项 01 表示一个 utf8 串，00 13（19） 表示长度，是【\[Ljava/lang/String;】
        0000240 69 6e 67 3b 29 56 01 00 04 61 72 67 73 01 00 13
        0000260 5b 4c 6a 61 76 61 2f 6c 61 6e 67 2f 53 74 72 69
        0000300 6e 67 3b 01 00 10 4d 65 74 68 6f 64 50 61 72 61
    -   第#18项 01 表示一个 utf8 串，00 10（16） 表示长度，是【MethodParameters】
        0000300 6e 67 3b 01 00 10 4d 65 74 68 6f 64 50 61 72 61
        0000320 6d 65 74 65 72 73 01 00 0a 53 6f 75 72 63 65 46
    -   第#19项 01 表示一个 utf8 串，00 0a（10） 表示长度，是【SourceFile】
        0000320 6d 65 74 65 72 73 01 00 0a 53 6f 75 72 63 65 46
        0000340 69 6c 65 01 00 0f 48 65 6c 6c 6f 57 6f 72 6c 64
    -   第#20项 01 表示一个 utf8 串，00 0f（15） 表示长度，是【HelloWorld.java】
        0000340 69 6c 65 01 00 0f 48 65 6c 6c 6f 57 6f 72 6c 64
        0000360 2e 6a 61 76 61 0c 00 07 00 08 07 00 1d 0c 00 1e
    -   第#21项 `0c` 表示一个 【`名+类型`】，`00 07 00 08` 引用了常量池中 `#7 #8` 两项
        0000360 2e 6a 61 76 61 0c 00 07 00 08 07 00 1d 0c 00 1e
    -   第#22项 07 表示一个 Class 信息，00 1d（29） 引用了常量池中 #29 项
        0000360 2e 6a 61 76 61 0c 00 07 00 08 07 00 1d 0c 00 1e
    -   第#23项 0c 表示一个 【名+类型】，00 1e（30） 00 1f （31）引用了常量池中 #30 #31 两项
        0000360 2e 6a 61 76 61 0c 00 07 00 08 07 00 1d 0c 00 1e
        0000400 00 1f 01 00 0b 68 65 6c 6c 6f 20 77 6f 72 6c 64
    -   第#24项 01 表示一个 utf8 串，00 0f（15） 表示长度，是【hello world】
        0000400 00 1f 01 00 0b 68 65 6c 6c 6f 20 77 6f 72 6c 64
    -   第#25项 07 表示一个 Class 信息，00 20（32） 引用了常量池中 #32 项
        0000420 07 00 20 0c 00 21 00 22 01 00 1b 63 6e 2f 69 74
    -   第#26项 0c 表示一个 【名+类型】，00 21（33） 00 22（34）引用了常量池中 #33 #34 两项
        0000420 07 00 20 0c 00 21 00 22 01 00 1b 63 6e 2f 69 74
    -   第#27项 01 表示一个 utf8 串，00 1b（27） 表示长度，是【cn/itcast/jvm/t5/HelloWorld】
        0000420 07 00 20 0c 00 21 00 22 01 00 1b 63 6e 2f 69 74
        0000440 63 61 73 74 2f 6a 76 6d 2f 74 35 2f 48 65 6c 6c
        0000460 6f 57 6f 72 6c 64 01 00 10 6a 61 76 61 2f 6c 61
    -   第#28项 01 表示一个 utf8 串，`00 10（16）` 表示`长度`，是【java/lang/Object】
        0000460 6f 57 6f 72 6c 64 01 00 10 6a 61 76 61 2f 6c 61
        0000500 6e 67 2f 4f 62 6a 65 63 74 01 00 10 6a 61 76 61
    -   第#29项 01 表示一个 utf8 串，00 10（16） 表示长度，是【java/lang/System】
        0000500 6e 67 2f 4f 62 6a 65 63 74 01 00 10 6a 61 76 61
        0000520 2f 6c 61 6e 67 2f 53 79 73 74 65 6d 01 00 03 6f
    -   第#30项 01 表示一个 utf8 串，00 03 表示长度，是【out】
        0000520 2f 6c 61 6e 67 2f 53 79 73 74 65 6d 01 00 03 6f
        0000540 75 74 01 00 15 4c 6a 61 76 61 2f 69 6f 2f 50 72
    -   第#31项 01 表示一个 utf8 串，00 15（21） 表示长度，是【Ljava/io/PrintStream;】
        0000540 75 74 01 00 15 4c 6a 61 76 61 2f 69 6f 2f 50 72
        0000560 69 6e 74 53 74 72 65 61 6d 3b 01 00 13 6a 61 76
    -   第#32项 01 表示一个 utf8 串，00 13（19） 表示长度，是【java/io/PrintStream】
        0000560 69 6e 74 53 74 72 65 61 6d 3b 01 00 13 6a 61 76
        0000600 61 2f 69 6f 2f 50 72 69 6e 74 53 74 72 65 61 6d
    -   第#33项 01 表示一个 utf8 串，00 07 表示长度，是【println】
        0000620 01 00 07 70 72 69 6e 74 6c 6e 01 00 15 28 4c 6a
    -   第#34项 01 表示一个 utf8 串，00 15（21） 表示长度，是【(Ljava/lang/String;)V】
        0000620 01 00 07 70 72 69 6e 74 6c 6e 01 00 15 28 4c 6a
        0000640 61 76 61 2f 6c 61 6e 67 2f 53 74 72 69 6e 67 3b
        0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01

#### 3.1.4 访问标识与继承信息

![](https://img-blog.csdnimg.cn/67cf44a961d4468ca2515db71e5e829b.png)

-   00 21(0x0020+0x0001)表示该 class 是一个类，公共的
    0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01
-   00 05 表示根据常量池中 #5 找到本类全限定名
    0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01
-   00 06 表示根据常量池中 #6 找到父类全限定名
    0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01
-   00 00表示接口的数量，本类为 0
    0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01

#### 3.1.5 Field 信息

![](https://img-blog.csdnimg.cn/f291e413fb054c18891ab9071d691e61.png)

-   00 00表示成员变量数量，本类为 0
    0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01

#### 3.1.6 Method 信息

-   00 02表示方法数量，本类为 2
    0000660 29 56 00 21 00 05 00 06 00 00 00 00 00 02 00 01
-   一个方法由`访问修饰符，名称，参数描述，方法属性数量，方法属性`组成
-   例1：method-init

    ![](https://img-blog.csdnimg.cn/223a137b506c4a03b37a674b8b0a63d1.png)
    -   红色代表访问修饰符（本类中是 public）
    -   蓝色代表引用了常量池 #07 项作为方法名称
    -   绿色代表引用了常量池 #08 项作为方法参数描述
    -   黄色代表方法属性数量，本方法是 1
    -   红色代表方法属性
        -   00 09 表示引用了常量池 #09 项，发现是【Code】属性
        -   00 00 00 2f 表示此属性的长度是 47
        -   00 01 表示【操作数栈】最大深度
        -   00 01 表示【局部变量表】最大槽（slot）数（长度）
        -   00 00 00 05 表示字节码长度，本例是 5
        -   2a b7 00 01 b1 是字节码指令
        -   00 00 00 02 表示方法细节属性数量，本例是 2
        -   00 0a 表示引用了常量池 #10 项，发现是【LineNumberTable】属性
            -   00 00 00 06 表示此属性的总长度，本例是 6
            -   00 01 表示【LineNumberTable】长度
            -   00 00 表示【字节码】行号 00 04 表示【java 源码】行号
        -   00 0b 表示引用了常量池 #11 项，发现是【LocalVariableTable】属性
            -   00 00 00 0c 表示此属性的总长度，本例是 12
            -   00 01 表示【LocalVariableTable】长度
            -   00 00 表示局部变量生命周期开始，相对于字节码的偏移量
            -   00 05 表示局部变量覆盖的范围长度
            -   00 0c 表示局部变量名称，本例引用了常量池 #12 项，是【this】
            -   00 0d 表示局部变量的类型，本例引用了常量池 #13 项，是【Lcn/itcast/jvm/t5/HelloWorld;】
            -   00 00 表示局部变量占有的槽位（slot）编号，本例是 0
-   例2：method-main

    ![](https://img-blog.csdnimg.cn/6be758b63c9c4cd2af5bf5bdc5530b50.png)
    > 红色代表访问修饰符（本类中是 public static）
    > 蓝色代表引用了常量池 #14 项作为方法名称
    > 绿色代表引用了常量池 #15 项作为方法参数描述
    > 黄色代表方法属性数量，本方法是 2
    > 红色代表方法属性（属性1）
    -   00 09 表示引用了常量池 #09 项，发现是【Code】属性
    -   00 00 00 37 表示此属性的长度是 55
    -   00 02 表示【操作数栈】最大深度
    -   00 01 表示【局部变量表】最大槽（slot）数
    -   00 00 00 05 表示字节码长度，本例是 9
    -   b2 00 02 12 03 b6 00 04 b1 是字节码指令
    -   00 00 00 02 表示方法细节属性数量，本例是 2
    -   00 0a 表示引用了常量池 #10 项，发现是【LineNumberTable】属性
        -   00 00 00 0a 表示此属性的总长度，本例是 10
        -   00 02 表示【LineNumberTable】长度
        -   00 00 表示【字节码】行号 00 06 表示【java 源码】行号
        -   00 08 表示【字节码】行号 00 07 表示【java 源码】行号
    -   00 0b 表示引用了常量池 #11 项，发现是【LocalVariableTable】属性
        -   00 00 00 0c 表示此属性的总长度，本例是 12
        -   00 01 表示【LocalVariableTable】长度
        -   00 00 表示局部变量生命周期开始，相对于字节码的偏移量
        -   00 09 表示局部变量覆盖的范围长度
        -   00 10 表示局部变量名称，本例引用了常量池 #16 项，是【args】
        -   00 11 表示局部变量的类型，本例引用了常量池 #17 项，是【\[Ljava/lang/String;】
        -   00 00 表示局部变量占有的槽位（slot）编号，本例是 0
            ![](https://img-blog.csdnimg.cn/5a02c1b7da024af99925f28d3a5c5944.png)
    -   红色代表方法属性（属性2）
        -   00 12 表示引用了常量池 #18 项，发现是【MethodParameters】属性
            -   00 00 00 05 表示此属性的总长度，本例是 5
            -   01 参数数量
            -   00 10 表示引用了常量池 #16 项，是【args】
            -   00 00 访问修饰符

#### 3.1.7 附加属性

> 0001100 00 12 00 00 00 05 01 00 10 00 00 00 01 00 13 00
> 0001120 0 00 02 00 14

-   00 01 表示附加属性数量
-   00 13 表示引用了常量池 #19 项，即【SourceFile】
-   00 00 00 02 表示此属性的长度
-   00 14 表示引用了常量池 #20 项，即【HelloWorld.java】

### 3.2 字节码指令

### 3.2.1 入门

> 参考链接：[https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-6.html#jvms-6.5](https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-6.html#jvms-6.5 "https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-6.html#jvms-6.5")

-   `2a b7 00 01 b1`
    > 接着上一节，研究一下两组字节码指令，一个是
    ```纯文本
    public cn.itcast.jvm.tHelloWorld();
    ```
    构造方法的字节码指令：
    1.  `2a` => aload\_0 加载 slot 0 的局部变量，即 this，做为下面的 invokespecial 构造方法调用的参数
    2.  `b7` => invokespecial 预备调用构造方法，哪个方法呢？
    3.  `00 01` 引用常量池中 #1 项，即【 Method java/lang/Object.“”😦)V 】
    4.  `b1` 表示返回

### 3.2.2 javap工具获取反编译字节码

-   自己分析类文件结构太麻烦了，Oracle 提供了 javap 工具来反编译 class 文件，使用方法见：`1.5.4 运行时常量池`
-   方法一：
    编译：
    ```纯文本
    javac -encoding utf-8 Demo1_java
    ```
    ，生成字节码文件
    反编译字节码文件：
    ```纯文本
    javap -v Demo1_class
    ```
    ，在控制台打印出字节码文件的内容
-   方法二：
    直接在IDEA中进行配置，可直接右键查看反编译好的字节码文件，方法见文章：Intellij IDEA 查看字节码

    ![](https://img-blog.csdnimg.cn/9f9ec2efb58e4497afe2bdc5eb49705b.png)

    ![](https://img-blog.csdnimg.cn/9a86f2f39d3f4444acd8f6aeb2e4af6c.png)

### 3.2.3 图解方法执行流程

#### ① 原始 java 代码

```纯文本
package cn.itcast.jvm.tbytecode; 
/**
* 演示 字节码指令 和 操作数栈、常量池的关系
 */ 
public class Demo3_1 { 
  public static void main(String[] args) { 
    int a = 10; 
    int b = Short.MAX_VALUE + 1; 
    int c = a + b; System.out.println(c); 
  } 
}
```

#### ② 编译后的字节码文件

```纯文本
"D:\\Program Files (x86)\\Java\\jdk15\\bin\\javap.exe" -v Demo3_class
Classfile /E:/00_learning/JAVA/资料-解密JVM/代码/jvm/out/production/jvm/cn/itcast/jvm/t3/bytecode/Demo3_class
  Last modified 2022年7月17日; size 635 bytes
  MD5 checksum 1a6413a652bcc5023f130b392deb76a1
  Compiled from "Demo3_java"
public class cn.itcast.jvm.tbytecode.Demo3_1
  minor version: 0
  major version: 52
  flags: (0x0021) ACC_PUBLIC, ACC_SUPER
  this_class: #6                          // cn/itcast/jvm/t3/bytecode/Demo3_1
  super_class: #7                         // java/lang/Object
  interfaces: 0, fields: 0, methods: 2, attributes: 1
Constant pool:
   #1 = Methodref          ##25         // java/lang/Object."<init>":()V
   #2 = Class              #26            // java/lang/Short
   #3 = Integer            32768
   #4 = Fieldref           ##28        // java/lang/System.out:Ljava/io/PrintStream;
   #5 = Methodref          ##30        // java/io/PrintStream.println:(I)V
   #6 = Class              #31            // cn/itcast/jvm/t3/bytecode/Demo3_1
   #7 = Class              #32            // java/lang/Object
   #8 = Utf8               <init>
   #9 = Utf8               ()V
  #10 = Utf8               Code
  #11 = Utf8               LineNumberTable
  #12 = Utf8               LocalVariableTable
  #13 = Utf8               this
  #14 = Utf8               Lcn/itcast/jvm/t3/bytecode/Demo3_1;
  #15 = Utf8               main
  #16 = Utf8               ([Ljava/lang/String;)V
  #17 = Utf8               args
  #18 = Utf8               [Ljava/lang/String;
  #19 = Utf8               a
  #20 = Utf8               I
  #21 = Utf8               b
  #22 = Utf8               c
  #23 = Utf8               SourceFile
  #24 = Utf8               Demo3_java
  #25 = NameAndType        #8:#9          // "<init>":()V
  #26 = Utf8               java/lang/Short
  #27 = Class              #33            // java/lang/System
  #28 = NameAndType        #34:#35        // out:Ljava/io/PrintStream;
  #29 = Class              #36            // java/io/PrintStream
  #30 = NameAndType        #37:#38        // println:(I)V
  #31 = Utf8               cn/itcast/jvm/t3/bytecode/Demo3_1
  #32 = Utf8               java/lang/Object
  #33 = Utf8               java/lang/System
  #34 = Utf8               out
  #35 = Utf8               Ljava/io/PrintStream;
  #36 = Utf8               java/io/PrintStream
  #37 = Utf8               println
  #38 = Utf8               (I)V
{
  public cn.itcast.jvm.tbytecode.Demo3_1();
    descriptor: ()V
    flags: (0x0001) ACC_PUBLIC
    Code:
      stack=1, locals=1, args_size=1
         0: aload_0
         1: invokespecial #1                  // Method java/lang/Object."<init>":()V
         4: return
      LineNumberTable:
        line 6: 0
      LocalVariableTable:
        Start  Length  Slot  Name   Signature
            0       5     0  this   Lcn/itcast/jvm/t3/bytecode/Demo3_1;

  public static void main(java.lang.String[]);
    descriptor: ([Ljava/lang/String;)V
    flags: (0x0009) ACC_PUBLIC, ACC_STATIC
    Code:
      stack=2, locals=4, args_size=1
         0: bipush        10
         2: istore_1
         3: ldc           #3                  // int 32768
         5: istore_2
         6: iload_1
         7: iload_2
         8: iadd
         9: istore_3
        10: getstatic     #4                  // Field java/lang/System.out:Ljava/io/PrintStream;
        13: iload_3
        14: invokevirtual #5                  // Method java/io/PrintStream.println:(I)V
        17: return
      LineNumberTable:
        line 8: 0
        line 9: 3
        line 10: 6
        line 11: 10
        line 12: 17
      LocalVariableTable:
        Start  Length  Slot  Name   Signature
            0      18     0  args   [Ljava/lang/String;
            3      15     1     a   I
            6      12     2     b   I
           10       8     3     c   I
}
SourceFile: "Demo3_java"
```

#### ③ 常量池载入运行时常量池

![](https://img-blog.csdnimg.cn/b22c66221bdc4b6b88909a7c6b41c5d2.png)

#### ④ 方法字节码载入方法区

![](https://img-blog.csdnimg.cn/9325775050974260a567330e57c1dc3d.png)

#### ⑤ main 线程开始运行，分配栈帧内存

> （stack=2，locals=4）

![](https://img-blog.csdnimg.cn/7c867c5cd4e54ec4a05bb98d3593567b.png)

#### ⑥ 执行引擎开始执行字节码

-   `bipush 10`
    -   将一个 byte 压入操作数栈（其长度会补齐 4 个字节），类似的指令还有
    -   sipush 将一个 short 压入操作数栈（其长度会补齐 4 个字节）
    -   ldc 将一个 int 压入操作数栈
    -   ldc2\_w 将一个 long 压入操作数栈（分两次压入，因为 long 是 8 个字节）
    -   这里小的数字都是和字节码指令存在一起，超过 short 范围的数字存入了常量池

        ![](https://img-blog.csdnimg.cn/22947ad85451424cab0b613ea93dfe30.png)
-   `istore_1`
    -   将操作数栈顶数据弹出，存入局部变量表的 slot 1

        ![](https://img-blog.csdnimg.cn/ac57df91c205499ba1659e1a9267f8f3.png)
-   `ldc #3`
    -   从常量池加载 #3 数据到操作数栈
    -   注意 Short.MAX\_VALUE 是 32767，所以 32768 = Short.MAX\_VALUE + 1 实际是在编译期间计算好的

        ![](https://img-blog.csdnimg.cn/00b7d21bc44c45d8b6f1ec0ea58f6775.png)
-   `istore_2`

    ![](https://img-blog.csdnimg.cn/3f6369e1a61540a9bd7cb57045b35b51.png)
-   `iload_1`

    ![](https://img-blog.csdnimg.cn/714d38435d904e70add6dc15fe333500.png)
-   `iload_2`

    ![](https://img-blog.csdnimg.cn/2966d08995414800bea1e0e5c3f1e007.png)
-   `iadd`

    ![](https://img-blog.csdnimg.cn/8c524e10f4544fec8966ac3ea05dbede.png)
-   `istore_3`

    ![](https://img-blog.csdnimg.cn/6b18ba723aef47d985f476458fd27fe3.png)
-   `getstatic #4`

    ![](https://img-blog.csdnimg.cn/879e32fc12ed4bf98226548073f0408f.png)

    ![](https://img-blog.csdnimg.cn/ae86a94b22a14e349b1f59daf468e3b4.png)
-   `iload_3`

    ![](https://img-blog.csdnimg.cn/3b72fd9a2e8a4067bf1d2094b48617c8.png)
-   `invokevirtual #5`
    -   找到常量池 #5 项
    -   定位到方法区 java/io/PrintStream.println:(I)V 方法
    -   生成新的栈帧（分配 locals、stack等）
    -   传递参数，执行新栈帧中的字节码

        ![](https://img-blog.csdnimg.cn/c32a6703a7bc41cf90201d0897f3106a.png)
    -   执行完毕，弹出栈帧
    -   清除 main 操作数栈内容

        ![](https://img-blog.csdnimg.cn/74969cb3fe4f43b2a7cb7585a35018b5.png)
-   `return`
    -   完成 main 方法调用，弹出 main 栈帧
    -   程序结束

### 3.2.4 练习 - 分析 i++

-   目的：从字节码角度分析 a++ 相关题目
-   源码：
    ```纯文本
    package cn.itcast.jvm.tbytecode;

    /**
     * 从字节码角度分析　a++  相关题目
     */
    public class Demo3_2 {
        public static void main(String[] args) {
            int a = 10;
            int b = a++ + ++a + a--;
            System.out.println(a);
            System.out.println(b);
        }
    }
    ```
-   字节码：
    ```纯文本
    "D:\\Program Files (x86)\\Java\\jdk15\\bin\\javap.exe" -v Demo3_class
    Classfile /E:/00_learning/JAVA/资料-解密JVM/代码/jvm/out/production/jvm/cn/itcast/jvm/t3/bytecode/Demo3_class
      Last modified 2022年7月17日; size 610 bytes
      MD5 checksum 5f6a35e5b9bb88d08249958a8d2ab043
      Compiled from "Demo3_java"
    public class cn.itcast.jvm.tbytecode.Demo3_2
      minor version: 0
      major version: 52
      flags: (0x0021) ACC_PUBLIC, ACC_SUPER
      this_class: #4                          // cn/itcast/jvm/t3/bytecode/Demo3_2
      super_class: #5                         // java/lang/Object
      interfaces: 0, fields: 0, methods: 2, attributes: 1
    Constant pool:
       #1 = Methodref          ##22         // java/lang/Object."<init>":()V
       #2 = Fieldref           ##24        // java/lang/System.out:Ljava/io/PrintStream;
       #3 = Methodref          ##26        // java/io/PrintStream.println:(I)V
       #4 = Class              #27            // cn/itcast/jvm/t3/bytecode/Demo3_2
       #5 = Class              #28            // java/lang/Object
       #6 = Utf8               <init>
       #7 = Utf8               ()V
       #8 = Utf8               Code
       #9 = Utf8               LineNumberTable
      #10 = Utf8               LocalVariableTable
      #11 = Utf8               this
      #12 = Utf8               Lcn/itcast/jvm/t3/bytecode/Demo3_2;
      #13 = Utf8               main
      #14 = Utf8               ([Ljava/lang/String;)V
      #15 = Utf8               args
      #16 = Utf8               [Ljava/lang/String;
      #17 = Utf8               a
      #18 = Utf8               I
      #19 = Utf8               b
      #20 = Utf8               SourceFile
      #21 = Utf8               Demo3_java
      #22 = NameAndType        #6:#7          // "<init>":()V
      #23 = Class              #29            // java/lang/System
      #24 = NameAndType        #30:#31        // out:Ljava/io/PrintStream;
      #25 = Class              #32            // java/io/PrintStream
      #26 = NameAndType        #33:#34        // println:(I)V
      #27 = Utf8               cn/itcast/jvm/t3/bytecode/Demo3_2
      #28 = Utf8               java/lang/Object
      #29 = Utf8               java/lang/System
      #30 = Utf8               out
      #31 = Utf8               Ljava/io/PrintStream;
      #32 = Utf8               java/io/PrintStream
      #33 = Utf8               println
      #34 = Utf8               (I)V
    {
      public cn.itcast.jvm.tbytecode.Demo3_2();
        descriptor: ()V
        flags: (0x0001) ACC_PUBLIC
        Code:
          stack=1, locals=1, args_size=1
             0: aload_0
             1: invokespecial #1                  // Method java/lang/Object."<init>":()V
             4: return
          LineNumberTable:
            line 6: 0
          LocalVariableTable:
            Start  Length  Slot  Name   Signature
                0       5     0  this   Lcn/itcast/jvm/t3/bytecode/Demo3_2;

      public static void main(java.lang.String[]);
        descriptor: ([Ljava/lang/String;)V
        flags: (0x0009) ACC_PUBLIC, ACC_STATIC
        Code:
          stack=2, locals=3, args_size=1
             0: bipush        10
             2: istore_1
             3: iload_1
             4: iinc          1, 1
             7: iinc          1, 1
            10: iload_1
            11: iadd
            12: iload_1
            13: iinc          1, -1
            16: iadd
            17: istore_2
            18: getstatic     #2                  // Field java/lang/System.out:Ljava/io/PrintStream;
            21: iload_1
            22: invokevirtual #3                  // Method java/io/PrintStream.println:(I)V
            25: getstatic     #2                  // Field java/lang/System.out:Ljava/io/PrintStream;
            28: iload_2
            29: invokevirtual #3                  // Method java/io/PrintStream.println:(I)V
            32: return
          LineNumberTable:
            line 8: 0
            line 9: 3
            line 10: 18
            line 11: 25
            line 12: 32
          LocalVariableTable:
            Start  Length  Slot  Name   Signature
                0      33     0  args   [Ljava/lang/String;
                3      30     1     a   I
               18      15     2     b   I
    }
    SourceFile: "Demo3_java"
    ```
-   分析：
    -   注意 iinc 指令是直接在局部变量 slot 上进行运算
    -   a++ 和 ++a 的区别是先执行 iload 还是 先执行 iinc

        ![](https://img-blog.csdnimg.cn/f2b7d15a9ef443a4b75c02850a301319.png)

        ![](https://img-blog.csdnimg.cn/413cd1c3c43c45a295322658ea191ec7.png)

        ![](https://img-blog.csdnimg.cn/e7be3dc4970d44fa82ee5d8d177e37ef.png)

        ![](https://img-blog.csdnimg.cn/8e8f4b6284d5416eb9eda7a3b4ea70d9.png)

        ![](https://img-blog.csdnimg.cn/cf058319a8584c4b8174ad71bb8321f6.png)

        ![](https://img-blog.csdnimg.cn/a57117b72d894be59ade99cccfa1ce2d.png)

### 3.2.5 条件判断指令

> 参考链接：[https://docs.oracle.com/javase/specs/jvms/se7/html/jvms-6.html#jvms-6.5.lcmp](https://docs.oracle.com/javase/specs/jvms/se7/html/jvms-6.html#jvms-6.5.lcmp "https://docs.oracle.com/javase/specs/jvms/se7/html/jvms-6.html#jvms-6.5.lcmp")

![](https://img-blog.csdnimg.cn/0dc47912b5cf4d419d0f259ccf9c3320.png)

### 3.2.6 循环控制指令

> 循环控制还是前面介绍的那些指令。

-   while 循环源码：
    ```纯文本
    public class Demo3_4 {
        public static void main(String[] args) {
            int a = 0;
            while (a < 10) {
                a++;
            }
        }
    }
    ```
-   字节码：
    ```纯文本
    0: iconst_0
     1: istore_1
     2: iload_1
     3: bipush        10
     5: if_icmpge     14
     8: iinc          1, 1
    11: goto          2
    14: return
    ```
-   do while 循环源码：
    ```纯文本
    public class Demo3_5 {
        public static void main(String[] args) {
            int a = 0;
            do {
                a++;
            } while (a < 10);
        }
    }
    ```
-   字节码：
    ```纯文本
    0: iconst_0
     1: istore_1
     2: iinc          1, 1
     5: iload_1
     6: bipush        10
     8: if_icmplt     2
    11: return
    ```
-   for 循环源码：
    ```纯文本
    public class Demo3_6 {
        public static void main(String[] args) {
            for (int i = 0; i < 10; i++) {

            }
        }
    }
    ```
-   字节码：
    ```纯文本
    0: iconst_0
     1: istore_1
     2: iload_1
     3: bipush        10
     5: if_icmpge     14
     8: iinc          1, 1
    11: goto          2
    14: return
    ```

### 3.2.7 练习 - 判断结果

-   请从字节码角度分析，下列代码运行的结果：
    ```纯文本
    public class Demo3_6_1 {
        public static void main(String[] args) {
            int i = 0;
            int x = 0;
            while (i < 10) {
                x = x++;
                i++;
            }
            System.out.println(x);// 结果是 0
        }
    }
    ```

> `x = x++;`：自增运算 iinc 指令是直接在局部变量 slot 上进行运算，对于此语句，x为局部变量表上的一个槽点，初值为0；`x++`对应两条指令iload\_x(将局部变量表的0读入操作数栈)与iinc\_x（局部变量槽内的0+1变为1）；然后进行赋值操作，用操作数栈中的0覆盖局部变量槽内x的值，即x的值又变回0。因此不论此语句循环几次x的值都为0。

### 3.2.8 构造方法

#### < cinit >()V

```纯文本
public class Demo3_8_1 {
    static int i = 10;

    static {
        i = 20;
    }

    static {
        i = 30;
    }
}
```

> 编译器会`按从上至下的顺序`，收集所有 static 静态代码块和静态成员赋值的代码，合并为一个特殊的方法 `<cinit>()V` ：

```纯文本
0: bipush        20
 2: putstatic     #3                  // Field i:I
 5: bipush        30
 7: putstatic     #3                  // Field i:I
10: bipush        10
12: putstatic     #3                  // Field i:I
15: return
```

> `<cinit>()V` 方法会在`类加载的初始化阶段`被调用。

#### < init >()V

```纯文本
public class Demo3_8_2 {

    private String a = "s1";

    {
        b = 20;
    }

    private int b = 10;

    {
        a = "s2";
    }

    public Demo3_8_2(String a, int b) {
        this.a = a;
        this.b = b;
    }

    public static void main(String[] args) {
        Demo3_8_2 d = new Demo3_8_2("s3", 30);
        System.out.println(d.a);
        System.out.println(d.b);
    }
}
```

> 编译器会`按从上至下的顺序`，收集所有 {} 代码块和成员变量赋值的代码，形成新的构造方法，但`原始构造方法内的代码总是在最后`

![](https://img-blog.csdnimg.cn/6018fdc752de44668dd1db5409276724.png)

### 3.2.9 方法调用

```纯文本
public class Demo3_9 {
    public Demo3_9() { }

    private void test1() { }

    private final void test2() { }

    public void test3() { }

    public static void test4() { }

    @Override
    public String toString() {
        return super.toString();
    }

    public static void main(String[] args) {
        Demo3_9 d = new Demo3_9();
        d.test1();
        d.test2();
        d.test3();
        d.test4();
        Demo3_test4();
        d.toString();
    }
}
```

> 不同的方法调用对应的字节码指令：

```纯文本
 0: new           #3                  // class cn/itcast/jvm/t3/bytecode/Demo3_9
 3: dup
 4: invokespecial #4                  // Method "<init>":()V
 7: astore_1
 8: aload_1
 9: invokespecial #5                  // Method test1:()V
12: aload_1
13: invokespecial #6                  // Method test2:()V
16: aload_1
17: invokevirtual #7                  // Method test3:()V
20: aload_1
21: pop
22: invokestatic  #8                  // Method test4:()V
25: invokestatic  #8                  // Method test4:()V
28: aload_1
29: invokevirtual #9                  // Method toString:()Ljava/lang/String;
32: pop
33: return
```

-   \*\*new \*\*是创建【对象】，给对象分配堆内存，执行成功会将【对象引用】压入操作数栈
-   \*\*dup \*\*是复制操作数栈栈顶的内容，本例即为【对象引用】，为什么需要两份引用呢，一个是要配合 invokespecial 调用该对象的构造方法 `"<init>":()V` （会消耗掉栈顶一个引用），另一个要配合 astore\_1 赋值给局部变量
-   **最终方法（final），私有方法（private），构造方法都是由 ****`invokespecial`**** 指令来调用，属于**\*\*`静态绑定`\*\*
-   **普通成员方法是由 ****`invokevirtual`**** 调用，属于**\*\*`动态绑定，即支持多态`\*\*
-   成员方法与静态方法调用的另一个区别是，执行方法前是否需要【对象引用】
-   比较有意思的是 `d.test4();` 是通过【对象引用】调用一个静态方法，可以看到在调用`invokestatic` 之前执行了 pop 指令，把【对象引用】从操作数栈弹掉了，**因此在调用静态方法时尽量使用类调用而不是对象，否则会产生冗余的虚拟机指令**
-   还有一个执行 `invokespecial` 的情况是通过 super 调用父类方法

### 3.2.10 多态的原理

```纯文本
package cn.itcast.jvm.tbytecode;

import java.io.IOException;

/**
 * 演示多态原理，注意加上下面的 JVM 参数，禁用指针压缩
 * -XX:-UseCompressedOops -XX:-UseCompressedClassPointers
 */
public class Demo3_10 {

    public static void test(Animal animal) {
        animal.eat();
        System.out.println(animal.toString());
    }

    public static void main(String[] args) throws IOException {
        test(new Cat());
        test(new Dog());
        System.in.read();
    }
}

abstract class Animal {
    public abstract void eat();

    @Override
    public String toString() {
        return "我是" + this.getClass().getSimpleName();
    }
}

class Dog extends Animal {

    @Override
    public void eat() {
        System.out.println("啃骨头");
    }
}

class Cat extends Animal {

    @Override
    public void eat() {
        System.out.println("吃鱼");
    }
}
```

1.  加虚拟机参数（`-XX:-UseCompressedOops -XX:-UseCompressedClassPointers`），运行代码 &#x20;
    &#x20;  停在 System.in.read() 方法上，这时运行 `jps` 获取进程 id
2.  运行 HSDB 工具 &#x20;

    进入 JDK 安装目录 →  bin 目录下，执行
    ```java
    java.exe -cp ../lib/sa-jdi.jar sun.jvm.hotspot.HSDB
    ```
    进入图形界面 file →  attach  输入进程 id
3.  查找某个对象 &#x20;
    &#x20;  打开 Tools -> Find Object By Query &#x20;
    &#x20;  输入&#x20;
    ```java
    select d from cn.itcast.jvm.tbytecode.Dog d
    ```
    ![在这里插入图片描述](https://img-blog.csdnimg.cn/908771ea9e864bcd91c3bfe472fa8180.png "在这里插入图片描述")

    点击 Execute 执行 &#x20;
4.  查看对象内存结构 &#x20;
    &#x20;  点击超链接可以看到对象的内存结构，此对象没有任何属性，因此只有对象头的 16 字节，前 8 字节是MarkWord，后 8 字节就是对象的 Class 指针 &#x20;
    &#x20;  但目前看不到它的实际地址 &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/d3659517bcdf492e8d348477da0a2672.png "在这里插入图片描述")
5.  查看对象 Class 的内存地址 &#x20;
    &#x20;  可以通过 Windows -> Console 进入命令行模式，执行
    ```java
    mem 0x00000001299b4978 2
    ```
    mem 有两个参数，参数 1 是对象地址，参数 2 是查看 2 行（即 16 字节） &#x20;

    结果中第二行 0x000000001b7d4028 即为 Class 的内存地址 &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/c50da64fbdb9488fbd94bd20a0898dd2.png "在这里插入图片描述")
6.  查看类的 vtable &#x20;
    &#x20;  方法1：Alt+R 进入 Inspector 工具，输入刚才的 Class 内存地址，看到如下界面： &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/8ed720027b5c4bf9a4cc5ee3dc893cf8.png "在这里插入图片描述")

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/3d40b65ac8ee4aa6893db6acab3a9cbb.png "在这里插入图片描述")

    ![](https://img-blog.csdnimg.cn/166f53c2c20d4024ae335c53171c7097.png)

    Console 进入命令行模式，执行：`mem 0x000000001b7d41e0 6` ，就得到了 6 个虚方法的入口地址。 &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/37931a556e184cfea52245e0eff3c75d.png "在这里插入图片描述")
7.  验证方法地址 &#x20;
    &#x20;  通过 Tools -> Class Browser ，搜索 Dog类 → 查看父类Animal → 再查看Object 分别查看每个类的**方法**定义，比较可知： &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/88fbe448e9474bb08bff789dfa4a8d3d.png "在这里插入图片描述")

    对号入座，发现：
    -   eat() 方法是 Dog 类自己的
    -   toString() 方法是继承 String 类的
    -   finalize() ，equals()，hashCode()，clone() 都是继承 Object 类的

-   小结
    当执行 invokevirtual 指令时：
    1.  先通过栈帧中的对象引用找到对象
    2.  分析对象头，找到对象的实际 Class
    3.  Class 结构中有 `vtable`，它在`类加载的链接阶段`就已经根据方法的重写规则`生成`好了
    4.  查表得到`方法的具体地址`
        1.  执行方法的字节码

### 3.2.11 异常处理

#### try-catch

```纯文本
public class Demo3_11_1 {
    public static void main(String[] args) {
        int i = 0;
        try {
            i = 10;
        } catch (Exception e) {
            i = 20;
        }
    }
}
```

> 字节码：

```纯文本
Code:
      stack=1, locals=3, args_size=1
         0: iconst_0
         1: istore_1
         2: bipush        10
         4: istore_1
         5: goto          12
         8: astore_2
         9: bipush        20
        11: istore_1
        12: return
      Exception table:
         from    to  target type
             2     5     8   Class java/lang/Exception
      LineNumberTable:
        line 6: 0
        line 8: 2
        line 11: 5
        line 9: 8
        line 10: 9
        line 12: 12
      LocalVariableTable:
        Start  Length  Slot  Name   Signature
            9       3     2     e   Ljava/lang/Exception;
            0      13     0  args   [Ljava/lang/String;
            2      11     1     i   I
```

-   可以看到多出来一个 Exception table 的结构，`[from, to)` 是`前闭后开`的检测范围，一旦这个范围内的字节码执行`出现异常`，则`通过 type 匹配异常类型`，如果一致，`进入 target 所指示行号`
-   8 行的字节码指令 astore\_2 是将异常对象引用存入局部变量表的 slot 2 位置，通过 `LocalVariableTable` 可知其存储的为e变量

#### 多个 single-catch 块的情况

```纯文本
public class Demo3_11_2 {
    public static void main(String[] args) {
        int i = 0;
        try {
            i = 10;
        } catch (ArithmeticException e) {
            i = 30;
        } catch (NullPointerException e) {
            i = 40;
        } catch (Exception e) {
            i = 50;
        }
    }
}
```

> 字节码：

```纯文本
Code:
      stack=1, locals=3, args_size=1
         0: iconst_0
         1: istore_1
         2: bipush        10
         4: istore_1
         5: goto          26
         8: astore_2
         9: bipush        30
        11: istore_1
        12: goto          26
        15: astore_2
        16: bipush        40
        18: istore_1
        19: goto          26
        22: astore_2
        23: bipush        50
        25: istore_1
        26: return
      Exception table:
         from    to  target type
             2     5     8   Class java/lang/ArithmeticException
             2     5    15   Class java/lang/NullPointerException
             2     5    22   Class java/lang/Exception
      LineNumberTable:
          ...
      LocalVariableTable:
        Start  Length  Slot  Name   Signature
            9       3     2     e   Ljava/lang/ArithmeticException;
           16       3     2     e   Ljava/lang/NullPointerException;
           23       3     2     e   Ljava/lang/Exception;
            0      27     0  args   [Ljava/lang/String;
            2      25     1     i   I
```

-   因为异常出现时，只能进入 Exception table 中一个分支，所以局部变量表 slot 2 位置被`共用`

#### multi-catch 的情况

```纯文本
public class Demo3_11_3 {
    public static void main(String[] args) {
        try {
            Method test = Demo3_11_class.getMethod("test");
            test.invoke(null);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    public static void test() {
        System.out.println("ok");
    }
}
```

> 字节码：

```纯文本
Code:
      stack=3, locals=2, args_size=1
         0: ldc           #2                  // class cn/itcast/jvm/t3/bytecode/Demo3_11_3
         2: ldc           #3                  // String test
         4: iconst_0
         5: anewarray     #4                  // class java/lang/Class
         8: invokevirtual #5                  // Method java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        11: astore_1
        12: aload_1
        13: aconst_null
        14: iconst_0
        15: anewarray     #6                  // class java/lang/Object
        18: invokevirtual #7                  // Method java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        21: pop
        22: goto          30
        25: astore_1
        26: aload_1
        27: invokevirtual #11                 // Method java/lang/ReflectiveOperationException.printStackTrace:()V
        30: return
      Exception table:
         from    to  target type
             0    22    25   Class java/lang/NoSuchMethodException
             0    22    25   Class java/lang/IllegalAccessException
             0    22    25   Class java/lang/reflect/InvocationTargetException
      LineNumberTable:
        ...
      LocalVariableTable:
        Start  Length  Slot  Name   Signature
           12      10     1  test   Ljava/lang/reflect/Method;
           26       4     1     e   Ljava/lang/ReflectiveOperationException;
            0      31     0  args   [Ljava/lang/String;
```

#### finally

```纯文本
public class Demo3_11_4 {
    public static void main(String[] args) {
        int i = 0;
        try {
            i = 10;
        } catch (Exception e) {
            i = 20;
        } finally {
            i = 30;
        }
    }
}
```

字节码：

![](https://img-blog.csdnimg.cn/1c77e28601b9410f87f257dadfe7a095.png)

-   可以看到 finally 中的代码被复制了 3 份，分别放入 try 流程，catch 流程以及 catch 剩余的异常类型流程

### 3.2.12 练习 - finally 面试题

#### finally 出现了 return

```纯文本
public class Demo3_12_1 {
    public static void main(String[] args) {
        int result = test();
        System.out.println(result);//20
    }

    public static int test() {
        try {
            int i = 1/0;
            return 10;
        } finally {
            return 20;
        }
    }
}
```

> 字节码：

```纯文本
Code:
      stack=2, locals=3, args_size=0
         0: iconst_1
         1: iconst_0
         2: idiv
         3: istore_0
         4: bipush        10
         6: istore_1
         7: bipush        20
         9: ireturn
        10: astore_2
        11: bipush        20
        13: ireturn
      Exception table:
         from    to  target type
             0     7    10   any
      LineNumberTable:
        ...
      LocalVariableTable:
        Start  Length  Slot  Name   Signature
            4       6     0     i   I
```

-   由于 finally 中的 ireturn 被插入了所有可能的流程，因此返回结果肯定以 finally 的为准
-   至于字节码中第 2 行，似乎没啥用，且留个伏笔，看下个例子
-   跟上例中的 finally 相比，发现没有 athrow 了，这告诉我们：`如果在 finally 中出现了 return，会吞掉异常`。因此在写代码时应当尽量避免在finally中写return

#### finally（无return）对返回值影响

```纯文本
public class Demo3_12_2 {
    public static void main(String[] args) {
        int result = test();
        System.out.println(result);//10
    }

    public static int test() {
        int i = 10;
        try {
            return i;
        } finally {
            i = 20;
        }
    }
}
```

> 字节码：

![](https://img-blog.csdnimg.cn/85f48ea546f3487faf6ad7d8b3c7d874.png)

### 3.2.13 synchronized

```纯文本
public class Demo3_13 {
    public static void main(String[] args) {
        Object lock = new Object();
        synchronized (lock) {
            System.out.println("ok");
        }
    }
}
```

字节码：

![](https://img-blog.csdnimg.cn/358177342d2941a7a64998f994ee4886.png)

> 注意synchronized 方法形式不会在字节码中体现。&#x20;

### 3.3 编译期处理(语法糖)

-   所谓的 `语法糖` ，其实就是`指 java 编译器把 `*.java\*\*`源码编译为`*.class` 字节码的过程中，自动生成和转换的一些代码`，主要是为了减轻程序员的负担，算是 java 编译器给的一个额外福利
-   注意，以下代码的分析，借助了 javap 工具，idea 的反编译功能，idea 插件 jclasslib 等工具。另外，编译器转换的结果直接就是 class 字节码，只是为了便于阅读，给出了 几乎等价 的 java 源码方式，并不是编译器还会转换出中间的 java 源码，切记。

### 3.3.1 默认构造器

![](https://img-blog.csdnimg.cn/63eef5af483d46bcb22001bb65210646.png)

> 编译成class后的代码：

![](https://img-blog.csdnimg.cn/ac049763ca3642c7ab0ccfe682f525a1.png)

### 3.3.2 自动拆装箱

> 这个特性是 JDK 5 开始加入的， 代码片段1：
>
> ![](https://img-blog.csdnimg.cn/8c4659aaae944c9ea914da1835e70f52.png)
>
> 这段代码在 JDK 5 之前是无法编译通过的，必须改写为 代码片段2：
>
> ![](https://img-blog.csdnimg.cn/141436937b984f72864a4f3ab52cb6df.png)
>
> 显然之前版本的代码太麻烦了，需要在基本类型和包装类型之间来回转换（尤其是集合类中操作的都是包装类型），因此这些转换的事情在 JDK 5 以后都由编译器在编译阶段完成。即 代码片段1 都会在编译阶段被转换为 代码片段2。

### 3.3.3 泛型集合取值]

> 泛型也是在 JDK 5 开始加入的特性，但 java 在编译泛型代码后会执行 `泛型擦除` 的动作，即`泛型信息在编译为字节码之后就丢失了，实际的类型都当做了 Object 类型`来处理： &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/c1402a582c0741569ac4d07319433b3a.png "在这里插入图片描述")

所以在取值时，编译器真正生成的字节码中，还要额外做一个类型转换的操作： &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/e15b21ae6f4c490da195c1033e860a10.png "在这里插入图片描述")

> 如果前面的 x 变量类型修改为 int 基本类型那么最终生成的字节码是： &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/8a17f4e53e7f4ffd99208fe3f7ffc50a.png "在这里插入图片描述")

字节码： &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/14529e63de3344879fd53c95addcdcd7.png "在这里插入图片描述")

![在这里插入图片描述](https://img-blog.csdnimg.cn/5bdc19a188eb4228bdeb74b526691424.png "在这里插入图片描述")

![在这里插入图片描述](https://img-blog.csdnimg.cn/b7de48e488e94c3bb110af9726c5506d.png "在这里插入图片描述")

擦除的是`字节码上的`泛型信息，可以看到 `LocalVariableTypeTable` 仍然保留了`方法参数泛型`以及`方法返回值泛型`的信息： &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/32d078b68e7946c89d4177279bd0de4a.png "在这里插入图片描述")

字节码：

```java
public java.util.Set<java.lang.Integer> test(java.util.List<java.lang.String>, java.util.Map<java.lang.Integer, java.lang.Object>);
    descriptor: (Ljava/util/List;Ljava/util/Map;)Ljava/util/Set;
    flags: (0x0001) ACC_PUBLIC
    Code:
      stack=1, locals=3, args_size=3
         0: aconst_null
         1: areturn
      LineNumberTable:
        line 34: 0
      LocalVariableTable:
        Start  Length  Slot  Name   Signature
            0       2     0  this   Lcn/itcast/jvm/t3/candy/Candy3;
            0       2     1  list   Ljava/util/List;
            0       2     2   map   Ljava/util/Map;
      LocalVariableTypeTable:
        Start  Length  Slot  Name   Signature
            0       2     1  list   Ljava/util/List<Ljava/lang/String;>;
            0       2     2   map   Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Object;>;
    Signature: #73                          // (Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Object;>;)Ljava/util/Set<Ljava/lang/Integer;>;
```

> 使用反射，仍然能够获得这些信息：

```java
Method test = Candyclass.getMethod("test", List.class, Map.class);
Type[] types = test.getGenericParameterTypes();
for (Type type : types) {
    if (type instanceof ParameterizedType) {
        ParameterizedType parameterizedType = (ParameterizedType) type;
        System.out.println("原始类型 - " + parameterizedType.getRawType());
        Type[] arguments = parameterizedType.getActualTypeArguments();
        for (int i = 0; i < arguments.length; i++) {
            System.out.printf("泛型参数[%d] - %s\\n", i, arguments[i]);
        }
    }
}
```

> 输出： &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/db6fa953fa494393bfc09196f4bf4bba.png "在这里插入图片描述")

### 3.3.4 可变参数

> 可变参数也是 JDK 5 开始加入的新特性：
> 例如：

![](https://img-blog.csdnimg.cn/92fef12d5f9b49c08aa68ae3af72e815.png)

> 可变参数&#x20;

> `String... args`

> &#x20;其实是一个&#x20;

> `String[] args`

> &#x20;，从代码中的赋值语句中就可以看出来。

> 同样 java 编译器会在编译期间将上述代码变换为：

![](https://img-blog.csdnimg.cn/99e14560d9f84df7aacb62613704dd6e.png)

-   注意
    如果调用了 `foo()` 则等价代码为 `foo(new String[]{})` ，创建了一个`空的数组`，而不会传递null 进去

### 3.3.5 foreach 循环

> 仍是 JDK 5 开始引入的语法糖，数组的循环：

![](https://img-blog.csdnimg.cn/e5da0d06bde24c5fb2208bcc40895078.png)

> 会被编译器转换为：

![](https://img-blog.csdnimg.cn/b95042dfc2f248e6b88ea3a3b5012be2.png)

> 而集合的循环：

![](https://img-blog.csdnimg.cn/1281729379ca4019b79712f3feefa1d4.png)

> 实际被编译器转换为对迭代器的调用：

![](https://img-blog.csdnimg.cn/92a0164cb51a4c64868f1f3badf38f71.png)

-   注意
    `for each` 循环写法，能够配合`数组`，以及 `所有实现了 `Iterable` 接口的集合类` 一起使用，其中 `Iterable 用来获取集合的迭代器（ Iterator ）`

### 3.3.7 switch 枚举

switch 枚举的例子，原始代码：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/28/1677587687127.png)

转换后代码：

![](https://img-blog.csdnimg.cn/d39ebd2c1ace476c8310cf2b6495be87.png)

![](https://img-blog.csdnimg.cn/9c010eb1f1c544238e014b9f424fcd5d.png)

### 3.3.8 枚举类

JDK 7 新增了枚举类，以前面的性别枚举为例：

![](https://img-blog.csdnimg.cn/5506c89df30d4c19a2c9d50891f035bf.png)

转换后代码：

![](https://img-blog.csdnimg.cn/182fdcf76cf6493a9c5ca60e831492e4.png)

### 3.3.9 try-with-resources

> JDK 7 开始新增了对`需要关闭的资源处理的特殊语法` `try-with-resources`： &#x20;
>
> ![在这里插入图片描述](https://img-blog.csdnimg.cn/b77ca0a57f0140888a9f75257aca6db1.png "在这里插入图片描述")
>
> 其中资源对象需要实现 `AutoCloseable` 接口，例如 `InputStream` 、 `OutputStream` 、 `Connection` 、 `Statement` 、 `ResultSet` 等接口都实现了 `AutoCloseable`，使用 `try-with- resources` 可以不用写 `finally` 语句块，编译器会帮助生成关闭资源代码，例如： &#x20;
>
> ![在这里插入图片描述](https://img-blog.csdnimg.cn/b1a5d341dbfc4fa1ba10336077d19662.png "在这里插入图片描述")
>
> 会被转换为： &#x20;
>
> ![在这里插入图片描述](https://img-blog.csdnimg.cn/5693889e46ec4481882a3f526749309b.png "在这里插入图片描述")
>
> ![在这里插入图片描述](https://img-blog.csdnimg.cn/b68d00c275174b82b39a77e1f5aad46d.png "在这里插入图片描述")
>
> 为什么要设计一个&#x20;
>
> ```java
> addSuppressed(Throwable e)
> ```
>
> ![在这里插入图片描述](https://img-blog.csdnimg.cn/a25438213c2a432595cd68aa153c427f.png "在这里插入图片描述")
>
> 输出： &#x20;
>
> ![在这里插入图片描述](https://img-blog.csdnimg.cn/a516673756ca4000bb061030fc1a4324.png "在这里插入图片描述")
>
> （添加被压制异常）的方法呢？是为了`防止异常信息的丢失`（想想 try-with-resources 生成的 fianlly 中如果抛出了异常）：
>
> ![](https://img-blog.csdnimg.cn/a516673756ca4000bb061030fc1a4324.png)

### 3.3.10 方法重写时的桥接方法

我们都知道，方法重写时对返回值分两种情况：

-   父子类的返回值完全一致
-   子类返回值可以是父类返回值的子类（比较绕口，见下面的例子）：

    对于子类，java 编译器会做如下处理：

    其中桥接方法比较特殊，仅对 java 虚拟机可见，并且与原来的 public Integer m() 没有命名冲突，可以用下面反射代码来验证：

    会输出：

    ![](https://img-blog.csdnimg.cn/a3a013e0ae2c40a9969771ffd3eab8c1.png)

    ![](https://img-blog.csdnimg.cn/bcc7a627a1614aba90bb79044e33cab3.png)

    ![](https://img-blog.csdnimg.cn/95100ec170ca4d88a4debc4cead02047.png)

    ![](https://img-blog.csdnimg.cn/3441729c2b14481a8fd5825b60d404fe.png)

### 3.3.11 匿名内部类

![](https://img-blog.csdnimg.cn/91f73f7233d94536a085f4b4ea07c59d.png)

转换后代码：

![](https://img-blog.csdnimg.cn/8464e1f24acb4734ba30cb5a2be4bc63.png)

![](https://img-blog.csdnimg.cn/d21fa585fd0c4ec488736fe37eacf337.png)

引用局部变量的匿名内部类，源代码：

![](https://img-blog.csdnimg.cn/d89a03c4deb146c0a60a273488e9e1bd.png)

转换后代码：

![](https://img-blog.csdnimg.cn/b9d4d4c4fd3242f6a81c15de6d820886.png)

![](https://img-blog.csdnimg.cn/b8f8a0a96bbd40f4b7b716fef1be3950.png)

-   注意
    这同时解释了为什么`匿名内部类引用局部变量时，局部变量必须是 final 的`：因为在创建`Candy11$1` 对象时，将 `x` 的值赋值给了`Candy11$1`对象的 `val$x` 属性，所以`x` 不应该再发生变化了，如果变化，那么`val$x`属性没有机会再跟着一起变化。

### 3.4 类加载阶段

### 3.4.1 加载

-   将类的字节码载入方法区中，内部采用 C++ 的 instanceKlass 描述 java 类，它的重要 field 有：
    -   `_java_mirror` 即 java 的类镜像，例如对 String 来说，就是 String.class，作用是把 klass 暴露给 java 使用
    -   `_super` 即父类
    -   `_fields` 即成员变量
    -   `_methods` 即方法
    -   `_constants` 即常量池
    -   `_class_loader` 即类加载器
    -   `_vtable` 虚方法表：存储方法的实际入口地址
    -   `_itable` 接口方法表

        ![](https://img-blog.csdnimg.cn/166c625d4073453b908982f3b4867b28.png)
-   如果这个类还有父类没有加载，先加载父类
-   加载和链接可能是交替运行的
-   注意：
    -   instanceKlass 这样的【元数据】是存储在方法区（1.8 后的元空间内），但 \_java\_mirror是存储在堆中
    -   可以通过前面介绍的 HSDB 工具查看

### 3.4.2 链接

#### 验证

验证类是否符合 JVM规范，安全性检查

-   用 UE 等支持二进制的编辑器修改 HelloWorld.class 的魔数，在控制台运行

    ![](https://img-blog.csdnimg.cn/03722b1ff1ea4782860fec5f3f73d95e.png)

#### 准备

为 `static 变量`分配空间，`设置默认值`

-   static 变量在 JDK 7 之前存储于 instanceKlass 末尾，从 JDK 7 开始，存储于 `_java_mirror 末尾`
-   `static 变量`分配空间和赋值是两个步骤，`分配空间`在`准备阶段`完成，`赋值`在`初始化阶段`完成
-   如果 `static 变量`是 `final` 的`基本类型`，以及`字符串常量`，那么编译阶段值就确定了，`赋值在准备阶段完成`
-   如果 `static 变量`是 `final 的`，但属于`引用类型`，那么赋值也会在`初始化阶段`完成

#### 解析

将常量池中的符号引用解析为直接引用（解析后才能知道类在内存中的实际地址）

-   注意：loadClass 方法仅会加载类，不会导致类的解析和初始化

    ![](https://img-blog.csdnimg.cn/f0d311c162564371b0824a5e28d58c8f.png)

### 3.4.3 初始化

-   `<cinit>()V` 方法
    **初始化即调用 ****`<cinit>()V`****，`虚拟机会保证这个类的『构造方法』的线程安全`**
-   发生的时机
    概括得说，类初始化是【`懒惰的`】
    -   main 方法所在的类，总会被首先初始化
    -   首次访问这个类的静态变量或静态方法时
    -   子类初始化，如果父类还没初始化，会引发
    -   子类访问父类的静态变量，只会触发父类的初始化
    -   Class.forName
    -   new 会导致初始化
-   不会导致类初始化的情况
    -   访问类的 `static final 静态常量`（`基本类型`和`字符串`） 不会触发初始化
    -   类对象.class 不会触发初始化
    -   创建该类的`数组`不会触发初始化
    -   类加载器的 loadClass 方法
    -   Class.forName 的参数 2 为 false 时
-   练习
    > 从字节码分析，使用 a，b，c 这三个常量是否会导致 E 初始化
    ```纯文本
    public class Load4 {
        public static void main(String[] args) {
            System.out.println(E.a);//不会，static final 的基本类型
            System.out.println(E.b);//不会，static final 的字符串
            System.out.println(E.c);//会，static final 的对象

        }
    }

    class E {
        public static final int a = 10;
        public static final String b = "hello";
        public static final Integer c = 20;  // Integer.valueOf(20)
        static {
            System.out.println("init E");
        }
    }
    ```
    > 典型应用 - 完成懒惰初始化单例模式
    ```纯文本
    public class Load9 {
        public static void main(String[] args) {
    //        Singleton.test();
            Singleton.getInstance();
        }

    }

    class Singleton {

        public static void test() {
            System.out.println("test");
        }

        private Singleton() {}

        private static class LazyHolder{
            private static final Singleton SINGLETON = new Singleton();
            static {
                System.out.println("lazy holder init");
            }
        }

        public static Singleton getInstance() {
            return LazyHolder.SINGLETON;
        }
    }
    ```
    > 以上的实现特点是：
    > ① 懒惰实例化；
    > ② 初始化时的线程安全是有保障的。

### 3.5 类加载器

-   类的加载：将class文件字节码内容加载到内存中，并将这些静态数据转换成方法区的运行时数据结构，然后生成一个代表这个类的java.lang.Class对象，作为方法区中类数据的访问入口（即引用地址）。所有需要访问和使用类数据只能通过这个Class对象。这个加载的过程需要`类加载器`参与。
-   Java虚拟机设计团队有意把类加载阶段中的“`通过一个类的全限定名来获取描述该类的二进制字节流`”这个动作放到Java虚拟机外部去实现，以便让应用程序自己决定如何去获取所需的类。`实现这个动作的代码被称为“类加载器”`（`ClassLoader`）
-   类加载器虽然只用于实现类的加载动作，但它在Java程序中起到的作用却远超类加载阶段
    对于任意一个类，都必须由加载它的`类加载器`和这个`类本身`一起共同确立其在Java虚拟机中的`唯一性`，每一个类加载器，都拥有一个独立的类名称空间。这句话可以表达得更通俗一些：`比较两个类是否“相等”，只有在这两个类是由同一个类加载器加载的前提下才有意义`，否则，即使这两个类来源于同一个Class文件，被同一个Java虚拟机加载，只要加载它们的类加载器不同，那这两个类就必定不相等
-   类加载器分类（以 JDK 8 为例）：

    ![](https://img-blog.csdnimg.cn/d3aa181948b74be4aca4b52a6c4d50da.png)

### 3.5.1 启动类加载器 Bootstrap ClassLoader

> 引导类加载器是使用C++语言实现的，是JVM自身的一部分，主要负责将`<JAVA_HOME>\lib`路径下的核心类库或`-Xbootclasspath`参数指定的路径下的jar包加载到内存中。
> 可以通过虚拟机参数将我们自己定义的类交由启动类加载器进行加载：

```纯文本
package cn.itcast.jvm.tload;

public class F {
    static {
        System.out.println("bootstrap F init");
    }
}
```

```纯文本
package cn.itcast.jvm.tload;

public class Load5_1 {
    public static void main(String[] args) throws ClassNotFoundException {
        Class<?> aClass = Class.forName("cn.itcast.jvm.tload.F");//类的加载、链接和初始化
        System.out.println(aClass.getClassLoader()); //查看由那个类加载器加载的（原来：AppClassLoader  ExtClassLoader）
    }
}
```

> 使用命令：

```纯文本
java -Xbootclasspath/a:.
```

```纯文本
E:\\git\\jvm\\out\\production\\jvm>java -Xbootclasspath/a:. 
cn.itcast.jvm.tload.Load5 
bootstrap F init 
null（说明使用的类加载器为启动类加载器）
```

-   `-Xbootclasspath` 表示设置 bootclasspath
-   其中 `/a:.` 表示将当前目录追加至 bootclasspath 之后
-   可以用这个办法替换核心类
    ```纯文本
    java -Xbootclasspath:<new bootclasspath>
    ```
    ```纯文本
    java -Xbootclasspath/a:<追加路径>
    ```
    ```纯文本
    java -Xbootclasspath/p:<追加路径>
    ```

### 3.5.2 扩展类加载器 Extension ClassLoader

> 这个类加载器是由sun公司实现的，位于HotSpot源码目录中的

```纯文本
sun.misc.Launcher$ExtClassLoader
```

位置。它主要负责加载`<JAVA_HOME>\lib\ext`目录下或者由系统变量`-Djava.ext.dir`a指定位路径中的类库。它可以直接被开发者使用。
如果`classpath`和

```纯文本
JAVA_HOME/jre/lib/ext
```

下有同名类，加载时会使用拓展类加载器加载。当应用程序类加载器发现拓展类加载器已将该同名类加载过了，则不会再次加载。

实验：

```纯文本
package cn.itcast.jvm.tload;

public class G {
    static {
        
        System.out.println("Classpath G init");
    }
}
```

```纯文本
package cn.itcast.jvm.tload;

public class Load5_2 {
    public static void main(String[] args) throws ClassNotFoundException {
        Class<?> aClass = Class.forName("cn.itcast.jvm.tload.G");
        System.out.println(aClass.getClassLoader());
    }
}
```

> 输出：

```纯文本
Classpath G init 
sun.misc.Launcher$AppClassLoader@18b4aac2
```

> 将上面G类的`Classpath G init` 改为输出`Ext G init`  打个 jar 包

```纯文本
E:\\git\\jvm\\out\\production\\jvm>jar -cvf my.jar cn/itcast/jvm/t3/load/G.class 
已添加清单 
正在添加: cn/itcast/jvm/t3/load/G.class(输入 = 481) (输出 = 322)(压缩了 33%)
```

> 将 jar 包拷贝到 (注意是JDK目录下的jre目录)

```纯文本
JAVA_HOME/jre/lib/ext
```

将`Ext G init`改回`Classpath G init` 重新执行 Load5\_2，输出：

```纯文本
Ext G init 
sun.misc.Launcher$ExtClassLoader@29453f44
```

结论：当扩展类加载已经加载同类路径下的类，会向上委派给父类加载。

### 3.5.3 双亲委派模式

所谓的双亲委派，就是指调用类加载器的 loadClass 方法时，查找类的规则

注意
这里的双亲，翻译为上级似乎更为合适，因为它们并没有继承关系

loadClass源码:

```java
protected Class<?> loadClass(String name, boolean resolve)
    throws ClassNotFoundException
{
    synchronized (getClassLoadingLock(name)) {
        // 首先查找该类是否已经被该类加载器加载过了
        Class<?> c = findLoadedClass(name);
        //如果没有被加载过
        if (c == null) {
            long t0 = System.nanoTime();
            try {
                //看是否被它的上级加载器加载过了 Extension的上级是Bootstarp，但它显示为null
                if (parent != null) {
                    c = parent.loadClass(name, false);
                } else {
                    //看是否被启动类加载器加载过
                    c = findBootstrapClassOrNull(name);
                }
            } catch (ClassNotFoundException e) {
                // ClassNotFoundException thrown if class not found
                // from the non-null parent class loader
                //捕获异常，但不做任何处理
            }

            if (c == null) {
                //如果还是没有找到，先让拓展类加载器调用findClass方法去找到该类，如果还是没找到，就抛出异常
                //然后让应用类加载器去找classpath下找该类
                long t1 = System.nanoTime();
                c = findClass(name);

                // 记录时间
                sun.misc.PerfCounter.getParentDelegationTime().addTime(t1 - t0);
                sun.misc.PerfCounter.getFindClassTime().addElapsedTimeFrom(t1);
                sun.misc.PerfCounter.getFindClasses().increment();
            }
        }
        if (resolve) {
            resolveClass(c);
        }
        return c;
    }
}
```

代码测试：给下面的第六行打断点，进行Debug，到第六行后，点入`loadClass` 的真正实现方法上，再打断点，然后再放开。进行debug，最后发现输出都是`AppClassLoader` 加载器。

```java
package com.zhuangjie.jvm;
public class Main {
    public static void main(String[] args) throws ClassNotFoundException {
        ClassLoader classLoader = new Main().getClass().getClassLoader();
        System.out.println(classLoader);
        Class<?> aClass = classLoader.loadClass("com.zhuangjie.jvm.Loador");

        System.out.println(aClass.getClassLoader());

    }
}

```

输出：

```text
sun.misc.Launcher$AppClassLoader@18b4aac2
sun.misc.Launcher$AppClassLoader@18b4aac2
```

> ①当App尝试加载一个类时，它不会直接尝试加载这个类，首先会在自己的命名空间中查询是否已经加载过这个类，如果没有会先将这个类加载请求委派给父类加载器Ext完成
> ②当尝试加载一个类时，它也不会直接尝试加载这个类，也会在自己的命名空间中查询是否已经加载过这个类，没有的话也会先将这个类加载请求委派给父类加载器完成
> ③如果加载失败，也就是代表着：这个需要被加载的类不在的加载范围内，那么会重新将这个类加载请求交由子类加载器完成
> ④如果加载失败，代表着这个类也不在的加载范围内，最后会重新将这个类加载请求交给子类加载器完成
> ⑤如果加载器也加载失败，就代表这个类根据全限定名无法查找到，则会抛出ClassNotFoundException异常
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/01/1677648186441.png)

### 3.5.4 线程上下文类加载器(双亲委派破坏者)

-   在Java中，官方为我们提供了很多SPI接口，例如JDBC、JBI、JNDI等。这类SPI接口，官方往往只会定义规范，具体的实现则是由第三方来完成的，比如JDBC，不同的数据库厂商都需自己根据JDBC接口的定义进行实现。
    在使用 JDBC 时，都需要加载 Driver 驱动，不知道你注意到没有，不写
    ```纯文本
    Class.forName("com.mysql.jdbc.Driver")
    ```
    也是可以让
    ```纯文本
    com.mysql.jdbc.Driver
    ```
    正确加载的，你知道是怎么做的吗？
-   总结：
    Java提供了很多核心接口的定义，这些接口被称为SPI接口，同时为了方便加载第三方的实现类，SPI提供了一种`动态的服务发现机制（约定）`，只要第三方在编写实现类时，在工程内新建一个`META-INF/services/``目录`并`在该目录下创建一个与服务接口名称同名的文件`，那么在程序启动的时候，就会根据约定去找到所有符合规范的实现类，然后交给线程上下文类加载器进行加载处理。

### 3.5.5 自定义类加载器

-   什么时候需要自定义类加载器
    1.  想加载非 classpath 随意路径中的类文件
    2.  都是通过接口来使用实现，希望解耦时，常用在框架设计
    3.  这些类希望予以隔离，不同应用的同名类都可以加载，不冲突，常见于 tomcat 容器
-   步骤：
    1.  继承 ClassLoader 父类
    2.  要遵从双亲委派机制，重写 findClass 方法（注意不是重写 loadClass 方法，否则不会走双亲委派机制）
    3.  读取类文件的字节码
    4.  调用父类的 defineClass 方法来加载类
    5.  使用者调用该类加载器的 loadClass 方法
    ```java
    package org.example;

    import java.io.ByteArrayOutputStream;
    import java.io.IOException;
    import java.nio.file.Files;
    import java.nio.file.Paths;
    import java.sql.Connection;
    import java.sql.DriverManager;
    import java.sql.SQLException;
    import java.util.ArrayList;

    public class Demo2 {
        public static void main(String[] args) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
            MyClassLoader mcl1 = new MyClassLoader();
            Class<?> clTest = mcl1.loadClass("CLTest");
            Object o1 = clTest.newInstance();

            MyClassLoader mcl2 = new MyClassLoader();
            Class<?> clTest2 = mcl2.loadClass("CLTest");
            Object o2 = clTest2.newInstance();

            System.out.println(o1 == o2);



        }
    }
    class MyClassLoader extends ClassLoader {
        @Override
        protected Class<?> findClass(String name) throws ClassNotFoundException {
            // 去掉包名，再javac编译，否则报： NoClassDefFoundError 
            String path = "d:\\system\\class\\CLTest.class";
            try {
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                Files.copy(Paths.get(path),os);
                byte[] bytes = os.toByteArray();
                return defineClass(name,bytes,0,bytes.length);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    ```

### 3.6 运行期优化

### 3.6.1 即时编译JIT

分层编译（TieredCompilation）   JVM 将执行状态分成了 5 个层次：

-   0 层，解释执行（Interpreter）
-   1 层，使用 C1 即时编译器编译执行（不带 profiling）
-   2 层，使用 C1 即时编译器编译执行（带基本的 profiling）
-   3 层，使用 C1 即时编译器编译执行（带完全的 profiling）
-   4 层，使用 C2 即时编译器编译执行

> profiling 是指在运行过程中收集一些程序执行状态的数据，例如【方法的调用次数】，【循环的   回边次数】等

即时编译器（JIT）与解释器的区别

-   解释器：
    -   将字节码解释为机器码，下次即使遇到相同的字节码，仍会`执行重复的解释`
    -   将字节码解释为针对所有平台都通用的机器码
-   JIT：
    -   将一些`字节码编译为机器码`，并存入 `Code Cache`，下次遇到相同的代码，直接执行，无需再编译
    -   会根据平台类型，生成平台特定的机器码 对于占据大部分的不常用的代码，我们无需耗费时间将其编译成机器码，而是采取解释执行的方式运行；另一方面，对于仅占据小部分的热点代码，我们则可以将其编译成机器码，以达到理想的运行速度。 执行效率上简单比较一下 Interpreter < C1 < C2，总的目标是发现热点代码（hotspot名称的由来），并对其进行优化

### 3.6.2 常见JIT优化

#### 逃逸分析

> 逃逸分析（Escape Analysis）简单来讲就是，Java Hotspot 虚拟机可以分析新创建对象的使用范围，并决定是否在 Java 堆上分配内存的一项技术
>
> JVM的逃逸分析是在运行时期对Java程序进行优化操作的一种技术，它可以帮助确定哪些对象应该在栈上分配，而不是在堆上分配。当一个对象不会被其他线程引用时，就可以将其分配到栈上。这样可以减少内存的使用量，并且可以更快地访问这些对象。

-   逃逸分析的 JVM 参数如下：
    -   开启逃逸分析：-XX:+DoEscapeAnalysis
    -   关闭逃逸分析：-XX:-DoEscapeAnalysis
    -   显示分析结果：-XX:+PrintEscapeAnalysis
-   逃逸分析技术在 Java SE 6u23+ 开始支持，并默认设置为启用状态，可以不用额外加这个参数

#### 方法内联

-   内联函数：内联函数就是在程序编译时，编译器`将程序中出现的内联函数的调用表达式用内联函数的函数体来直接进行替换`
-   C++是否为内联函数由自己决定，`Java由编译器决定`。Java不支持直接声明为内联函数的，如果想让他内联，你只能够向编译器提出请求： `关键字final修饰` 用来指明那个函数是希望被JVM内联的。
-   如果JVM监测到一些小方法被频繁的执行，它会进行内联，把方法的调用替换成方法体本身，如下例中的`square`方法：

```纯文本
package cn.itcast.jvm.tjit;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class JIT2 {
    // -XX:+UnlockDiagnosticVMOptions -XX:+PrintInlining （解锁隐藏参数）打印 inlining 信息 
    // -XX:CompileCommand=dontinline,*JITsquare 禁止某个方法 inlining 
    // -XX:+PrintCompilation 打印编译信息

    public static void main(String[] args) {

        int x = 0;
        for (int i = 0; i < 500; i++) {
            long start = System.nanoTime();
            for (int j = 0; j < 1000; j++) {
                x = square(9);

            }
            long end = System.nanoTime();
            System.out.printf("%d\\t%d\\t%d\\n",i,x,(end - start));
        }
    }

    private static int square(final int i) {
        return i * i;
    }
}
```

#### 反射优化（字段优化）

```纯文本
public class Reflect1 {
   public static void foo() {
      System.out.println("foo...");
   }

   public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
      Method foo = Democlass.getMethod("foo");
      for(int i = 0; i<=16; i++) {
         foo.invoke(null);
      }
   }
}
```

> invoke方法源码：

![](https://img-blog.csdnimg.cn/acb12b4b10484f498877cd8e9fa40a9d.png)

> 默认会通过DelegatingMethodAccessorImpl访问NativeMethodAccessorImpl，NativeMethodAccessorImpl方法中规定：当invoke方法调用次数超过15次时，会将本地方法访问器替换为一个运行期间动态生成的新的方法访问器：

```纯文本
class NativeMethodAccessorImpl extends MethodAccessorImpl {
    private final Method method;
    private DelegatingMethodAccessorImpl parent;
    private int numInvocations;

    NativeMethodAccessorImpl(Method var1) {
        this.method = var1;
    }

    public Object invoke(Object var1, Object[] var2) throws IllegalArgumentException, InvocationTargetException {
        if (++this.numInvocations > ReflectionFactory.inflationThreshold() && !ReflectUtil.isVMAnonymousClass(this.method.getDeclaringClass())) {
            MethodAccessorImpl var3 = (MethodAccessorImpl)(new MethodAccessorGenerator()).generateMethod(this.method.getDeclaringClass(), this.method.getName(), this.method.getParameterTypes(), this.method.getReturnType(), this.method.getExceptionTypes(), this.method.getModifiers());
            this.parent.setDelegate(var3);
        }

        return invoke0(this.method, var1, var2);
    }

    void setParent(DelegatingMethodAccessorImpl var1) {
        this.parent = var1;
    }

    private static native Object invoke0(Method var0, Object var1, Object[] var2);
}
```

![](https://img-blog.csdnimg.cn/17a5f44bd80c469faf6451ea7dd3a846.png)

![](https://img-blog.csdnimg.cn/b3ef0f4fd2fb492981da49fc1d36de92.png)

> 当调用到第 16 次（从0开始算）时，会采用运行时生成的类代替掉最初的实现，可以通过 debug 得到类名为：

```纯文本
sun.reflect.GeneratedMethodAccessor1
```

，其在实现时会从反射调用变为正常调用，即直接调用`Reflect1.foo()`

![](https://img-blog.csdnimg.cn/b0be8d4d50984be6b1e08f025c48acde.png)

## 4. 内存模型

### 4.1 java内存模型

-   很多人将【java 内存结构】与【java 内存模型】傻傻分不清，【`java 内存模型`】是 】是 \*\*Java Memory Model（JMM）\*\***Java Memory Model（JMM）** 的意思。 的意思。
-   关于它的权威解释，请参考[https://download.oracle.com/otn-pub/jcp/memory\_model-1.0-pfd-spec-oth-JSpec/memory\_model-1\_0-pfd-spec.pdf?AuthParam=1562811549\_4d4994cbd5b59d964cd2907ea22ca08b](https://download.oracle.com/otn-pub/jcp/memory_model-1.0-pfd-spec-oth-JSpec/memory_model-1_0-pfd-spec.pdf?AuthParam=1562811549_4d4994cbd5b59d964cd2907ea22ca08b "https://download.oracle.com/otn-pub/jcp/memory_model-1.0-pfd-spec-oth-JSpec/memory_model-1_0-pfd-spec.pdf?AuthParam=1562811549_4d4994cbd5b59d964cd2907ea22ca08b")
    简单的说，`JMM 定义了一套在多线程读写共享数据时（成员变量、数组）时，对数据的可见性、有序性、和原子性的规则和保障`

### 4.1.1 原子性

> 原子性是指在一个操作中就是`cpu不可以在中途暂停然后再调度，既不被中断操作，要不执行完成，要不就不执行`。
> 原子性在学习线程时讲过，下面来个例子简单回顾一下：
> 问题提出，两个线程对初始值为 0 的静态变量一个做自增，一个做自减，各做 5000 次，结果是 0 吗？

-   问题分析：
    以上的结果可能是正数、负数、零。为什么呢？因为 Java 中对静态变量的自增，自减并不是原子操作。
    例如对于 `i++` 而言（i 为静态变量），实际会产生如下的 JVM 字节码指令：

    而对应 `i--`也是类似：

    而 Java 的内存模型如下，完成静态变量的自增，自减需要在主存和线程内存中进行数据交换：

    如果是单线程以下8 行代码是顺序执行（不会交错）没有问题：

    但多线程下这 8 行代码可能交错运行（不同线程抢占CPU资源）：

    ![](https://img-blog.csdnimg.cn/2ee3704bd8e141af8a0c04c1294376af.png)

    ![](https://img-blog.csdnimg.cn/4d25251efaa8441193894bc48b5d3416.png)

    ![](https://img-blog.csdnimg.cn/a9c78d82370943b6b5f5a2b66ca17eed.png)

    ![](https://img-blog.csdnimg.cn/47b419eea30e45088a049f3d83201285.png)

    ![](https://img-blog.csdnimg.cn/188406e9507249d9942ef370b4c0b474.png)
-   解决方法：`synchronized` （同步关键字）
    -   语法：
        ```纯文本
        synchronized( 对象 ) { 
          要作为原子操作代码 
        }
        ```
    -   用 `synchronized`解决并发问题：

        ![](https://img-blog.csdnimg.cn/dfdf075db3b84efa806a9e5b02de6975.png)
    -   理解：
        你可以把 obj 想象成一个房间，线程 t1，t2 想象成两个人。
        当线程 t1 执行到 `synchronized(obj)` 时就好比 t1 进入了这个房间，并反手锁住了门，在门内执行`count++` 代码。
        这时候如果 t2 也运行到了 `synchronized(obj)` 时，它发现门被锁住了，只能在门外等待。
        当 t1 执行完 `synchronized{}` 块内的代码，这时候才会解开门上的锁，从 `obj` 房间出来。t2 线程这时才可以进入 `obj` 房间，反锁住门，执行它的 `count--` 代码。
        > 注意：上例中 t1 和 t2 线程必须用 `synchronized` 锁住同一个 `obj` 对象，如果 t1 锁住的是 m1 对象，t2 锁住的是 m2 对象，就好比两个人分别进入了两个不同的房间，没法起到同步的效果。

### 4.1.2 可见性

-   \*   退不出的循环   先来看一个现象，main 线程对 run 变量的修改对于 t 线程不可见，导致了 t 线程无法停止：  &#x20;
    !\[]\(<https://img-blog.csdnimg.cn/a5a27fd318dd4467828dc5410bfbc374.png>)
    &#x20;  原因分析：
    1.  初始状态， t 线程刚开始从主内存读取了 run 的值到工作内存。  &#x20;

![](https://img-blog.csdnimg.cn/d9f1e3e50a2b4ac3b24c829d04e9027d.png)

![](https://img-blog.csdnimg.cn/a969f3776883423785f5593c4da74d05.png)

![](https://img-blog.csdnimg.cn/dd5236ec6b114881815d3c24e0d45114.png)

-   解决方法：`volatile`（易变关键字）   它可以用来修饰成员变量和静态成员变量，他可以`避免线程从自己的工作缓存中查找变量的值，必须到主存中获取它的值`，线程操作 volatile 变量都是直接操作主存
-   可见性：   前面例子体现的实际就是可见性，它保证的是`在多个线程之间，一个线程对 volatile 变量的修改对另一个线程可见`， 不能保证原子性，仅用在`一个写线程，多个读线程`的情况：   上例从字节码理解是这样的：      比较一下之前我们将线程安全时举的例子：两个线程一个 `i++` 一个 `i--`，只能保证看到最新值，不能解决指令交错
    > 注意   synchronized 语句块既可以保证代码块的原子性，也同时保证代码块内变量的可见性。但缺点是   synchronized是属于重量级操作，性能相对更低
    -   如果在前面示例的死循环中加入 System.out.println() 会发现即使不加 volatile 修饰符，线程 t 也能正确看到对 run 变量的修改了，想一想为什么？   println()方法底层包含`synchronized`关键字，强制当前线程从主存中读取变量值。

1.  1 秒之后，main 线程修改了 run 的值，并同步至主存，而 t 是从自己工作内存中的高速缓存中读取这个变量的值，结果永远是旧值  &#x20;
2.  因为 t 线程要频繁从主内存中读取 run 的值，JIT 编译器会将 run 的值缓存至自己工作内存中的高速缓存中，减少对主存中 run 的访问，提高效率  &#x20;

![在这里插入图片描述](https://img-blog.csdnimg.cn/87e14d5c2fd64d34a301df398e426fdf.png "在这里插入图片描述")

### 4.1.3 有序性

-   诡异的结果 &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/95da5ae1e95743dcbf21637293780908.png "在这里插入图片描述")
    -   `I_Result` 是一个对象，有一个属性 r1 用来保存结果，问，可能的结果有几种？
        -   情况1：线程1 先执行，这时 ready = false，所以进入 else 分支结果为 `1`
        -   情况2：线程2 先执行 num = 2，但没来得及执行 ready = true，线程1 执行，还是进入 else 分支，结果为`1`
        -   情况3：线程2 执行到 ready = true，线程1 执行，这回进入 if 分支，结果为 `4`（因为 num 已经执行过了）
        -   情况4：线程2 执行 ready = true，切换到线程1，进入 if 分支，相加为 `0`，再切回线程2 执行num = 2
    -   这种现象叫做指令重排，是 JIT 编译器在运行时的一些优化，这个现象需要通过大量测试才能复现：借助 java 并发压测工具 `jcstress` &#x20;
        ```java
        mvn archetype:generate -DinteractiveMode=false - DarchetypeGroupId=org.openjdk.jcstress -DarchetypeArtifactId=jcstress-java-test- archetype -DgroupId=org.sample -DartifactId=test -Dversion=0
        ```
        创建 maven 项目，提供如下测试类： &#x20;

        ![在这里插入图片描述](https://img-blog.csdnimg.cn/3fb7bef99f554578a0b434e09f3bb113.png "在这里插入图片描述")

        执行：
        ```java
        mvn clean install 
        java -jar target/jcstress.jar
        ```
        > 会输出我们感兴趣的结果，摘录其中一次结果： &#x20;
        > ![在这里插入图片描述](https://img-blog.csdnimg.cn/0f9bdee56645412d8e5db707224d8d8f.png "在这里插入图片描述")
        ![在这里插入图片描述](https://img-blog.csdnimg.cn/f17e6be86c88407d92183db3bf68941c.png "在这里插入图片描述")

        可以看到，出现结果为 0 的情况有 638 次，虽然次数相对很少，但毕竟是出现了。
-   解决方法 &#x20;

    `volatile 修饰的变量，可以禁用指令重排` &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/2f416b17e1f144cbafdde4f2082ed997.png "在这里插入图片描述")

    结果为： &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/7686f2592a874855bc8c6660a2617b21.png "在这里插入图片描述")
-   有序性理解 &#x20;

    JVM 会在不影响正确性的前提下，可以调整语句的执行顺序，思考下面一段代码： &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/365ea73f52c34b95960012918740a05e.png "在这里插入图片描述")

    可以看到，至于是先执行 i 还是 先执行 j ，对最终的结果不会产生影响。这种特性称之为『指令重排』，多线程下『指令重排』会影响正确性，例如著名的 double-checked locking 模式实现单例： &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/a442b02e16124b4f827f6ae449beed92.png "在这里插入图片描述")

    以上的实现特点是：
    -   懒惰实例化
    -   首次使用 getInstance() 才使用 synchronized 加锁，后续使用时无需加锁
    > 但在多线程环境下，上面的代码是有问题的， INSTANCE = new Singleton() 对应的字节码为： &#x20;
    > ![在这里插入图片描述](https://img-blog.csdnimg.cn/368680889c5a4b1e877ecdfac15c2c44.png "在这里插入图片描述")
    其中 4 7 两步的顺序不是固定的，也许 jvm 会优化为：先将引用地址赋值给 INSTANCE 变量后，再执行构造方法，如果两个线程 t1，t2 按如下时间序列执行： &#x20;

    ![在这里插入图片描述](https://img-blog.csdnimg.cn/4559775d604b4d37b5572e3c65b65b81.png "在这里插入图片描述")

    这时 t1 还未完全将构造方法执行完毕，如果在构造方法中要执行很多初始化操作，那么 t2 拿到的是将是一个未初始化完毕的单例 &#x20;

    `对 INSTANCE 使用 volatile 修饰即可，可以禁用指令重排`，但要注意在 JDK 5 以上的版本的 volatile 才会真正有效

### 4.1.4 happens-before

> `happens-before` 规定了`哪些写操作对其它线程的读操作可见`，它是可见性与有序性的一套规则总结，抛开以下 happens-before 规则，JMM 并不能保证一个线程对共享变量的写，对于其它线程对该共享变量的读可见：

-   线程解锁 m 之前对变量的写，对于接下来对 m 加锁的其它线程对该变量的读可见

    ![](https://img-blog.csdnimg.cn/93079534795049c2b49c1017662fbf28.png)
-   线程对 volatile 变量的写，对接下来其它线程对该变量的读可见

    ![](https://img-blog.csdnimg.cn/55fe1a30e3ff4d3f9c59f259811d92ab.png)
-   线程 start 前对变量的写，对该线程开始后对该变量的读可见

    ![](https://img-blog.csdnimg.cn/1498fe66ff4e4614b8cae73a3cbe8d41.png)
-   线程结束前对变量的写，对其它线程得知它结束后的读可见（比如其它线程调用 t1.isAlive() 或t1.join()等待它结束）

    ![](https://img-blog.csdnimg.cn/d9bf20080d5247beaf777331ae7602ae.png)
-   线程 t1 打断 t2（interrupt）前对变量的写，对于其他线程得知 t2 被打断后对变量的读可见（通过t2.interrupted 或 t2.isInterrupted）

    ![](https://img-blog.csdnimg.cn/35c7ec1f8e5841e1a5cf5dc2ef3b5e2e.png)
-   对变量默认值（0，false，null）的写，对其它线程对该变量的读可见
-   具有传递性，如果 x hb-> y 并且 y hb-> z 那么有 x hb-> z

> 变量都是指成员变量或静态成员变量

### 4.2 CAS 与 原子类

### 4.2.1 CAS(Compare and Swap)

> `CAS 即 Compare and Swap` ，它体现的一种`乐观锁`的思想，比如多个线程要对一个共享的整型变量执行 +1 操作：

![](https://img-blog.csdnimg.cn/b14242cbfa794cdd96bfd2f5a2644798.png)

-   获取共享变量时，为了保证该变量的可见性，`需要使用 volatile 修饰`（保证拿到的是最新值，否则CAS没有意义）。`结合 CAS 和 volatile可以实现无锁并发，适用于竞争不激烈、多核 CPU 的场景下。`
    -   因为没有使用 synchronized，所以线程不会陷入阻塞，这是效率提升的因素之一
    -   但如果竞争激烈，可以想到重试必然频繁发生，反而效率会受影响
-   CAS 底层依赖于一个 Unsafe 类来直接调用操作系统底层的 CAS 指令

### 4.2.2 乐观锁与悲观锁

-   CAS 是基于乐观锁的思想：最乐观的估计，不怕别的线程来修改共享变量，就算改了也没关系，我吃亏点再重试呗。
-   synchronized 是基于悲观锁的思想：最悲观的估计，得防着其它线程来修改共享变量，我上了锁你们都别想改，我改完了解开锁，你们才有机会。

### 4.2.3 原子操作类

> **juc（java.util.concurrent）** ​**juc（java.util.concurrent）** 中提供了原子操作类，可以提供线程安全的操作，例如：AtomicInteger、AtomicBoolean等，它们底层就是采用 中提供了原子操作类，可以提供线程安全的操作，例如：AtomicInteger、AtomicBoolean等，它们底层就是采用`CAS 技术 + volatile` 来实现的。

![](https://img-blog.csdnimg.cn/11e356bfa9d443309c0307a0386159a4.png)

![](https://img-blog.csdnimg.cn/a206719986574a4db76271d4c0c36ea3.png)

### 4.3 synchronized 优化

> Java HotSpot 虚拟机中，每个对象都有`对象头（包括 class 指针和 Mark Word）`。`Mark Word` 平时存储这个对象的`哈希码 、 分代年龄` ，当`加锁`时，这些信息就根据情况被替换为`标记位 、 线程锁记录指针 、 重量级锁指针 、 线程ID` 等内容。

### 4.3.1 轻量级锁

-   如果一个对象`虽然有多线程访问，但多线程访问的时间是错开的`（也就是没有竞争），那么可以使用轻量级锁来优化。这就好比：
    学生（线程 A）用课本占座，上了半节课，出门了（CPU时间到），回来一看，发现课本没变，说明没有竞争，继续上他的课。
    如果这期间有其它学生（线程 B）来了，会告知（线程A）有并发访问，线程 A 随即升级为重量级锁，进入重量级锁的流程。
    而重量级锁就不是那么用课本占座那么简单了，可以想象线程 A 走之前，把座位用一个铁栅栏围起来。
-   假设有两个方法同步块，利用同一个对象加锁：

    每个线程都的栈帧都会包含一个锁记录的结构，内部可以存储锁定对象的 Mark Word

    ![](https://img-blog.csdnimg.cn/edc9b64cd3f54c0db019b7af0848a556.png)

    ![](https://img-blog.csdnimg.cn/4ad78724140d4e29a648ba5bb28353f5.png)

### 4.3.2 锁膨胀

> 如果在尝试加轻量级锁的过程中，CAS 操作无法成功，这时一种情况就是有其它线程为此对象加上了轻量级锁（有竞争），这时需要进行锁膨胀，将轻量级锁变为重量级锁。

![](https://img-blog.csdnimg.cn/ad508266245d4083b5e1ea1e7147bca0.png)

![](https://img-blog.csdnimg.cn/65b0c86bb1e04598a69a1b91b697a90e.png)

### 4.3.3 重量锁

-   `重量级锁竞争`的时候，还可以`使用自旋来进行优化`，如果当前线程自旋成功（即这时候持锁线程已经退出了同步块，释放了锁），这时当前线程就可以避免阻塞。
-   在 `Java 6 之后自旋锁是自适应的`，比如对象刚刚的一次自旋操作成功过，那么认为这次自旋成功的可能性会高，就多自旋几次；反之，就少自旋甚至不自旋，总之，比较智能。
    -   自旋会占用 CPU 时间，单核 CPU 自旋就是浪费，多核 CPU 自旋才能发挥优势。
    -   好比等红灯时汽车是不是熄火，不熄火相当于自旋（等待时间短了划算），熄火了相当于阻塞（等待时间长了划算）
    -   Java 7 之后不能控制是否开启自旋功能
-   自旋重试成功的情况：

    ![](https://img-blog.csdnimg.cn/593854ca6fdc4e02b5aa7f7ad995d240.png)
-   自旋重试失败的情况：

    ![](https://img-blog.csdnimg.cn/444ba5645da24138880f6723da0eb7af.png)

### 4.3.4 偏向锁

> `轻量级锁`在`没有竞争`时（就自己这个线程），`每次重入仍然需要执行 CAS 操作`。Java 6 中引入了`偏向锁`来做进一步优化：`只有第一次使用时CAS 将线程 ID 设置到对象的 Mark Word 头，之后发现这个线程 ID是自己的就表示没有竞争，不用重新 CAS。`

### 4.3.5 其它优化

1.  减少上锁时间
    同步代码块中尽量短
2.  减少锁的粒度
    将一个锁拆分为多个锁提高并发度，例如：
    -   ConcurrentHashMap
    -   LongAdder 分为 base 和 cells 两部分。没有并发争用的时候或者是 cells 数组正在初始化的时候，会使用 CAS 来累加值到 base，有并发争用，会初始化 cells 数组，数组有多少个 cell，就允许有多少线程并行修改，最后将数组中每个 cell 累加，再加上 base 就是最终的值
    -   LinkedBlockingQueue 入队和出队使用不同的锁，相对于LinkedBlockingArray只有一个锁效率要高
3.  锁粗化
    多次循环进入同步块不如同步块内多次循环
    另外 JVM 可能会做如下优化，把多次 append 的加锁操作粗化为一次（因为都是对同一个对象加锁，没必要重入多次）

    ![](https://img-blog.csdnimg.cn/d8832322f3554fed8bca84040500aa25.png)
4.  锁消除
    JVM 会进行代码的逃逸分析，例如某个加锁对象是方法内局部变量，不会被其它线程所访问到，这时候就会被即时编译器忽略掉所有同步操作。
5.  读写分离
    CopyOnWriteArrayList
    ConyOnWriteSet

> 参考：
> [https://wiki.openjdk.java.net/display/HotSpot/Synchronization](https://wiki.openjdk.java.net/display/HotSpot/Synchronization "https://wiki.openjdk.java.net/display/HotSpot/Synchronization")[http://luojinping.com/2015/07/09/java锁优化/](http://luojinping.com/2015/07/09/java锁优化/ "http://luojinping.com/2015/07/09/java锁优化/")[https://www.infoq.cn/article/java-se-16-synchronized](https://www.infoq.cn/article/java-se-16-synchronized "https://www.infoq.cn/article/java-se-16-synchronized")[https://www.jianshu.com/p/9932047a89be](https://www.jianshu.com/p/9932047a89be "https://www.jianshu.com/p/9932047a89be")[https://www.cnblogs.com/sheeva/p/6366782.html](https://www.cnblogs.com/sheeva/p/6366782.html "https://www.cnblogs.com/sheeva/p/6366782.html")[https://stackoverflow.com/questions/46312817/does-java-ever-rebias-an-individual-lock](https://stackoverflow.com/questions/46312817/does-java-ever-rebias-an-individual-lock "https://stackoverflow.com/questions/46312817/does-java-ever-rebias-an-individual-lock")
