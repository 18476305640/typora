# JUC

视频教程地址：[https://www.bilibili.com/video/BV1ar4y1x727](https://www.bilibili.com/video/BV1ar4y1x727 "https://www.bilibili.com/video/BV1ar4y1x727")

你可能要先了解以下内容：

[线程池](线程池/线程池.md "线程池")

### +为什么要学JUC

> 核心越多，处理器的并行处理能力越强，换句话说，就是能够同时处理任务的数量多。 主频越高，说明在处理单个任务的时候更快。 大家可以把核心数量看作“手”的数量——数量越多，同时搬起的东西就越多； 而主频就相当于“手”的力量——力量越大，就能胜任更繁重的工作。

可是从2003年开始CPU主频已经不再翻倍，而是采用多核而不是更快的主频。
在主频不再提高且核数在不断增加的情况下，要想让程序更快就要用到**并行或并发**编程。

并发：也称为上下文切换

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541615051161654161505064.png)

并行：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541613930711654161392909.png)

### - 并发相关Java包

-   涉及到的`包`内容
    -   `java.util.concurrent`
    -   `java.util.concurrent.atomic`
    -   `java.util.concurrent.locks`
    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541523218951654152321022.png)

### - 并发始祖

-   并发始祖Doug Lea

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541524388841654152438521.png)

### + start线程解读

初始程序

```java
public static void main(String[] args) {
        Thread t1 = new Thread(() ->{
        },"t1");
        t1.start();
    }

```

```java
//start
    public synchronized void start() {
        /**
         * This method is not invoked for the main method thread or "system"
         * group threads created/set up by the VM. Any new functionality added
         * to this method in the future may have to also be added to the VM.
         *
         * A zero status value corresponds to state "NEW".
         */
        if (threadStatus != 0)
            throw new IllegalThreadStateException();

        /* Notify the group that this thread is about to be started
         * so that it can be added to the group's list of threads
         * and the group's unstarted count can be decremented. */
        group.add(this);

        boolean started = false;
        try {
            start0();
            started = true;
        } finally {
            try {
                if (!started) {
                    group.threadStartFailed(this);
                }
            } catch (Throwable ignore) {
                /* do nothing. If start0 threw a Throwable then
                  it will be passed up the call stack */
            }
        }
    }

```

```java
private native void start0();//start0是一个native方法

```

`native`调用了本地方法，我们可以通过下载官网OpenJDK查看其源码

-   thread.c

    java线程是通过start的方法启动执行的，主要内容在native方法start0中

    Openjdk的写JNI一般是一一对应的，`Thread.java`对应的就是`Thread.c`

    `start0`其实就是`JVM_StartThread`。此时查看源代码可以看到在jvm.h中找到了声明，jvm.cpp中有实现。

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541526688891654152668784.png)
-   jvm.cpp

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541527258861654152725119.png)
-   thread.cpp

    终于在这里调用了**操作系统的线程启动**，`os::start_thread（thread);`

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541527748851654152774497.png)

### + Java多线程相关概念

-   1把锁
-   2个并（并发和并行）

    ①并发

    是在同一实体上的多个事件，是在同一台处理器上“同时”处理多个任务，同一时刻，其实是只有一个事件在发生。

    ②并行

    是在不同实体上的多个事件，是在多台处理器上同时处理多个任务，同一时刻，大家都真的在做事情，你做你的，我做我的

    **并发VS并行**

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541529318851654152931584.png)
-   3个程（进程 线程 管程）

    通过上面start线程的案例，其实进程线程都来源于操作系统。

    ①进程

    系统中运行的一个应用程序就是一个进程，每一个进程都有它自己的内存空间和系统资源。

    ②线程

    也被称为轻量级进程，在同一个进程内基本会有1一个或多个线程，是大多数操作系统进行调度的基本单元。

    ③管程

    Monitor（监视器），也就是我们平时说的**锁**

    Monitor其实是一种同步机制，他的义务是保证（同一时间）只有一个线程可以访问被保护的数据和代码。

    JVM中同步是基于进入和退出监视器对象(Monitor,管程对象)来实现的，每个对象实例都会有一个Monitor对象，

    Monitor对象会和Java对象一同创建并销毁，它底层是由C++语言来实现的。

    \>>>**进程VS线程**<<<

    进程是…，线程是…，进程和线程的最大不同在于进程基本上是独立的，而线程不一定，线程共享**方法区**和**堆**，线程私有**栈**、**本地方法栈**和**程序计数器**

    \>>>**用户线程和守护线程**<<<

    Java线程分为用户线程和守护线程

    线程的daemon属性为
    -   true表示是守护线程。
    -   false表示是用户线程。
    <!---->
    -   用户线程

        是系统的工作线程，它会完成这个程序需要完成的业务操作。main线程 也是用户线程。
    -   守护线程

        是一种特殊的线程，为其他线程服务的，在后台默默地完成一些系统性的服务，比如垃圾回收线程，会随着用户线程的关闭而关闭。
        ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541550448771654155044807.png)
    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541551798861654155179286.png)

### \[\_1\_] 引出FutureTask

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16541586940911654158694029.png)

这个类实现了Runnable与Future，有一个构造方法，传入Callable。集**多线程/有返回/异步任务** 于一身。&#x20;

### \[\_2\_] FutureTask结合线程池提高性能

-   使用示例

    \_3\_FutureTask结合线程池提高性能.java：直接看main方法，就能顺着看懂
    ```java
    package com.zhuangjie.javaJUC;

    import java.util.concurrent.*;

    public class _3_FutureTask结合线程池提高性能 {
        public static void main(String[] args) throws ExecutionException, InterruptedException {
            new _3_FutureTask结合线程池提高性能().A(); //不使用FutureTask  耗时：928ms!
            new _3_FutureTask结合线程池提高性能().B(); //只使用FutureTask  耗时：359ms!
            new _3_FutureTask结合线程池提高性能().C(); //使用 FutureTask + 线程性 耗时：304ms!
        }

        public void A() {
            long begin = System.currentTimeMillis();
            try { Thread.sleep(300);}catch (Exception e) {}
            try { Thread.sleep(300);}catch (Exception e) {}
            try { Thread.sleep(300);}catch (Exception e) {}
            long end = System.currentTimeMillis();
            System.out.println("==> main线程执行三个任务，耗时："+(end - begin)+"ms!");

        }
        public void B() throws ExecutionException, InterruptedException {
            long begin = System.currentTimeMillis();
            FutureTask<String> sft1 = new FutureTask<String>(() -> {
                try { Thread.sleep(300);}catch (Exception e) {}
                return "sft1:返回的结果！";
            });
            new Thread(sft1).start();

            FutureTask<String> sft2 = new FutureTask<String>(() -> {
                try { Thread.sleep(300);}catch (Exception e) {}
                return "sft1:返回的结果！";
            });
            new Thread(sft2).start();

            FutureTask<String> sft3 = new FutureTask<String>(() -> {
                try { Thread.sleep(300);}catch (Exception e) {}
                return "sft1:返回的结果！";
            });
            new Thread(sft3).start();


            String s1 = sft1.get();
            String s2 = sft2.get();
            String s3 = sft3.get();
            long end = System.currentTimeMillis();
            System.out.println("==> FutureTask 线程执行三个任务，耗时："+(end - begin)+"ms!");
            System.out.println(s1+"-"+s2+"-"+s3);

        }
        public void C() throws ExecutionException, InterruptedException {
            FutureTask<String> sft1 = new FutureTask<String>(() -> {
                try { Thread.sleep(300);}catch (Exception e) {}
                return "sft1:返回的结果！";
            });

            FutureTask<String> sft2 = new FutureTask<String>(() -> {
                try { Thread.sleep(300);}catch (Exception e) {}
                return "sft1:返回的结果！";
            });

            FutureTask<String> sft3 = new FutureTask<String>(() -> {
                try { Thread.sleep(300);}catch (Exception e) {}
                return "sft1:返回的结果！";
            });


            ExecutorService threadPool = Executors.newFixedThreadPool(3); //创建一个线程池

            long begin = System.currentTimeMillis();
            threadPool.submit(sft1);
            threadPool.submit(sft2);
            threadPool.submit(sft3);

            String s1 = sft1.get();
            String s2 = sft2.get();
            String s3 = sft3.get();

            long end = System.currentTimeMillis();
            threadPool.shutdown(); //关闭线程池
            System.out.println("==> FutureTask-threadPool  线程执行三个任务，耗时："+(end - begin)+"ms!");
            System.out.println(s1+"-"+s2+"-"+s3);


        }
    }



    ```

### \[\_3\_] CompletableFuture的引入

Future存在的缺点：

1）一旦调用get()方法求结果，如果计算没有完成容易导致程序阻塞，0(T- \_-T)0

2）用isDone轮询，会耗费无谓的CPU资源

\_4\_FutureTask的缺点.java

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class _4_FutureTask的缺点 {
    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException {
        FutureTask<String> stringFutureTask = new FutureTask<>(() -> {
            Thread.sleep(3000);
            return "Hello,world!";
        });
        Thread t = new Thread(stringFutureTask);
        t.start();
        //1）一旦调用get()方法求结果，如果计算没有完成容易导致程序阻塞，0(T---T)0
        //System.out.println(stringFutureTask.get(1, TimeUnit.SECONDS)); //只愿意等待1s,如果获取不到，报错。
        
        //2）使用isDone轮询，会耗费无谓的CPU资源
        while (true) {
            if (stringFutureTask.isDone()) {
                System.out.println(stringFutureTask.get());
                return;
            }else {
                System.out.println("别再催了，越催越慢！");
                Thread.sleep(500);
            }
        }


    }

}

```

### \[\_4\_] CompletableFuture的说明

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16542476431571654247642588.png)

CompletableFuture：代表异步计算过程中的某一个阶段，一个阶段完成以后可能会触发另外一个阶段，有些类似Linux系统的管道分隔符传参数。

-   在Java8中，CompletableFuture提供了非常强大的Future的扩展功能，可以帮助我们简化异步编程的复杂性，并且提供了函数式编程的能力，可以通过回调的方式处理计算结果，也提供了转换和组合CompletableFuture的方法。
-   它可能代表一个明确完成的Future,也有可能代表一个完成阶段（CompletionStage),它支持在计算完成以后触发一些函数或执行某些动作。
-   它实现了Future和CompletionStage接口

### \[\_5\_] CompletableFuture的四大静态方法

1）**集线程池：**

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16542594796581654259478862.png)

```java
package com.zhuangjie.javaJUC;

import sun.nio.ch.ThreadPool;

import java.util.concurrent.*;

public class _5_CompletableFuture的四大静态方法 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        CompletableFuture<Void> cf1 = CompletableFuture.runAsync(() -> {
            try { Thread.sleep(1000);  }catch (Exception e) { }
            System.out.println(Thread.currentThread().getName());
        });
        System.out.println(cf1.get());


        ExecutorService threadPool = Executors.newFixedThreadPool(3);
        CompletableFuture<Void> cf2 = CompletableFuture.runAsync(() -> {
            try { Thread.sleep(1000);  }catch (Exception e) { }
            System.out.println(Thread.currentThread().getName());
        },threadPool);
        
        System.out.println(cf2.get());
        threadPool.shutdown();


    }
}

```

执行输出：

```java
ForkJoinPool.commonPool-worker-1
null
pool-1-thread-1
null

```

```java
package com.zhuangjie.javaJUC;

import sun.nio.ch.ThreadPool;

import java.util.concurrent.*;

public class _5_CompletableFuture的四大静态方法 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        CompletableFuture<String> cf1 = CompletableFuture.supplyAsync(() -> {
            try { Thread.sleep(1000);  }catch (Exception e) { }
            System.out.println(Thread.currentThread().getName());
            return "不指定线程池！";
        });
        System.out.println(cf1.get());


        ExecutorService threadPool = Executors.newFixedThreadPool(3);
        CompletableFuture<String> cf2 = CompletableFuture.supplyAsync(() -> {
            try { Thread.sleep(1000);  }catch (Exception e) { }
            System.out.println(Thread.currentThread().getName());
            return "指定了线程池！";
        },threadPool);

        System.out.println(cf2.get());
        threadPool.shutdown();


    }
}

```

执行输出：

```java
ForkJoinPool.commonPool-worker-1
不指定线程池！
pool-1-thread-1
指定了线程池！
```

### \[\_6\_] CompletableFuture异步编程

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class _6_CompletableFuture通用异步编程 {
    public static void main(String[] args) {
        ExecutorService threadPool = Executors.newFixedThreadPool(3);

        try {
            CompletableFuture<String> exceptionally = CompletableFuture.supplyAsync(() -> { //Supplier,当没有返回值时是Runable
                try {
                    Thread.sleep(2000);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                int i = 1 / 0;
                return "OK";
            }, threadPool).whenComplete((v, e) -> { //BiComsumer  ，当是一个参数时是Comsumer
                //不管程序是否出错，这个都会执行
                if (e == null) {
                    System.out.println("1");
                }
            }).exceptionally(e -> { //Function
                //只有e != null (有异常)时这个方法才会执行
                System.out.println("2");
                return null;
            });
            //System.out.println(exceptionally.get()); //有上面的返回值处理操作，我们就不需要进行get了，这个方法是阻塞的
            System.out.println("主线程先去忙其它事情了~");

        } catch (Exception e) {
            System.out.println("使用Completable异常");
        } finally {
            threadPool.shutdown();
        }
    }
}

```

函数式接口复习：

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16543892117121654389210944.png)

### \[\_7\_] CompletableFuture中join()和get()方法的区别

**一.相同点：**

join()和get()方法都是用来获取CompletableFuture异步之后的返回值

**二.区别：**

1.join()方法抛出的是uncheck异常（即未经检查的异常),不会强制开发者抛出，

会将异常包装成CompletionException异常 /CancellationException异常，但是本质原因还是代码内存在的真正的异常

### +实战前扫盲

1）链式设置类的参数值

```java
package com.zhuangjie.javaJUC;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

public class _7_实战前学习 {
    public static void main(String[] args) {
        ABC abc = new ABC();
        abc.setName("小庄").setAge(22).setOccupation("IT");
        System.out.println(abc);
    }

}
@AllArgsConstructor
@NoArgsConstructor
@Data
@Accessors(chain = true) //开启链式编程，由一行一行地set通过链式编程，合成一行
@ToString
class ABC{
    private String name;
    private int age;
    private String occupation;



}

```

2）我们在使用get获取CompletableFuture时，会进行在编译期间，会做检查异常，即要做异常的处理try或放在方法上。

而jon就不做编译期间异常检查，不会进行异常处理，但出现异常该抛还是要抛的。

### + 学完线程池后再使用CompletableFuture&#x20;

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.*;

public class _9_JUC再复习 {

    public static void main(String[] args) {
        //创建一个线程池
        ThreadPoolExecutor threadPool = new ThreadPoolExecutor(2, 5, 30, TimeUnit.SECONDS, new ArrayBlockingQueue<>(10), (runnable, threadPoolExecutor) -> {
            if (!threadPoolExecutor.isShutdown()) {
                runnable.run();
            }
        });
        try {
            //创建CompletableFuture
            CompletableFuture<String> exceptionally = CompletableFuture.supplyAsync(() -> {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return "异步任务，迅步地处理返回值，多线程~";
            }, threadPool).whenComplete((v, e) -> {
                if (e == null) {
                    //如果没有异常，即成功时~
                    System.out.println("success: "+v);
                }
            }).exceptionally(e -> {
                //如果有异常时
                System.out.println("fall: "+e);
                //返回null
                return null;
            });
            System.out.println("主线程执行别的去了");
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }finally {
            //关闭线程池
            threadPool.shutdown();
        }

    }
}

```

### + 电商比价实战

分别对不同的电商平台对指定的商品进行抓取，根据传统方式与加入CompletableFuture的方式进行操作时间的比较。

```java
package com.zhuangjie.javaJUC;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

public class _10_电商比价 {
    //要搜集的电商平台
    static List<NetMall> list = Arrays.asList(
            new NetMall("京东"),
            new NetMall("淘宝"),
            new NetMall("拼多多")
    );
    //【1】传统方式，电商平台越多，就越慢
    public static List<String> getPrice(List<NetMall> list, String productName) {
        long begin = System.currentTimeMillis();
        List<String> collect = list.stream().map(netMall -> String.format(productName + "在%s上卖%.2f元",netMall.getStoreName(), netMall.calcPrice())).collect(Collectors.toList());
        long end = System.currentTimeMillis();
        System.out.println("收集耗时："+(end - begin)+"ms。");
        return collect;


    }
    //【2】使用CompletableFuture进行并发操作，添加更多的电商平台，影响甚微
    public static List<String> getPriceForCompletableFuture(List<NetMall> list, String productName) {
        long begin = System.currentTimeMillis();
        List<String> collect = list.stream().map(netMall -> CompletableFuture.supplyAsync(() -> String.format(productName + "在%s上卖%.2f元", netMall.getStoreName(), netMall.calcPrice()))).collect(Collectors.toList()).stream().map(c -> c.join()).collect(Collectors.toList());
        long end = System.currentTimeMillis();
        System.out.println("使用CompletableFuture 收集耗时："+(end - begin)+"ms。");
        return collect;

    }
     //【3】使用Stream的并发流，内置并发操作，添加更多的电商平台，影响甚微，比CompletableFuture方式简单一些
    public static List<String> getPriceForParallelStream(List<NetMall> list, String productName) {
        long begin = System.currentTimeMillis();
        List<String> collect = list.parallelStream().map(netMall -> String.format(productName + "在%s上卖%.2f元",netMall.getStoreName(), netMall.calcPrice())).collect(Collectors.toList());
        long end = System.currentTimeMillis();
        System.out.println("收集耗时："+(end - begin)+"ms。");
        return collect;


    }
    //测试入口
    public static void main(String[] args) {
        List<String> mysql01 = getPrice(list, "mysql");
        List<String> mysql02 = getPriceForCompletableFuture(list, "mysql");
        List<String> mysql03 = getPriceForParallelStream(list, "mysql");
        System.out.println(mysql01);
        System.out.println(mysql02);
        System.out.println(mysql03);
    }


}
//电商类
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
class NetMall {
    private String storeName;

    public double calcPrice()  {
        try { Thread.sleep(1000); }catch (Exception e) {}

        return ThreadLocalRandom.current().nextDouble() *100 + storeName.charAt(0);
    }
}

```

### \[\_8\_] 获取CompletableFuture结果的方法

```java
package com.zhuangjie.javaJUC;

import org.junit.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class _11_CompletableFuture的常用方法 {
    @Test
    public void test01(){
        CompletableFuture<String> stringCompletableFuture = CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Hello,world";
        });
        //get （一直等待）
        try {
            String str = stringCompletableFuture.get();
            System.out.println(str);
        }catch (Exception e) {}
        //get 超时不候（报错）
        try {
            String str02 = stringCompletableFuture.get(1, TimeUnit.SECONDS);
            System.out.println(str02);
        }catch (Exception e) {}
        //join  获取不到不报错
        String join = stringCompletableFuture.join();
        System.out.println(join);
        //getNow 直接获取，如果没有，返回兜底的值
        String ng = stringCompletableFuture.getNow("获取不到");
        System.out.println(ng);

        //complete , 如果执行到complete还没有，就打断，将complete参数的值作为CompletableFuture返回的值，并返回true。如果已经有值了，返回true
        //try {Thread.sleep(2500);}catch (Exception e) {} 
        System.out.println(stringCompletableFuture.complete("获取失败"));
        System.out.println(stringCompletableFuture.join());
    }
}

```

### \[\_9\_] 对CompletableFuture计算的结果进行处理的方法

下面主要说了两种对CompletableFuture计算的结果进行处理的方法，分别是thenApply、handle。&#x20;

```java
package com.zhuangjie.javaJUC;

import org.junit.Test;

import java.util.concurrent.CompletableFuture;

public class _12_对CompletableFuture的计算结果进行处理 {
    @Test
    public void test01() {
        /**thenApply 可以对上一次操作返回的结果进行处理，然后返回处理的值。当在运算的过程中出错了，后面的thenApply就不会再执行了，而是开始执行下面的
         whenComplete 和 exceptionally
         以下程序输出的结果 ：
             第一次运算~
             第二次运算~
             出错了,异常信息：java.lang.ArithmeticException: / by zero

         */
        CompletableFuture.supplyAsync(()-> {
            System.out.println("第一次运算~");
           return 1;
        }).thenApply(prv->{
            System.out.println("第二次运算~");
            int i = 1/0;
            return prv + 1;
        }).thenApply(prv->{
            System.out.println("第三次运算~");
            return prv + 1;
        }).whenComplete((prv,e)->{
            if (e == null) {
                System.out.println("没有异常，结果是："+prv);
            }
        }).exceptionally(e->{
            System.out.println("出错了,异常信息："+e.getMessage());
            return null;
        });

        try {Thread.sleep(2000); }catch (Exception e) {}
    }
    @Test
    public void test02() {
        /**handle 可以对上一次操作返回的结果进行处理，然后返回处理的值。当在运算的过程中出错了，后面的thandle会继续执行了，但第二个参数是e就不是null了，
          然后就接着执行whenComplete与exceptionally。
         下面程序的输出结果：
             第一次运算~
             第二次运算~
             第三次运算~
             上一步出现异常了
             出错了,异常信息：java.lang.NullPointerException

         */
        CompletableFuture.supplyAsync(()-> {
            System.out.println("第一次运算~");
            return 1;
        }).handle((prv,e)->{
            System.out.println("第二次运算~");
            if (e != null) {
                System.out.println("\t上一步出现异常了");
            }
            int i = 1/0;
            return prv + 1;
        }).handle((prv,e)->{
            System.out.println("第三次运算~");
            if (e != null) {
                System.out.println("\t上一步出现异常了");
            }
            return prv + 1;
        }).whenComplete((prv,e)->{
            if (e == null) {
                System.out.println("没有异常，结果是："+prv);
            }
        }).exceptionally(e->{
            System.out.println("出错了,异常信息："+e.getMessage());
            return null;
        });

        try {Thread.sleep(2000); }catch (Exception e) {}
    }
}

```

### \[\_10\_] thenAccept对CompletableFuture的返回值进行消费与thenRun

```java
    @Test
    public void test03() {
        CompletableFuture<Void> voidCompletableFuture = CompletableFuture.supplyAsync(() -> {
            return "Hello,world~";
        }).thenAccept(prv -> { //thenAccept 消费型, 需要上面返回的参数，但自己又不需要返回新的值 
            System.out.println(prv);
        }).thenRun(()->{ //thenRun 不接受上一步返回的值，且没有返回值，这是一个Runnable
            try{Thread.sleep(2000);}catch (Exception e) {}
            System.out.println("好像使用了异步");
        });
        //没有返回值
        System.out.println(voidCompletableFuture.join());
    }
```

### \[\_11\_] 线程池与thenRun

使用thenRun还是使用thenRunAsync，会影响我们使用的线程。

在supplyAsync的Lambda方法体中，如果执行地很快，也会影响我们使用的线程。

```java
package com.zhuangjie.javaJUC;

import javafx.application.Application;
import javafx.stage.Stage;
import org.junit.Test;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class _13_线程池与CompletableFuture  {
    @Test
    public void test01(){
        //创建一个线程池
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(2, 3, 20, TimeUnit.SECONDS, new ArrayBlockingQueue(3));
        //创建CompletableFuture使用线程池
        CompletableFuture.supplyAsync(()->{
            try {Thread.sleep(1000);}catch (Exception e){} //【2】如果这行注释，且后面使用的是thenRun，而不是使用thenRunAsync时，那么由于太快，则在下面的thenRun 使用的都是main线程，而不是我们创建的线程池中的线程
            System.out.println(Thread.currentThread().getName());
            return "Hello,world~";
        },threadPoolExecutor).thenRunAsync(()->{ //【1】thenRunAsync 别起炉灶，将不会用我们传入的线程池中的线程，而是内置的ForkJoinPool，这会导致下面都是一样
            System.out.println(Thread.currentThread().getName());
        }).thenRun(()->{
            System.out.println(Thread.currentThread().getName());
        }).thenRun(()->{
            System.out.println(Thread.currentThread().getName());
        });
        try {Thread.sleep(3000);}catch (Exception e){}

    }

}

```

### \[\_12\_] 谁快用谁（CompletableFuture）

我们要讲的主角是 applyToEither方法

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.CompletableFuture;

public class _14_谁快用谁 {
    public static void main(String[] args) {
        //参赛者：小毛
        CompletableFuture<String> futureA = CompletableFuture.supplyAsync(() -> {
            try {
                try { Thread.sleep(1000); } catch (Exception e) { }
            } catch (Exception e) {
            }
            System.out.println("小毛到达了");
            return "小毛";
        });
        //参赛者：小东
        CompletableFuture<String> futureB = CompletableFuture.supplyAsync(() -> {
            try { Thread.sleep(1500); } catch (Exception e) { }
            System.out.println("小东到达了");
            return "小东";
        });
        //applyToEither  谁快用谁，f就是最快的那个返回的值
        CompletableFuture<String> stringCompletableFuture = futureA.applyToEither(futureB, f -> {
            System.out.println(f + "是冠军");
            return "活动结束~";
        });
        System.out.println(stringCompletableFuture.join());
        //main线程先不要结束,等待2000
        try { Thread.sleep(2000); } catch (Exception e) { }



    }

}

```

### \[\_13\_] 对计算结果的合并计算

要讲的主角是 thenCombine ，等待两个完成后，再进行两者返回值进行新操作，并返回新的值

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.CompletableFuture;

public class _15_计算结果合并 {
    public static void main(String[] args) {
        CompletableFuture<Integer> future1 = CompletableFuture.supplyAsync(() -> {
            try{Thread.sleep(1000);}catch (Exception e) {}
            return 1314;
        });
        CompletableFuture<Integer> future2 = CompletableFuture.supplyAsync(() -> {
            try{Thread.sleep(2000);}catch (Exception e) {}
            return 520;
        });
        //future1  1s后返回结果，还需要再等future2，才能开始对两个计算结果进行结合
        CompletableFuture<Integer> result = future1.thenCombine(future2, (v1, v2) -> {
            System.out.println("计算结果合并中~");
            return v1 + v2;
        });
        //返回最终结果，并输出
        System.out.println(result.join());
    }
}

```

### <14> 多线程锁

#### \[\_1\_] 悲观锁与乐观锁

**悲观锁**

认为自己在使用数据的时候一定有别的线程来修改数据，因此在获取数据的时候会先加锁，确保数据不会被别的线程修改。
synchronized关键字和Lock的实现类都是悲观锁

synchronized

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16555367526041655536752534.png)

Lock

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16555367015771655536700855.png)

应用场景：适合写操作多的场景

代码实操

示例1：

```java
package com.zhuangjie.javaJUC;

public class _16_悲观锁synchroneized {
    public static void main(String[] args) throws InterruptedException {
        Phone phone = new Phone();
        new Thread(()->{
            phone.Email();
        }).start();
        try { Thread.sleep(300); } catch (InterruptedException e) { }
        new Thread(()->{
            phone.SMS();
        }).start();

        try { Thread.sleep(3000); } catch (InterruptedException e) { }


    }


}
class Phone {
    public synchronized void Email()  {
        try { Thread.sleep(2000); } catch (InterruptedException e) { }
        System.out.println("send Email~");
    }
    public synchronized void SMS() {
        System.out.println("send SMS~");
    }
}

```

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16555407896711655540789456.png)

本示例总结：`非静态方法+synchronized` 锁的是this，即当前实例对象。即`对象锁`。假设有两个被synchronized修饰的方法，A方法执行后B方法再执行，且使用的是同一个对象调用，此时A、B方法会共同一个锁。那么只有A方法执行完成或抛出异常白带释放锁，B方法才能执行。

示例2：

```java
package com.zhuangjie.javaJUC;

public class _16_悲观锁synchroneized {
    public static void main(String[] args) throws InterruptedException {
        Phone phone01 = new Phone();
        Phone phone02 = new Phone();
        new Thread(()->{
            phone01.Email();
        }).start();
        try { Thread.sleep(300); } catch (InterruptedException e) { }
        new Thread(()->{
            phone02.SMS();
        }).start();

        try { Thread.sleep(3000); } catch (InterruptedException e) { }


    }


}
class Phone {
    public static synchronized void Email()  {
        try { Thread.sleep(2000); } catch (InterruptedException e) { }
        System.out.println("send Email~");
    }
    public static synchronized void SMS() {
        System.out.println("send SMS~");
    }
}

```

本示例总结：`  static synchronized  ` 锁的是类对象,即`类锁`，所以不管是否从哪个该类的实例调用，都要获取类锁才能执行。所以SMS方法需要先等Email方法执行完成才能执行。因为Email先于SMS方法执行，所以就要等。

补充：同步代码块， 可以自己选择锁什么，可以是类对象，也可以是一个类的实例对象

```java
synchronized (new _16_悲观锁synchroneized().getClass()) {
}
synchronized (new _16_悲观锁synchroneized()) {
}
```

**乐观锁**
认为自己在使用数据时不会有别的线程修改数据或资源，所以不会添加锁。在Java中是通过使用无锁编程来实现，只是在更新数据的时候去判断，之前有没有别的线程更新了这个数据。如果这个数据没有被更新，当前线程将自己修改的数据成功写入。如果这个数据已经被其它线程更新，则根据不同的实现方式执行不同的操作，比如放弃修改、重试抢锁等等

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16555368228421655536822758.png)

判断规则：
1版本号机制Version
2最常采用的是CAS算法，Java原子类中的递增操作就通过CAS自旋实现的。

适用场景：适合读操作多的场景

#### + 通过反编译看synchronized

**synchronized同步代码块，有以下两种情况：**

1）通过命令`javap -c **.class` 进行编译，在一般情况下，是一个monitorenter对两个monitorexit的。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16557974338681655797433494.png)

2）如果我们在里面直接抛出运行时异常时，即以下代码，反编译的是一个monitorenter对一个monitorexit。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16557976931811655797692801.png)

对`static synchronized` 与`synchronized` 通过反编译 `javap -v **.class` 分别如下&#x20;

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16557982787951655798278716.png)

#### \[\_2\_] synchronized 的底层分析

每个对象，天生就带一个ObjectMonitor(管程)，对象与它的管程有着共生关系，它像是一个小本本，记录着一些信息。ObjectMonitor.java 底层是由ObjectMonitor.cpp支持的。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558008665001655800866321.png)

每个对象分两种，它可以是普通对象，也可以被当着锁对象，锁对象是有工作的，它需要站在synchronized外，记录着信息，管理着进来的线程。

#### \[\_3\_] 公平锁与非公平锁

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558017897041655801789471.png)

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.locks.ReentrantLock;

class A {
    private int number = 50;
    private ReentrantLock lock = new ReentrantLock(false); //true为公平锁，false为非公平锁（默认）

    public void sale() {
        lock.lock(); //加锁
        try {
            if (number > 0) {
                System.out.println(Thread.currentThread().getName() + "卖出第" + (number--) + "张票！");
            }
        } finally {
            lock.unlock(); //释放锁
//            try {
//                Thread.sleep(200); //如果是非公平锁，添加这个可以公平一些
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }
    }

}

public class _18_公平锁与非公平锁 {
    public static void main(String[] args) {
        A a = new A();
        new Thread(() -> { for (int i = 0; i < 55; i++) { a.sale(); } }, "A线程").start();
        new Thread(() -> { for (int i = 0; i < 55; i++) { a.sale(); } }, "B线程").start();
        new Thread(() -> { for (int i = 0; i < 55; i++) { a.sale(); } }, "C线程").start();
    }
}

```

**非公平锁：**

-   非公平锁性能高于公平锁性能。首先，在恢复一个被挂起的线程与该线程真正运行之间存在着严重的延迟（上下文切换）。而且，非公平锁能更充分的利用cpu的时间片，尽量的减少cpu空闲的状态时间。
-   可能也发现了，这样可能导致队列中间的线程一直获取不到锁或者长时间获取不到锁，导致饿死。

**公平锁：**

-   如果想让线程雨露均沾，那就用公平锁，但公平锁会导致上下文切换，使CPU利用率下降。
-   吞吐量会下降很多，cpu会不断唤醒阻塞的线程且cpu唤醒阻塞线程的开销会很大。

#### \[\_4\_] 可重入锁

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558860627521655886062514.png)

**可重入锁是一种技术：** 任意线程在获取到锁之后能够再次获取该锁而不会被锁所阻塞。

`synchronized`与`ReentrantLock`都是可重入锁，synchronized是隐式锁，ReentrantLock是显式锁。即“同步代码块A获取A锁，且同步代码块A内的同步代码块B内也需要A锁，当一个线程获取进入了同步代码块A内，那么就不需要再去获取同步代码块B中的A锁了，可以直接执行里面的锁，假设执行同步代码块B，还需要获取A锁，那么就会产生死锁。即可重入锁这点可以避免死锁”

**原理：**

1.  当执行monitorenter时，如果目标锁对象的计数器为零，那么说明它没有被其他线程所持有，Java虚拟机会将该锁对象的持有线程设置为当前线程，并且将其计数器加1。
2.  在目标锁对象的计数器不为零的情况下，如果锁对象的持有线程是当前线程，那么Java虚拟机可以将其计数器加1,否则需要等待，直至持有线程释放该锁。
3.  当执行monitorexit时，Java虚拟机则需将锁对象的计数器减1。计数器为零代表锁已被释放。

**以下是一个死锁情况的简单示例：**

-   线程 1 持有锁 A 并请求锁 B
-   线程 2 持有锁 B 并请求锁 A

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.locks.ReentrantLock;

public class _19_可重入锁 {
    public static void main(String[] args) {
        System.out.println("===死锁演示===");
        Object a = new Object();
        Object b = new Object();
        new Thread(()->{
            synchronized (a) {
                System.out.println(Thread.currentThread().getName()+"获取到了第一把锁！准备去获取第二把锁");
                //等待二秒，确保”线程2“获取到了第二把锁
                try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
                synchronized (b) {
                    System.out.println(Thread.currentThread().getName()+"获取到了第二把锁！");
                }
            }
        },"线程1").start();

        //等待一秒，确保”线程1“获取到了第一把锁
        try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }

        new Thread(()->{
            synchronized (b) {
                System.out.println(Thread.currentThread().getName()+"获取到了第二把锁！，准备去获取第一把锁！");
                synchronized (a) {
                    System.out.println(Thread.currentThread().getName()+"获取到了第一把锁！");
                }
            }
        },"线程2").start();

    }
}


```

**ReentrantLock重入锁**:  使用ReentrantLock重入锁，需要注意，lock()与unlock() 要配对, 否则会造成另一个线程阻塞（注意这并不是死锁）

```java
package com.zhuangjie.javaJUC;

import java.util.concurrent.locks.ReentrantLock;

public class _20_ReentrantLock使用重入锁 {
    //使用ReentrantLock重入锁，需要注意，lock()与unlock() 要配对, 否则会造成另一个线程阻塞（注意这并不是死锁）
    private static ReentrantLock reentrantLock = new ReentrantLock();
    public static void call() {
        reentrantLock.lock();
        System.out.println(Thread.currentThread().getName()+"，大聪明：Hello,world");
            reentrantLock.lock();
            System.out.println(Thread.currentThread().getName()+"猪猪：Hello,world");
            reentrantLock.unlock();
//        reentrantLock.unlock(); //注释该行会造成另一个线程阻塞（注意这并不是死锁）
    }
    public static void main(String[] args) {
        new Thread(() -> {
            call();
        },"线程A").start();
        //确保线程A先执行
        try { Thread.sleep(200); }catch (Exception e) {}
        new Thread(() -> {
            call();
        },"线程B").start();




    }
}

```

#### \[\_5\_] 如何检查死锁

**什么是死锁：**

死锁是指两个或两个以上的线程在执行过程中，因争夺资源而造成的一种互相等待的现象，若无外力干涉那它们都将无法推进下去，如果系统资源充足，进程的资源请求都能够得到满足，死锁出现的可能性就很低，否则就会因争夺有限的资源而陷入死锁。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558843903981655884389913.png)

-   一个死锁的案例
    ```java
    package com.zhuangjie.javaJUC;

    import java.util.concurrent.locks.ReentrantLock;

    public class _19_可重入锁 {
        public static void main(String[] args) {
            System.out.println("===死锁演示===");
            Object a = new Object();
            Object b = new Object();
            new Thread(()->{
                synchronized (a) {
                    System.out.println(Thread.currentThread().getName()+"获取到了第一把锁！准备去获取第二把锁");
                    //等待二秒，确保”线程2“获取到了第二把锁
                    try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
                    synchronized (b) {
                        System.out.println(Thread.currentThread().getName()+"获取到了第二把锁！");
                    }
                }
            },"线程1").start();

            //等待一秒，确保”线程1“获取到了第一把锁
            try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }

            new Thread(()->{
                synchronized (b) {
                    System.out.println(Thread.currentThread().getName()+"获取到了第二把锁！，准备去获取第一把锁！");
                    synchronized (a) {
                        System.out.println(Thread.currentThread().getName()+"获取到了第一把锁！");
                    }
                }
            },"线程2").start();

        }
    }

    ```

**检查死锁的方式**

**1）纯命令的方式**

jps -l   #查看java进程

jstack 进程号   #jstack用于生成java虚拟机当前时刻的线程快照。线程快照是当前java虚拟机内每一条线程正在执行的方法堆栈的集合，生成线程快照的主要目的是定位线程出现长时间停顿的原因，如线程间死锁、死循环、请求外部资源导致的长时间等待等。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558851835471655885183450.png)

**2) 图形界面的方式**

jconsole   #从Java 5开始引入了JConsole。JConsole是一个内置Java性能分析器，可以从命令行或在GUI shell中运行。您可以轻松地使用JConsole（或者，它更高端的“近亲” VisualVM）来监控Java应用程序性能和跟踪Java中的代码。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558847429491655884742864.png)

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558848623961655884862274.png)

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16558849133971655884912934.png)

## \[\_15\_] 中断机制

#### \[\_15.1\_] 什么是中断机制

通过调用方法将自己或其它线程的中断标记符为true，表示该线程需要中断，但是否中断，什么时候中断，由将要中断的线程程序自己根据查看自己标记符然后来决定。（协商的方式）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/11/1665470996590.png)

#### \[\_15.2\_] 中断运行中的线程

通过一个`volatile` 变量实现

```java
public class test06 {
    private static volatile boolean isStop = false;
    public static void main(String[] args) {
        new Thread(()->{
            while (true) {
                if (isStop) {
                    System.out.println("线程A退出运行！");
                    return;
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("线程A运行中");
            }

        }).start();
        new Thread(()->{
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("与线程A协商中");
            isStop = true;
        }).start();

    }
}
```

除此我们还可以通过

-   AtomicBoolean：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/11/1665472750095.png](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/11/1665472750095.png "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/11/1665472750095.png")
-   Thread类自带的中断api实例方法实现：

    **本章重点：**

    thread.interrupt() 设置一个活动的（不能是阻塞的，如sleep,wait,join）线程的中断状态位为`true`

    thread.isInterrupted() 查看一个线程的中断状态位（`true` 或 `false`）
    ```java
    public class test06 {
        public static void main(String[] args) {

            Thread t1 = new Thread(()->{
                while (true) {
                    if (Thread.currentThread().isInterrupted()) {
                        System.out.println(Thread.currentThread().isInterrupted()+"线程A退出运行！");
                        return;
                    }
                    System.out.println("线程A运行中");
                }

            });
            t1.start();
            Thread t2 = new Thread(()->{
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("与线程A协商中");
                t1.interrupt();
            });
            t2.start();

        }
    }

    ```

但原理都是一样的，都是借助一个变量。

> 🤣 **当线程真的结束后，我们再调用**\*\*`isInterrupted()`查看该线程的中断符号位，值是什么呢？\*\*​
>
> 经代码验证，值是`false`
>
> **😠 为什么中断正在睡眠的线程后，无法让线程停止？**
>
> 中断一个正在睡眠的线程，会使线程的中断位变为`false` 相当于没有调用中断。我们想要继续让该线程中断，就要在异常捕获catch中调用 `Thread.currentThread().interrupt();` 了。
>
> ![2022-10-11](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/11/1665479036857.png "2022-10-11")
>
> ```java
>
> public class test06 {
>     public static void main(String[] args) {
>
>         Thread t1 = new Thread(()->{
>             while (true) {
>                 if (Thread.currentThread().isInterrupted()) {
>                     System.out.println(Thread.currentThread().isInterrupted()+"线程A退出运行！");
>                     return;
>                 }
>                 try {
>                     Thread.sleep(200);
>                 } catch (InterruptedException e) {
>                     Thread.currentThread().interrupt(); // 此时t1线程的中断状态位为false,因为中断了正在睡眠的线程，如果想要 继续中断，就需要再次调用中断方法
>                 }
>                 System.out.println("线程A运行中");
>             }
>
>         });
>         t1.start();
>         Thread t2 = new Thread(()->{
>             try {
>                 Thread.sleep(1000);
>             } catch (InterruptedException e) {
>                 e.printStackTrace();
>             }
>             System.out.println("与线程A协商中");
>             t1.interrupt();
>
>         });
>         t2.start();
>
>     }
> }
> ```

#### \[\_15.3\_]  isInterrupted()与静态方法interrupted()区别

```java
    public static boolean interrupted() {
        return currentThread().isInterrupted(true);
    }


    public boolean isInterrupted() {
        return isInterrupted(false);
    }

    private native boolean isInterrupted(boolean ClearInterrupted);
```

通过查看源码，可知`interrupted`与公开`isInterrupted`  都是调用类的私有方法`isInterrupted` ，两者唯一区别是 `interrupted` 会重置线程的中断符号位为`false` 而`isInterrupted`则只是查看线程符号位的值，而不会重置。

验证：

```java
public class test06 {
    public static void main(String[] args) {
        System.out.println("开始设置当前线程的中断符号位");
        Thread.currentThread().interrupt();
        System.out.println(Thread.currentThread().isInterrupted()); //true
        System.out.println(Thread.currentThread().isInterrupted()); //true

        System.out.println("开始设置当前线程的中断符号位");
        Thread.currentThread().interrupt();
        System.out.println(Thread.interrupted()); //true
        System.out.println(Thread.interrupted()); //false

    }
}
```

### \[\_16\_] 线程的等待与唤醒机制

![2022-10-12](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/12/1665568271193.png "2022-10-12")

#### \[\_16.1\_]方式一： synchronized - wait- notify

objectLock .`wait`  : 让拥有该锁对象(objectLock )上的线程进行等待状态

objectLock .`notify`: 唤醒持有锁对象(objectLock )上的线程。

```java
public class test06 {
    public static void main(String[] args) {
        Object objectLock = new Object();
        new Thread(()->{
            synchronized (objectLock) {
                try {
                    objectLock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread().getName()+"线程被唤醒了~");
            }
        },"t1").start();

        try { Thread.sleep(1000); } catch (InterruptedException e) { }

        new Thread(()->{
            synchronized (objectLock) {
                objectLock.notify();
                System.out.println(Thread.currentThread().getName()+"发出通过~");
            }
        },"t2").start();


    }
}
```

执行输出 ：

```bash
"C:\Program Files\Java\jdk1.8.0_202\bin\java.exe" "-javaagent:D:\apps\edu_software\idea\IntelliJ IDEA 2020.2.2\lib\idea_rt.jar=64783:D:\apps\edu_software\idea\IntelliJ IDEA 2020.2.2\bin" -Dfile.encoding=UTF-8 -classpath "C:\Program Files\Java\jdk1.8.0_202\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\deploy.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\access-bridge-64.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\cldrdata.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\dnsns.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\jaccess.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\jfxrt.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\localedata.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\nashorn.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\sunec.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\sunjce_provider.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\sunmscapi.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\sunpkcs11.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\ext\zipfs.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\javaws.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\jce.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\jfxswt.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\management-agent.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\plugin.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\resources.jar;C:\Program Files\Java\jdk1.8.0_202\jre\lib\rt.jar;C:\Users\zhuangjie\IdeaProjects\java_test01\out\production\java_test01" com.zhuangjie.demo.test06
t2发出通过~
t1线程被唤醒了~

进程已结束,退出代码0

```

> **注意**
>
> 1.  `wait`与`notify`方法调用的是`锁对象` ,即 `锁对象`.\[wait | notify]&#x20;
> 2.  顺序是先`wait`再`notify`

#### \[\_16.2\_] 方式二：Lock - await - signal

Condition：相当于锁对象 ，监视器

Lock：相当于synchronized

await：等待

signal：唤醒

```java
public class test06 {
    public static void main(String[] args) {

        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();
        new Thread(()->{
            lock.lock();
            try {
                condition.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName()+"线程被唤醒了~");
            lock.unlock();
        },"t1").start();

        try { Thread.sleep(1000); } catch (InterruptedException e) { }

        new Thread(()->{
            System.out.println("--准备去通知，但还没通知--");
            // t1线程进入等待，会释放锁，在这里就会获取到锁
            lock.lock();
                condition.signal();
                System.out.println(Thread.currentThread().getName()+"发出通过~");
            lock.unlock();
        },"t2").start();

    }
}
```

效果与synchronized是相同的。

#### \[\_16.3\_] 方式三LockSupport  ： park - unpark

该类与使用它的每个线程关联一个许可证（在[Semaphore](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/Semaphore.html "Semaphore")类的意义上）。 如果许可证可用，将立即返回`park` ，并在此过程中消费; 否则\_可能会\_阻止。 如果尚未提供许可，则致电`unpark`获得许可。 （与Semaphores不同，许可证不会累积。最多只有一个。）可靠的使用需要使用volatile（或原子）变量来控制何时停放或取消停放。 对于易失性变量访问保持对这些方法的调用的顺序，但不一定是非易失性变量访问。

线程阻塞需要消耗凭证（permit),这个凭证最多只有1个，不能累加，凭证存放在线程中。

**消耗凭证**：先执行`park` 再执行 `unpark`

```java
public class test06 {
    public static void main(String[] args) {

        Thread t1 = new Thread(()->{
            System.out.println("-公园门口检票中-");
            long begin = System.currentTimeMillis();
            LockSupport.park();
            System.out.println(Thread.currentThread().getName()+"检查通过！");
            System.out.println("*** 检查耗时："+(System.currentTimeMillis() - begin));
        },"t1");t1.start();

        try { Thread.sleep(1000); } catch (InterruptedException e) { }

        new Thread(()->{
            System.out.println(Thread.currentThread().getName()+"购票中");
            LockSupport.unpark(t1);
            System.out.println(Thread.currentThread().getName()+"已购票");

        },"t2").start();

    }
}
```

执行输出：

```java
"C:\Program Files\Java\jdk1.8.0_202\bin\java.exe" ...  com.zhuangjie.demo.test06
-公园门口检票中-
t2购票中
t2已购票
t1检查通过！
*** 检查耗时：1006
```

**验证无顺序区别**：先执行`unpark` 再执行 `park`&#x20;

```java
public class test06 {
    public static void main(String[] args) {

        Thread t1 = new Thread(()->{
            try { Thread.sleep(1000); } catch (InterruptedException e) { }

            System.out.println("-公园门口检票中-");
            long begin = System.currentTimeMillis();
            LockSupport.park();
            System.out.println(Thread.currentThread().getName()+"检查通过！");
            System.out.println("*** 检查耗时："+(System.currentTimeMillis() - begin));
        },"t1");t1.start();


        new Thread(()->{
            System.out.println(Thread.currentThread().getName()+"购票中");
            LockSupport.unpark(t1);
            System.out.println(Thread.currentThread().getName()+"已购票");

        },"t2").start();

    }
}

```

执行输出：

```bash
"C:\Program Files\Java\jdk1.8.0_202\bin\java.exe" ...  com.zhuangjie.demo.test06
t2购票中
t2已购票
-公园门口检票中-
t1检查通过！
*** 检查耗时：0
```

**验证：** 线程阻塞需要消耗凭证（permit),这个凭证最多只有1个，不能累加。

```java
public class test06 {
    public static void main(String[] args) {

        Thread t1 = new Thread(()->{
            try { Thread.sleep(1000); } catch (InterruptedException e) { }

            System.out.println("-公园门口检票中-");
            long begin = System.currentTimeMillis();
            // 如果能拥有两个凭证，是不会阻塞了
            LockSupport.park();
            LockSupport.park();
            System.out.println(Thread.currentThread().getName()+"检查通过！");
            System.out.println("*** 检查耗时："+(System.currentTimeMillis() - begin));
        },"t1");t1.start();
        
        new Thread(()->{
            System.out.println(Thread.currentThread().getName()+"购票中");
            // 意想发放两个凭证
            LockSupport.unpark(t1);
            LockSupport.unpark(t1);
            System.out.println(Thread.currentThread().getName()+"已购票");

        },"t2").start();

    }
}
```

执行输出 ：

```bash
"C:\Program Files\Java\jdk1.8.0_202\bin\java.exe" ...  com.zhuangjie.demo.test06
t2购票中
t2已购票
-公园门口检票中-
```

发现会进入阻塞，所以验证成功，线程最多只有一个凭证。

### \[\_17\_] JMM (Java 内存模型)

因为有这么多级的缓存（cpu和物理主内存的速度不一致的）, CPU的运行并不是直接操作内存而是先把内存里边的数据读到缓存，而内存的读和写操作的时候就会造成不一致的问题。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/12/1665569989798.png)

JVM规范中试图定义一种Java内存模型（java Memory Model,简称JMM)来屏蔽掉各种硬件和操作系统的内存访问差异，以实现让Java程序在各种平台下都能达到一致的内存访问效果。

所以，推导出我们需要知道JMM

JMM(Java内存模型Java Memory Model,简称JMM)本身是一种抽象的概念并不真实存在它仅仅描述的是一组约定或规范，通过这规范定义了程序中（尤其是多线程）各个变量的读写访问方式并决定一个线程对共享变量的写入何时以及如何变成对另一个线程可见，关键技术点都是围绕多线程的原子性、可见性和有序性展开的。

**原则：**
JMM的关键技术点都是围绕多线程的原子性、可见性和有序性展开的

**能干嘛？**
1通过JMM来实现线程和主内存之间的抽象关系。
2屏蔽各个硬件平台和操作系统的内存访问差异以实现让Java程序在各种平台下都能达到一致的内存访问效果。

#### \[\_17.1\_] JMM之三大特性

**特性一：可见性**

是指当一个线程修改了某一个共享变量的值，其他线程是否能够立即知道该变更，JMM规定了所有的变量都存储在主内存中。

![2022-10-13](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/13/1665622197586.png "2022-10-13")

这里可能存在“脏读”的情况，在MySQL中指：一个事务读取了另事务未提交的数据；在这里也一样，一个线程读取了另一个线程修改但未刷新到主内存中的数据（变量）。

要保证存在脏读，一个线程修改了，要通知其它线程去主内存中重新读取变量到自己的本地内存中。

> JMM中关于synchronized有如下规定，线程加锁时，必须清空工作内存中共享变量的值，从而使用共享变量时需要从主内存重新读取；线程在解锁时，需要把工作内存中最新的共享变量的值写入到主存，以此来保证共享变量的可见性。(ps这里是个泛指，不是说只有在退出synchronized时才同步变量到主存)

**特性二：原子性**

指一个操作是不可打断的，即多线程环境下，操作不能被其他线程干扰

**特性三：有序性**

**是什么**
对于一个线程的执行代码而言，我们总是习惯性认为代码的执行总是从上到下，有序执行。但（为什么重排→）为了提升性能，编译器和处理器通常会对指令序列进行重新排序。（在什么情况下可以重排→）Java规范规定JVM线程内部维持顺序化语义，即只要程序的最终结果与它顺序化执行的结果相等，那么指令的执行顺序可以与代码顺序不一致，此过程叫指令的重排序。

**优缺点**
JVM能根据处理器特性（CPU多级缓存系统、多核处理器等）适当的对机器指令进行重排序，使机器指令能更符合CPU的执行特性，最大限度的发挥机器性能。但是，（在什么情况下重排会有问题 →）指令重排可以保证串行语义一致，但没有义务保证多线程间的语义也一致（即可能产生“脏读”）,简单说，两行以上不相干的代码在执行的时候有可能先执行的不是第一条，不见得是从上到下顺序执行，执行顺序会被优化。

从源码到最终执行示例图：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/13/1665623938422.png)

#### \[\_17.2\_] Happens-before

**Happens-before**：A Happens-Before B，意味着A发生过的事情 对B来说是可见的，无论A事件和B事件是否发生在同一个线程里。

如果重排序后结果与按照happens-before关系来执行的结果，那么这种重排序并不非法。

happens-before这么做的目的，都是为了在不改变程序执行结果的前提下，尽可能地提高程序执行的并行度。

**Happens-before的8条原则：**

**1、单线程happen-before原则：**

在同一个线程中，书写在前面的操作happen-before后面的操作。

**2、锁的happen-before原则：**

同一个锁的unlock操作happen-before此锁的lock操作。

**3、volatile的happen-before原则：**

对一个volatile变量的写操作happen-before对此变量的任意操作(当然也包括写操作了)。

**4、happen-before的传递性原则：**

如果A操作 happen-before B操作，B操作happen-before C操作，那么A操作happen-before C操作。

**5、线程启动的happen-before原则：**

如果线程A调用线程B的start()方法来启动线程B，则start()操作Happens-Before于线程B中的任意操作。

**6、线程中断的happen-before原则：**

对线程interrupt方法的调用happen-before被中断线程的检测到中断发送的代码。

**7、线程终结的happen-before原则：**

线程A等待线程B完成（在线程A中调用线程B的join()方法实现），当线程B完成后（线程A调用线程B的join()方法返回），则线程A能够访问到线程B对共享变量的操作。

**8、对象创建的happen-before原则：**

一个对象的初始化完成先于他的finalize方法调用。

> Happens-Before的作用猜想：保证在多线程并发下，避免因为重排序与JMM模型（主内存与本地内存模型）而引起的脏读的情况。
>
> 但实际上我们还需要使用volatile与synchronized等来保证。

> **JMM的设计分为两部分：**
>
> 一部分是面向我们程序员提供的，也就是happens-before规则，它通俗易懂的向我们程序 员阐述了一个强内存模型，我们只要理解  happens-before规则 ，就可以编写并发安全的程序了。
>
> 另一部分是针对 JVM实现的，为了尽可能少的对编译器和处理器做约束从而提高性能，JMM在不影响程序执行结果 的前提下对其不做要求，即允许优化重排序 。我们只需要关注前者就好了，也就是理解 happens-before 规则 即可，其它繁杂的内容有JMM规范结合操作系统 给我们搞定，我们只写好代码即可。

### \[\_18\_] volatile之两大特性

两大特性：能保障可见性与顺序性（禁重排）

> **volatile的内存语义：**
>
> 1.  当写一个volatile变量时，JMM会把该线程对应的本地内存中的共享变量值立即 刷新回主内存中。
> 2.  当读一个volatile变量时，JMM会把该线程对应的本地内存设置为无效，重新回到主内存中读取最新共享变量。
>
> 所以volatile的写内存语义是直接刷新 到主内存中，读的内存语义是直接从主内存中读取。

😗 那volatile实现可见性与顺序性的原理是什么呢？

`内存屏障`使得volatile的可见性与顺序性得到保证

😀  **内存屏障(Memory Barrier)**：

#### \[\_18.1\_] 两大特性的实现原理：**内存屏障概述**

-   Memory barrier 使得CPU 或 编译器在对内存进行操作的时候, 严格按照一定的顺序来执行
-   Memory barrier是一种CPU指令，用于控制特定条件下的重排序和内存可见性问题。Java编译器也会根据内存屏障的规则禁止重排序。
-   有的处理器的重排序规则较严，无需内存屏障也能很好的工作，Java编译器会在这种情况下不放置内存屏障。

**Memory Barrier可以被分为以下几种类型：**

**粗分两种：**

-   `写屏障（Store Memory Barrier)` : 告诉处理器在写屏障之前将所有存储在缓存（store bufferes)中的数据同步到主内存。也就是说当看到Store屏障指令，就必须把该指令之前所有写入指令执行完毕才能继续往下执行。
-   `读屏障（Load Memory Barrier)`: 处理器在读屏障之后的读操作，都在读屏障之后执行。也就是说在Load屏障指令之后就能够保证后面的读取数据指令一定能够读取到最新的数据。（后面的读的线程会立即从主内存中刷新本地内存的变量，保障能读到最新的）

**细分四种：**

-   `LoadLoad`屏障：对于这样的语句Load1; LoadLoad; Load2，在Load2及后续读取操作要读取的数据被访问前，保证Load1要读取的数据被读取完毕。
-   `StoreStore`屏障：对于这样的语句Store1; StoreStore; Store2，在Store2及后续写入操作执行前，保证Store1的写入操作对其它处理器可见。
-   `LoadStore`屏障：对于这样的语句Load1; LoadStore; Store2，在Store2及后续写入操作被刷出前，保证Load1要读取的数据被读取完毕。
-   `StoreLoad`屏障：对于这样的语句Store1; StoreLoad; Load2，在Load2及后续所有读取操作执行前，保证Store1的写入对所有处理器可见。它的开销是四种屏障中最大的。在大多数处理器的实现中，这个屏障是个万能屏障，兼具其它三种内存屏障的功能。

#### \[\_18.2\_] **内存屏障的应用**

1.  **内存屏障在volatile中的使用**

    内存屏障在volatile读写的插入策略：

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/02/12/1676206539233.png)
    1.  当第一个操作为volatile读时，不论第二个操作是什么，都不能重排序。这个操作保证了volatile读之后的操作不会被重排到volatile读之前。
    2.  当第二个操作为volatile写时，不论第一个操作是什么，都不能重排序。这个操作保证了volatile写之前的操作不会被重排到volatile写之后
        当第一个操作为volatile写时，第二个操作为volatile读时，不能重排。
2.  **内存屏障在final中的使用**
    -   新建对象过程中，构造体中对final域的初始化写入(StoreStore屏障)和这个对象赋值给其他引用变量，这两个操作不能重排序；
    -   初次读包含final域的对象引用和读取这个final域（LoadLoad屏障），这两个操作不能重排序；
    -   Intel 64/IA-32架构下写操作之间不会发生重排序StoreStore会被省略，这种架构下也不会对逻辑上有先后依赖关系的操作进行重排序，所以LoadLoad也会变省略。

#### \[\_18.3\_] volatile的可见性演示

```java
public class test03 {
    private static boolean b = true;
    // private static volatile boolean b = true;
    public static void main(String[] args) throws InterruptedException {
        new Thread(()->{
            while (b) {

            }
            System.out.println("值修改了，退出while~");
        }).start();

        Thread.sleep(1000);

        b = false;
        System.out.println("值修改完成~");
    }

}
```

执行输出：

```java
值修改完成~
```

分析：main的子线程并没有退出while，

情况一：是 main线程修改了，但main线程并没有把本地内存的`b` 值刷到主内存中，对子线程是不可见的；&#x20;

情况二：main将值刷到了主内存，但子线程没有读取主内存中的值，而是使用本地工作内存的`b` 值；

解决方法：给`b` 共享变量加`volatile` 即可。

**volatile变量的读写过程：**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/14/1665735571508.png)

read(读取）→load(加载）→use(使用）→assign(赋值）→store(存储）→write(写入）→lock(锁定）→unlock(解锁） &#x20;

此时其它线程修改的那个变量的副本就失效了，就会从主内存中读取最新的值到本地内存中

#### \[\_18.4\_] volatile的原子性演示

```java
class myNumber {
    public static volatile int n = 0;
    public  static void NumberPlusPlus() {
        n++;
    }

}
public class volatile无法保证原子性演示 {
    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < 10000; i++) {
            new Thread(()->{
                myNumber.NumberPlusPlus();
            }).start();
        }
        Thread.sleep(2000);
        System.out.println(myNumber.n);

    }
}
```

执行输出：

```bash
9996
```

解析：按正常的逻辑（或说单线程下），是`10000` 但在多线程下，不能保证原子性，值就可能小于`10000` ，上面加上了`volatile ` 也不能没有保证原子性，也证实了`volatile` 不能保障原子性。

上面会出现的原因是：`n++` 涉及到了`volatile` 读与写：

![2022-10-14](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/14/1665738007065.png "2022-10-14")

在多线程下：以上面的代码为例，如果在主内存中`n` 的值 为5，此时线程A与线程B都获取到`n` 的值为5放在自己的本地内存中，线程A与线程B都进行`n++` 操作，线程A经过`数据加载→数据计算→数据赋值` 后保存到了本地内存，此时主内存`n`的值为`6`，此时线程B的`n`值作费了，但线程B也已经计算或数据赋值了,`n`的值也为`6` 也写入到了主内存。这就有问题了，本来这一套下来`n`的值应该变为`7`的，出现了写丢失。

![2022-10-14](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/14/1665741552606.png "2022-10-14")

#### \[\_19.5\_] volatile的顺序性演示

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/14/1665743652801.png)

![2022-10-14](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/14/1665743488850.png "2022-10-14")

#### \[\_19.6\_] volatile的使用场景

1.  单一赋值，即不要像i++这种的复合操作。
2.  用于状态标志，比如用作线程的中断标志位时
3.  读多写少，那就可以使用volatile保证读的可见性，synchronized 保证写的原子性
4.  双重检查创建单例时：
    ```java
    //解决了线程安全，效率低问题——“双重检查” Double Check
    class Singleton_Type5 {
        //创建一个成员变量
        //volatile 作用是在多线程操作下，第一，修改后，直接将线程的操作内存，放在所有线程的主操作内存上，会同步到所有线程内存——可见性。第二，禁止指令重排优化的规则，避免系统优化机制的干扰
        // 这里volatile的作用是避免 instance = new Singleton_Type5(); 的重排序，避免即使跳出同步代码块后，instance的值使用方法为null，这样就不能保证在多线程下只创建一次Singleton_Type5对象了
        private static volatile Singleton_Type5 instance;
        //使构造方法私有，对外不可见
        private Singleton_Type5(){}
        //创建一个方法，使外界获取单一实例
        public static Singleton_Type5 getInstance() {
            //第一层检查虽然不能拦着后面的线程，但可以保证成员变量 instance 赋值后，不让线程执行synchronized 同步代码块，从而造成的效率低问题
            if (instance == null) {
                //同步代码块
                synchronized (Singleton_Type5.class) {
                    //让界于第一层if与synchronized 的初始线程，跳过，从而避免其它线程创建实例
                    if (instance == null) {
                        instance = new Singleton_Type5();
                    }
                }
            }
            return instance;
        }

    }

    ```
    避免以下进行重排序

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/16/1665884910270.png)

#### \[\_19.7\_] volatile总结

**volatile是如何保证可见性的？**

答：

写操作的话，这个变量的最新值会立即刷新回到主内存中
读操作的话，总是能够读取到这个变量的最新值，也就是这个变量最后被修改的值

volatile是如何禁重排的？

-   对于写操作：在前面加`StoreStore` ，在后面加`StoreLoad` ,作用是：写之前的写操作禁排，后面的volatile读，禁重排。
-   对于读操作：在后面加`LoadStore` 与`LoadLoad` ：读之后的操作都禁重排

**凭什么我们java写了一个volatile关键字系统底层加入内存屏障？两者关系怎么勾搭上的？**

![2022-10-16](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/16/1665887662741.png "2022-10-16")

**内存屏障是什么？**

是一种屏障指令，它使得CPU或编译器对屏障指令的前和后所发出的内存操作执行一个排序的约束。也叫内存栅栏或栅栏指令

**内存屏障能做什么？**

阻止屏障两边的指令重排序
写数据时加入屏障，强制将线程私有工作内存的数据刷回主物理内存
读数据时加入屏障，线程私有工作内存的数据失效，重新到主物理内存中获取最新数据

**内存屏障四大指令**

在每一个volatile写操作前面插入一个StoreStore屏障
在每一个volatile写操作后面插入一个StoreLoad屏障
在每一个volatile读操作后面插入一个LoadLoad屏障
在每一个volatile读操作后面插入一个LoadStore屏障

### \[\_19\_] CAS

CAS（Compare-and-Swap）就是比较与交换。

**CAS与原子类Atomic ：**

Atomic 原子操作类是基于无锁 CAS + volatile 实现的，并且类中的所有方法都使用 final 修饰，进一步保证线程安全。而 [CAS](https://so.csdn.net/so/search?q=CAS\&spm=1001.2101.3001.7020 "CAS") 算法的具体实现方式在于 Unsafe 类中，Unsafe 类的所有方法都是 native 修饰的，也就是说所有方法都是直接调用操作系统底层资源进行执行相应任务。Atomic 使用乐观策略，每次操作时都假设没有冲突发生，并采用 volatile 配合 CAS 去修改内存中的变量，如果失败则重试，直到成功为止。

多线程环境不使用原子类保证线程安全i++(基本数据类型）,就要使用synchronized +volatile实现
多线程环境使用原子类保证线程安全i++ (基本数据类型）

**CAS思想**：类似于我们的乐观锁，很乐观地认真一个线程在修改的时候，其它线程不会来修改，如A去读取一个变量时，期望的旧值是K，A线程进行K++后，去修改，如果此时旧值还是期望的旧值K，则进行修改，如果不是重试（自旋）或放弃。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/16/1665894885644.png)

硬件级别保证 CAS操作的数据一致与安全

```java
public class test04 {
    public static void main(String[] args) {
        AtomicInteger atomicInteger=new AtomicInteger(5);
        System.out.println(atomicInteger.compareAndSet(5,2022)+"\t"+atomicInteger.get());
        System.out.println(atomicInteger.compareAndSet(5,2022)+"\t"+atomicInteger.get());
    }
}
```

输出：

```bash
true  2022
false  2022

Process finished with exit code 0
```

compareAndSet 底层实现是使用Unfase的compareAndSwapXXX方法实现的, 而compareAndSwapXXX又是native方法实现的。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/16/1665896038578.png)

上面的`compareAndSwapXXX`是CAS方法。

CAS是JDK提供的非阻塞原子性操作，它通过硬件保证了比较-更新的原子性。它是非阻塞的且自身具有原子性，也就是说这玩意效率更高且通过硬件保证，说明这玩意更可靠。

CAS是一条CPU的原子指令（cmpxchg指令）,不会造成所谓的数据不一致问题，Unsafe提供的

CAS方法（如compareAndSwapXXX)底层实现即为CPU指令cmpxchg。执行cmpxchg指令的时候，会判断当前系统是否为多核系统，如果是就给总线加锁，只有一个线程会对总线加锁成功，加锁成功之后会执行cas操作，也就是说CAS的原子性实际上是CPU实现独占的，比起用synchronized重量级锁，这里的排他时间要短很多，所以在多线程情况下性能会比较好。

> 使用原子类的：原子类内部使用native+volatile+CAS实现的，native+CAS保证了原子性，如保证i++操作原子性，且volatile修饰了要操作的值 `private volatile int value;` 所有能保障其操作的可见性与顺序性。

#### \[\_19.1\_] Unsafe 类

是CAS的核心类，由于Java方法无法直接访问底层系统，需要通过本地（native)方法来访问，Unsafe相当于一个后门，基于该类可以直接操作特定内存的数据。Unsafe类存在于sun.misc包中，其内部方法操作可以像C的指针一样直接操作内存，因为Java中CAS操作的执行依赖于Unsafe类的方法。

**为什么不加锁也能保证操作的原子性呢？**

CAS的全称为Compare-And-Swap,它是一条CPU并发原语。
它的功能是判断内存某个位置的值是否为预期值，如果是则更改为新的值，这个过程是原子的。
Atomiclnteger类主要利用CAS(compare and swap)+volatile和native方法来保证原子操作，从而避免synchronized的高开销，执行效率大为提升。

在前面学volatile时，做过一个案例，使用volatile进行多线程的i++操作，发现1000个线程进行i++，最后i的值是≤1000的，出现了写丢失的情况，这是因为i++不是原子性的，使用CAS我们就可以保证这里的原子性：

> **为什么CAS操作是原子性的？**
>
> CAS并发原语体现在JAVA语言中就是sun.misc.Unsafe类中的各个方法。调用UnSafe类中的CAS方法，JVM会帮我们实现出CAS汇编指令。这是一种完全依赖于硬件的功能，通过它实现了原子操作。再次强调，由于CAS是一种系统原语，原语属于操作系统用语范畴，是由若干条指令组成的，用于完成某个功能的一个过程，并且原语的执行必须是连续的，在执行过程中不犯许被中断，也就是说CAS是一条CPU的原子指令，不会造成所谓的数据不一致问题。
>
> 只需要记住：CAS是靠硬件实现的从而在硬件层面提升效率，最底层还是交给硬件来保证原子性和可见性。实现方式是基于硬件平台的汇编指令，在intel的CPU中（X86机器上）,使用的是汇编指令cmpxchg指令。
> 核心思想就是：比较要更新变量的值V和预期值E(compare),相等才会将V的值设为新值N(swap)如果不相等自旋再来。

也是通过加锁的，不过这种是乐观锁，且失败且进行重试（自旋）。

下面就是CAS操作的源码分析：`getAndAdd` 是`AtomicInteger`的方法，下面的`delta`表示自旋成功后值的改变量。`getAndAdd` 方法参数，`var1` 与`var2`（对象地址在这个内存中的偏移量）就可以确定`旧值`的地址，获取这个`旧值`  `var5` ,进行自旋判断，传入var1与var2在进行改值时判断，如果当时再次得到的`旧值` == `var5` ，那就将`旧值` 改为 `var5`+`var4`(增量 )。

![\` 2022-10-16](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/16/1665907497132.png "` 2022-10-16")

#### \[\_19.2\_] 原子类

原子类，有许多基本类型的，那可能是我们自定义类型的吗？答案是可以的，为我们提供了`AtomicReference` 类，具体使用如下：

```java
class User {
    private int age;
    private String name;

    public User(int age,String name) {
        this.age = age;
        this.name = name;
    }
    @Override
    public String toString() {
        return "User{" +
                "age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
}
public class _原子类AtomicReference {
    public static void main(String[] args) {
        User user1 = new User(22,"张三");
        User user2 = new User(23,"李四");
        AtomicReference<User> userAtomicReference = new AtomicReference<>();
        userAtomicReference.set(user1);
        System.out.println(userAtomicReference.compareAndSet(user1,user2)+"--"+userAtomicReference.get());
        System.out.println(userAtomicReference.compareAndSet(user1,user2)+"--"+userAtomicReference.get());
    }
}
```

执行输出：

```bash
true--User{age=23, name='李四'}
false--User{age=23, name='李四'}

进程已结束,退出代码0
```

#### \[\_19.3\_] 使用CAS实现lock() 与unlock()

```java
public class _手写自旋锁 {
    // 保障可见性与原子性
    private AtomicReference atomicReference =  new AtomicReference<Thread>();
    public void lock() {
        Thread thread = Thread.currentThread();
        while (! atomicReference.compareAndSet(null,thread)) { // 如果被占用，自旋
        }
    }
    public void unlock() {
        Thread thread = Thread.currentThread();
        atomicReference.compareAndSet(thread,null);
        System.out.println(thread.getName()+"exit lock..");
    }

    public static void main(String[] args) throws InterruptedException {
        _手写自旋锁 v = new _手写自旋锁();
        new Thread(()->{
            v.lock();
            System.out.println(Thread.currentThread().getName()+"抢到锁了");
            try { Thread.sleep(4000); } catch (InterruptedException e) { e.printStackTrace(); }
            v.unlock();
        },"t1").start();
        try { Thread.sleep(500); } catch (InterruptedException e) { e.printStackTrace(); }
        new Thread(()->{
            v.lock();
            System.out.println(Thread.currentThread().getName()+"抢到锁了");
            v.unlock();
        },"t2").start();
    }
}
```

#### \[\_19.4\_] CAS的缺点

-   **循环时间长开销很大**

    很简单，CAS用到while，如果一直while，自然开销很大
-   **引出来ABA问题？**

    A线程得到旧值5，想要去修改时，在这个过程中，有另一个线程对值改为了6，然后又改为了5，此时A线程再去修改，发现还是5然后修改成功了，在这个过程中，线程A是没有意识到旧值的改变的，这可能会产生一些问题。

    单线程解决ABA问题
    ```java
    public class 单线程避免ABA问题 {
        public static void main(String[] args) {
            Book book1 = new Book("小庄", "github上传");
            Book book2 = new Book("小庄", "记住阅读进度脚本");
            AtomicStampedReference<Book> asr = new AtomicStampedReference<Book>(book1,1);
            System.out.println(asr.getReference()+"，版本："+asr.getStamp());

            int stamp = asr.getStamp();
            boolean b1 = asr.compareAndSet(book1, book2, stamp, stamp + 1);
            System.out.println(asr.getReference()+"，版本："+asr.getStamp()+"b:"+b1);

            boolean b2 = asr.compareAndSet(book2, book1, stamp, stamp + 1);
            System.out.println(asr.getReference()+"，版本："+asr.getStamp()+"b:"+b2);


        }
    }
    ```
    多线程解决ABA问题
    ```java
    public class 多线程解决ABA问题 {
        static AtomicStampedReference<Integer> stampedReference = new AtomicStampedReference<>(100,1);

        public static void main(String[] args) throws InterruptedException {
            System.out.println("初始化值："+stampedReference.getReference());
            new Thread(()->{
                try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }
                int stamp1 = stampedReference.getStamp();
                System.out.println("1,v="+stamp1+"=> "+stampedReference.compareAndSet(100, 101, stamp1, stamp1 + 1));
                int stamp2 = stampedReference.getStamp();
                System.out.println("2,v="+stamp2+"=> "+stampedReference.compareAndSet(101, 100, stamp2, stamp2 + 1));
            },"t1").start();
            new Thread(()->{
                int stamp1 = stampedReference.getStamp();
                try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
                System.out.println("3,v="+stamp1+"=> "+stampedReference.compareAndSet(100, 102, stamp1, stamp1 + 1));
                System.out.println("最终值："+stampedReference.getReference());
            },"t1").start();
        }
    }

    ```

#### \[\_19.5\_] 原子类：基本类型原子类 & 数组类型原子类

**基本类型原子类**：

Atomiclnteger
AtomicBoolean
AtomicLong

常用API：

public final int get()//获取当前的值
public final int getAndSet(int newValue)//获取当前的值，并设置新的值
public final int getAndlncrement()//获取当前的值，并自增
public final int getAndDecrement()//获取当前的值，并自减
public final int getAndAdd(int delta)//获取当前的值，并加上预期的值
boolean compareAndSet(int expect,int update)//如果输入的数值等于预期值，则以原子方式将该值设置为输入值（update)

*拿 Atomiclnteger 演示：*

```java
public class 原子类与CountDownLatch {
    public static void main(String[] args) throws InterruptedException {
        AtomicInteger atomicInteger = new AtomicInteger(0);
        final Integer SIZE = 100;
        CountDownLatch countDownLatch = new CountDownLatch(SIZE);
        for (int i = 0; i < SIZE; i++) {
            new Thread(()->{
                try {
                    for (int i1 = 0; i1 < 1000; i1++) {
                        atomicInteger.getAndIncrement();
                    }
                }finally {
                    countDownLatch.countDown();
                }
            }).start();
        }
        countDownLatch.await();
//        Thread.sleep(2000);
        System.out.println("结果："+atomicInteger.get());
    }
}
```

**数组原子类**

```java
public class 原子类数组 {
    public static void main(String[] args) {
        AtomicIntegerArray atomicIntegerArray = new AtomicIntegerArray(new int[5]);
        System.out.println( atomicIntegerArray.get(0));
        atomicIntegerArray.getAndIncrement(0); // 指定index的value值自境
        System.out.println(atomicIntegerArray.get(0));
        atomicIntegerArray.getAndSet(0,2022); // 将指定index的value修改
        System.out.println(atomicIntegerArray.get(0));
    }
}
```

#### \[\_19.6\_] 原子类：引用类型原子类

AtomicReference：会出现ABA问题
AtomicStampedReference：解决了ABA问题，表示修改过几次
AtomicMarkableReference：带标记的，表示是否修改过，就玩一次（一次性筷子）

```java
public class 引用类型原子类_带标记的 {
    public static void main(String[] args) {
        // 赋值初始值与初始标志(false)
        AtomicMarkableReference<Integer> integerAtomicMarkableReference = new AtomicMarkableReference<Integer>(1,false);
        // 如果标记为false，且旧值为1那就修改值为2,标志修改为true
        boolean b = integerAtomicMarkableReference.compareAndSet(1, 2, false, true);
        System.out.println(b+","+integerAtomicMarkableReference.getReference()); // 查看值
        System.out.println(integerAtomicMarkableReference.isMarked()); // 查看标记
    }
}
```

#### \[\_19.7\_] 原子类：对象的属性修改原子类

**使用目的**：以一种线程安全的方式操作非线程安全对象的某些字段。

AtomiclntegerFieldUpdater：原子更新对象中int类型字段的值
AtomicLongFieldUpdater：原子更新对象中Long类型字段的值
AtomicReferenceFieldUpdater：原子更新引用类型字段的值

**使用方式**：

要求：

-   要操作的对象字段是 `public volatile`
-   因为对象的属性修改类型原子类都是抽象类，所以每次使用都必须使用

    静态方法newUpdater()创建工个更新器，并且需要设置想要更新的类和属性。

**案例1：**

以前：通过`synchronized` 修饰方法的方式原子性修改对象的某个字段值。

现在：通过使用`AtomicXXXFieldUpdater`的方式线程安全地修改对象的某些字段

```java
class BankAccount {
    // 要操作的对象字段是 public volatile
    public volatile int money = 0;
    // 不安全的方式
    public void add() {
        money++;
    }
    // 安全的方式
    // 因为对象的属性修改类型原子类都是抽象类，所以每次使用都必须使用
    // 静态方法newUpdater()创建工个更新器，并且需要设置想要更新的类和属性。
    AtomicIntegerFieldUpdater fieldUpdater =  AtomicIntegerFieldUpdater.newUpdater(this.getClass(),"money");
    public void transMoney(BankAccount bankAccount,Integer addMoney) {
        fieldUpdater.getAndAdd(bankAccount,addMoney);
    }
    public int get() {
        return money;
    }
}
public class 以原子的方式修改对象的属性 {
    public static void main(String[] args) throws InterruptedException {
        // 以下代码目的：多线程进行 ++ 操作，当所有线程操作完时打印money值

        BankAccount bankAccount = new BankAccount();
        final int SIZE = 100;
        CountDownLatch countDownLatch = new CountDownLatch(SIZE);
        for (int i = 0; i < SIZE; i++) {
            new Thread(()->{
                try {
                    for (int i1 = 0; i1 < 1000; i1++) {
//                        bankAccount.add();
                        bankAccount.transMoney(bankAccount,1);
                    }
                }finally {
                    countDownLatch.countDown();
                }

            }).start();

        }
        countDownLatch.await();
        System.out.println("done,值："+bankAccount.get());

    }


}
```

解析：

![2022-10-18](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/18/1666086416988.png "2022-10-18")

**案例2：**

```java
class MyVar { // 资源类
    public volatile Boolean isInit = false;
    AtomicReferenceFieldUpdater<MyVar,Boolean> referenceFieldUpdater =
            AtomicReferenceFieldUpdater.newUpdater(MyVar.class,Boolean.class,"isInit");
    public void init(MyVar myVar) {
        if (referenceFieldUpdater.compareAndSet(myVar,false,true)) {
            System.out.println(Thread.currentThread().getName()+"获取到了");
        }else {
            System.out.println("已经有线程获取到了");
        }
    }
}

public class 对象的属性修改原子类 {
    public static void main(String[] args) {
        MyVar myVar = new MyVar();
        for (int i = 0; i < 5; i++) {
            new Thread(()->{
                myVar.init(myVar);
            }).start();
        }
    }
}
```

#### \[\_19.8\_] 原子增强类：LongAdder与LongAccumulator&#x20;

JDK1.8新增的

**LongAdder**

一个或多个变量，它们共同维持最初的零`long`总和。 当跨线程争用更新（方法[add(long)](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/LongAdder.html#add\(long\) "add(long)") ）时，变量集可以动态增长以减少争用。 方法[sum()](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/LongAdder.html#sum\(\) "sum()") （或等效地， [longValue()](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/LongAdder.html#longValue\(\) "longValue()") ）返回保持总和的变量的当前总和。

当多个线程更新用于收集统计信息但不用于细粒度同步控制的目的的公共和时，此类通常优于[AtomicLong](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/AtomicLong.html "AtomicLong") (减少乐观锁重试次数)。 在低更新争用下，这两个类具有相似的特征。 但在高争用的情况下，这一类的预期吞吐量明显更高，但代价是空间消耗更高。

**Accumulator**

使用提供的函数一起维护运行的`long`值的一个或多个变量。 当跨线程争用更新（方法[accumulate(long)](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/LongAccumulator.html#accumulate\(long\) "accumulate(long)") ）时，变量集可以动态增长以减少争用。 方法[get()](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/LongAccumulator.html#get\(\) "get()") （或等效地， [longValue()](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/LongAccumulator.html#longValue\(\) "longValue()") ）返回维护更新的变量的当前值。

当多个线程更新用于收集统计信息但不用于细粒度同步控制的目的的公共值时，此类通常优于[AtomicLong](https://www.runoob.com/manual/jdk11api/java.base/java/util/concurrent/atomic/AtomicLong.html "AtomicLong") 。 在低更新争用下，这两个类具有相似的特征。 但在高争用的情况下，这一类的预期吞吐量明显更高，但代价是空间消耗更高。

```java
public class LongAdder与LongAccumulator {
    public static void main(String[] args) {
        LongAdder longAdder = new LongAdder();

        longAdder.increment();
        longAdder.increment();
        longAdder.increment();

        System.out.println(longAdder.sum());

        LongAccumulator longAccumulator = new LongAccumulator((x, y) -> x + y, 0);
        // 此时x=0 y=1
        longAccumulator.accumulate(1);
        // 此时x=1 y=2
        longAccumulator.accumulate(2);
        System.out.println(longAccumulator.get());
    }
}
```

#### \[\_19.9\_] 原子增强类：高性能点赞案例

> JMM中关于synchronized有如下规定，线程加锁时，必须清空工作内存中共享变量的值，从而使用共享变量时需要从主内存重新读取；线程在解锁时，需要把工作内存中最新的共享变量的值写入到主存，以此来保证共享变量的可见性。(ps这里是个泛指，不是说只有在退出synchronized时才同步变量到主存)

```java
package com.zhuangjie.demo;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAccumulator;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Consumer;

public class _高性能的点赞器 {
    int number = 0;

    public synchronized void clickBySynchronized() {
        number++;
    }

    AtomicLong atomicLong = new AtomicLong(0);

    public void clickByAtomicLong() {
        atomicLong.getAndIncrement();
    }

    LongAdder longAdder = new LongAdder();

    public void clickByLongAdder() {
        longAdder.increment();
    }

    LongAccumulator longAccumulator = new LongAccumulator((x, y) -> x + y, 0);

    public void clickByLongAccumulator() {
        longAccumulator.accumulate(1);
    }

}

class Test {
    public static void main(String[] args) throws InterruptedException {
        final int THREAD_SIZE = 50;
        final long A_COUNT = 1000000;
        Test.clickBySynchronizedTest(THREAD_SIZE, A_COUNT, obj -> {
            obj.clickBySynchronized();
        }, objects -> {
            Long begin = (Long) objects[0];
            Long end = (Long) objects[1];
            _高性能的点赞器 c = (_高性能的点赞器) objects[2];
            System.out.println("耗时："+(end-begin)+",普通方式，最终值："+c.number);
        });

        Test.clickBySynchronizedTest(THREAD_SIZE, A_COUNT, obj -> {
            obj.clickByAtomicLong();
        }, objects -> {
            Long begin = (Long) objects[0];
            Long end = (Long) objects[1];
            _高性能的点赞器 c = (_高性能的点赞器) objects[2];
            System.out.println("耗时："+(end-begin)+",Atomic方式，最终值："+c.atomicLong.get());
        });

        Test.clickBySynchronizedTest(THREAD_SIZE, A_COUNT, obj -> {
            obj.clickByLongAdder();
        }, objects -> {
            Long begin = (Long) objects[0];
            Long end = (Long) objects[1];
            _高性能的点赞器 c = (_高性能的点赞器) objects[2];
            System.out.println("耗时："+(end-begin)+",Adder方式，最终值："+c.longAdder.sum());
        });
        Test.clickBySynchronizedTest(THREAD_SIZE, A_COUNT, obj -> {
            obj.clickByLongAccumulator();
        }, objects -> {
            Long begin = (Long) objects[0];
            Long end = (Long) objects[1];
            _高性能的点赞器 c = (_高性能的点赞器) objects[2];
            System.out.println("耗时："+(end-begin)+",Accumulator方式，最终值："+c.longAccumulator.get());
        });
    }

    public static void clickBySynchronizedTest(int threadNumber, long clickCount, Consumer<_高性能的点赞器> consumer, Consumer<Object[]> result) throws InterruptedException {
        _高性能的点赞器 c = new _高性能的点赞器();
        CountDownLatch countDownLatch = new CountDownLatch(threadNumber);
        long begin = System.currentTimeMillis();
        for (int i = 0; i < threadNumber; i++) {

            new Thread(() -> {
                try {
                    for (int i1 = 0; i1 < clickCount; i1++) {
                        consumer.accept(c);
                    }
                } finally {
                    countDownLatch.countDown();
                }
            }).start();

        }
        countDownLatch.await();
        long end = System.currentTimeMillis();
        result.accept(new Object[]{begin,end,c});
    }
}


```

输出：

```json
耗时：1364,普通方式，最终值：50000000
耗时：835,Atomic方式，最终值：50000000
耗时：97,Adder方式，最终值：50000000
耗时：94,Accumulator方式，最终值：50000000

Process finished with exit code 0
```

#### \[\_19.10\_] 原子增强类：为什么LongAdder这么快？

`AtomicLong`是只有一个窗口进行`CAS`，那太慢了，如果有很多线程进来，就只有一个线程在操作，其它线程都得自旋着。

`LongAdder`扩展了窗口，`cells`数组元素都是一个窗口，`base`是最初的那个窗口，如下图`base`与`cells`数组都定义在`LongAdder`的父类中：

![2022-10-19](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/19/1666180149124.png "2022-10-19")

当我们调用`sum`方法时，就会统计各个窗口的值,也就是`base`与`cells`数组的value求和作为返回值 。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/19/1666179671841.png)

这也解释了为什么`LongAddr`比`AtomicLong`快了。

#### \[\_19.11\_] 原子增强类：LongAdder源码分析

1.最初无竞争时只更新base;
2.如果更新base失败后，首次新建一个Cell]数组
3.当多个线程竞争同一个Cell比较激烈时，可能就要对Cells\[] 进行扩容

核心方法：add

```java
    /*
    as 是striped64中的cells数组属性
    b 是striped64中的base属性
    v 是当前线程hash到的cell中存储的值
    m 是cells的长度减1,hash时作为掩码使用
    a 是当前线程hash到的cell
    */
    public void add(long x) {
        Cell[] as; long b, v; int m; Cell a;
        // 如果子窗口不为空，或者使用base窗口进行cas失败，就会进入if体
        if ((as = cells) != null || !casBase(b = base, b + x)) {
            // 刚进来，为true，表示不拥挤
            boolean uncontended = true;
            // 如果子窗口数组为null（ 或 数组长度小于0） 或者 要操作的窗口为null(还没人来上班)
            // 再或者要操作的窗口不为null，且cas失败时 就会进行下面的if体
            if (as == null || (m = as.length - 1) < 0 ||
                (a = as[getProbe() & m]) == null ||
                !(uncontended = a.cas(v = a.value, v + x)))
                // 根据分析if条件，可以知道这里主要负责窗口的初始化与窗口的扩容
                longAccumulate(x, null, uncontended);
        }
    }
```

核心方法：

![2022-10-19](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/19/1666188420499.png "2022-10-19")

```java
    /*
      下面代码的主要结构最外层有一个for(;;)，里面有两个嵌套的if
       由上面第一个方法add的源码可知，调用这个方法（longAccumulate）的，主要有三种情况：
       1、第一种窗口还没有的(cells = null)，此时的是wasUncontended = true
         在第一个if中第二个case满足条件，
         -> else if (cellsBusy == 0 && cells == as && casCellsBusy()) {
         判断是否有人在修改cells， 在cells没有被修改过（为null），如果都满足修改 "cellsBusy"为1 （表示有人在操作cells）
         进入上面说的case体后，再次判断cells == as ，然后初始化cells，将本次线程要操作的值放在 rs[h & 1] 上，然后break退出for，从而结束
       2、第二种：窗口（要cas的cells数据元素）初始化了，但该窗口还没有人上班（为null，还没有Cell）
         会进入第二个if的直接if体中（不是下面的case） 
         如果没有在操作cells （cellsBusy为0），那我就new 一个工作人员（Cell）,然后再判断现在还有没有人在操作cells，如果没有
         就cas cellsBusy为1（获取操作cells的锁）,获取到后，再次判断此窗口是不是还没有人（Cell）,如果是就将刚才new的Cell放在那个位置（此时放入的Cell的值已经是要放
         入的值了，此次add任务完成，就可以break退出了）
         
       3、第三种：cas失败， cells != null 要cas的窗口也有工作人员了，wasUncontended 为 false
         进入第二个if的第二个case中，目的是将 wasUncontended 改为true
         再会次进入第二个if但第三个case中，再次尝试cas，如果成功就退出，如果失败，
           接着去本次if下个case 来判断 cells的长度是否 >= NCPU（为falsse会进入下面的本次if下面的case，最终进行扩容）,会一直在cas。
       
    */
    final void longAccumulate(long x, LongBinaryOperator fn,
                              boolean wasUncontended) {
        // 如果线程的hash为0进行强制初始化
                              
        int h;
        if ((h = getProbe()) == 0) {
            ThreadLocalRandom.current(); // force initialization
            h = getProbe();
            wasUncontended = true;
        }
        boolean collide = false;                // True if last slot nonempty
        for (;;) {
            Cell[] as; Cell a; int n; long v;
            if ((as = cells) != null && (n = as.length) > 0) {
                if ((a = as[(n - 1) & h]) == null) {
                    if (cellsBusy == 0) {       // Try to attach new Cell
                        Cell r = new Cell(x);   // Optimistically create
                        if (cellsBusy == 0 && casCellsBusy()) {
                            boolean created = false;
                            try {               // Recheck under lock
                                Cell[] rs; int m, j;
                                if ((rs = cells) != null &&
                                    (m = rs.length) > 0 &&
                                    rs[j = (m - 1) & h] == null) {
                                    rs[j] = r;
                                    created = true;
                                }
                            } finally {
                                cellsBusy = 0;
                            }
                            if (created)
                                break;
                            continue;           // Slot is now non-empty
                        }
                    }
                    collide = false;
                }
                else if (!wasUncontended)       // CAS already known to fail
                    wasUncontended = true;      // Continue after rehash
                else if (a.cas(v = a.value, ((fn == null) ? v + x :
                                             fn.applyAsLong(v, x))))
                    break;
                else if (n >= NCPU || cells != as)
                    collide = false;            // At max size or stale
                else if (!collide)
                    collide = true;
                else if (cellsBusy == 0 && casCellsBusy()) {
                    try {
                        if (cells == as) {      // Expand table unless stale
                            Cell[] rs = new Cell[n << 1];
                            for (int i = 0; i < n; ++i)
                                rs[i] = as[i];
                            cells = rs;
                        }
                    } finally {
                        cellsBusy = 0;
                    }
                    collide = false;
                    continue;                   // Retry with expanded table
                }
                h = advanceProbe(h);
            }
            else if (cellsBusy == 0 && cells == as && casCellsBusy()) {
                boolean init = false;
                try {                           // Initialize table
                    if (cells == as) {
                        Cell[] rs = new Cell[2];
                        rs[h & 1] = new Cell(x);
                        cells = rs;
                        init = true;
                    }
                } finally {
                    cellsBusy = 0;
                }
                if (init)
                    break;
            }
            else if (casBase(v = base, ((fn == null) ? v + x :
                                        fn.applyAsLong(v, x))))
                break;                          // Fall back on using base
        }
    }
```

#### \[\_19.12\_] 原子增强类：AtomicLong与LongAdder区别

通过查看源码，知道了为什么LongAdder为什么比AtomicLong更快，除此我们还需要知道：

AtomicLong：保证精度，性能代价

使用场景：低并发下的全局计算，能保证并发下的准确性，高并发下性能急剧下降。

LongAdder：保证性能（分散热点数据），精度代价（最终一致性）

使用场景：高并发下的全局计算，精度要求不高下使用（最终一致性）。

### \[\_20\_] ThreadLocal

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666343387337.png)

将上面的人比拟为线程，血槽比拟为ThreadLocal变量，当一个人中枪了，就那一个人中枪，其它人血槽并不会少。

ThreadLocal并不解决线程间共享数据的问题。ThreadLocal （ThreadLocal 存储的数据是放在线程实例中的）适用于变量在线程间隔离且在方法间共享的场景。

![2022-10-20](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/20/1666234498924.png "2022-10-20")

出现前，多个线程进行操作共享资源，虽然也能达到一致性，但这样会影响性能。

出现后，各操作操作自己的那一份，避免了线程安全问题，提高性能。

代码演示：

表示销售人员卖房子

第一种（注释部分）：使用旧方式，每个人（线程）进行卖房子，得到全部的人卖的房子和。

第二种：使用ThreadLocal，得到每个人卖的房子数（分灶吃饭）

```java
class House {
    int saleCount = 0;
    public synchronized void saleHouse(int number) {
        saleCount+=number;
    }
    ThreadLocal<Integer> saleVolume = ThreadLocal.withInitial (()->0);
    public void saleHouseByThreadLocal(int number) {
        saleVolume.set(saleVolume.get()+number);
    }

}
public class _ThreadLocal房销售 {
    public static void main(String[] args) throws InterruptedException {
//        CountDownLatch countDownLatch = new CountDownLatch(10);
//        House house = new House();
//        for (int i = 0; i < 10; i++) {
//            new Thread(()->{
//                try {
//                    int sum = 0;
//                    for (int i1 = 0; i1 < 10; i1++) {
//                        int max = 5;
//                        int min = 2;
//                        int saleNumber = (int)(Math.random()*(max+1-min))+min;
//                        house.saleHouse(saleNumber);
//                        sum += saleNumber;
//                    }
//                    System.out.println("线程"+Thread.currentThread().getName()+"销售出了"+sum);
//                }finally {
//                    countDownLatch.countDown();
//                }
//            },""+i).start();
//        }
//        countDownLatch.await();
//        System.out.println("总销售："+house.saleCount);


        CountDownLatch countDownLatch = new CountDownLatch(10);
        House house = new House();
        for (int i = 0; i < 10; i++) {
            new Thread(()->{
                try {
                    for (int i1 = 0; i1 < 10; i1++) {
                        int max = 5;
                        int min = 2;
                        int saleNumber = (int)(Math.random()*(max+1-min))+min;
                        house.saleHouseByThreadLocal(saleNumber);
                    }
                    System.out.println("线程"+Thread.currentThread().getName()+"销售出了"+house.saleVolume.get());
                }finally {
                    countDownLatch.countDown();
                }
            },""+i).start();
        }

    }
}


```

#### \[\_20.1\_] ThreadLocal可能会造成的问题

ThreadLocal表示线程的局部变量，不共享的，每个线程都有一份（数据存到Thread的threadLocals 成员变量中），至少是什么变量由创建ThreadLocal时写的泛型决定。

-   为什么ThreadLocal会造成内存的泄露呢？

    答：在线程池下，由于线程的复用，在线程切换为其它业务逻辑时（复用），原来存的值还没删除，但线程又销毁，就会导致内存泄露，还会影响后续的业务逻辑。

> 在阿里规范中【强制】：必须回收自定义的ThreadLocal变量，尤其在线程池场景下，线程经常会被利用，如果不清理自定义的ThreadLocal变量，可能会影响后续业务逻辑和造成内存泄露等问题，尽量在代理中使用try-finally块进行回收。

![2022-10-20](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/20/1666240567416.png "2022-10-20")

#### \[\_20.2\_] ThreadLocal的源码分析

这里涉及到三个类: `Thread` 、`ThreadLocal` 、`ThreadLocalMap`

ThreadLocalMap 是ThreadLocal的静态内部类，而Thread类中聚合着ThreadLocalMap存储着线程的局部变量，它是一个Map,  key是Thread操作的ThreadLocal实例，value是实际存储的值，如Integer，String。而`ThreadLocal` 就像操作当前线程的 ThreadLocalMap的客户端，提供操作线程局部变量的get,set方法。

ThreadLocalMap 是ThreadLocal的静态内部类：

![2022-10-20](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/20/1666254540517.png "2022-10-20")

Thread聚合着ThreadLocalMap:

![2022-10-20](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/20/1666254663067.png "2022-10-20")

ThreadLocal的get方法：

```java
    public T get() {
        Thread t = Thread.currentThread();
        // 根据当前线程获取线程中存储的map
        ThreadLocalMap map = getMap(t);
        if (map != null) {
            // 如果map不为null，根据当前ThreadLocal实例获取存储的值
            ThreadLocalMap.Entry e = map.getEntry(this);
            if (e != null) {
                @SuppressWarnings("unchecked")
                T result = (T)e.value;
                return result;
            }
        }
        // 走到这有两种情况，第一种map为空或map没有该元素（可能调用了remove方法）
        // 上面两种情况都会调用下面的方法，创建一个在创建ThreadLocal实例前指定的初始化值存入为元素，然后返回该元素的value值。
        return setInitialValue();
    }
```

ThreadLocal的set方法：

```java
    // 以key为this，value为要设置的值存放Thread聚合的ThreadLocalMap实例中
    public void set(T value) {
        Thread t = Thread.currentThread();
        ThreadLocalMap map = getMap(t);
        if (map != null)
            map.set(this, value);
        else
            createMap(t, value);
    }
```

#### \[\_20.3\_] 为什么ThreadLocal是弱引用

> 引用有强、软、弱、虚？
>
> **强引用：**
>
> 当内存不足，JVM开始垃圾回收，对于强引用的对象，就算是出现了OOM也不会对该对象进行回收，死都不收。强引用是我们最常见的普通对象引用，只要还有强引用指向一个对象，就能表明对象还“活着”，垃圾收集器不会碰这种对象。在Java中最常见的就是强引用，把一个对象赋给一个引用变量，这个引用变量就是一个强引用。当一个对象被强引用变量引用时，它处于可达状态，它是不可能被垃圾回收机制回收的，即使该对象以后永远都不会被用到，JVM也不会回收。因此强引用是造成Java内存泄漏的主要原因之一。对于一个普通的对象，如果没有其他的引用关系，只要超过了引用的作用域或者显式地将相应（强）引用赋值为null,一般认为就是可以被垃圾收集的了（当然具体回收时机还是要看垃圾收集策略）。
>
> 只有手动将对象赋值为null，对象才能被GC回收，也就是“特意提醒”JVM这块资源可以进行垃圾回收了。
>
> **软引用：** 当内存充足时，System.gc() 也不会回收，当内存不足时，不用手动触发也会进行回收。
>
> ```java
> // 设置虚拟机参数，方便进行测试：-Xms10m -Xmx10m
> public class Java_软引用示例 {
>     public static void main(String[] args) {
>     
>         // 注意这里不要将软引用对象单独这里：Object obj = new Object() ，然后再放在SoftReference，这就是强引用了
>         SoftReference<Object> sr = new SoftReference<>(new Object());
>         System.gc();
>         try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }
>         System.out.println("内存充足，对象："+sr.get());
>
>         try {
>             Byte[] bs = new Byte[20*1024*1024];
>         }catch (Throwable e) {
>             System.out.println(e.getMessage());
>         }
>         System.gc();
>         try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }
>         System.out.println("内存不充足，对象："+sr.get());
>     }
> }
> ```
>
> 输出：
>
> ```java
> 内存充足，对象：java.lang.Object@74a14482
> Java heap space
> 内存不充足，对象：null
>
> 进程已结束,退出代码0
>
> ```
>
> ***应用场景：***
>
> 假如有一个应用需要读取大量的本地图片：
> 如果每次读取图片都从硬盘读取则会严重影响性能，
> 如果一次性全部加载到内存中又可能造成内存溢出。
> 此时使用软引用可以解决这个问题。
> 设计思路：用一个HashMap来保存图片的路径和相应图片对象关联的软引用之间的映射关系，在内存不足时，JVM会自动回收这些缓存图片对象所占用的空间，从而有效地避免了OOM的问题。
> Map\<String, SoftReference\<Bitmap>> imageCache = new HashMap\<String, SoftReference\<Bitmap>>();
>
> **弱引用：** 不管内存是否充足，GC时都会回收。
>
> ```java
> // 这里不用设置虚拟机参数
> public class Java_弱引用示例 {
>     public static void main(String[] args) {
>         // 注意这里不要将软引用对象单独这里：Object obj = new Object() ，然后再放在WeakReference，这就是强引用了
>         WeakReference<Object> weakReference = new WeakReference<Object>(new Object());
>         System.out.println(weakReference.get());
>         System.gc();
>         System.out.println(weakReference.get());
>     }
> }
>
> ```
>
> 输出：
>
> ```bash
> java.lang.Object@74a14482
> null
>
> 进程已结束,退出代码0
> ```
>
> **虚引用（幻影引用）：**
>
> 特点之一：无法通过虚引用来获取对一个对象的真实引用。
>
> 特点之二：就是 虚引用必须与ReferenceQueue一起使用
>
> ```java
> // 设置虚拟机参数，方便进行测试：-Xms10m -Xmx10m
> public class Java_虚引用示例 {
>     public static void main(String[] args) {
>         Object obj = new Object();
>         ReferenceQueue<Object> referenceQueue = new ReferenceQueue<>();
>         PhantomReference<Object> phantomReference = new PhantomReference<>(obj, referenceQueue);
>
>         ArrayList<byte[]> list = new ArrayList<>();
>         new Thread(()->{
>             while (true) {
>                 list.add(new byte[1 * 1024 * 1024]);
>                 try { TimeUnit.MILLISECONDS.sleep(500); } catch (InterruptedException e) { e.printStackTrace(); }
>                 System.out.println(phantomReference.get()+",add ok!");
>             }
>         },"t1").start();
>         new Thread(()->{
>             while (true) {
>                 Reference<?> item = referenceQueue.poll();
>                 if (item != null) {
>                     System.out.println("---有虚对象加入了队列"+item);
>                     break;
>                 }
>             }
>         },"t2").start();
>     }
> }
>
>
> ```
>
> 输出：
>
> ```bash
> null,add ok!
> ---有虚对象加入了队列java.lang.ref.PhantomReference@3354d998
> null,add ok!
> null,add ok!
> null,add ok!
> null,add ok!
> null,add ok!
> null,add ok!
> Exception in thread "t1" java.lang.OutOfMemoryError: Java heap space
>   at com.zhuangjie.demo.Java_虚引用示例.lambda$main$0(Java_虚引用示例.java:20)
>   at com.zhuangjie.demo.Java_虚引用示例$$Lambda$1/1078694789.run(Unknown Source)
>   at java.lang.Thread.run(Thread.java:748)
>
> 进程已结束,退出代码0
> ```
>
> ![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666337784835.png "2022-10-21")

回收正题：为什么ThreadLocal在ThreadLocalMap弱引用于entry中的key？

![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666339790788.png "2022-10-21")

如果我们不使用弱引用，在方法调用完后（栈帧弹出），ThreadLocal对象还是会存留于Thread的ThreadLocalMap中，但这在后面又是用不到的，如果是Entry强引用于k （ThreadLocal对象），就会导致内存泄露。那有了弱引用就能100%保证不造成内存泄露了吗？那肯定不是，请继续看

弱引用使ThreadLocalMap中有key为null的Entry,就没有办法访问这些key为null的Entry的
value,如果当前线程再迟迟不结束的话（比如正好用在线程池）,这些key为null的Entry的value就会一直存在一条强引用链。虽然调用get、set时发现key为null时就会去回收整个entry、value,因此弱引用不能100%保证内存不泄露。我们要在不使用某个ThreadLocal对象后，手动调用remoev方法来删除它，

其是在线程池中，不仅仅是内存泄露的问题，因为线程池中的线程是重复使用的，意味着这个线程的ThreadLocalMap对象也是重复使用的，如果
我们不手动调用remove方法，那么后面的线程就有可能获取到上个线程遗留下来的value值，造成bug。

那接下来我们就来讲一下，set、get方法会去检查所有键为null的Entry对象。

首先我们需要知道，当调用“expungeStaleEntry”方法时，就表示去清理线程的ThreadLocalMap聚合对象key为null的Entry。

**set方法：**

![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666342992567.png "2022-10-21")

**get方法：**

![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666342290180.png "2022-10-21")

**remove方法:**

![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666342439743.png "2022-10-21")

从前面的set,getEntry,remove方法看出，在threadLocal的生命周期里，针对threadLocal存在的内存泄漏的问题都会通过`expungeStaleEntry`这个方法清理掉key为nul的脏entry。

### \[\_21\_] 对象的内存布局

> **阿里的面试题：**
>
> Object object=new Object() 谈谈你对这句话的理解？
> 一般而言JDK8按照默认情况下，new一个对象占多少内存空间
> 对象在堆内存中布局
> 再说对象头的MarkWord
> 聊聊Object obj=new Object()

**位置所在？**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/22/1666426615362.png)

**对象在堆中构成布局？**

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/22/1666427625828.png)

对象头：如果是普通对象只有两部分，即`markWork`和`类型指针`,如果是数组对象，会另加一个`length`，length就是数组的长度，

mark work 是主要内容，占用8个字节（64位），存储的分别是：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/22/1666429294793.png)

锁升级后`mark word`的变化：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/22/1666431942794.png)

类型指针（指向它的类元数据的指针）：存储的是方法区中的类元地址。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/22/1666430273452.png)

实例数据：当我们声明了一个成员变量，保存在实例数据中。

对齐填充：我们知道一个对象有对象头，实例数据与对齐填充，那好对象头`16`个字节（`mark work` = `8`个字节 ，`类型指针`  `8`个字节（忽略压缩指针）），如果声明了一个成员变量 `boolean` b ，那好实例数据占用`1` 字节，总共16+1 = `17`个字节，由于`17`不是`8`的倍数，那这个对象占用`24`个字节，余下的`7`个字节由`对齐填充`占位。

> **使用JOL验证Java 对象布局**，回答new 一个对象占用多少。
>
> **JOL** (Java Object Layout) is the tiny toolbox to analyze object layout schemes in JVMs. These tools are using Unsafe, JVMTI, and Serviceability Agent (SA) heavily to decoder the *actual* object layout, footprint, and references. This makes JOL much more accurate than other tools relying on heap dumps, specification assumptions, etc.
>
> 官网：[https://openjdk.org/projects/code-tools/jol/](https://openjdk.org/projects/code-tools/jol/ "https://openjdk.org/projects/code-tools/jol/")
>
> maven依赖：
>
> ```xml
> <dependency>
>     <groupId>org.openjdk.jol</groupId>
>     <artifactId>jol-core</artifactId>
>     <version>0.9</version>
> </dependency>
> ```
>
> 1、基本信息输出：
>
> ```java
> public class 通过JOL查看java对象布局 {
>     public static void main(String[] args) {
>         System.out.println(VM.current().details());
>     }
> }
> ```
>
> 输出：
>
> ```bash
> # Running 64-bit HotSpot VM.   64位的Java虚拟机
> # Using compressed oop with 0-bit shift.
> # Using compressed klass with 3-bit shift.  
> # Objects are 8 bytes aligned.   对齐倍数是8
> # Field sizes by type: 4, 1, 1, 2, 2, 4, 4, 8, 8 [bytes]
> # Array element sizes: 4, 1, 1, 2, 2, 4, 4, 8, 8 [bytes]
> ```
>
> 2、Java对象大小验证
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/22/1666434653732.png)
>
> 如果没有那实例数据，对象的大小是8+4（类型指针）=`12`个字节，加上int与boolean后是12+4+1=`17`个字节，然后不是8的倍数，所以对齐填充是`24`-17=7个字节。

> **分代年龄最大是15**
>
> 我们知道存储在对象头的对象分代年龄占`4`位 2^4=16,有16种变化，设置虚拟机参数`-XX:MaxTenuringThreshold=16` 然后运行java程序，就会报错，最大是`15`。
>
> ```bash
> Error: Could not create the Java Virtual Machine.
> Error: A fatal exception has occurred. Program will exit.
> MaxTenuringThreshold of 16 is invalid; must be between 0 and 15
>
> 进程已结束,退出代码1
> ```

> **使用压缩指针前后区别**
>
> 1、使用压缩指针(默认)`-XX:+UseCompressedClassPointers` &#x20;
>
> 对象头占用12个字节 + 对齐补充 4个字节 = 16个字节
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666491159090.png)
>
> 2、不使用压缩指针：`-XX:-UseCompressedClassPointers` &#x20;
>
> 可以看出，16个字节全被对象头占用了
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666491046967.png)

### \[\_22\_] synchronized锁升级

**锁升级：** 无锁-偏向锁-轻量锁-重量锁。

锁升级中锁对象的MarkWord的变化：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666492030673.png)

为什么要进行锁升级？Java6之前，只有两种状态`无锁`与`重量级锁`, 重量级锁要进行线程间的切换，这是非常消耗资源的。

重量级锁，效率低下，因为监视器锁（monitor)是依赖层的操作系统的Mutex Lock(系统互斥量）来实现的，挂起线程和恢复线程都需要转入内核态去完成（进行系统执行，那就要进行用户态和内核态之间的切换）。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666492791611.png)

**为什么每一个对象都可以成为一个锁？**

1.  首先，Java中的每个对象都派生自[Object类](https://so.csdn.net/so/search?q=Object类\&spm=1001.2101.3001.7020 "Object类")，而每个Java Object在JVM内部都有一个native的C++对象 oop/oopDesc进行对应。
2.  线程在获取锁的时候，实际上就是获得一个监视器对象(monitor) ,monitor可以认为是一个同步对象，所有的Java对象是天生携带monitor。在hotspot[源码](https://so.csdn.net/so/search?q=源码\&spm=1001.2101.3001.7020 "源码")的 markOop.hpp文件中，可以看到下面这段代码。

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666495011889.png)

    多个线程访问同步代码块时，相当于去争抢对象监视器修改对象中的锁标识,上面的代码中ObjectMonitor这个对象和线程争抢锁的逻辑有密切的关系&#x20;

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666494627662.png)

Java6之后，为了减少获得锁和释放锁所带来的性能消耗，引入了轻量级锁和偏向锁需要有个逐步升级的过程，别一开始就捕到重量级锁。

#### \[\_22.1\_] 无锁

```java
public class 无锁状态说明 {
    public static void main(String[] args) {
        Object o = new Object();
        System.out.println("十进制hash码："+o.hashCode());
        System.out.println("十六进制hash码："+Integer.toHexString(o.hashCode()));
        System.out.println("二进制hash码："+Integer.toBinaryString(o.hashCode()));
        System.out.println(ClassLayout.parseInstance(o).toPrintable());
    }
}
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666497287534.png)

查看是否默认开启偏向锁，几秒生效

```bash
$ java -XX:+PrintFlagsInitial | grep BiasedLock*
     intx BiasedLockingBulkRebiasThreshold          = 20                                  {product}
     intx BiasedLockingBulkRevokeThreshold          = 40                                  {product}
     intx BiasedLockingDecayTime                    = 25000                               {product}
     intx BiasedLockingStartupDelay                 = 4000    # 4s后生效，之前都是直接轻量锁                          {product}
     bool TraceBiasedLocking                        = false                               {product}
     bool UseBiasedLocking                          = true     # 默认开启偏向锁                           {product}

```

如果让它直接生效，不用等4s？

`-XX:BiasedLockingStartupDelay=0`

**实验一：验证4s后开启偏向锁**（一直执行，观察执行4s的锁）

```java
class Ticket {
    private int number = 50;
    private Object lockObject = new Object();
    public void sale() {
        synchronized (lockObject) {
            if (number > 0) {
                System.out.println(Thread.currentThread().getName()+"卖出第：\t"+(number--)+"\t还剩下："+number);
                System.out.println(ClassLayout.parseInstance(lockObject).toPrintable());
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

public class synchrnized与偏向锁 {
    public static void main(String[] args) throws InterruptedException {


        Ticket ticket = new Ticket();
        new Thread(()->{
            for (int i = 0; i < 50; i++) {
                ticket.sale();
            }
        },"a").start();
        try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }
        System.out.println("==线程竞争==");
        new Thread(()->{
            for (int i = 0; i < 50; i++) {
                ticket.sale();
            }
        },"b").start();

    }
}
```

发现：5000之前执行的也都是轻量锁，发现并没有转到偏向锁，而是后面有竞争后，直接变为重量锁。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/24/1666619096197.png)

睡眠4s以上后，开始执行线程。

```java
class Ticket {
    private int number = 50;
    private Object lockObject = new Object();
    public void sale() {
        synchronized (lockObject) {
            if (number > 0) {
                System.out.println(Thread.currentThread().getName()+"卖出第：\t"+(number--)+"\t还剩下："+number);
                System.out.println(ClassLayout.parseInstance(lockObject).toPrintable());
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}

public class synchrnized与偏向锁 {
    public static void main(String[] args) throws InterruptedException {

        try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }
        Ticket ticket = new Ticket();
        new Thread(()->{
            for (int i = 0; i < 50; i++) {
                ticket.sale();
            }
        },"a").start();
        try { Thread.sleep(4000); } catch (InterruptedException e) { e.printStackTrace(); }
        System.out.println("==线程竞争==");
        new Thread(()->{
            for (int i = 0; i < 3; i++) {
                ticket.sale();
            }
        },"b").start();

    }
}
```

发现由偏向锁过渡到了重量锁

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/24/1666620114663.png)

#### \[\_22.2\_] 锁升级（锁膨胀）

> **了解synchronized的升级的基本知识**
>
> **用户态和内核态**
>
> 上面提到了，重量级锁获取锁和释放锁需要经过操作系统，这是一个重量级操作，这句话是什么意思呢？
>
> -   内核态：其实从本质上说就是我们所说的内核，它是一种**特殊的软件程序**，特殊在哪儿呢？**控制计算机的硬件资源，例如协调CPU资源，分配内存资源，并且提供稳定的环境供应用程序运行**。
> -   用户态：用户态就是提供应用程序运行的空间，为了使应用程序访问到内核管理的资源例如CPU，内存，I/O。内核必须提供一组通用的访问接口，这些接口就叫**系统调用。**
>
> **用户态到内核态的切换**
>
> 用户程序都是运行在用户态的，但是有时候程序确实需要做一些内核的事情，例如从硬盘读取数据，或者从硬盘获取输入，而唯一可以做这些事情的就是操作系统即内核态（synchronized中依赖的monitor也需要依赖操作系统完成，因此需要用户态到内核态的切换）所以程序就需要先向操作系统请求以程序的名义来执行这些操作。
>
> 这时候就需要：将用户态程序切换到内核态，**但是不能控制在内核态中执行的命令** 这部分先不做太多解释，需要知道的是synchronized是依赖操作系统实现的，因此在使用synchronized同步锁的时候需要进行用户态到内核态的切换。
>
> **synchronized 内核态切换**
>
> 简单来说在JVM中synchronized重量级锁的底层原理monitorenter和monitorexit字节码依赖于底层的操作系统的Mutex Lock来实现的，但是由于使用Mutex Lock需要将当前线程挂起并从用户态切换到内核态来执行，这种切换的代价是非常昂贵的。
>
> \*\*为什么优化synchronized \*\*
>
> 在JDK1.5之前，synchronized是重量级锁，1.6以后对其进行了优化，有了一个 **无锁-->偏向锁-->自旋锁-->重量级锁** 的锁升级的过程，而不是一上来就是重量级锁了，为什么呢？因为重量级锁获取锁和释放锁需要经过操作系统，是一个重量级的操作。对于重量锁来说，一旦线程获取失败，就要陷入阻塞状态，并且是操作系统层面的阻塞，这个过程涉及用户态到核心态的切换，是一个开销非常大的操作。而研究表明，线程持有锁的时间是比较短暂的，也就是说，当前线程即使现在获取锁失败，但可能很快地将来就能够获取到锁，这种情况下将线程挂起是很不划算的行为。所以要对"synchronized总是启用重量级锁"这个机制进行优化。

> **锁升级**
>
> 偏向锁：一个线程执行的场景
>
> 轻量锁：竞争比较少的情况，两个线程几乎交替执行的情况
>
> 重量级锁：当CAS执行超过10次仍失败时，就会升级为重量级锁
>
> **锁升级过程（陈述）：**
>
> 在 JDK 1.6 之前直到重量锁的，1.6及后面引入了偏向锁与轻量锁。
>
> 最开始是无锁的状态，当有一个线程过来时，看到是无锁（001）时就会在Mark Work中存储线程 ID，然后线程执行同步代码，它就是偏向线程，此时偏向线程执行完同步代码块，执行完后不会主动释放偏向锁，再次执行同步代码块时，且还是偏向锁时，会看锁对象对象头Mark Word的线程ID是否是当前线程ID，如果是直接执行同步代码块，这样在没有竞争时，线程不用获取锁与释放锁。
>
> 当偏向线程A执行过程中，有线程B过来想获得偏向锁，但锁的Mark Work存储的线程ID不是当前线程ID，会进行CAS操作替换对象头中的线程ID，当CAS替换失败时（一次失败说明有竞争，有竞争就不能再是偏向锁了），进行偏向锁的撤销，即将偏向锁转为轻量锁（当到达全局安全点（safepoint）时获得偏向锁的线程被挂起，偏向锁升级为轻量级锁，然后被阻塞在安全点的线程继续往下执行同步代码。）
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/24/1666623528031.png)
>
> 此时偏向锁已经 变为了轻量锁，持有之前偏向锁的线程执行完后，发现有竞争（轻量锁或说重量锁）会主动释放锁，如果还要执行，会与其它线程一样进行CAS竞争（CAS地把当前线程栈中的lockRecord与锁的MarkWork进行替换），
>
> > 升级到轻量级锁后锁对象的hashCode信息去哪了？   存到了当前线程栈中的lockRecord内。
> >
> > 轻量级锁获取锁的流程：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666677845935.png](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666677845935.png "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666677845935.png")
> >
> > 退出轻量级锁的过程：[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666678440855.png](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666678440855.png "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666678440855.png")
>
> 在这个竞争过程中，如果有线程自旋10次失败（可以调整），就会将轻量锁升级为重量锁（选择权交给操作系统），其它线程看到是重量锁且被占用时，会将则直接将自己挂起（而不是忙等），等待将来被唤醒。
>
> > 重量级锁是指当有一个线程获取锁之后，其余所有等待获取该锁的线程都会处于阻塞状态。
> >
> > 重量级锁原理：
> > Java中synchronized的重量级锁，是基于进入和退出Monitor对象实现的。在编译时会将同步块的开始位置插入monitor enter指令，在结束位置插入monitor exit指令。当线程执行到monitor enter指令时，会尝试获取对象所对应的Monitor所有权，（如果获取到了，即获取到了锁，会在Monitor的owner中存放当前线程的id,这样它将处于锁定状态，除非退出同步块，否则其他线程无法获取到这个Monitor。）
> >
> > 升级到重量级锁锁对象的hashCode信息去哪了？   对象头中的markwod，和轻量级锁中的处理类似， 被存入了objectMonitor对象的header字段中了。
>
> **整个过程：**
>
> ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/24/1666624253339.png)
>
> 在JDK15(包含JDK15) 后启动虚拟机当不再默认开启偏向锁，并在之后的版本禁用、废弃并最终删除偏向锁 。[https://openjdk.org/jeps/374](https://openjdk.org/jeps/374 "https://openjdk.org/jeps/374")

#### \[\_22.3\_] hashCode与锁升级

偏向锁过程中遇到一致性哈希计算请求，立马撤销偏向模式，膨胀为重量级锁

```java
class Ticket {
    private int number = 50;
    private Object lockObject = new Object();
    public void sale() {
        synchronized (lockObject) {
            System.out.println("获取hashCode前");
            System.out.println(ClassLayout.parseInstance(lockObject).toPrintable());
            System.out.println(this.lockObject.hashCode());
            System.out.println("获取hashCode后");
            System.out.println(ClassLayout.parseInstance(lockObject).toPrintable());
            if (number > 0) {
                System.out.println(Thread.currentThread().getName()+"卖出第：\t"+(number--)+"\t还剩下："+number);
                System.out.println(ClassLayout.parseInstance(lockObject).toPrintable());
            }
        }
        try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }


    }
}

public class synchrnized与偏向锁 {
    public static void main(String[] args) throws InterruptedException {

        try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }
        Ticket ticket = new Ticket();
        ticket.sale();
    }
}

```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666675280008.png)

当一个对象已经计算过identity hash code,它就无法进入偏向锁状态，跳过偏向锁，直接升级轻量级锁

```java
class Ticket {
    private int number = 50;
    private Object lockObject = new Object();
    public void sale() {
        System.out.println(this.lockObject.hashCode());
        synchronized (lockObject) {
            System.out.println("获取hashCode后无法进入偏向锁");
            System.out.println(ClassLayout.parseInstance(lockObject).toPrintable());

            if (number > 0) {
                System.out.println(Thread.currentThread().getName()+"卖出第：\t"+(number--)+"\t还剩下："+number);
                System.out.println(ClassLayout.parseInstance(lockObject).toPrintable());
            }
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }
}

public class synchrnized与偏向锁 {
    public static void main(String[] args) throws InterruptedException {

        try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }
        Ticket ticket = new Ticket();
        ticket.sale();
    }
}

```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666675484591.png)

#### \[\_22.4\_] 锁消除与锁粗化

**锁消除：** 找出锁的对象 → 是否逃逸出被其它线程共享的风险 → 没有那就进行消除

```java
public String concatString(String s1, String s2, String s3) {  
    StringBuffer sb = new StringBuffer();  
    sb.append(s1);  
    sb.append(s2);  
    sb.append(s3);  
    return sb.toString();  
}  
```

每个StringBuffer.append()方法中都有一个同步块(锁的是当前对象)，锁就是sb对象。虚拟机观察变量sb，很快就会发现它的动态作用域被限制在concatString()方法内部。也就是sb的所有引用永远不会“逃逸”到concatString()方法之外，其他线程无法访问到它，所以这里虽然有锁，但是可以被安全地消除掉，在即时编译之后，这段代码就会忽略掉所有的同步而直接执行了。

**锁粗化**：**锁粗化是指，将多个连续的加锁、解锁操作连接在一起，扩展成一个范围更大的锁**。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/25/1666682170802.png)

### \[\_23\_] AQS

AQS (AbstractQueuedSynchronizer) 中文叫“抽象的队列同步器”，

谈到并发编程，不得不说AQS(AbstractQueuedSynchronizer)，这可谓是`Doug Lea`老爷子的大作之一。AQS即是抽象队列同步器，是用来构建Lock锁和同步组件的基础框架，很多我们熟知的锁和同步组件都是基于AQS构建，比如ReentrantLock、ReentrantReadWriteLock、CountDownLatch、Semaphore。

#### \[\_23.1\_] AQS 在代码上的解析

```java
public abstract class AbstractQueuedSynchronizer extends AbstractOwnableSynchronizer implements java.io.Serializable {
    //头结点
    private transient volatile Node head;
    //尾节点
    private transient volatile Node tail;
    //共享状态
    private volatile int state;
    
    //内部类，构建链表的Node节点
    static final class Node {
        volatile Node prev;
        volatile Node next;
        volatile Thread thread;
    }
}
//AbstractQueuedSynchronizer的父类
public abstract class AbstractOwnableSynchronizer implements java.io.Serializable {
    //占用锁的线程
    private transient Thread exclusiveOwnerThread;
}
```

由源码可以看出AQS是有以下几个部分组成的：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/28/1666935889304.png)

\*\* AQS 解析：state共享变量\*\*​

AQS中里一个很重要的字段state，表示同步状态，是由`volatile`修饰的，用于展示当前临界资源的获锁情况。通过getState()，setState()，compareAndSetState()三个方法进行维护。

```java
private volatile int state;

protected final int getState() {
    return state;
}
protected final void setState(int newState) {
    state = newState;
}
//CAS操作
protected final boolean compareAndSetState(int expect, int update) {
    return unsafe.compareAndSwapInt(this, stateOffset, expect, update);
}
```

**AQS 解析：CLH队列**

AQS里另一个重要的概念就是CLH队列，它是一个双向链表队列，其内部由head和tail分别记录头结点和尾结点，队列的元素类型是Node。

简单讲一下这个队列的作用，就是当一个线程获取同步状态(state)失败时，AQS会将此线程以及等待的状态等信息封装成Node加入到队列中，同时阻塞该线程，等待后续的被唤醒。

队列的元素就是一个个的Node节点，下面讲一下Node节点的组成：

```java
static final class Node {
    //共享模式下的等待标记
    static final Node SHARED = new Node();
    //独占模式下的等待标记
    static final Node EXCLUSIVE = null;
    //表示当前节点的线程因为超时或者中断被取消
    static final int CANCELLED =  1;
    //表示当前节点的后续节点的线程需要运行，也就是通过unpark操作
    static final int SIGNAL    = -1;
    //表示当前节点在condition队列中
    static final int CONDITION = -2;
    //共享模式下起作用，表示后续的节点会传播唤醒的操作
    static final int PROPAGATE = -3;
    //状态，包括上面的四种状态值，初始值为0，一般是节点的初始状态
    volatile int waitStatus;
    //上一个节点的引用
    volatile Node prev;
    //下一个节点的引用
    volatile Node next;
    //保存在当前节点的线程引用
    volatile Thread thread;
    //condition队列的后续节点
    Node nextWaiter;
}
```

**AQS 解析：exclusiveOwnerThread**

AQS通过继承AbstractOwnableSynchronizer类，拥有的属性。表示独占模式下同步器的持有者。

> **独占式 **：同一时刻仅有一个线程持有同步状态，也就是其他线程只有在占有的线程释放后才能竞争，比如**ReentrantLock**。下面从源码切入，梳理独占式的实现思路。
>
> **共享式：** 即共享资源可以被多个线程同时占有，直到共享资源被占用完毕。比如ReadWriteLock和CountdownLatch。下面我们从源码去分析其实现原理。
>
> 下面讲的是独占式而不是共享式，如果想了解，请参考：[https://developer.aliyun.com/article/779674#slide-7](https://developer.aliyun.com/article/779674#slide-7 "https://developer.aliyun.com/article/779674#slide-7")

#### \[\_23.2\_] AQS在**ReentrantLock**中的应用

下面我们来解析基于AQS实现**ReentrantLock**非公平锁。

#### ——reentrantLock.lock();

**ReentrantLock**的基本使用：

```java
        ReentrantLock reentrantLock = new ReentrantLock();
        new Thread(()->{
            // 【1】
            reentrantLock.lock();
            try {
                System.out.println("你好");
                try {Thread.sleep(500); } catch (InterruptedException e) {e.printStackTrace();}
            }finally {
                // 【2】
                reentrantLock.unlock();
            }
        }).start();
```

第【1】进行线程的排队阻塞，当【2】执行后，锁持有者会唤醒其后继节点中的线程执行来抢锁。

上面【1】整理的逻辑如下，现在我们进行源码进行深入解析：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/28/1666936834967.png)

入口：reentrantLock.lock();

追入的第一个方法：

```java
        final void lock() {
            // 尝试改变共享变量state由0变为1
            if (compareAndSetState(0, 1))
                // 如果抢到设置锁拥有者为当前线程，reentrantLock.lock();方法执行完成，就可以执行被锁住的内容了
                setExclusiveOwnerThread(Thread.currentThread());
            else
                // 获取锁失败，调用acquire 进行后续的等待工作
                acquire(1);
        }
```

非公平锁的acquire方法：

```java
    public final void acquire(int arg) {
        // 再次尝试获取锁
        if (!tryAcquire(arg) &&
            // 如果获取锁失败，调用addWaiter方法封装当前线程为Node加入等待队列中，然后再调用acquireQueued方法使线程阻塞
            acquireQueued(addWaiter(Node.EXCLUSIVE), arg))
            selfInterrupt();
    }
```

> 追入addWaiter方法：
>
> ```java
>     private Node addWaiter(Node mode) {
>         // 将当前线程包装到Node (状态为EXCLUSIVE，标记为独占模式)
>         Node node = new Node(Thread.currentThread(), mode);
>         // Try the fast path of enq; backup to full enq on failure
>         Node pred = tail;
>         // 如果尾节点不为null
>         if (pred != null) {
>             // 封装好的节点prev指向原来的尾节点
>             node.prev = pred;
>             // 修改尾节点指向新节点
>             if (compareAndSetTail(pred, node)) {
>                 // 让原来的尾节点的next指定新节点
>                 pred.next = node;
>                 // 将封装来的节点返回
>                 return node;
>             }
>         }
>         // 如果还没有初始化队列
>         enq(node);
>         // 将封装来的节点返回
>         return node;
>     }
> ```
>
> > enq方法
> >
> > ```java
> >  private Node enq(final Node node) {
> >       for (;;) {
> >           // 【1】能从这里进来，说明队列还没有初始化此时 队列的head与tail都为null
> >           Node t = tail;
> >           // 【2】满足条件  【5】此时尾节点与头节点都不为null，不满足条件
> >           if (t == null) { // Must initialize
> >               //【3】让head指定创建的节点head=new Node()
> >               if (compareAndSetHead(new Node()))
> >                   // 【4】 让尾节点也指向头节点
> >                   tail = head;
> >           } else {
> >               // 【6】让新创建的节点prev指向头节点
> >               node.prev = t;
> >               // 【7】尾节点改为指向新节点
> >               if (compareAndSetTail(t, node)) {
> >                   // 【8】头节点（新节点的前一个节点）的next指向新节点
> >                   t.next = node;
> >                   // 返回头节点
> >                   return t;
> >               }
> >           }
> >       }
> >   }
> > ```
>
> 追入acquireQueued：使新加入的节点中的线程阻塞
>
> ```java
>     final boolean acquireQueued(final Node node, int arg) {
>         // 【1】默认失败
>         boolean failed = true;
>         try {
>             // 【2】interrupted 是返回值，表示是否被中断
>             boolean interrupted = false;
>             for (;;) {
>                 // 【3】获取新节点的前一个节点  【6】线程被唤醒了，说明当前线程满足执行条件，准备去抢锁
>                 final Node p = node.predecessor();
>                 // 【4】如果前一个节点是头节点，就尝试抢锁
>                 if (p == head && tryAcquire(arg)) {
>                     //【4.1】如果抢到锁，就将新节点设为头节点，之前的头节点会被GC
>                     setHead(node);
>                     p.next = null; // help GC
>                     failed = false;
>                     // 【4.2】 返回true，表示没有被中断，直接获取到了锁 【7】线程抢到锁了,使当前节点为点位节点，返回true
>                     return interrupted;
>                 }
>                 // 【5】不是即将执行的节点（新节点的前一个节点不是头节点）或无法获取到锁
>                 //      判断能否park，
>                 if (shouldParkAfterFailedAcquire(p, node) &&
>                     //  如果可以park,检查并park阻塞当前线程
>                     //  如果在这个过程中，线程被中断返回true
>                     parkAndCheckInterrupt()) 
>                     // 在这个过程中，线程被中断(会调用interrupted()方法（并将中断位由true改为false，需要在后面的执行中需要调用）)，将interrupted 设为true
>                     interrupted = true;
>             }
>         } finally {
>             if (failed)
>                 /*
>                 如果线程在等待过程中被中断过，它是不响应的。只是获取资源后才再进行自我中断selfInterrupt()，
>                 将中断补上。因为在等待队列中自旋状态的线程是不会响应中断的，它会把中断记录下来，如果在自旋时发生过中断，
>                 就返回true。然后就会执行selfInterrupt()方法，而这个方法就是简单的中断当前线程Thread.currentThread().interrupt();
>                 其作用就是补上在自旋时没有响应的中断。
>                 */
>                 cancelAcquire(node);
>         }
>     }
> ```
>
> 返回lock()的入口
>
> ```java
>     public final void acquire(int arg) {
>         if (!tryAcquire(arg) &&
>             acquireQueued(addWaiter(Node.EXCLUSIVE), arg)) 
>             // 如果acquireQueued返回的中断为true，会自我中断，也就是将线程的标志位改回true（下面selfInterrupt方法的作用是恢复中断标志位为true），该线程被中断了
>             selfInterrupt();
>     }
> ```

#### ——reentrantLock.unlock();

当锁拥有者获取到了锁，执行完了同步逻辑，就要unlock了，该方面要做的是唤醒下一个节点（当前节点还是队列中的头节点）。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/28/1666943726571.png)

### \[\_24\_] 读写锁

`读`与`写`就像一个刀的`刀尖`与`刀背` , 拍的时候不能切，切的时候不能拍。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/28/1666947841433.png)

读与写（或写写）是`互斥`的，读读是`共享`的。

#### \[\_24.1\_] 从ReentrantLock到ReentrantReadWriteLock

从ReentrantLock

```java
class SourceReadWrite {
    private volatile String flag;

    public void write()  {
        String name = Thread.currentThread().getName();
        System.out.println("【<写】开始写入:"+name);
        try { Thread.sleep(200); } catch (InterruptedException e) { e.printStackTrace(); }
        flag = Thread.currentThread().getName();
        System.out.println("【写>】完成写入:"+name);
    }
    public void read() {
        String name = Thread.currentThread().getName();
        System.out.println("【<读】开始读取:"+name);
        try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
        String tmp_flag = flag;
        System.out.println("【读>】完成读取:"+name);
    }
}
public class _从ReentrantLock到ReentrantReadWriteLock {
    public static void main(String[] args) {
        ReentrantLock lock = new ReentrantLock();
        ReentrantReadWriteLock rwlock = new ReentrantReadWriteLock();
        SourceReadWrite sourceReadWrite = new SourceReadWrite();
        for (int i = 0; i < 10; i++) {

            new Thread(()->{
                lock.lock();
                sourceReadWrite.write();
                lock.unlock();
            },"写线程"+i).start();
        }
        for (int i = 0; i < 10; i++) {
            new Thread(()->{
                lock.lock();
                sourceReadWrite.read();
                lock.unlock();
            },"读线程"+i).start();

        }
    }

}
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/28/1666951134699.png)

**到ReentrantReadWriteLock**

```java
class SourceReadWrite {
    private volatile String flag;

    public void write()  {
        String name = Thread.currentThread().getName();
        System.out.println("【<写】开始写入:"+name);
        try { Thread.sleep(200); } catch (InterruptedException e) { e.printStackTrace(); }
        flag = Thread.currentThread().getName();
        System.out.println("【写>】完成写入:"+name);
    }
    public void read() {
        String name = Thread.currentThread().getName();
        System.out.println("【<读】开始读取:"+name);
        try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
        String tmp_flag = flag;
        System.out.println("【读>】完成读取:"+name);
    }
}
public class _从ReentrantLock到ReentrantReadWriteLock {
    public static void main(String[] args) {
        ReentrantLock lock = new ReentrantLock();
        ReentrantReadWriteLock rwlock = new ReentrantReadWriteLock();
        SourceReadWrite sourceReadWrite = new SourceReadWrite();
        for (int i = 0; i < 10; i++) {

            new Thread(()->{
                rwlock.writeLock().lock();
                sourceReadWrite.write();
                rwlock.writeLock().unlock();
            },"写线程"+i).start();
        }
        for (int i = 0; i < 10; i++) {
            new Thread(()->{
                rwlock.readLock().lock();
                sourceReadWrite.read();
                rwlock.readLock().unlock();
            },"读线程"+i).start();

        }
    }

}
```

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/28/1666951020187.png)

#### \[\_24.2\_] 锁降级

就是从`写锁`降级为`读锁` ,  `ReentrantReadWriteLock` 不支持`锁升级`但支持`锁降级`.

“**下面演示了锁升级（ReentrantReadWriteLock会产生死锁）与锁降级**”

```java
public class _演示ReentrantReadWriteLock锁降级 {
    public static void main(String[] args) {
        ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
        ReentrantReadWriteLock.ReadLock rl = rwl.readLock();
        ReentrantReadWriteLock.WriteLock wl = rwl.writeLock();
        // 尝试锁升级-结果产生死锁
//        try {
//            wl.lock();
//            System.out.println("写");
//
//            rl.lock();
//        }finally {
//            try {
//                System.out.println("读");
//                wl.unlock();
//            }finally {
//
//
//                rl.unlock();
//            }
//        }
        // 尝试锁降级-正常执行
        try {
            rl.lock();
            System.out.println("写");

            wl.lock();
        }finally {
            try {
                System.out.println("读");
                rl.unlock();
            }finally {


                wl.unlock();
            }
        }

    }
}

```

> **为什么要进行锁降级？**
>
> 当线程写完要读的时候，为了避免释放写锁后其它线程获取到写锁进行修改当前线程修改好的数据，就要进行锁降级，从上面也可以看出锁降级过程是：**获取写锁→获取读锁→释放写锁→释放读锁** ,这样就可以保证直接过渡到读锁，这个过程不会有其它写线程来干扰数据，避免不可重复读。
>
> **ReentrantReadWriteLock存在的问题——锁饥饿问题：**
> ReentrantReadWriteLock实现了读写分离，但是一旦读操作比较多的时候，想要获取写锁就变得比较困难了，
> 假如当前1000个线程，999个读，1个写，有可能999个读取线程长时间抢到了锁，那1个写线程就悲剧了
> 因为当前有可能会一直存在读锁，而无法获得写锁，根本没机会写，o(T\_T)o。

### \[\_25\_] 邮戳锁

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/29/1667039140185.png)

`邮戳锁` 是`读写锁`的升级版, 允许在读的时候可以写，所以与读写锁不同的是邮戳锁有乐观读功能。解决了`锁饥饿`问题。

> **缺点：**
>
> StampedLock 不支持重入，没有Re开头
> StampedLock的悲观读锁和写锁都不支持条件变量（Condition),这个也需要注意。
> 使用StampedLock一定不要调用中断操作，即不要调用interrupt()方法

**邮戳锁传统读写实现：**

```java
class Work {
    public static volatile int number = 0;
    public static StampedLock stampedLock = new StampedLock();

    public void write() {
        System.out.println("[写线程修改前]");
        long stamp = stampedLock.writeLock();
        System.out.println("写入开始");
        try {
            number = 20;
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            System.out.println("写入完成");
            stampedLock.unlockWrite(stamp);

        }
    }

    public void read() {
        long stamp = stampedLock.readLock();
        System.out.println("在在读取");
        try {
            number = 20;
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            System.out.println("读取完成");
            stampedLock.unlockRead(stamp);

        }
    }
}

public class _演示StampedLock作为普通的读写锁 {
    public static void main(String[] args) {
        Work work = new Work();
        for (int i = 0; i < 5; i++) {
            new Thread(() -> {
                work.read();
            }).start();
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        new Thread(() -> {
            work.write();
        }).start();
    }
}
```

**邮戳锁实现乐观读功能：** 当乐观读失败后进行悲观读

```java
class Work {
    private Integer i = 0;
    private StampedLock stampedLock = new StampedLock();
    public void read() {
        long stamp = stampedLock.tryOptimisticRead();
        System.out.println("乐观读："+i);
        try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }

        if (!stampedLock.validate(stamp)) {
            // 被修改了
            long l = stampedLock.readLock();
            System.out.println("乐观失败加锁读："+i);
            stampedLock.unlockRead(l);
        }

    }
    public void write() {
        long stamp = stampedLock.writeLock();
        i = 20;
        stampedLock.unlockWrite(stamp);
    }
}
public class _StampedLock乐观读 {
    public static void main(String[] args) throws InterruptedException {
        Work b = new Work();
        // 读
        new Thread(()->{
            b.read();
        }).start();
        Thread.sleep(500);
        // 写
        new Thread(()->{
            b.write();
        }).start();

    }
}
```
