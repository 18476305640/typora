# Java基础

JDK文档：[https://www.matools.com/api/java8](https://www.matools.com/api/java8 "https://www.matools.com/api/java8")

#### 1.1 Java的数据类型

-   字符串常量："123","abc"
-   字符常量：'a','1'(单引号内没有任何东西会报错，且有仅只有一个字符)
-   整数常量：1，200
-   浮点数常量：1.23,65.1
-   布尔常量：true,false
-   空常量：null (不能直接输出null)

#### 1.2 基本数据类型与引用数据类型

-   \[基本数据类型]
    -   整数型 byte short int(默认) long
    -   浮点型 float(数后需加F)  double(默认)
    -   字符型 char
    -   布尔型 boolean
-   \[引用数据类型]
-   字符串、数组、类、接口、Lambda

#### 1.3 变量的默认值

成员变量声明后有默认值，如果是在方法内声明后是没有默认值的，且要知道变量声明时可以没有值，但在使用时一定要有值。

#### 1.4 自动类型转换与强制类型转换

-   【自动类型转换】A:byte,short,char --» int --» long --» float --» double。
    -   在int类型“之下”的变量进行运算时，会转为int进行运算，就算是同一类型，也是要转为int的。
-   【强制类型转换】
    -   在自动类型转换下，进行逆向转换时，即小范围转大范围，如果大范围的超过也小范围，数据会溢出，转换得到的结果是已损值。

#### 1.5 字符编码

是一套自然语言与电脑二进制的转换规则，而字符集就是一套编码规则，编码与解码是规则的使用,而蓄编码与解码不同就会出现乱码。

-   编码介绍：ASCII字符集是各字符集的原始祖先，它是最基本的字符编码，其它字符集都兼容它，CBKxxx有GB2312（简体）-GBK（简繁）-GB18030（简繁和和民族文字）是我囯的编码规则。

    Unicode字符集，是万国码，兼容各国家的文字，有UTF-8,UTF-16,UTF-32而UTF-8是最常用，UTF-8是可变长度的：

    \#128个US-ASCII字符，只需一个字节编码。

    \#拉丁文等字符，需要二个字节编码。

    \#大部分常用字（含中文），使用三个字节编码。其他极少使用Unicode辅助字符，使用四字节编码。

#### 1.6 运算符

一元运算符：自增自减运算符

二元运算符：赋值运算符、比较运算符、逻辑运算符

三元运算符：a>b?a:b;三元运算符结果必须被使用。

加法运算符：

char、byte、short-->int-->float-->double-->String

两个数据类型进行相加时，遵循从小转大运算，如果是与String进行运算，会转为String再和String进行运算

如果是多位相加，则从左到右进行一次两位且逐位运算。

等号“==”运算符：

基本数据类型：比较值。

引用数值类型：比较地址值。

其它运算。

#### 1.7 编译器的常量优化

short s=5+7时，在编译后，相当于short s=12，而不会5+7运算后转int再赋值给short而报错。

#### 1.8 控制语句

#### 1.9 数组的方法

-   初始化后长度固定&#x20;
-   常见异常：数组异常：Exception:ArrayIndexOutOfBoundsException(越界异常）--超出定义的数组长度、NullPointerException（空指针异常）--访问的数组没有指向堆;

#### 2.0 方法

-   方法的组成：方法修饰符+\[static或final]+方法返回值+方法名称(参数列表){\[方法体]+\[返回语句]};
-   方法重载（Overload）:方法名相同，参数列表不同的一系列方法，若在一个类中写了多个这类的方法，就是方法重载了。

#### 2.1 栈与堆

-   栈：当调用方法时，就进栈

    堆：当new时就创建一块空间

    方法区：本身运行的类与运行中涉及的类

#### 2.2 构造方法

用来创建类的实例对象。

#### 2.3 静态方法与成员方法

静态方法不需要创建对象，用的是类对象

#### 2.4 方法中的this

this就是要创建出来的对象，所以调用的是对象的成员变量，而右边的是根据最近原则得到的name，即传入的name

```java
public class Son{
       private String name;
       public void setName(String name){
           this.name=name;
       }
     }
```

#### 2.5 构造方法与普通方法

没有static与返回值这两个位置，且要求方法与类名一致。

#### 2.6 构造方法的调用&#x20;

我们用new调用类的构造方法时，构造方法可能会调用其它构造方法，但不管最后是哪个构造方法，最先执行的是super()，用来创建父类对象，然后再原路返回执行构造方法。

#### 2.7 JDK文档的查看方法

&#x20;在左边索引中进行搜索类名或接口名，两次次回车打开详情，首先要看的是这个所属的包、看这个是类、抽象类还是接口。再看其构造方法与方法。Ctrl+R可进行查找。

#### 2.8 匿名对象

new 出来直接使用

#### 2.9 自动装箱与拆箱

从java1.5开始支持包装类的自动拆装箱，所以我们可以把包装类当然基本类型使用，它们是兼容的。

byte       Byte

short      Short

boolean    Boolean

char       Charset【特殊】

int        Integer【特殊】（数值范围\[-128,127]，用“==”是相等的）

long       Long    （如果不在\[-127,128]之间，不能直接比较，应转换为long比较，使用longValue方法可以得到long）

float      Float

double     Double

包装类的自动拆箱与装箱：虽然ArrayList只能存储引用数据类型，如果想使用基本数据类型，我们可以用数据类型的包装类，它们是引用数据类型的

ArrayList\<Integer> arrayList=new ArrayList<>();

arrayList.add(11);//装箱，默认new Integer(11);

int num=arrayList.get(0);//拆箱,默认arrayList.get(0).intValue();

#### 3.0 字符串String

```java
额外要记的单词：suffix（后缀）

构建方法：
  通过byte、字符串、数组
接口方法：
  判断两个字符串是否相等：equalsIgnoreCase、equals
  查看是否以什么字符串结尾：endsWith(".txt");
  转为byte数组：getBytes()
  获取hashCode()
  获取第一次出现的index : indexOf("txt");
  从字符串池中获取："" ， new String("") ，
  如果改变，就不是池中的了，想要从指向池中的，需要用：intern() 从池中获取
  判断length的length是否为0：isEmpty()
  从后面开始的：lastIndexOf(".");
  获取字符串长度：length()
  利用正则匹配，判断是否包含：matches("(.*)txt(.*)");
  字符替换：  replace(char oldChar, char newChar)
  测试此字符串是否以指定的前缀开头：startsWith(String prefix)
  截取字符串子集：substring(int beginIndex, int endIndex)
  转小写：toLowerCase()
  转大写：toUpperCase()
  删除任何前导和尾随空格：trim()
  
  
静态方法：
  将一些类型值转为字符串类型：String.valueOf(可以是很多类型值);
    
扩展：
  StringBuffer： 用于经常性的字符串的变化  

```

字符串：jdk1.8及以前String使用的是char数组作为底层，因为每一个char占用两个字节而拉丁字符只需要一个字节就可以存储。所以从jdk1.9后用byte数组作为底层。

内存：

String a="HelloWorld!";//底层byte数组的内存地址存放在字符串常量池中。可重复利用

String b=new String("HelloWorld!");//不用池子中已存在的，而总是自己创建。

底层：

byte\[] by={97,98,99};//新字符串底层

char\[] ch={'A','B','C'};//旧字符串底层

方法

判断：public boolean equals(Object anObject)：//对字符串的内容进行比较。而"=="是进行对象地址的比较。\[一定要确保左边是字符串]

判断：public boolean equalsIgnoreCase(String anotherString)：忽略大小写，进行比较字符串中的内容。\[一定要确保左边是字符串]

长度：public int length():返回此字符串的长度。

截取：public String substring(int beginIndex,int endIndex):返回一个新字符串\[a,b)，它是此字符串的一个子字符串。

一个参数，代表起始位置，截取到末尾。

转char数组：char\[] chars = ab.toCharArray();

获取底层byte数组：byte\[] bytes = ab.getBytes();

内容替换： String tm = "你会不会玩啊？你大爷的！".replace("你大爷的", "");

分割：String\[] split = "123,456,789".split(",");//特别地如果用"."进行分割，那么就会失败，原因是分割的底层是用了正则，所以我们需要用"\\\\."对"."

进行转意;

类型转换：利用包装类的方法进行字符串转数值方法

字符转Integer或说int: Integer.parseInt("100");

字符转Double或说double: Double.parseDouble("100");

#### 3.1 修饰符static

内存：用static修饰的变量，存在于内存的方法区（Method Area）中的，是该类所有实例对象的"共有"属性，与类的实例对象无关。

#### 3.2 Arrays数组工具类

#### 3.3 Math数字工具类

说明：Math类是数学相关的工具类，里面提供了大量进行数学运算的静态方法。

方法：public static double abs(..)：取绝对值;

public static double ceil(double a):向上取整

public static double floor(double a):向下取整

public static final double PI:代表圆周率的值。

#### 3.4 继承

子类构造方法调用 ，就会调用 super，super代表父类。

重写是方法名相同，参数列表也相同。//可重写为访问修饰扩大，返回值类型缩小。

#### 3.5 抽象类

类声明上，由calss转为abstract class

方法声明上，声明上由public 转为public abstract

跟接口一样，不能创建对象 。

\[(顶层抽象类)]--\[（抽象子类）--(普通子类)]--普通类

#### 3.6 接口

\[public] \[static] \[final] 数据类型 常量名称 =数据值; //介意常量名称这样写，“"MNUM\_OF\_DEF”。

\[public] \[abstract] 返回值类型 方法名称(参数列表);//接口中最重要的内容

#### 3.7 单继承多实现

#### 3.8 父类优先于接口

、如果一个类继承了一个类与实现了一个接口，若有冲突，父类优先。

#### 3.9 当两个父接口冲突时

一个接口继承了多个接口，如果默认方法有冲突，如果这时子接口不覆盖掉父接口的冲突方法，是会报错的，因为两父接口间没有优先级的。

#### 4.0 多态

态(向上转型)：

说明：父类  对象=new 子类(参数列表);

用多态对象需遵循：编译（+属性）父类，运行子类。

多态的好处与弊端

好处：只有父类方法存在有的，才能调用，且成员方法运行看右边（子类）;

弊端：无法调用子类特有的内容（变量+方法），“解决方法：向下转型”;

向下转型（“还原”解决弊端）

理解：向下转型，将子类还原回来了，就不存在多态的特征了。

注意：如果还原回原来的，如果是猫转成了狗，会出现类转换异常（介意转换前用instanceof作判

#### 4.1 final修饰

用final关键字来修饰类，则这个类不能有子类，即太监类。

用final关键字来修饰方法，那么这个方法是不能被子类重写的。

用final关键字来局部变量，首先要知道局部变量如果不赋值是没有默认值的，所以声明时没有赋值，则会给予一次赋值的机会。

用final关键字来成员变量，首先要知道成员变量是有默认值的，如果在初始化时不设置，必须保证所有构造方法都能给其赋值。

#### 4.2四种权限修饰符

private :类外不能访问

(default):包外不能访问

protected :包外非子类不能访问

public :都可访问

#### 4.3 内部类

类的权限修饰符

外部类：public/(default)  //因为那两种是无意义的。

成员内部类：全部可用 //像成员方法的权限修饰一样

局部内部类：全不可用 //因为只能给所在方法使用。

分类说明：

成员内部类：跟成员方法同等位置，我们在调用时分可见调用与不可见调用，可见直接new即可，不可见调用（外部与本类静态方法）格式：

外部类.内部类 内部类对象名 = new 外部类().内部类();

局部内部类：跟局部变量同等位置，只能给所在方法使用。若用到其局部变量，该变量必须是final,因为生命周期不同。

但从java 8+开始，只要保证该局部变量不变，可以省略final不写。

匿名内部类：我们可以将运用多态得到的实现类或子类的对象看作成员变量或局部变量。只使用一次或代码比较少才推荐使用，

格式：接口 对象名 = new 接口(){..需要重写接口的全部内部..};

父类 对象名= new 父类(){ ..匿名子类体.. };

注意：匿名内部类与匿名对象不同，匿名对象忽略的是对象名，而匿名内部类忽略的是实现类或子类（用{}代替。）

#### 4.4 接口变量

定义接口后，即可拿来当作类型使用。运用多态设置值。(多态，匿名内部类，匿名内部类+匿名对象)

#### 4.5 根类Object

继承Object类，Object 是类层次结构的根类。每个类都直接或间接使用Object作为父类，所有对象（包括数组）都实现这个类的方法。

方法：

toString：不重写toString方法默认打印的是类的包名+地址值。一般重写为对类属性的打印输出。[可快速生成](输出引用对象时，默认调用其toString\(\)方法 "可快速生成")。

equals:重写父类Object方法，注意this代表左边。看传入是否与this相等或是否为其类的实例，若为null，直接返回false;\[可快速生成]

Objects工具类

public boolean equals(String a,String b)方法：可避免Object的equals方法的空指针异常问题。

String a=null;a.equals("abc");//就会出现空指针异常。

String a=null;Objects.equals(a,"abc");//返回false

### 4.6 可变参数

**说明：** 可变参数是一个参数，如果要写多个不同类型的参数，可变参数必须写在最后。

**底层：** 可变参数是一个参数，实质是个数组。（当我们调用传入参数后，这个可变参数的底层数组的长度就确定了）

**语法：** public void foo(String ...varargs){}

### 4.7 异常

分类：Exception包括Error错误(编译期异常)与RuntimeException(运行期异常：当出现异常时，没有处理逻辑下，方法会将这个异常传递到调用者，进行依次传递，当抛到JVM虚拟机时，控制台打印红色字体错误信息并终止当前执行的java程序。)

过程分析：

产生异常：

捕获：参考下面“捕获处理异常”

主动产生：用throw关键字，示例：throw new ArrayIndexOutOfBoundException("越界异常");//new的是RuntimeException（运行期异常）的子类。

抛出异常(处理异常)：在方法参数列表后写："throws \<Exception或其子类>,..{} ", 调用者必须处理这个异常，当然也可以选择抛出或try..catch...;

捕获处理异常（处理异常）：

try{

//可能会出现异常的代码

}eatch(\<Exception或其子类> e){

//捕获到后如何处理异常（一般在工作中，将错误信息写入日志中）

//Throwable 类是 Java 语言中所有错误或异常的超类,定义有三个方法：e.getMessage();-->e.toString()-->printStackTrace();（信息详细程度向右增强）

}finally{

//不管是否出现错误，都会执行的代码

//这里一般放释放close语句（在释放时，检查资源是否为null，为null无需释放,JDK1.7,1.9有了新的处理方案，来简化资源的释放操作）

}

注意：1、可一次捕获多次处理，但要注意异常的顺序（子异常类写在上面）。

2、如果finally有return，"会覆盖掉其它地方的return语句"。

3、重写父类方法时，需要与父类方法同步，父类没有抛出异常，子类也是不能抛出的，如果有不能抛出比父类范围大的异常。

自定义异常：一般重写Exception与RuntimeException(出错不会报错),且分别写一个无参构造方法与有参（String 的错误提示信息）构造方法。

书写：

public class  MyException extends Exception{

public MyException(){ }

public MyException(String ErrorString){

super(ErrorString);//信息的传递：自定义--->Exception-->Throwable,来覆盖超类toString（）原有的错误信息。

}

}

主动抛出异常：

用法：throw new MyException("出现了\*\*异常");

### 4.8 Date时间对象/格式转换

构造方法：

Date( \[long time] );根据传入的毫秒值创建日期对象//无参数默认当前系统时间的毫秒值创建对象

方法：

getTime(); 返回Date对象对应的毫秒值。

toString(); 输出默认调用，示例"Fri Sep 25 11:08:36 CST 2020"

工具：

（1）文本生成&文本解析

介绍：SimpleDateFormat-->DateFormat（该抽象类实现了Serializable, Cloneable这两个接口）;

我们要想获取指定的日期格式，必不可少的是格式,我们可以利用SimpleDateFormat创建一个想要的格式。

示例：SimpleDateFormat sm=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//之间可用一些字符隔开来美化生成的文本。

y  年

M  月

d  日

H  时

m  分

s  秒

SimpleDateFormat方法：

传入Date对象转为指定文本。// String format = sdf.format(date);

传入文本，按照模式生成Date对象。// Date parse = sdf.parse("2020年09月16日 10时07分58秒");

（2）日期自定义--日历对象

介绍：Calendar是一个日历抽象类，我们可以利用其静态方法获取其子类来创建对象。

Calendar c = Calendar.getInstance();

使用：

基本操作方法：

c.set(Calendar.MONTH,2);//指定（左边参数）设置值（右边）。\[年月日可重载设置]

c.add(Calendar.MONTH,2);//指定（左边参数）设置值（this+右边）

c.get(Calendar.MONTH)+1;//获取指定的量（外国月份从0月开始），年日类同。
