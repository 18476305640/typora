# File

#### 5.2 File类

构造方法

File(参数列表) //里面可以有两个参数（头尾关系），File与String，String与String,如果是单参数那就是String.

静态方法

File.pathSeparator 他是一个与系统有关的路径分隔符，为了方便，它被表示为一个字符串。

成员方法

File解析

getAbsolutePath()  会判断是否相对还是绝对路径，如果是相对路径转为以项目路径为parent来组装

getPath()  将此File转换为路径名字符串,类似于toString()方法

getName()  返回File表示的文件或目录的名称

length() 返回由此File表示的文件的字节大小

判断File表示的内容

exist()  判断文件或文件夹是否存在

isDirectory()  断判当前路径代表的是文件还是文件夹,是文件夹返回true，如果不存在，返回false

isFile() 断判当前路径代表的是文件还是文件夹,是文件返回true,如果不存在，返回false

根据File创建文件或文件夹

createNewFile() 当且仅当，路径正确，要创建路径代表文件，返回true;

mkdir() 当且仅当，路径正确，且只要创建一个文件夹时，返回true;

mkdirs() 当且仅当，路径正确，且可创建文件夹，返回true

根据File遍历文件夹下的文件与文件夹

list() 返回当前文件夹下的所以文件与文件夹名称，是一个List\<String>集合

listFiles() 返回当前文件夹下的所以文件与文件夹的绝对路径，是一个List\<File>集合
