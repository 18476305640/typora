# JDBC

### + JavaWeb技术架构

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16569842022771656984197778.png)

### \[\_1\_] JDBC

**Java数据库连接**，（**Java Database Connectivity**，简称**JDBC**）是[Java语言](https://zh.wikipedia.org/wiki/Java语言 "Java语言")中用来规范[客户端](https://zh.wikipedia.org/wiki/客户端 "客户端")程序如何来访问[数据库](https://zh.wikipedia.org/wiki/数据库 "数据库")的[应用程序接口](https://zh.wikipedia.org/wiki/应用程序接口 "应用程序接口")。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16569850679881656985067875.png)

JDBC接口（API)包括两个层次：

-   面向应用的API（JDBC接口）：JavaAPI,，抽象接口，供应用程序开发人员使用（连接数据库，执行SQL语句，获得结
    果）。 &#x20;
-   面向数据库的API： Java Driver API，供开发商开发数据库驱动程序用。

> JDBC是sun公司提供一套用于数据库操作的接口，java程序员只需要面向这套接口编程即可。不同的数据库厂商，需要针对这套接口，提供不同实现。不同的实现的集合，即为不同数据库的驱动。
> \-----面向接口编程

### \[\_2\_> 面向程序员的API

1.  注册数据库驱动。
2.  建立数据库连接。
3.  创建一个Statement。
4.  执行SQL语句。
5.  处理结果集。
6.  关闭数据库连接

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16571149259991657114925389.png)

#### \[\_2.1\_] 创建连接的方式

1、需要引入的jar包：[https://mvnrepository.com/artifact/mysql/mysql-connector-java/5.1.47](https://mvnrepository.com/artifact/mysql/mysql-connector-java/5.1.47 "https://mvnrepository.com/artifact/mysql/mysql-connector-java/5.1.47")

2、代码：

```java
package com.zhuangjie.jdbc;

import com.mysql.jdbc.Driver;
import org.junit.Test;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class _1_连接JDBC {
    //第一种方式：直接使用第三方的驱动进行创建连接，这是不推荐的方式
    @Test
    public void test01() throws SQLException {
        String url = "jdbc:mysql://127.0.0.1:3306/test";
        Properties info = new Properties();
        info.setProperty("user","root");
        info.setProperty("password","3333");
        Driver driver = new Driver();
        Connection connect = driver.connect(url, info);
        System.out.println(connect);

    }
    //第二种方式：使用反射的方式，消除第三方直接创建Driver
    @Test
    public void test02() throws Exception {
        String url = "jdbc:mysql://127.0.0.1:3306/test";
        Properties info = new Properties();
        info.setProperty("user","root");
        info.setProperty("password","3333");
        Class<?> aClass = Class.forName("com.mysql.jdbc.Driver");
        Driver driver = (Driver) aClass.newInstance();
        Connection connect = driver.connect(url, info);
        System.out.println(connect);

    }
    //第三种方式：使用DriverManger替代Driver
    @Test
    public void test03() throws Exception {
        Class<?> aClass = Class.forName("com.mysql.jdbc.Driver");
        Driver driver = (Driver) aClass.newInstance();

        String url = "jdbc:mysql://127.0.0.1:3306/test";
        String user = "root";
        String passsword = "3333";

        //注册驱动
        DriverManager.registerDriver(driver);
        //获取连接
        Connection connection = DriverManager.getConnection(url, user, passsword);
        System.out.println(connection);


    }
    //第四种方式：加载驱动即可，不需要显式的注册驱动，是对第三步的简写，可以简写是因为第三方的Driver类内部已经帮我们注册了（将自己家的Driver驱动 注册到DriverManger中了）
    @Test
    public void test04() throws Exception {


        String url = "jdbc:mysql://127.0.0.1:3306/test";
        String user = "root";
        String passsword = "3333";
        //加载驱动，我们不需要自己注册是因为Driver内部:
        /*
            tatic {
                try {
                    DriverManager.registerDriver(new Driver());
                } catch (SQLException var1) {
                    throw new RuntimeException("Can't register driver!");
                }
            }
         */
        Class.forName("com.mysql.jdbc.Driver");
        //获取连接
        Connection connection = DriverManager.getConnection(url, user, passsword);
        System.out.println(connection);


    }
    //第五种方式(final)：跟第四种是一样的，只是把数据与程序解耦出来了
    @Test
    public void test05() throws Exception {
        InputStream is = this.getClass().getClassLoader().getResourceAsStream("jdbc.properties");
        Properties info = new Properties();
        info.load(is);
        String url = (String) info.get("url");
        String username = (String) info.get("username");
        String password = (String) info.get("password");
        Class.forName("com.mysql.jdbc.Driver");
        Connection connection = DriverManager.getConnection(url, username, password);
        System.out.println(connection);

    }

}

```

#### +封装一个JDBC连接

```java
package com.zhuangjie.jdbc.utils;


import com.zhuangjie.jopo.User;

import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class JDBCUtils {
    //获取数据库连接
    public static Connection getConnection() {
        try {
            InputStream is = JDBCUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
            Properties properties = new Properties();
            properties.load(is);
            String url = (String)properties.get("url");
            String username = (String)properties.get("username");
            String password = (String)properties.get("password");
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection(url, username, password);
        }catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
    }


}


```

#### + 封装资源关闭

JDBC中有三个资源是要关闭的，连接`Connection`，只要进行SQL操作必有的`Statement`、 查询操作有的`ResultSet `

```java
package com.zhuangjie.jdbc.utils;


import com.zhuangjie.jopo.User;

import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class JDBCUtils {

    //关闭 Connection 与 Statement
    public static void close(Connection connection, Statement statement) {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
    //关闭 Connection 与 Statement
    public static void close(Connection connection, Statement statement,ResultSet rs) {
        if(rs != null) {
            try {
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        close(connection,statement);

    }



}


```

#### \*\*- \*\*基本CURD操作 (作业专属)

[https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/jdbc.zip](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/jdbc.zip "https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2023/03/09/jdbc.zip")

主要逻辑：

```java
package com.zhuangjie.jdbc.task;

import com.sun.org.apache.bcel.internal.generic.ACONST_NULL;
import com.zhuangjie.jdbc.entity.User;
import com.zhuangjie.jdbc.utils.JDBC;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Task1 {
    /**
     * 增删查操作，只示例一种
     */
    @Test
    public void test1() throws SQLException {
        Connection connection = JDBC.getConnection();
        Statement statement = connection.createStatement();
        String sql = "INSERT INTO user (id,username,password,email) values (2,'zhuangjie','3333','zhuangjie@gmail.com')";
        boolean b = statement.execute(sql);
        if (!b) System.out.println("操作成功！");
        connection.close();
    }


    /**查询**/
    @Test
    public void test2() throws SQLException {
        Connection connection = JDBC.getConnection();
        Statement statement = connection.createStatement();
        // 查询
        String queueSql = "SELECT * FROM user";
        ResultSet rs = statement.executeQuery(queueSql);
        ArrayList<User> users = new ArrayList<>();
        while (rs.next()) {
            Long id = rs.getLong("id");
            String username = rs.getString("username");
            String password = rs.getString("password");
            String email = rs.getString("email");
            User user = new User(id,username,password,email);
            users.add(user);
        }
        System.out.println("查询成功！");
        System.out.println(users);
        connection.close();

    }

}

```

#### \[\_2.2\_] 增删改操作

Statement存在的问题

-   问题一：存在拼串操作，繁琐
-   问题二：存在5QL注入问题

Statement是PreparedStatement的父类，如果使用Statement会有sql注入的漏洞，所以我们要使用PreparedStatement进行执行SQL，且能预编译SQL。

PreparedStatement的优点

-   Statement拼串和SQL注入问题（ SQL预编译能 防止SQL注入与提高性能）
-   PreparedStatement操作Blob的数据，而Statement做不到。
-   Preparedstatement可以实现更高效的批量操作。

PreparedStatement 与Statement 区别

-   PreparedStatement是预编译的SQL语句，效率高于Statement。
-   PreparedStatement支持?操作符，相对于Statement更加灵活。
-   PreparedStatement可以防止SQL注入，安全性高于Statement。
-   CallableStatement适用于执行存储过程。

请看下面的注释【1】、【2】 从而看懂代码

步骤：

1、获取连接Connection&#x20;

2、使用连接获取 PreparedStatement

3、填充点位符

4、调用.execute() 方法去执行SQL

```java
package com.zhuangjie.jdbc.utils;


import com.zhuangjie.jopo.User;

import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class JDBCUtils {
    //执行增删改操作
    public static boolean sqlPost(String sql,Object ...args) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i+1,args[i]);
            }
            // execute 方法，如果是查询有ResultSet的就返回true，如果是增删改操作就返回false
            preparedStatement.execute();
            return true;
        }catch (Exception e) {
            System.out.println("出错了");
            return false;
        }finally {
            close(connection,preparedStatement);
        }

    }



}


```

#### \[\_2.3\_] 查询操作

步骤：

1、获取连接Connection&#x20;

2、使用连接获取 PreparedStatement

3、填充点位符

4、调用executeQuery();  方法去执行SQL, 得到结果集ResultSet

5、从ResultSet中获取结果

ResultSet对象维护了一个游标，指向当前的数据行。开始的时候这个游标指向的是第一行。如果调用了ResultSet的next()方法游标会下移一行，如果没有更多的数据了，next()方法会返回false。可以在for循环中用它来遍历数据集。

一共有三种ResultSet对象。

-   **ResultSet.TYPE\_FORWARD\_ONLY：这是默认的类型，它的游标只能往下移。**
-   **ResultSet.TYPE\_SCROLL\_INSENSITIVE：游标可以上下移动，一旦它创建后，数据库里的数据再发生修改，对它来说是透明的。**
-   **ResultSet.TYPE\_SCROLL\_SENSITIVE：游标可以上下移动，如果生成后数据库还发生了修改操作，它是能够感知到的。**

ResultSet有两种并发类型。

-   ResultSet.CONCUR\_READ\_ONLY:**ResultSet是只读的，这是默认类型**。
-   ResultSet.CONCUR\_UPDATABLE:**我们可以使用ResultSet的更新方法来更新里面的数据。**

将上面的操作封装为统一的方法：

```java
package com.zhuangjie.jdbc.utils;


import com.zhuangjie.jopo.User;

import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class JDBCUtils {

    //执行查询操作
    // 要操作数据库对应的java的实体类 、 SQL语句、SQL中的占位符对应的值
    public static<T> List<T> sqlGet(Class<T> tClass, String sql, Object ...args) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement(sql);
            //填充占位符
            for (int i = 0  ; i < args.length; i++) {
                preparedStatement.setObject(i+1,args[i]);
            }
            //执行查询操作
            resultSet = preparedStatement.executeQuery();
            //遍历ResultSet后进行ORM（对象关系映射），后得到的实体集合，用到了反射 
            ArrayList<T> ts = new ArrayList<>();
            //ResultSetMetaData 用于检索此 ResultSet对象列的数量，类型和属性。
            ResultSetMetaData metaData = resultSet.getMetaData();
            //有几条数据
            int columnCount = metaData.getColumnCount();
            while (resultSet.next()) { //指针后移（必须后移），返回是否有下一位元素      
                //创建一行要封闭的空数据对象
                T t = tClass.newInstance();
                //对空数据对象进行封装
                for (int i = 0; i < columnCount; i++) {
                    //getColumnLabel 与getColumnName区别是：getColumnName忽略别名，获取真实列名，getColumnLabel优先获取别名
                    String columnName = metaData.getColumnName(i + 1);
                    Object columnValue = resultSet.getObject(i + 1);
                    Field declaredField = t.getClass().getDeclaredField(JDBCUtils.toHump(columnName));
                    declaredField.setAccessible(true);
                    declaredField.set(t,columnValue);
                }
                ts.add(t);

            }
            return ts;
        }catch (Exception e) {
            System.out.println("出错了:"+e.getMessage());
            return null;
        }finally {
            close(connection,preparedStatement,resultSet);
        }

    }
    //作用示例：user_id 转为userId
    private static  String toHump(String name) {
        String[] arr = name.split("_");
        String newStr = arr[0];
        for (int i = 1; i < arr.length; i++) {
            newStr += arr[i].substring(0, 1).toUpperCase() + arr[i].substring(1);
        }
        return newStr;

    }


}

```

### - 面试题：execute，executeQuery，executeUpdate的区别是什么？

> execute，executeQuery，executeUpdate的区别是什么？

-   Statement的execute(String query)方法用来**执行任意的SQL查询**，如果查询的结果是一个ResultSet，这个方法就返回true值。如果结果不是ResultSet，比如insert或者update查询，它就会返回false。我们可以通过它的getResultSet方法来获取ResultSet，或者通过getUpdateCount()方法来获取更新的记录条数。
-   Statement的executeQuery(String query)接口用来执行select查询，并且返回ResultSet。即使查询不到记录返回的ResultSet也不会为null。我们通常使用executeQuery**来执行查询语句**，这样的话如果传进来的是insert或者update语句的话，它会抛出错误信息为 “executeQuery method can not be used for update”的java.util.SQLException。
-   Statement的executeUpdate(String query)方法**用来执行insert或者update/delete（DML）语句，或者 什么也不返回DDL语句**。返回值是int类型，如果是DML语句的话，它就是更新的条数，如果是DDL的话，就返回0。
-   只有当你不确定是什么语句的时候才应该使用execute()方法，否则应该使用executeQuery或者executeUpdate方法。

### +对Blob列的插入与读取

**Blob类型**

-   MySQL中，BLOB是一个二进制大型对象，是一个可以存储大量数据的容器，它能容纳不同大小的数据
-   插入BLOB类型的数据必须使用PreparedStatement,因为BLOB类型的数据无法使用字符串拼接写的。
-   MySQL的四种BLOB类型（除了在存储的最大信息量上不同外，他们是等同的）
-   实际使用中根据需要存入的数据大小定义不同的BLOB类型。
-   需要注意的是：如果存储的文件过大，数据库的性能会下降。

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16570986297201657098629065.png)

（1）Blob列的插入操作

```java
package com.zhuangjie.jdbc;

import com.zhuangjie.jdbc.utils.JDBCUtils;
import org.junit.Test;

import java.io.*;
import java.sql.*;

public class _3_Blob {
    //blob列插入操作: blob对应的列是输入流对象，其它的和正常的插入操作无异
    public static void main(String[] args) throws IOException, SQLException {
        FileInputStream is = new FileInputStream(new File("D:\\software\\迅雷极简融合版ThunderS_20201121_Green.zip"));
        Connection connection = JDBCUtils.getConnection();
        String sql = "update user set head=? where id=?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setBlob(1,is);
        preparedStatement.setObject(2,1);
        preparedStatement.execute();
        System.out.println("sql执行完成");

        is.close();

    }
}


```

（2）Blob列的读取操作：

```java
package com.zhuangjie.jdbc;

import com.zhuangjie.jdbc.utils.JDBCUtils;
import org.junit.Test;

import java.io.*;
import java.sql.*;

public class _3_Blob {
    //blob列读取操作
    @Test
    public void read() throws SQLException, IOException {
        Connection connection = JDBCUtils.getConnection();
        String sql = "select head from user where id=?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1,1);
        ResultSet resultSet = preparedStatement.executeQuery();
        FileOutputStream os = new FileOutputStream(new File("D:\\1.png"));
        if (resultSet.next()) {
            //获取Blob列为Blob对象，然后再将blob对象转为输入流对象，通过操作输入流对象可以将存储的文件保存为数据
            Blob blob = resultSet.getBlob(1);
            InputStream in = blob.getBinaryStream();
            byte[] bytes = new byte[1024];
            int readLen = 0;
            while ((readLen = in.read(bytes)) > 0) {
                os.write(bytes,0,readLen);
            }
            in.close();
            os.close();

        }

    }
}

```

注意事项：默认最大的blob存储的大小 4194304，超过会报以下错误：`Packet for query is too large (10384984 > 4194304). You can change this value on the server by setting the max_allowed_packet' variable.
false`,   那么在mysql的安装目录下，找my.ini文件加上如下的配置参数：max\_allowed\_packet=16M。同时注意：修改了my.ini文件之后，需要重新启动mysq服
务。

### + 批量插入

有三种优化方式：

第一种方式：利用PreparedStatement有预先编译的功能, 提高SQL的执行效率

第二种方式优化点：开启批量提交（先缓存够了，再提交）

第三种方式优化点：关闭自动提交，即

connection.setAutoCommit(false); //关闭自动提交

批量插入操作

connection.commit(); //提交

补充说明：其实第二种跟第三种本质 没有太大的区别，我们将第二种批量提交的大小改大点，也能跟第三种差不多。

```java
package com.zhuangjie.jdbc;

import com.zhuangjie.jdbc.utils.JDBCUtils;
import org.junit.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class _4_批量插入 {

    /*
        第一种方式：利用PreparedStatement有预先编译的功能, 提高SQL的执行效率
        而最原始方式是调用我们封装的增删改方法用for循环添加，这是效率最低下的一种方式。
     */
    @Test
    public void inserts1() throws Exception{
        Connection connection = null;
        PreparedStatement ps = null;
        try {
            long begin = System.currentTimeMillis();

            connection = JDBCUtils.getConnection();
            String sql = "insert into user(id,name) values(?,?)";
            ps = connection.prepareStatement(sql);
            for (int i = 0; i < 100000; i++) {
                ps.setObject(1,i+1);
                ps.setObject(2,"小庄"+(i+1));
                ps.execute();
            }
            long end = System.currentTimeMillis();
            System.out.println("耗时："+(end - begin)+"ms~");
        }catch (Exception e) {
            System.out.println("出错了:"+e.getMessage());
        }finally {
            JDBCUtils.close(connection,ps);
        }

    }
    /*
        第二种方式优化点：开启批量提交：
        批量插入的方式三：
            1.addBatch()、executeBatch()、clearBatch()
            2.mysq1服务器默认是关闭批处理的，我们需要通过一个参数，让mysq1开启批处理的支持。
              ?rewriteBatchedStatements=true 写在配置文件的ur1后面
            3.使用更新的mysq1驱动：mysql-connector-java-5.1.37-bin.jar
     */
    //耗时：18915ms~
    @Test
    public void inserts2() throws Exception{
        Connection connection = null;
        PreparedStatement ps = null;
        try {
            long begin = System.currentTimeMillis();
            connection = JDBCUtils.getConnection();
            String sql = "insert into user(id,name) values(?,?)";
            ps = connection.prepareStatement(sql);
            int sql_count = 0;
            for (int i = 0; i < 1000000; i++) {
                ps.setObject(1,i+1);
                ps.setObject(2,"小庄"+(i+1));
                sql_count++;
                ps.addBatch();
                if (sql_count >= 500) {
                    ps.executeBatch();
                    ps.clearBatch();
                    sql_count = 0;
                }
            }
            ps.executeBatch();
            ps.clearBatch();

            long end = System.currentTimeMillis();
            System.out.println("耗时："+(end - begin)+"ms~");
        }catch (Exception e) {
            System.out.println("出错了:"+e.getMessage());
        }finally {
            JDBCUtils.close(connection,ps);
        }

    }

    /*
    开启批量提交：
        批量插入的方式三：
            1.addBatch()、executeBatch()、clearBatch()
            2.mysq1服务器默认是关闭批处理的，我们需要通过一个参数，让mysq1开启批处理的支持。
              ?rewriteBatchedStatements=true 写在配置文件的ur1后面
            3.使用更新的mysq1驱动：mysql-connector-java-5.1.37-bin.jar
    第三种方式：优化点是，关闭自动提交
    connection.setAutoCommit(false);
    全部执行完后，再
    connection.commit();
     */
    @Test
    public void inserts3() throws Exception{
        Connection connection = null;
        PreparedStatement ps = null;
        try {
            long begin = System.currentTimeMillis();
            connection = JDBCUtils.getConnection();
            String sql = "insert into user(id,name) values(?,?)";
            ps = connection.prepareStatement(sql);
            int sql_count = 0;
            connection.setAutoCommit(false);
            for (int i = 0; i < 1000000; i++) {
                ps.setObject(1,i+1);
                ps.setObject(2,"小庄"+(i+1));
                sql_count++;
                ps.addBatch();
                if (sql_count >= 500) {
                    ps.executeBatch();
                    ps.clearBatch();
                    sql_count = 0;
                }
            }
            ps.executeBatch();
            ps.clearBatch();
            connection.commit();
            long end = System.currentTimeMillis();
            System.out.println("耗时："+(end - begin)+"ms~");
        }catch (Exception e) {
            System.out.println("出错了:"+e.getMessage());
        }finally {
            JDBCUtils.close(connection,ps);
        }

    }
}

```

### \[\_3\_] 事务

哪些操作会导致数据的自动提交？

1、DDL操作一旦执行，都会自动提交。set autocommit=false对DDL操作失效

2、DML默认情况下，一旦执行，就会自动提交。我们可以通过set autocommit=false的方式取消DML操作的自动提交。

3、在默认情况下（autocommit = true），在关闭连接时，也会触发自动的提交数据

综上，可以得到，我们在执行DML前，需要 `set autocommit=false` 然后再执行DML操作(这些DML操作用的都是同一个Connect)，完成后再`commit`,当出现异常时，我们需要捕获，并进行`rollback` ，最后在finally中关闭链接。

注意事项：如果我们提交事务后，如果不关闭，比如返回给数据库连接池，那么我们需要恢复为默认提交了。因为你修改了，别人人家也会认为是自动提交的，所以你要恢复你设置的东西。

```java
package com.zhuangjie.jdbc;

import com.zhuangjie.jdbc.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class _5_事务 {
    public static void update(Connection connection,String sql,Object ...args) {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i+1,args[i]);
            }
            preparedStatement.execute();

        } catch (SQLException throwables) {
            System.out.println("出错了："+throwables.getMessage());
            JDBCUtils.close(null,preparedStatement);
        }

    }

    public static void main(String[] args) throws SQLException {

        Connection connection = null;
        try {
            connection = JDBCUtils.getConnection();
            connection.setAutoCommit(false);
            String sql = "update user set balance= balance + ? where id=?";
            update(connection,sql,-100,1);
            // int i = 1/0;
            update(connection,sql,100,2);
            connection.commit();
            System.out.println("已提交~");
        }catch (Exception e) {
            connection.rollback();
            System.out.println("出错了，正在回滚~");
        }finally {
            //恢复为自动提交
            connection.setAutoCommit(true);
            if (connection != null) {
                connection.close();
            }
        }


    }
}

```

### \[\_4\_] 事务在并发中存在的问题

脏读：读取了人家未提交的数据，且最后人家回滚了。

-   脏读还不懂？
    > A事务读取B事务尚未提交的数据，此时如果B事务发生错误并执行回滚操作，那么A事务读取到的数据就是脏数据。就好像原本的数据比较干净、纯粹，此时由于B事务更改了它，这个数据变得不再纯粹。这个时候A事务立即读取了这个脏数据，但事务B良心发现，又用回滚把数据恢复成原来干净、纯粹的样子，而事务A却什么都不知道，最终结果就是事务A读取了此次的脏数据，称为脏读。
    > 这种情况常发生于转账与取款操作中：
    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16571796550001657179654375.png)

不可重复读：前后两次读取的内容不同

-   不可重复读还不懂？

    事务A在执行读取操作，由整个事务A比较大，前后读取同一条数据需要经历很长的时间 。而在事务A第一次读取数据，比如此时读取了小明的年龄为20岁，事务B执行更改操作，将小明的年龄更改为30岁，此时事务A第二次读取到小明的年龄时，发现其年龄是30岁，和之前的数据不一样了，也就是数据不重复了，系统不可以读取到重复的数据，成为不可重复读。

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16571797369971657179736278.png)

幻读：前后多次读取，数据总量不一致

-   幻读还不懂？

    事务A在执行读取操作，需要两次统计数据的总量，前一次查询数据总量后，此时事务B执行了新增数据的操作并提交后，这个时候事务A读取的数据总量和之前统计的不一样，就像产生了幻觉一样，平白无故的多了几条数据，成为幻读。

    ![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16571797870061657179786873.png)

### \[\_5\_] 事务的四大特性

1、**原子性**：事务包含的所有数据库操作要么全部成功，要不全部失败回滚

2、**一致性**：一个事务执行之前和执行之后都必须处于一致性状态。拿转账来说，假设用户A和用户B两者的钱加起来一共是5000，那么不管A和B之间如何转账，转几次账，事务结束后两个用户的钱相加起来应该还得是5000，这就是事务的一致性。即没有无端地多或少。

3、**隔离性**：一个事务未提交的业务结果是否对于其它事务可见。级别一般有：**read\_uncommit，read\_commit，read\_repeatable，Serializable 串行化访问**。

读未提交会导致脏读、不可重复读与幻读

读已提交可以解决脏读

重复读锁住了行，使行的内容可以重复读

串行化锁住了表，就之前是可以多个事务并行的，但设置为串行化后就只能一个一个事务地执行了，解决了幻读

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16571806839971657180683669.png)

补充：MySQL的默认隔离级别就是Repeatable（重复读）,Oracle默认Read committed（读已提交），最高级别Serializable&#x20;

4、**持久性**：一个事务一旦被提交了，那么对数据库中数据的改变就是永久性的，即便是在数据库系统遇到故障的情况下也不会丢失提交事务的操作。

### + 事务隔离性的验证

-   每启动一个 mysql 程序, 就会获得一个单独的数据库连接. 每个数据库连接都有一个全局变量 @@tx\_isolation, 表示当前的事务隔离级别。
-   查看当前的隔离级别:&#x20;
    ```text
    SELECT @@tx_isolation;
    ```
-   设置当前 mySQL 连接的隔离级别: &#x20;
    ```text
    // 全局的
    mysql> set global transaction isolation level read committed;
    // 当前会话
    mysql> set session transaction isolation level read committed;
    ```

不想用root登录操作？

-   创建mysql数据库用户：
    ```text
    create user tom identified by 'abc123';
    ```
-   授予权限
    ```text
    #授予通过网络方式登录的tom用户，对所有库所有表的全部权限，密码设为abc123.
    grant all privileges on *.* to tom@'%'  identified by 'abc123'; 

     #给tom用户使用本地命令行方式，授予atguigudb这个库下的所有表的插删改查的权限。
    grant select,insert,delete,update on atguigudb.* to tom@localhost identified by 'abc123'; 

    ```

验证“读已提交”

![](https://fastly.jsdelivr.net/gh/18476305640/typora@master/image/16571909151631657190915010.png)

### \[\_6\_] 在Java代码中开启指定的隔离级别

获取到连接后，在connection.setAutoCommit(false); 前，进行调用Connection的方法：

connection.setTransactionIsolation(Connection.TRANSACTION\_REPEATABLE\_READ);&#x20;

### \[\_7\_> 数据库连接池

#### \[\_7.1\_] C3P0数据库连接池

-   JDBC 的数据库连接池使用 javax.sql.DataSource 来表示，DataSource 只是一个接口，该接口通常由服务器(Weblogic, WebSphere, Tomcat)提供实现，也有一些开源组织提供实现：
    -   **DBCP** 是Apache提供的数据库连接池。tomcat 服务器自带dbcp数据库连接池。**速度相对c3p0较快**，但因自身存在BUG，Hibernate3已不再提供支持。
    -   **C3P0**是一个开源组织提供的一个数据库连接池，**速度相对较慢，稳定性还可以。** hibernate官方推荐使用
    -   **Proxool** 是sourceforge下的一个开源项目数据库连接池，有监控连接池状态的功能，**稳定性较c3p0差一点**
    -   **BoneCP** 是一个开源组织提供的数据库连接池，速度快
    -   **Druid** 是阿里提供的数据库连接池，据说是集DBCP 、C3P0 、Proxool 优点于一身的数据库连接池，但是速度不确定是否有BoneCP快
-   DataSource 通常被称为数据源，它包含连接池和连接池管理两个部分，习惯上也经常把 DataSource 称为连接池
-   **DataSource用来取代DriverManager来获取Connection，获取速度快，同时可以大幅度提高数据库访问速度。**
-   特别注意：
    -   数据源和数据库连接不同，数据源无需创建多个，它是产生数据库连接的工厂，因此**整个应用只需要一个数据源即可。**
    -   当数据库访问结束后，程序还是像以前一样关闭数据库连接：conn.close(); 但conn.close()并没有关闭数据库的物理连接，它仅仅把数据库连接释放，归还给了数据库连接池。

导入jar包

`c3p0-0.9.1.2.jar`

`mchange-commons-java-0.2.11.jar`  不导入这个可能会报错，是依赖关系

第一种方式：硬编码

```java
package com.zhuangjie.jdbc;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.junit.Test;

import javax.sql.DataSource;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

public class _6_c3p0数据库连接池 {
    //第一种方式：直接使用Java代码的方式
    public static void main(String[] args) throws PropertyVetoException, SQLException, InterruptedException {
        ComboPooledDataSource cpds = new ComboPooledDataSource();
        cpds.setDriverClass("com.mysql.jdbc.Driver");
        cpds.setJdbcUrl("jdbc:mysql://localhost:3306/test");
        cpds.setUser("root");
        cpds.setPassword("3333");
        Connection connection = cpds.getConnection();
        System.out.println(connection);

        System.out.println("被占用的连接数： " + cpds.getNumBusyConnections());
        System.out.println("连接池中的总连接数：" + cpds.getNumConnections());
        /*输出：
            被占用的连接数： 1
            连接池中的总连接数：3
         */
        connection.close(); //将连接返回到数据库连接池中
        Thread.sleep(2000); //等待关闭
        System.out.println("--");
        System.out.println("被占用的连接数： " + cpds.getNumBusyConnections());
        System.out.println("连接池中的总连接数：" + cpds.getNumConnections());
        /*输出：
            被占用的连接数： 0
            连接池中的总连接数：3
         */
        cpds.close(); // 关闭数据库连接池
        
    }

}

```

第二种方式：使用配置文件的方式（推荐）

1.  导入上面说的两个jar包后，写配置文件，
2.  如果在普通的java项目中，将c3p0-config.xml文件放在src下；如果是maven项目，把c3p0-config.xml文件放在resources下；

```java
package com.zhuangjie.jdbc;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.junit.Test;

import javax.sql.DataSource;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

public class _6_c3p0数据库连接池 {
    //使用C3P0数据库连接池的配置文件方式，获取数据库的连接：推荐
    //注意不能把创建连接池的对象放在获取连接的方法中，不然每一次获取就会创建连接池，这会很无语~
    private static DataSource cpds = new ComboPooledDataSource("c3p0");//配置文件中写连接源配置名称
    //作为一个静态的方法，让其它方法来获取连接，解耦作用
    public static Connection getConnection() throws SQLException, InterruptedException {
        Connection conn = cpds.getConnection();
        Thread.sleep(2000); //等待连接创建完成
        System.out.println("被占用的连接数： " + ((ComboPooledDataSource)cpds).getNumBusyConnections());
        System.out.println("连接池中的总连接数：" + ((ComboPooledDataSource)cpds).getNumConnections());
        return conn;
    }
}

```

#### \[\_7.2\_] Druid数据库连接

Druid是阿里巴巴开源平台上一个数据库连接池实现，它结合了C3P0（效率比较小，但稳定）、DBCP（效率相对C3P0好，但有Bug）、Proxool等DB池的优点，同时加入了日志监控，可以很好的监控DB池连接和SQL的执行情况，可以说是针对监控而生的DB连接池，**可以说是目前最好的连接池之一。**

1、引入  jar包：

druid-1.1.16.jar

2、druid.properties 配置

```java
url=jdbc:mysql://localhost:3306/test?rewriteBatchedStatements=true
username=root
password=3333
driverClassName=com.mysql.jdbc.Driver

initialSize=10
maxActive=20
maxWait=1000
filters=wall
```

3、java代码操作创建连接池：

```java
package com.zhuangjie.jdbc;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import org.junit.Test;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class _7_Druid数据库连接池 {
    private static DataSource dataSource;
    static {
        //【1】创建Druid数据库连接池对象
        try {
            Properties properties = new Properties();
            InputStream resourceAsStream = _7_Druid数据库连接池.class.getClassLoader().getResourceAsStream("druid.properties");
            properties.load(resourceAsStream);
            dataSource = DruidDataSourceFactory.createDataSource(properties);
        }catch (Exception e) {
            System.out.println("创建数据库连接池："+e.getMessage());
        }
    }
    /*
        【2】获取池中的连接对象
     */
    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return connection;
    }
    //【3】
    @Test
    public void MyTest() throws Exception {
        //获取一个连接对象
        Connection connection = _7_Druid数据库连接池.getConnection();
        System.out.println(connection);
        //返还连接到池中
        connection.close();

    }
}

```

### + apache的DbUtils工具

> commons-dbutils 是 Apache 组织提供的一个开源 JDBC工具类库，它是对JDBC的简单封装，学习成本极低，并且使用dbutils能极大简化jdbc编码的工作量，同时也不会影响程序的性能。

1、引入jar包：commons-dbutils-1.3.jar

2、进行 "增删改查" 操作

```java
package com.zhuangjie.jdbc;

import com.zhuangjie.jopo.User;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class _8_DBUtils {
    //增
    @Test
    public void insertTest() throws SQLException {
        Connection connection = _7_Druid数据库连接池.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        BeanHandler<User>  rsh= new BeanHandler<>(User.class);
        String sql = "insert into user(id,name)values(?,?)";
        int i = queryRunner.update(connection, sql, 5, "小宝");
        System.out.println("影响行数="+i);
        DbUtils.close(connection);
    }
    //删
    @Test
    public void deleteTest() throws SQLException {
        Connection connection = _7_Druid数据库连接池.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        BeanHandler<User>  rsh= new BeanHandler<>(User.class);
        String sql = "delete from user where id = ?";
        int i = queryRunner.update(connection, sql, 5);
        System.out.println("影响行数="+i);
        DbUtils.close(connection);
    }
    //改
    @Test
    public void updateTest() throws SQLException {
        Connection connection = _7_Druid数据库连接池.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        BeanHandler<User>  rsh= new BeanHandler<>(User.class);
        String sql = "update user set name=? where id = ?";
        int i = queryRunner.update(connection, sql, "大聪明",2);
        System.out.println("影响行数="+i);
        DbUtils.close(connection);
    }

    //查询一条记录
    @Test
    public void queryOnTest() throws SQLException {
        Connection connection = _7_Druid数据库连接池.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        BeanHandler<User>  rsh= new BeanHandler<>(User.class);
        String sql = "select * from user where id = ?";
        User query = queryRunner.query(connection, sql, rsh, 1);
        System.out.println(query);
        DbUtils.close(connection);
    }
    //查询多条记录
    @Test
    public void queryListTest() throws SQLException {
        Connection connection = _7_Druid数据库连接池.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        BeanListHandler<User> rsh = new BeanListHandler<>(User.class);
        String sql = "select * from user where id < 5";
        List<User> query = queryRunner.query(connection, sql, rsh);
        System.out.println(query);
        DbUtils.close(connection);
    }
}

```
