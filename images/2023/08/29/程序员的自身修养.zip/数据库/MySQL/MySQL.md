# MySQL

教程视频（B站）：[https://www.bilibili.com/video/BV1iq4y1u7vj](https://www.bilibili.com/video/BV1iq4y1u7vj "https://www.bilibili.com/video/BV1iq4y1u7vj")

[MySQL基础篇](MySQL基础篇/MySQL基础篇.md "MySQL基础篇")

[MySQL高级篇](MySQL高级篇/MySQL高级篇.md "MySQL高级篇")
