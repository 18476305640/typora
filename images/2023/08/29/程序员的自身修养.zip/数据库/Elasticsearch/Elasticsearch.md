# Elasticsearch

## \[1] ElasticSearch基本内容

### 1.1 ElasticSearch简介

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/15/1665801878568.png)

基本概念：`index库` > `type表` > `document文档(记录)`

1.  **index索引** （db）

动词：相当于mysql的insert

名词：相当于mysql的db

1.  **Type类型**（数组）

在index中，可以定义一个或多个类型

类似于mysql的表，每一种类型的数据放在一起

1.  **Document文档** （数组中的对象, 类似于表记录）

保存在某个index下，某种type的一个数据document，文档是json格式的，document就像是mysql中的某个table里面的内容。每一行对应的列叫属性

![2022-10-15](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/15/1665801928386.png "2022-10-15")

> 为什么ES搜索快？倒排索引
>
> **保存的记录**
>
> -   红海行动
> -   探索红海行动
> -   红海特别行动
> -   红海记录片
> -   特工红海特别探索
>
> **将内容分词就记录到索引中**
>
> | 词   | 记录        |
> | --- | --------- |
> | 红海  | 1,2,3,4,5 |
> | 行动  | 1,2,3     |
> | 探索  | 2,5       |
> | 特别  | 3,5       |
> | 纪录片 | 4,        |
> | 特工  | 5         |
>
> **检索：**
>
> 1）、红海特工行动？
>
> 解析：1\~5都会被查出来 ，但最终哪个匹配呢？ 查出后计算相关性得分：1，2，3，5号记录命中了2次，以 3号本身才有3个单词，匹配数为2，所以是2/3，故这些记录的评分如下：
>
> `1`:  2/2
>
> `2`：2/3
>
> `3`:  2/3
>
> `5`:  2/4
>
> `4`:  1/2

> 关系型数据库中两个数据表示是独立的，即使他们里面有相同名称的列也不影响使用，但ES中不是这样的。elasticsearch是基于Lucene开发的搜索引擎，而ES中不同type下名称相同的filed最终在Lucene中的处理方式是一样的。
>
> -   两个不同type下的两个user\_name，在ES同一个索引下其实被认为是同一个filed，你必须在两个不同的type中定义相同的filed映射。否则，不同type中的相同字段名称就会在处理中出现冲突的情况，导致Lucene处理效率下降。
> -   去掉type就是为了提高ES处理数据的效率。
> -   Elasticsearch 7.xURL中的type参数为可选。比如，索引一个文档不再要求提供文档类型。
> -   Elasticsearch 8.x不再支持URL中的type参数。 &#x20;
>
>     解决：将索引从多类型迁移到单类型，每种类型文档一个独立索引

### 1.2 安装elastic search

dokcer中安装ElasticSearch

1.  下载ealastic search（存储和检索）和kibana（可视化检索）
    ```bash
    docker pull elasticsearch:7.4.2
    docker pull kibana:7.4.2
    # 版本要统一

    ```
2.  配置
    ```bash
    # 将docker里的目录挂载到linux的/mydata目录中
    # 修改/mydata就可以改掉docker里的
    mkdir -p /mydata/elasticsearch/config
    mkdir -p /mydata/elasticsearch/data

    # es可以被远程任何机器访问
    echo "http.host: 0.0.0.0" >/mydata/elasticsearch/config/elasticsearch.yml

    # 递归更改权限，es需要访问
    chmod -R 777 /mydata/elasticsearch/
    ```
3.  启动Elastic search
    ```bash
    # 9200是用户交互端口 9300是集群心跳端口
    # -e指定是单阶段运行
    # -e指定占用的内存大小，生产时可以设置32G
    docker run --name elasticsearch -p 9200:9200 -p 9300:9300 \
    -e  "discovery.type=single-node" \
    -e ES_JAVA_OPTS="-Xms64m -Xmx512m" \
    -v /mydata/elasticsearch/config/elasticsearch.yml:/usr/share/elasticsearch/config/elasticsearch.yml \
    -v /mydata/elasticsearch/data:/usr/share/elasticsearch/data \
    -v  /mydata/elasticsearch/plugins:/usr/share/elasticsearch/plugins \
    -d elasticsearch:7.4.2 


    # 设置开机启动elasticsearch
    docker update elasticsearch --restart=always


    ```
    因为容器里的文件映射到了外面，所以删除容器和新建容器数据还在

    第一次查docker ps启动了，第二次查的时候发现关闭了，docker logs elasticsearch

    [http://192.168.56.10:9200](http://192.168.56.10:9200 "http://192.168.56.10:9200")

    数据挂载到外面，但是访问权限不足

    把/mydata/elasticsearch下文件夹的权限设置好，上面已经设置过了
    ```bash
    docker save -o kibana.tar kibana:7.4.2 
    docker load -i kibana.tar 
    # 如何通过其他工具链接ssh
    # vim etc/ssh/sshd_config  #修改 PasswordAuthentication yes
    systemctl restart sshd.service  #或 service sshd restart

    ```
4.  启动kibana
    ```bash
    # kibana指定了了ES交互端口9200  # 5600位kibana主页端口
    docker run --name kibana -e ELASTICSEARCH_HOSTS=http://192.168.87.101:9200 -p 5601:5601 -d kibana:7.4.2

    # 设置开机启动kibana
    docker update kibana  --restart=always
    ```
5.  测试

    查看elasticsearch版本信息： <http://192.168.87.101:9200>
    ```json
    {
      "name": "1540a9d15a77",
      "cluster_name": "elasticsearch",
      "cluster_uuid": "485etaTXTROdMfBm-HLN1w",
      "version": {
        "number": "7.4.2",
        "build_flavor": "default",
        "build_type": "docker",
        "build_hash": "2f90bbf7b93631e52bafb59b3b049cb44ec25e96",
        "build_date": "2019-10-28T20:40:44.881551Z",
        "build_snapshot": false,
        "lucene_version": "8.2.0",
        "minimum_wire_compatibility_version": "6.8.0",
        "minimum_index_compatibility_version": "6.0.0-beta1"
      },
      "tagline": "You Know, for Search"
    }
    ```
    显示elasticsearch 节点信息 [http://192.168.87.101:9200/\_cat/nodes](http://192.168.87.101:9200/_cat/nodes "http://192.168.87.101:9200/_cat/nodes")
    ```bash
    127.0.0.1 14 99 25 0.29 0.40 0.22 dilm * 66718a266132

    66718a266132代表上面的结点
    *代表是主节点
    ```
    **kibana**

    访问Kibana：[http://192.168.87.101:5601/app/kibana](http://192.168.87.101:5601/app/kibana "http://192.168.87.101:5601/app/kibana")

### 1.3 初步检索

<https://doc.yonyoucloud.com/doc/mastering-elasticsearch/index.html>

ES支持通过 HTTP 向 [RESTful](https://so.csdn.net/so/search?q=RESTful\&spm=1001.2101.3001.7020 "RESTful") API 请求进行交互

#### 基本操作

> 查询的信息说明：当我们查询一条信息时：
>
> GET [http://192.168.87.101:9200/school/student/3](http://192.168.87.101:9200/school/student/3 "http://192.168.87.101:9200/school/student/3") HTTP/1.1
>
> 输出：
>
> ```json
> {
>   "_index": "school",
>   "_type": "student",
>   "_id": "3",
>   "_version": 7,
>   "_seq_no": 11,
>   "_primary_term": 1,
>   "found": true,
>   "_source": {
>     "name": "zhuangjie",
>     "age": 23
>   }
> }
> ```
>
> `_version` : 每次操作成功且内容改变后，+1
>
> `_seq_no` ：每次操作成功，就算值没有改变（一条插入操作执行了多次）也会 +1
>
> `_seq_no` 和 `_primary_term` 乐观更新。sequence number 和 the primary term 独一无二地标识一次变动。

#### **更新文档**

前面学习了下面两种更新文档的方式：

新的方式，声明式的更新文档：与上面不同的是，需要在后面加`_update` 且，更新文档的值放在json下doc下，如果不放在doc下会报错。且这种操作`_version`和`_seq_no`都不变。

如果连接执行再次更新操作，那第二次肯定是没意义的，那下面就会返回`noop`标志

#### **删除文档与索引**

> 注意：elasticsearch并没有提供删除类型的操作，只提供了删除索引和文档的操作。

#### **ES的批量操作——bulk**

批量插入

像这种操作，我们要使用`Kibana` 进行请求了（注意下面二行一插入）

![2022-10-16](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/16/1665930712744.png "2022-10-16")

[http://192.168.87.101:5601/app/kibana#/dev\_tools](http://192.168.87.101:5601/app/kibana#/dev_tools "http://192.168.87.101:5601/app/kibana#/dev_tools")

> PS：这里的批量操作，当发生某一条执行发生失败时，其他的数据仍然能够接着执行，也就是说彼此之间是独立的。

> 实例2：对于整个索引执行批量操作
>
> ```http
> POST /_bulk
> {"delete":{"_index":"website","_type":"blog","_id":"123"}}
> {"create":{"_index":"website","_type":"blog","_id":"123"}}
> {"title":"my first blog post"}
> {"index":{"_index":"website","_type":"blog"}}
> {"title":"my second blog post"}
> {"update":{"_index":"website","_type":"blog","_id":"123"}}
> {"doc":{"title":"my updated blog post"}}
> ```

#### 进阶检索准备

测试样本导入

准备了一份顾客银行账户信息的虚构的JSON文档样本。每个文档都有下列的schema（模式）。

[https://raw.githubusercontent.com/18476305640/typora/master/images/2022/10/16/accounts.json](https://raw.githubusercontent.com/18476305640/typora/master/images/2022/10/16/accounts.json "https://raw.githubusercontent.com/18476305640/typora/master/images/2022/10/16/accounts.json") ，导入测试数据

刚导入了1000条

#### {}  检索文档

-   通过REST request uri 发送搜索参数 （uri +检索参数）；
    ```http
    /*
    q=* # 查询所有
    sort # 排序字段
    asc #升序
    */
    GET bank/_search?q=*&sort=account_number:asc

    ```
-   通过REST request body 来发送它们（uri+请求体）；
    ```http
    GET /bank/_search
    {
      "query": { "match_all": {} }, #最简单的查询，匹配所有文档，给它们一个_score .1.0
      "sort": [
        { "account_number": "asc" },
        { "balance":"desc"}
      ]
    }
    ```
    等价于空查询，查询索引库中所有的文档：
    ```http
    GET /bank/_search
    {

    }
    ```
    > Postman中get不能携带请求体，我们变为post也是一样的，我们post一个json风格的查询请求体到\_search

#### query/match 【拆分匹配查询】

如果是非字符串，会进行精确匹配。如果是字符串，会进行全文检索

精确匹配

字符串全文检索

> 如果`match` 匹配的是字符串，就进行分词匹配，即`a b` 会找出包含a或b的项。如果不想进行分词，找的是不可分的`a b` 那怎么办呢？请看下面的`query/match_phrase`

#### query/match\_phrase 【不拆分匹配】

\[不拆分匹配]

结果：

#### query/multi\_match 【多字段分词匹配】

#### query/bool

#### —/must 复合查询

#### —/filter【结果过滤】

-   must 贡献得分
-   should 贡献得分
-   must\_not 不贡献得分
-   filter 不贡献得分

#### ——/range 【范围查询】

![2022-10-18](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/18/1666097309331.png "2022-10-18")

#### ——/term 【精确非文本查询】

和match一样。匹配某个属性的值。

-   全文检索字段用match，
-   对于精确的，如年龄，这种就可以使用term，而对于字符匹配就不要使用term

es默认存储text值时用分词分析，所以要搜索text值，使用match

-   字段.keyword：要一一匹配到，不完整的字符串那可匹配不了，如`a` 去匹配`a b` 那就匹配不了
-   match\_phrase：子串就可以，比如拿`a b` 去匹配`a b c`

term演示：

![2022-10-18](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/18/1666096833356.png "2022-10-18")

### 1.4 数据分析

> 前面介绍检索，但还没介绍分析

聚合提供了从数据中分组和提取数据的能力。最简单的聚合方法大致等于SQL `Group by`和SQL`聚合函数`。

在elasticsearch中，返回的数据中聚合的数据与检索的数据相隔开

#### 普通聚合

**例：搜索address中包含mill的所有人的年龄分布以及平均年龄，但不显示这些人的详情**

输出的结果&#x20;

![2022-10-18](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/18/1666100376369.png "2022-10-18")

#### 子聚合

![2022-10-18](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/18/1666101112311.png "2022-10-18")

### 1.5 mapping字段映射

#### ElasticSearch 8.X为什么要移除type?

**1、index、type的初衷**

之前es将index、type类比于关系型数据库（例如mysql）中database、table，这么考虑的目的是“方便管理数据之间的关系”。

**2、为什么现在要移除type？**

2.1 在关系型数据库中table是独立的（独立存储），但es中同一个index中不同type是存储在同一个索引中的（lucene的索引文件），因此不同type中相同名字的字段的定义（mapping）必须一致。

2.2 不同类型的“记录”存储在同一个index中，会影响lucene的压缩性能。（所以要将index由db转为table，type暂保留，不建议指定，默认为`_doc` ，要保证一个索引只保存一张表 ）

**3、替换策略**

3.1 一个index只存储一种类型的“记录”

这种方案的优点：

a）lucene索引中数据比较整齐（相对于稀疏），利于lucene进行压缩。

b）文本相关性打分更加精确（tf、idf，考虑idf中命中文档总数）

3.2 用一个字段来存储type

如果有很多规模比较小的数据表需要建立索引，可以考虑放到同一个index中，每条记录添加一个type字段进行区分。

这种方案的优点：

a）es集群对分片数量有限制，这种方案可以减少index的数量。

#### 数据迁移

1.  Elasticsearch 7.x URL中的type参数为可选。比如，索引一个文档不再要求提供文档类型。
2.  Elasticsearch 8.x **不再支持URL中的type参数**。

1、**创建映射：**

第一次存储数据的时候es就猜出了映射

第一次存储数据前可以指定映射

> 创建索引时，指定映射：
>
> ```json
> PUT /my_index
> {
>   "mappings": {
>     "properties": {
>       "age": {
>         "type": "integer"
>       },
>       "email": {
>         "type": "keyword" # 指定为keyword
>       },
>       "name": {
>         "type": "text" # 全文检索。保存时候分词，检索时候进行分词匹配
>       }
>     }
>   }
> }
>
> ```

2、**查看映射**

`GET /my_index`

添加新的字段映射`PUT /my_index/_mapping`

不能更新映射

对于已经存在的字段映射，我们不能更新。更新必须创建新的索引，进行**数据迁移**。

3、**数据迁移**

那如何进行数据迁移呢？

1.  先查看旧的数据映射，然后复制
2.  使用旧的映射信息进行修改，用来创建新的映射(我们可以修改类型，如将年龄的long改为integer)
3.  进行数据迁移
    ```json
    6.0以后写法
    POST reindex
    {
      "source":{
          "index":"twitter"
       },
      "dest":{
          "index":"new_twitters"
       }
    }


    老版本写法
    POST reindex
    {
      "source":{
          "index":"twitter",
          "twitter":"twitter"
       },
      "dest":{
          "index":"new_twitters"
       }
    }

    ```

### 1.6 分词

一个tokenizer（分词器）接收一个字符流，将之分割为独立的`tokens`（词元，通常是独立的单词），然后输出tokens流。

例如：whitespace tokenizer遇到空白字符时分割文本。它会将文本"`Quick brown fox!`"分割为`[Quick,brown,fox!]`

该tokenizer（分词器）还负责记录各个terms(词条)的顺序或position位置（用于phrase短语和word proximity词近邻查询），以及term（词条）所代表的原始word（单词）的start（起始）和end（结束）的character offsets（字符串偏移量）（用于高亮显示搜索的内容）。

elasticsearch提供了很多内置的分词器（标准分词器），可以用来构建custom analyzers（自定义分词器）。

**测试内置分词器**：

结果：

但是对于中文，该分词器，只会分为一个个字符，我们需要安装中文的分词器`ik`

**安装ik分词器：**

[https://github.com/medcl/elasticsearch-analysis-ik/releases](https://github.com/medcl/elasticsearch-analysis-ik/releases "https://github.com/medcl/elasticsearch-analysis-ik/releases")

在前面安装的elasticsearch时，我们已经将elasticsearch容器的“`/usr/share/elasticsearch/plugins`”目录，映射到宿主机的“ `/mydata/elasticsearch/plugins`”目录下，所以比较方便的做法就是下载“`/elasticsearch-analysis-ik-7.4.2.zip`”文件，然后**解压到该文件夹**下即可。安装完毕后，需要重启elasticsearch容器。

如果不嫌麻烦，还可以采用如下的方式。

确认是否安装好了分词器

发现，分成了`['我','是','中','国','人']`

使用`ik` 分词：

方式一：

```json
# 方式一
GET _analyze
{
   "analyzer": "ik_smart", 
   "text":"我是中国人"
}

```

结果：

```json
{
  "tokens" : [
    {
      "token" : "我",
      "start_offset" : 0,
      "end_offset" : 1,
      "type" : "CN_CHAR",
      "position" : 0
    },
    {
      "token" : "是",
      "start_offset" : 1,
      "end_offset" : 2,
      "type" : "CN_CHAR",
      "position" : 1
    },
    {
      "token" : "中国人",
      "start_offset" : 2,
      "end_offset" : 5,
      "type" : "CN_WORD",
      "position" : 2
    }
  ]
}


```

方式二：

```json
GET _analyze
{
   "analyzer": "ik_max_word", 
   "text":"我是中国人"
}
```

输出：

```json
{
  "tokens" : [
    {
      "token" : "我",
      "start_offset" : 0,
      "end_offset" : 1,
      "type" : "CN_CHAR",
      "position" : 0
    },
    {
      "token" : "是",
      "start_offset" : 1,
      "end_offset" : 2,
      "type" : "CN_CHAR",
      "position" : 1
    },
    {
      "token" : "中国人",
      "start_offset" : 2,
      "end_offset" : 5,
      "type" : "CN_WORD",
      "position" : 2
    },
    {
      "token" : "中国",
      "start_offset" : 2,
      "end_offset" : 4,
      "type" : "CN_WORD",
      "position" : 3
    },
    {
      "token" : "国人",
      "start_offset" : 3,
      "end_offset" : 5,
      "type" : "CN_WORD",
      "position" : 4
    }
  ]
}

```

**自定义ik分词：**

在宿主机上执行：

在宿主机上创建文件 `/mydata/nginx/html/es/fenci.txt`

已知访问：[http://192.168.87.101/es/fenci.txt](http://192.168.87.101:8989/fenci.txt "http://192.168.87.101/es/fenci.txt")，有：

修改`/usr/share/elasticsearch/plugins/ik/config/IKAnalyzer.cfg.xml` 也就是`/mydata/elasticsearch/plugins/ik/config/IKAnalyzer.cfg.xml`&#x20;

我们配置了：\<entry key="remote\_ext\_dict">[http://192.168.87.101/es/fenci.txt\</entry](http://192.168.87.101/es/fenci.txt</entry)>

然后重新启动es：docker restart elasticsearch

输出：

这样我们的自定义分词就生效了。

### 1.7 ElasticSearch整合到项目

> java操作es有两种方式
>
> **1）9300: TCP**
>
> -   spring-data-elasticsearch:transport-api.jar;
>     -   springboot版本不同，ransport-api.jar不同，不能适配es版本
>     -   7.x已经不建议使用，8以后就要废弃
>
> **2）9200: HTTP**
>
> -   jestClient: 非官方，更新慢；
> -   RestTemplate：模拟HTTP请求，ES很多操作需要自己封装，麻烦；
> -   HttpClient：同上；
> -   `Elasticsearch-Rest-Client`：官方RestClient，封装了ES操作，API层次分明，上手简单；
>
>     ![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666354894703.png "2022-10-21")
>
>     最终选择Elasticsearch-Rest-Client（elasticsearch-rest-high-level-client）
>
>     [https://www.elastic.co/guide/en/elasticsearch/client/java-rest/current/java-rest-high.html](https://www.elastic.co/guide/en/elasticsearch/client/java-rest/current/java-rest-high.html "https://www.elastic.co/guide/en/elasticsearch/client/java-rest/current/java-rest-high.html")

**进入正题：SpringBoot整合ElasticSearch**

创建项目 `gulimall-search`

![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666359927039.png "2022-10-21")

配置依赖

配置：

application.yml ： 不加入nacos注册中心的配置,将报错

bootstrap.properties：在这里主要配置了nacos配置中心

主启动类：排除dataSource与加入注册中心

ES配置类：

config > GuliESConfig.java

查看版本：

![2022-10-21](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/21/1666361033746.png "2022-10-21")

并不是我们指定的7.4.2 有 6.X.X版本依赖, 运行会报错，我们需要做以下工作：

`gulimall-search` → pom.xml：第一点

`gulimall-search` → pom.xml：第二点, 在properties 下加 `<elasticsearch.version>7.4.2</elasticsearch.version>`

> 完整的pom.xml
>
> ```xml
> <?xml version="1.0" encoding="UTF-8"?>
> <project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
>     xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
>     <modelVersion>4.0.0</modelVersion>
>     <groupId>com.zhuangjie.gulimall</groupId>
>     <artifactId>search</artifactId>
>     <version>0.0.1-SNAPSHOT</version>
>     <name>search</name>
>     <description>搜索</description>
>     <parent>
>         <artifactId>spring-boot-dependencies</artifactId>
>         <groupId>org.springframework.boot</groupId>
>         <version>2.2.5.RELEASE</version>
>         <relativePath/>
>     </parent>
>
>     <properties>
>         <java.version>1.8</java.version>
>         <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
>         <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
>         <spring-boot.version>2.2.5.RELEASE</spring-boot.version>
>         <spring-cloud.version>Hoxton.RELEASE</spring-cloud.version>
>         <elasticsearch.version>7.4.2</elasticsearch.version>
>     </properties>
>
>     <dependencies>
>
>         <dependency>
>             <groupId>org.springframework.boot</groupId>
>             <artifactId>spring-boot-starter-web</artifactId>
>         </dependency>
>
>         <dependency>
>             <groupId>org.springframework.boot</groupId>
>             <artifactId>spring-boot-starter-test</artifactId>
>             <scope>test</scope>
>             <exclusions>
>                 <exclusion>
>                     <groupId>org.junit.vintage</groupId>
>                     <artifactId>junit-vintage-engine</artifactId>
>                 </exclusion>
>             </exclusions>
>         </dependency>
>
>         <dependency>
>             <groupId>com.zhuangjie.gulimall</groupId>
>             <artifactId>gulimall-common</artifactId>
>             <version>0.0.1-SNAPSHOT</version>
>         </dependency>
>
>         <dependency>
>             <groupId>org.elasticsearch.client</groupId>
>             <artifactId>elasticsearch-rest-high-level-client</artifactId>
>             <version>7.4.2</version>
>         </dependency>
>
>     </dependencies>
>     <dependencyManagement>
>         <dependencies>
>             <dependency>
>                 <groupId>org.springframework.cloud</groupId>
>                 <artifactId>spring-cloud-dependencies</artifactId>
>                 <version>${spring-cloud.version}</version>
>                 <type>pom</type>
>                 <scope>import</scope>
>             </dependency>
>             <dependency>
>                 <groupId>org.springframework.boot</groupId>
>                 <artifactId>spring-boot-dependencies</artifactId>
>                 <version>${spring-boot.version}</version>
>                 <type>pom</type>
>                 <scope>import</scope>
>             </dependency>
>         </dependencies>
>     </dependencyManagement>
>
>     <build>
>         <plugins>
>             <plugin>
>                 <groupId>org.apache.maven.plugins</groupId>
>                 <artifactId>maven-compiler-plugin</artifactId>
>                 <version>3.8.1</version>
>                 <configuration>
>                     <source>1.8</source>
>                     <target>1.8</target>
>                     <encoding>UTF-8</encoding>
>                 </configuration>
>             </plugin>
>             <plugin>
>                 <groupId>org.springframework.boot</groupId>
>                 <artifactId>spring-boot-maven-plugin</artifactId>
>                 <version>2.3.7.RELEASE</version>
>                 <configuration>
>                     <mainClass>com.zhuangjie.gulimall.search.SearchApplication</mainClass>
>                 </configuration>
>                 <executions>
>                     <execution>
>                         <id>repackage</id>
>                         <goals>
>                             <goal>repackage</goal>
>                         </goals>
>                     </execution>
>                 </executions>
>             </plugin>
>         </plugins>
>     </build>
>
> </project>
>
> ```

写测试类：

最后运行输出：

#### 测试

官方文档：[https://www.elastic.co/guide/en/elasticsearch/client/java-rest/current/java-rest-high-search.html](https://www.elastic.co/guide/en/elasticsearch/client/java-rest/current/java-rest-high-search.html "https://www.elastic.co/guide/en/elasticsearch/client/java-rest/current/java-rest-high-search.html")

SearchApplicationTests.java : 测试类

测试输出：java.net.ConnectException: Timeout connecting to \[localhost/127.0.0.1:9200]

奇怪，我配置的地址不是本地的啊，那段配置肯定没有生效，以似乎做以下配置：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/22/1666450476182.png)

然后就成功了。

#### 高级测试-检索

SearchApplicationTests.java : 测试类

输出：

#### 高级测试-检索与分析

结果分析：

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/images/2022/10/23/1666529337196.png)

**获取hits项为对象，需要生成clash，复制一个hits项的JSON**

```json
{
    "account_number":970,
    "balance":19648,
    "firstname":"Forbes",
    "lastname":"Wallace",
    "age":28,
    "gender":"M",
    "address":"990 Mill Road",
    "employer":"Pheast",
    "email":"forbeswallace@pheast.com",
    "city":"Lopezo",
    "state":"AK"
}
```

json转java实体：[https://www.json.cn/json/json2java.html](https://www.json.cn/json/json2java.html "https://www.json.cn/json/json2java.html")

将类名改为`Accout`, 在类上再加上`@ToString` 然后将hits项转为对象：

```java
.... 请求得到 searchResponse

SearchHit[] hits = searchResponse.getHits().getHits();
for (SearchHit hit : hits) {
    String sourceAsString = hit.getSourceAsString();
    Accout accout = JSON.parseObject(sourceAsString, Accout.class);
    System.out.println(accout);
}
```

输出：

```bash
...

SearchApplicationTests.Accout(account_number=970, balance=19648, firstname=Forbes, lastname=Wallace, age=28, gender=M, address=990 Mill Road, employer=Pheast, email=forbeswallace@pheast.com, city=Lopezo, state=AK)
SearchApplicationTests.Accout(account_number=136, balance=45801, firstname=Winnie, lastname=Holland, age=38, gender=M, address=198 Mill Lane, employer=Neteria, email=winnieholland@neteria.com, city=Urie, state=IL)
SearchApplicationTests.Accout(account_number=345, balance=9812, firstname=Parker, lastname=Hines, age=38, gender=M, address=715 Mill Avenue, employer=Baluba, email=parkerhines@baluba.com, city=Blackgum, state=KY)
SearchApplicationTests.Accout(account_number=472, balance=25571, firstname=Lee, lastname=Long, age=32, gender=F, address=288 Mill Street, employer=Comverges, email=leelong@comverges.com, city=Movico, state=MT)

2022-10-23 21:03:15.302  INFO 11032 --- [extShutdownHook] o.s.s.concurrent.ThreadPoolTaskExecutor  : Shutting down ExecutorService 'applicationTaskExecutor'

进程已结束,退出代码0
```

**获取分析（分布与聚合）结果**

```java
        ... 请求得到searchResponse
        
        Aggregations aggregations = searchResponse.getAggregations();
        // 分布结果遍历
        Terms ageAgg1 = aggregations.get("ageAgg");
        for (Terms.Bucket bucket : ageAgg1.getBuckets()) {
            String keyAsString = bucket.getKeyAsString();
            System.out.println("年龄："+keyAsString+"==>"+bucket.getDocCount());
        }
        // 聚合结果输出
        Avg balanceAvg = aggregations.get("balanceAvg");
        System.out.println("平均薪资："+balanceAvg.getValue());
```

输出：

```bash
...

年龄：38==>2
年龄：28==>1
年龄：32==>1
平均薪资：25208.0

2022-10-23 21:19:30.220  INFO 576 --- [extShutdownHook] o.s.s.concurrent.ThreadPoolTaskExecutor  : Shutting down ExecutorService 'applicationTaskExecutor'

进程已结束,退出代码0
```

## \[2] 实战说明

### 2.1 检索&#x20;

#### 检索条件分析

-   全文检索：skuTitle-》keyword
-   排序：saleCount（销量）、hotScore（热度分）、skuPrice（价格）
-   过滤：hasStock、skuPrice区间、brandId、catalog3Id、attrs
-   聚合：attrs

> 完整查询参数 `keyword=小米&sort=saleCount_desc/asc&hasStock=0/1&skuPrice=400_1900&brandId=1&catalog3Id=1&at trs=1_3G:4G:5G&attrs=2_骁龙845&attrs=4_高清屏`

#### DSL分析

```json
GET gulimall_product/_search
{
  "query": {
    "bool": {
      "must": [
        {
          "match": {
            "skuTitle": "华为"
          }
        }
      ],
      "filter": [
        {
            "term": {
              "catalogId": "225"
            }
        },
        {
            "terms": {
            "brandId": [
              "2"
            ]
          }
        },
        {
          "term": {
            "hasStock": "false"
          }
        },
        {
          "range": {
            "skuPrice": {
              "gte": 1000,
              "lte": 7000
            }
          }
        },
        {
          "nested": {
            "path": "attrs",
            "query": {
              "bool": {
                "must": [
                  {
                    "term": {
                      "attrs.attrId": {
                        "value": "6"
                      }
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    }
  },
  "sort": [
    {
      "skuPrice": {
        "order": "desc"
      }
    }
  ],
  "from": 0,
  "size": 5,
  "highlight": {
    "fields": {"skuTitle": {}},
    "pre_tags": "<b style='color:red'>", 
    "post_tags": "</b>"
  },
  "aggs": {
    "brandAgg": {
      "terms": {
        "field": "brandId",
        "size": 10
      },
      "aggs": {
        "brandNameAgg": {
          "terms": {
            "field": "brandName",
            "size": 10
          }
        },
      
        "brandImgAgg": {
          "terms": {
            "field": "brandImg",
            "size": 10
          }
        }
        
      }
    },
    "catalogAgg":{
      "terms": {
        "field": "catalogId",
        "size": 10
      },
      "aggs": {
        "catalogNameAgg": {
          "terms": {
            "field": "catalogName",
            "size": 10
          }
        }
      }
    },
    "attrs":{
      "nested": {
        "path": "attrs"
      },
      "aggs": {
        "attrIdAgg": {
          "terms": {
            "field": "attrs.attrId",
            "size": 10
          },
          "aggs": {
            "attrNameAgg": {
              "terms": {
                "field": "attrs.attrName",
                "size": 10
              }
            }
          }
        }
      }
    }
  }
}
```

#### 检索代码编写: 构建搜索请求（代码DSL）

```java
    private SearchRequest bulidSearchRequest(SearchParam searchParam) {
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        //1. 构建bool query
        BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
        //1.1 bool must
        if (!StringUtils.isEmpty(searchParam.getKeyword())) {
            boolQueryBuilder.must(QueryBuilders.matchQuery("skuTitle", searchParam.getKeyword()));
        }

        //1.2 bool filter
        //1.2.1 catalog
        if (searchParam.getCatalog3Id()!=null){
            boolQueryBuilder.filter(QueryBuilders.termQuery("catalogId", searchParam.getCatalog3Id()));
        }
        //1.2.2 brand
        if (searchParam.getBrandId()!=null&&searchParam.getBrandId().size()>0) {
            boolQueryBuilder.filter(QueryBuilders.termsQuery("brandId",searchParam.getBrandId()));
        }
        //1.2.3 hasStock
        if (searchParam.getHasStock() != null) {
            boolQueryBuilder.filter(QueryBuilders.termQuery("hasStock", searchParam.getHasStock() == 1));
        }
        //1.2.4 priceRange
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery("skuPrice");
        if (!StringUtils.isEmpty(searchParam.getSkuPrice())) {
            String[] prices = searchParam.getSkuPrice().split("_");
            if (prices.length == 1) {
                if (searchParam.getSkuPrice().startsWith("_")) {
                    rangeQueryBuilder.lte(Integer.parseInt(prices[0]));
                }else {
                    rangeQueryBuilder.gte(Integer.parseInt(prices[0]));
                }
            } else if (prices.length == 2) {
                //_6000会截取成["","6000"]
                if (!prices[0].isEmpty()) {
                    rangeQueryBuilder.gte(Integer.parseInt(prices[0]));
                }
                rangeQueryBuilder.lte(Integer.parseInt(prices[1]));
            }
            boolQueryBuilder.filter(rangeQueryBuilder);
        }
        //1.2.5 attrs-nested
        //attrs=1_5寸:8寸&2_16G:8G
        List<String> attrs = searchParam.getAttrs();
        BoolQueryBuilder queryBuilder = new BoolQueryBuilder();
        if (attrs!=null&&attrs.size() > 0) {
            attrs.forEach(attr->{
                String[] attrSplit = attr.split("_");
                queryBuilder.must(QueryBuilders.termQuery("attrs.attrId", attrSplit[0]));
                String[] attrValues = attrSplit[1].split(":");
                queryBuilder.must(QueryBuilders.termsQuery("attrs.attrValue", attrValues));
            });
        }
        NestedQueryBuilder nestedQueryBuilder = QueryBuilders.nestedQuery("attrs", queryBuilder, ScoreMode.None);
        boolQueryBuilder.filter(nestedQueryBuilder);
        //1. bool query构建完成
        searchSourceBuilder.query(boolQueryBuilder);

        //2. sort  eg:sort=saleCount_desc/asc
        if (!StringUtils.isEmpty(searchParam.getSort())) {
            String[] sortSplit = searchParam.getSort().split("_");
            searchSourceBuilder.sort(sortSplit[0], sortSplit[1].equalsIgnoreCase("asc") ? SortOrder.ASC : SortOrder.DESC);
        }

        //3. 分页
        searchSourceBuilder.from((searchParam.getPageNum() - 1) * EsConstant.PRODUCT_PAGESIZE);
        searchSourceBuilder.size(EsConstant.PRODUCT_PAGESIZE);

        //4. 高亮highlight
        if (!StringUtils.isEmpty(searchParam.getKeyword())) {
            HighlightBuilder highlightBuilder = new HighlightBuilder();
            highlightBuilder.field("skuTitle");
            highlightBuilder.preTags("<b style='color:red'>");
            highlightBuilder.postTags("</b>");
            searchSourceBuilder.highlighter(highlightBuilder);
        }

        //5. 聚合
        //5.1 按照brand聚合
        TermsAggregationBuilder brandAgg = AggregationBuilders.terms("brandAgg").field("brandId");
        TermsAggregationBuilder brandNameAgg = AggregationBuilders.terms("brandNameAgg").field("brandName");
        TermsAggregationBuilder brandImgAgg = AggregationBuilders.terms("brandImgAgg").field("brandImg");
        brandAgg.subAggregation(brandNameAgg);
        brandAgg.subAggregation(brandImgAgg);
        searchSourceBuilder.aggregation(brandAgg);

        //5.2 按照catalog聚合
        TermsAggregationBuilder catalogAgg = AggregationBuilders.terms("catalogAgg").field("catalogId");
        TermsAggregationBuilder catalogNameAgg = AggregationBuilders.terms("catalogNameAgg").field("catalogName");
        catalogAgg.subAggregation(catalogNameAgg);
        searchSourceBuilder.aggregation(catalogAgg);

        //5.3 按照attrs聚合
        NestedAggregationBuilder nestedAggregationBuilder = new NestedAggregationBuilder("attrs", "attrs");
        //按照attrId聚合
        TermsAggregationBuilder attrIdAgg = AggregationBuilders.terms("attrIdAgg").field("attrs.attrId");
        //按照attrId聚合之后再按照attrName和attrValue聚合
        TermsAggregationBuilder attrNameAgg = AggregationBuilders.terms("attrNameAgg").field("attrs.attrName");
        TermsAggregationBuilder attrValueAgg = AggregationBuilders.terms("attrValueAgg").field("attrs.attrValue");
        attrIdAgg.subAggregation(attrNameAgg);
        attrIdAgg.subAggregation(attrValueAgg);

        nestedAggregationBuilder.subAggregation(attrIdAgg);
        searchSourceBuilder.aggregation(nestedAggregationBuilder);

        log.debug("构建的DSL语句 {}",searchSourceBuilder.toString());

        SearchRequest request = new SearchRequest(new String[]{EsConstant.PRODUCT_INDEX}, searchSourceBuilder);
        return request;
    }
```

#### 检索代码编写：封装搜索结果

```java
private SearchResult bulidSearchResult(SearchParam searchParam, SearchResponse searchResponse) {
    SearchResult result = new SearchResult();
    SearchHits hits = searchResponse.getHits();
    //1. 封装查询到的商品信息
    if (hits.getHits()!=null&&hits.getHits().length>0){
        List<SkuEsModel> skuEsModels = new ArrayList<>();
        for (SearchHit hit : hits) {
            String sourceAsString = hit.getSourceAsString();
            SkuEsModel skuEsModel = JSON.parseObject(sourceAsString, SkuEsModel.class);
            //设置高亮属性
            if (!StringUtils.isEmpty(searchParam.getKeyword())) {
                HighlightField skuTitle = hit.getHighlightFields().get("skuTitle");
                String highLight = skuTitle.getFragments()[0].string();
                skuEsModel.setSkuTitle(highLight);
            }
            skuEsModels.add(skuEsModel);
        }
        result.setProduct(skuEsModels);
    }

    //2. 封装分页信息
    //2.1 当前页码
    result.setPageNum(searchParam.getPageNum());
    //2.2 总记录数
    long total = hits.getTotalHits().value;
    result.setTotal(total);
    //2.3 总页码
    Integer totalPages = (int)total % EsConstant.PRODUCT_PAGESIZE == 0 ?
            (int)total / EsConstant.PRODUCT_PAGESIZE : (int)total / EsConstant.PRODUCT_PAGESIZE + 1;
    result.setTotalPages(totalPages);
    List<Integer> pageNavs = new ArrayList<>();
    for (int i = 1; i <= totalPages; i++) {
        pageNavs.add(i);
    }
    result.setPageNavs(pageNavs);

    //3. 查询结果涉及到的品牌
    List<SearchResult.BrandVo> brandVos = new ArrayList<>();
    Aggregations aggregations = searchResponse.getAggregations();
    //ParsedLongTerms用于接收terms聚合的结果，并且可以把key转化为Long类型的数据
    ParsedLongTerms brandAgg = aggregations.get("brandAgg");
    for (Terms.Bucket bucket : brandAgg.getBuckets()) {
        //3.1 得到品牌id
        Long brandId = bucket.getKeyAsNumber().longValue();

        Aggregations subBrandAggs = bucket.getAggregations();
        //3.2 得到品牌图片
        ParsedStringTerms brandImgAgg=subBrandAggs.get("brandImgAgg");
        String brandImg = brandImgAgg.getBuckets().get(0).getKeyAsString();
        //3.3 得到品牌名字
        Terms brandNameAgg=subBrandAggs.get("brandNameAgg");
        String brandName = brandNameAgg.getBuckets().get(0).getKeyAsString();
        SearchResult.BrandVo brandVo = new SearchResult.BrandVo(brandId, brandName, brandImg);
        brandVos.add(brandVo);
    }
    result.setBrands(brandVos);

    //4. 查询涉及到的所有分类
    List<SearchResult.CatalogVo> catalogVos = new ArrayList<>();
    ParsedLongTerms catalogAgg = aggregations.get("catalogAgg");
    for (Terms.Bucket bucket : catalogAgg.getBuckets()) {
        //4.1 获取分类id
        Long catalogId = bucket.getKeyAsNumber().longValue();
        Aggregations subcatalogAggs = bucket.getAggregations();
        //4.2 获取分类名
        ParsedStringTerms catalogNameAgg=subcatalogAggs.get("catalogNameAgg");
        String catalogName = catalogNameAgg.getBuckets().get(0).getKeyAsString();
        SearchResult.CatalogVo catalogVo = new SearchResult.CatalogVo(catalogId, catalogName);
        catalogVos.add(catalogVo);
    }
    result.setCatalogs(catalogVos);

    //5 查询涉及到的所有属性
    List<SearchResult.AttrVo> attrVos = new ArrayList<>();
    //ParsedNested用于接收内置属性的聚合
    ParsedNested parsedNested=aggregations.get("attrs");
    ParsedLongTerms attrIdAgg=parsedNested.getAggregations().get("attrIdAgg");
    for (Terms.Bucket bucket : attrIdAgg.getBuckets()) {
        //5.1 查询属性id
        Long attrId = bucket.getKeyAsNumber().longValue();

        Aggregations subAttrAgg = bucket.getAggregations();
        //5.2 查询属性名
        ParsedStringTerms attrNameAgg=subAttrAgg.get("attrNameAgg");
        String attrName = attrNameAgg.getBuckets().get(0).getKeyAsString();
        //5.3 查询属性值
        ParsedStringTerms attrValueAgg = subAttrAgg.get("attrValueAgg");
        List<String> attrValues = new ArrayList<>();
        for (Terms.Bucket attrValueAggBucket : attrValueAgg.getBuckets()) {
            String attrValue = attrValueAggBucket.getKeyAsString();
            attrValues.add(attrValue);
            List<SearchResult.NavVo> navVos = new ArrayList<>();
        }
        SearchResult.AttrVo attrVo = new SearchResult.AttrVo(attrId, attrName, attrValues);
        attrVos.add(attrVo);
    }
    result.setAttrs(attrVos);

    // 6. 构建面包屑导航
    List<String> attrs = searchParam.getAttrs();
    if (attrs != null && attrs.size() > 0) {
        List<SearchResult.NavVo> navVos = attrs.stream().map(attr -> {
            String[] split = attr.split("_");
            SearchResult.NavVo navVo = new SearchResult.NavVo();
            //6.1 设置属性值
            navVo.setNavValue(split[1]);
            //6.2 查询并设置属性名
            try {
                R r = productFeignService.info(Long.parseLong(split[0]));
                if (r.getCode() == 0) {
                    AttrResponseVo attrResponseVo = JSON.parseObject(JSON.toJSONString(r.get("attr")), new TypeReference<AttrResponseVo>() {
                    });
                    navVo.setNavName(attrResponseVo.getAttrName());
                }
            } catch (Exception e) {
                log.error("远程调用商品服务查询属性失败", e);
            }
            //6.3 设置面包屑跳转链接
            String queryString = searchParam.get_queryString();
            String replace = queryString.replace("&attrs=" + attr, "").replace("attrs=" + attr+"&", "").replace("attrs=" + attr, "");
            navVo.setLink("http://search.gulimall.com/search.html" + (replace.isEmpty()?"":"?"+replace));
            return navVo;
        }).collect(Collectors.toList());
        result.setNavs(navVos);
    }
    return result;
}
```
