# XML技术

XML (eXtensible Markup Language) 是一种标记语言，用于存储和传输数据。它的结构灵活，可以定义自己的标签，并且与平台和程序无关，因此被广泛应用于 Web 应用程序和数据交换。XML 文档是由元素、属性和文本组成的，并使用标签表示数据结构。

[https://www.bilibili.com/video/BV12x411h7xR/?spm\_id\_from=333.337.search-card.all.click\&vd\_source=efcb6bee91cb11215a6c31f8ee75f85c](https://www.bilibili.com/video/BV12x411h7xR/?spm_id_from=333.337.search-card.all.click\&vd_source=efcb6bee91cb11215a6c31f8ee75f85c "https://www.bilibili.com/video/BV12x411h7xR/?spm_id_from=333.337.search-card.all.click\&vd_source=efcb6bee91cb11215a6c31f8ee75f85c")
