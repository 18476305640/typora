package org.zhuangjie.set;

public class Test {
    public static void main(String[] args) {
        TreeSet<String> treeSet = new TreeSet<>();
        treeSet.add("哈哈");
        treeSet.add("嘻嘻");
        treeSet.traversal(null);

    }
}
