package org.zhuangjie.tree;

import org.zhuangjie.tree.javabean.Person;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Test {
    public static void main(String[] args) {
//        BSTree<Person> BSTree = new RBTree<>();
//        List<Integer> ages = Arrays.asList(90, 100, 86, 55, 14, 64, 41, 18, 40, 87, 29, 26, 24, 50, 21, 75, 80, 52, 4);
//        for (Integer age : ages) {
//            BSTree.add(new Person(age+"号", age));
//        }
//        System.out.println(BSTree);
//        for (Integer age : ages) {
//            if (age == 55) {
//                System.out.println("");
//            }
//            BSTree.remove(new Person(age+"号", age));
//            System.out.println(BSTree);
//            System.out.println("本次删除的是："+age);
//            System.out.println("---------");
//        }
        Double.hashCode(12);
        Long.hashCode(12);

        double d = 1;
        Double.hashCode(d);

        HashMap<Object, Object> objectObjectHashMap = new HashMap<>();
//        objectObjectHashMap.put()
//        objectObjectHashMap.remove()



    }
}
