package com.zhuangjie.thymeleafspringboot.controller;

import com.zhuangjie.thymeleafspringboot.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Controller
public class HelloController {

    @RequestMapping({"/","index.html"})
    public String index(Model model, HttpServletRequest request) {
        model.addAttribute("date",new Date());
        request.setAttribute("requestAttr","我是request的属性值");
        HttpSession session = request.getSession();
        ServletContext context = request.getServletContext();
        context.setAttribute("contextAttr","我是application的属性值");
        session.setAttribute("sessionAttr","我是session的属性值");

        return "index";
    }


}
