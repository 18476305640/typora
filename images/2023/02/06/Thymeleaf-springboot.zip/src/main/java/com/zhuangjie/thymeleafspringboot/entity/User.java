package com.zhuangjie.thymeleafspringboot.entity;

public class User {
    private String username;
    private Integer age;
    private Character sex;

    public User(String username, Integer age, Character sex) {
        this.username = username;
        this.age = age;
        this.sex = sex;
    }

    public User() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Character getSex() {
        return sex;
    }

    public void setSex(Character sex) {
        this.sex = sex;
    }
}
