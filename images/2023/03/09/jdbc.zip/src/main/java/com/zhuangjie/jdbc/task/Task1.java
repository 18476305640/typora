package com.zhuangjie.jdbc.task;

import com.sun.org.apache.bcel.internal.generic.ACONST_NULL;
import com.zhuangjie.jdbc.entity.User;
import com.zhuangjie.jdbc.utils.JDBC;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Task1 {
    /**
     * 增删查操作，只示例一种
     */
    @Test
    public void test1() throws SQLException {
        Connection connection = JDBC.getConnection();
        Statement statement = connection.createStatement();
        String sql = "INSERT INTO user (id,username,password,email) values (2,'zhuangjie','3333','zhuangjie@gmail.com')";
        boolean b = statement.execute(sql);
        if (!b) System.out.println("操作成功！");
        connection.close();
    }


    /**查询**/
    @Test
    public void test2() throws SQLException {
        Connection connection = JDBC.getConnection();
        Statement statement = connection.createStatement();
        // 查询
        String queueSql = "SELECT * FROM user";
        ResultSet rs = statement.executeQuery(queueSql);
        ArrayList<User> users = new ArrayList<>();
        while (rs.next()) {
            Long id = rs.getLong("id");
            String username = rs.getString("username");
            String password = rs.getString("password");
            String email = rs.getString("email");
            User user = new User(id,username,password,email);
            users.add(user);
        }
        System.out.println("查询成功！");
        System.out.println(users);
        connection.close();

    }

}
