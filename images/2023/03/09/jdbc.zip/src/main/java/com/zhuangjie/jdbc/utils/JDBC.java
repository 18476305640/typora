package com.zhuangjie.jdbc.utils;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class JDBC {
    public static Connection getConnection() {
        Properties info = new Properties();
        try (
                InputStream is = JDBC.class.getClassLoader().getResourceAsStream("jdbc.properties");
        ) {
            info.load(is);
            String url = (String) info.get("url");
            String username = (String) info.get("username");
            String password = (String) info.get("password");

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, username, password);
            return connection;
        }catch (Exception e) {
            e.printStackTrace();
            System.err.println("获取 Connection 失败！");

        }finally {
            if (info != null ) info.clone();
        }
        return null;
    }
}
