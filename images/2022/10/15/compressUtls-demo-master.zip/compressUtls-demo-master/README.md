# compressUtils-demo

### 简介
- 这是一个js实现、利用canvas进行图片压缩工具类

- 体积很小，方便引入项目

- log注明了压缩前后的图片大小

