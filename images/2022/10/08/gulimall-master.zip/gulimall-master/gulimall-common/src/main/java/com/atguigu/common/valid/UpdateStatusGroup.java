package com.atguigu.common.valid;

public interface UpdateStatusGroup {
}
