package com.zhuangjie.spring.framework.v2.beans.support;

import com.zhuangjie.spring.framework.annotation.Controller;
import com.zhuangjie.spring.framework.annotation.Service;
import com.zhuangjie.spring.framework.v2.beans.config.BeanDefinition;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * 存放着扫描的 className 集合
 * @author manzhuangjie
 */
public class BeanDefinitionReader {

    private Properties contextConfig = new Properties();

    private List<String> registryBeanClass = new ArrayList<>();

    public BeanDefinitionReader(String[] configLocations) {
        // 加载配置文件
        doLoadConfig(configLocations[0]);
        // 解析配置文件
        doScanner(contextConfig.getProperty("scanPackage"));

    }

    /**
     * 扫描 class 放到List集合
     * @param scanPackage
     */
    private void doScanner(String scanPackage) {
        // url 是 “/com/zhuangjie/demo”
        URL url = this.getClass().getClassLoader().getResource("/" + scanPackage.replaceAll("\\.", "/"));
        // 获取File对象
        File file = new File(url.getFile());
        for (File packageChildFile : file.listFiles()) {
            if(packageChildFile.isDirectory()) {
                // 如果是文件夹，递归
                this.doScanner(scanPackage+"."+packageChildFile.getName());
            }else {
                // 如果是文件, 且是 .class结尾的 得到 com.zhuangjie.demo.Controller 存到 classNames数组中
                if(!packageChildFile.getName().endsWith(".class")) {continue;}
                String name = packageChildFile.getName();
                String className = scanPackage + "." + name.substring(0, name.lastIndexOf(".class"));
                registryBeanClass.add(className);
            }
        }
    }

    /**
     * 初始化 contextConfig
     * @param configLocation
     */
    private void doLoadConfig(String configLocation) {
        // 此时的contextConfigLocation值为“application.properties”，是从web.xml中读取的，转成输入流
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(configLocation);
        try {
            // 加载了配置文件
            contextConfig.load(is);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("加载配置-加载配置失败！");
        }finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    System.out.println("加载配置-关闭输入流失败！");
                }
            }
        }

    }

    /**
     * 将收集的className 转为  Definitions （simpleName,className） 对象数组
     * @return
     */
    public List<BeanDefinition> doLoadBeanDefinitions() {
        ArrayList<BeanDefinition> result = new ArrayList<>();
        try {
            for(String className: registryBeanClass) {
                Class<?> beanClass = Class.forName(className);
                if(!(beanClass.isAnnotationPresent(Service.class)
                        || beanClass.isAnnotationPresent(Controller.class))) {
                    continue;
                }
                if(beanClass.isInterface()) {
                    continue;
                }
                result.add(doCreateBeanDefinition(toLowerFirstCase(beanClass.getSimpleName()),className));
                for (Class<?> i : beanClass.getInterfaces()) {
                    result.add(doCreateBeanDefinition(i.getName(),className));
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * 将参数封闭为 BeanDefinition对象
     * @param factoryBeanName
     * @param beanClassName
     * @return
     */
    private BeanDefinition doCreateBeanDefinition(String factoryBeanName, String beanClassName) {
        BeanDefinition beanDefinition = new BeanDefinition();
        beanDefinition.setFactoryBeanName(factoryBeanName);
        beanDefinition.setBeanClassName(beanClassName);
        return beanDefinition;
    }

    /**
     * 首字母小写
     * @param simpleName
     * @return
     */
    private  String toLowerFirstCase(String simpleName) {
        if (simpleName.isEmpty()) {return simpleName;};
        char[] chars = simpleName.toCharArray();
        chars[0] = (chars[0]+"").toLowerCase().toCharArray()[0];
        return new String(chars);
    }
}
