package com.zhuangjie.demo.service.impl;

import com.zhuangjie.demo.service.UserService;
import com.zhuangjie.spring.framework.annotation.Service;

/**
 * @author manzhuangjie
 */
@Service
public class UserServiceImpl implements UserService {
    @Override
    public Integer addition(Integer i, Integer j) {
        return i + j;
    }
}
