package com.zhuangjie.spring.framework.v3.servlet;

import java.util.regex.Matcher;
import java.util.regex.Pattern;public class Test {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("(.+)[(（](.*)[)）][：:](http.+)|(.+)[：:](http.+)");
        Matcher matcher = pattern.matcher("RSSHUB（订阅规则源）：https://docs.rsshub.app/social-media.html#dou-yin\n" +
                "\n" +
                "声咖（在线视频配音，小说）：https://shengka.ai.sogou.com/tts/new/\n" +
                "\n" +
                "FORVO：https://zh.forvo.com/\n" +
                "\n" +
                "我的js库（收集但未整理）：https://www.cnblogs.com/zhuangjie/p/16853776.html");
        while (matcher.find()) {
            if (matcher.group(3) == null) {
                System.out.println("标题："+matcher.group(4)+"，链接："+matcher.group(5));
            }else {
                System.out.println("标题："+matcher.group(1)+",描述："+matcher.group(2)+"，链接："+matcher.group(3));
            }

        }

    }
}


