package com.zhuangjie.spring.framework.v3.servlet;

import com.sun.deploy.util.StringUtils;

import java.io.File;

/**
 * 视图解析器
 *
 * @author manzhuangjie
 * @date 2022/11/24
 */
public class ViewResolver {
    private File templateRootDir;
    public final String DEFAULT_TEMPLATE_SUFFIX = ".html";
    public ViewResolver() {
    }

    public ViewResolver(String templateRoot) {
        String templdateRootPath = this.getClass().getClassLoader().getResource(templateRoot).getFile();
        this.templateRootDir = new File(templdateRootPath);
    }
    public View resolverViewName(String viewName) {
        if(viewName == null || "".equals(viewName.trim())) {return null;}
        viewName = viewName.endsWith(DEFAULT_TEMPLATE_SUFFIX)?viewName:(viewName+DEFAULT_TEMPLATE_SUFFIX);
        File templateFile = new File((this.templateRootDir.getPath() + "/" + viewName).replaceAll("/+", "/"));
        return new View(templateFile);
    }

}
