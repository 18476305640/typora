package com.zhuangjie.demo.controller;

import com.zhuangjie.spring.framework.annotation.Controller;
import com.zhuangjie.spring.framework.annotation.RequestMapper;
import com.zhuangjie.spring.framework.v3.servlet.ModelAndView;

import java.io.IOException;
import java.util.HashMap;

/**
 * @author manzhuangjie
 * @date 2022/11/24
 */
@Controller
public class IndexController {
    @RequestMapper("/")
    public ModelAndView home() throws IOException {
        ModelAndView home = new ModelAndView("home");
        HashMap<String, Object> model = new HashMap<>(8);
        model.put("info","兄弟们好~");
        home.setModel(model);
        return home;
    }
}
