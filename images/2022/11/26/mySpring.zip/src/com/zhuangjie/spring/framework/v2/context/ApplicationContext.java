package com.zhuangjie.spring.framework.v2.context;

import com.zhuangjie.spring.framework.annotation.Autowired;
import com.zhuangjie.spring.framework.v2.beans.BeanWrapper;
import com.zhuangjie.spring.framework.v2.beans.config.BeanDefinition;
import com.zhuangjie.spring.framework.v2.beans.support.BeanDefinitionReader;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author manzhuangjie
 */
public class ApplicationContext {
    private String[] configLocations;
    private BeanDefinitionReader reader;
    private HashMap<String, BeanDefinition> beanDefinitionMap = new HashMap<>();
    private HashMap<String, BeanWrapper> factoryBeanInstanceCache = new HashMap<>();
    private HashMap<String, Object> factoryBeanObjectCache = new HashMap<>();

    public ApplicationContext(String... configLocations) {
        try {
            this.configLocations = configLocations;

            // 1、 加载配置文件
            this.reader = new BeanDefinitionReader(this.configLocations);

            //2、将所有的配置信息转为BeanDefinition对象
            List<BeanDefinition> beanDefinitions = this.reader.doLoadBeanDefinitions();

            //3、将BeanDefinition对象缓存到beanDefinitionMap中
            doRegistryBeanDefinition(beanDefinitions);
            //4、根据BeanDefinition创建不需要延时加载的Bean对象
            doCreateBean();
        } catch (Exception e) {
            System.out.println("[ERROR] ApplicationContext class error!");
        }


    }

    private void doCreateBean() {
        for (Map.Entry<String, BeanDefinition> beanDefinitionEntry : this.beanDefinitionMap.entrySet()) {
            String beanName = beanDefinitionEntry.getKey();
            getBean(beanName);
        }

    }

    /**
     * 将 beanDefinitions 数组 转为  A：Definition对象， com.XXX.A:Definition对象
     *
     * @param beanDefinitions
     * @throws Exception
     */
    private void doRegistryBeanDefinition(List<BeanDefinition> beanDefinitions) throws Exception {
        for (BeanDefinition beanDefinition : beanDefinitions) {
            if (this.beanDefinitionMap.containsKey(beanDefinition.getFactoryBeanName())) {
                throw new Exception("The beanName " + beanDefinition.getFactoryBeanName() + " is exists!!");
            }
            this.beanDefinitionMap.put(beanDefinition.getFactoryBeanName(), beanDefinition);
            this.beanDefinitionMap.put(beanDefinition.getBeanClassName(), beanDefinition);

        }


    }

    public Object getBean(Class clazz) {
        return getBean(clazz.getName());
    }

    public Object getBean(String beanName) {
        // 1、根据beanName ，可以拿到配置信息
        BeanDefinition beanDefinition = this.beanDefinitionMap.get(beanName);
        //2、根据BeanDefinition对象创建实例
        Object instance = instaniateBean(beanName, beanDefinition);
        //3、将返回的instance封装为BeanWrapper
        BeanWrapper beanWrapper = new BeanWrapper(instance);
        //4、将beanWrapper 对象缓存到IOC容器中
        this.factoryBeanInstanceCache.put(beanName, beanWrapper);
        //5、完成依赖注入
        populateBean(beanName, beanDefinition, beanWrapper);
        return this.factoryBeanInstanceCache.get(beanName).getWrapperInstance();
    }


    private void populateBean(String beanName, BeanDefinition beanDefinition, BeanWrapper beanWrapper) {
        Object instance = beanWrapper.getWrapperInstance();
        Class<?> clazz = beanWrapper.getWrapperClass();
        Field[] declaredFields = clazz.getDeclaredFields();
        for (Field field : declaredFields) {
            // 对实例的所有有@Autowired注解的属性进行自动注入
            Autowired autowired = field.getAnnotation(Autowired.class);
            if (autowired == null) {
                continue;
            }
            // 构造从IOC中获取值的beanName
            String autowiredBeanName = autowired.value().trim();
            if (autowiredBeanName.isEmpty()) {
                autowiredBeanName = field.getType().getName();
            }
            // 强制暴力访问
            field.setAccessible(true);
            try {
                if (!this.factoryBeanInstanceCache.containsKey(autowiredBeanName)) {
                    continue;
                }
                field.set(instance, this.factoryBeanInstanceCache.get(autowiredBeanName).getWrapperInstance());
            } catch (IllegalAccessException e) {
                System.out.println("[ERROR] 为属性注入失败！");
            }

        }

    }

    /**
     * 创建实例，保存 (beanName,instance) 到 factoryBeanObjectCache Map中
     *
     * @param beanName
     * @param beanDefinition
     * @return
     */
    private Object instaniateBean(String beanName, BeanDefinition beanDefinition) {
        String className = beanDefinition.getBeanClassName();
        Object instance = null;
        try {
            Class<?> clazz = Class.forName(className);
            instance = clazz.newInstance();

            // 预留 AOP入口

            // 三级缓存
            this.factoryBeanObjectCache.put(beanName, instance);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        return instance;
    }


    public int getBeanDefinitionCount() {
        return this.beanDefinitionMap.size();
    }

    public String[] getBeanDefinitionNames() {
        return this.beanDefinitionMap.keySet().toArray(new String[this.beanDefinitionMap.size()]);
    }
}
