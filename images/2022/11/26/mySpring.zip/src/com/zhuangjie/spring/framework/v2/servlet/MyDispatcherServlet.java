package com.zhuangjie.spring.framework.v2.servlet;

import com.zhuangjie.spring.framework.annotation.Controller;
import com.zhuangjie.spring.framework.annotation.RequestMapper;
import com.zhuangjie.spring.framework.v2.context.ApplicationContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

public class MyDispatcherServlet extends HttpServlet {
    private Map<String,Method> handlerMapping = new HashMap<>();


    private ApplicationContext context;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            doDispatch(req,resp);
        } catch (Exception e) {
            // 报 500
            resp.getWriter().write("500 Handler error！");
        }
    }

    private void doDispatch(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String url = req.getRequestURI();
        String contextPath = req.getContextPath();
        url = url.replaceAll(contextPath, "").replaceAll("/+", "/");
        if(!handlerMapping.containsKey(url)) {
            // 报404
            resp.getWriter().write("404 Not found~");
            return;
        }
        // 没什么了
        Map<String, String[]> param = req.getParameterMap();
        Method method = this.handlerMapping.get(url);
        String name = param.get("name")[0];
        method.invoke( this.context.getBean(method.getDeclaringClass()),new Object[]{req,resp,name });
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        /**
         * v2版本
         * 下面 new ApplicationContext 内部的IOC容器（factoryBeanInstanceCache） 存储的实例还不完全依赖注入成功，
         * 只是容器有了才能注入，但这没关系，在后调用getBean时，此时IOC容器的实例已经全部有了，此时再进行getBean进行依赖注入时
         * 肯定是全部注入的。
         */
        context = new ApplicationContext(config.getInitParameter("contextConfigLocation"));

        doInitHandlerMappering();

        System.out.println("Spring framwork is inited!");
    }

    /**
     * 收集url-method映射
     */
    private void doInitHandlerMappering() {
        if (this.context.getBeanDefinitionCount() == 0) {return;}
        // 从Controller中获取请求映射信息
        for (String beanName : this.context.getBeanDefinitionNames()) {
            Object instance = this.context.getBean(beanName);
            Class<?> clazz = instance.getClass();
            if(!clazz.isAnnotationPresent(Controller.class)) {continue;}
            // 这里的类上都有@Controller注解
            String baseUrl = "";
            RequestMapper requestMapper = clazz.getAnnotation(RequestMapper.class);
            if (requestMapper != null) {
                baseUrl =  requestMapper.value();
            }
            Method[] methods = clazz.getMethods();
            for (Method method : methods) {
                RequestMapper methodRequestMapper = method.getAnnotation(RequestMapper.class);
                if(methodRequestMapper == null) {continue;}
                // 收集的url 如： /user/hello
                String url = ("/"+baseUrl+"/"+methodRequestMapper.value()).replaceAll("/+","/");
                // "/user/hello" : method 存入handlerMapping
                handlerMapping.put(url,method);
                System.out.println(String.format("[HandlerMapping] <- [%s,%s]",url,method.getName()));
            }

        }
    }




    private  String toLowerFirstCase(String simpleName) {
        if (simpleName.isEmpty()) {return simpleName;};
        char[] chars = simpleName.toCharArray();
        chars[0] = (chars[0]+"").toLowerCase().toCharArray()[0];
        return new String(chars);
    }




}
