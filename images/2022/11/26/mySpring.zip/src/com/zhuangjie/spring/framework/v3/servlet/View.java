package com.zhuangjie.spring.framework.v3.servlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 视图
 *
 * @author manzhuangjie
 * @date 2022/11/24
 */
public class View {
    private File viewFile;
    private String viewName;

    public File getViewFile() {
        return viewFile;
    }

    public void setViewFile(File viewFile) {
        this.viewFile = viewFile;
    }

    public String getViewName() {
        return viewName;
    }

    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    public View(File templateFile) {
        this.viewFile = templateFile;
        this.viewName = templateFile.getName().split("\\.")[0];
    }

    public View(String viewName,File viewFile) {
        this.viewFile = viewFile;
        this.viewName = viewName;
    }

    /**
     * 渲染
     * @param model 模型
     * @param req   request
     * @param resp  response
     * @throws IOException ioexception
     */
    public void render(Map<String,?> model, HttpServletRequest req, HttpServletResponse resp) throws IOException {
        StringBuffer sb = new StringBuffer();
        RandomAccessFile ra = new RandomAccessFile(this.viewFile, "r");
        String line = null;
        while (null != (line = ra.readLine())) {
            line = new String(line.getBytes("iso-8859-1"),"utf-8");
            Pattern pattern = Pattern.compile("\\$\\{(.+)\\}");
            Matcher matcher = pattern.matcher(line);
            while (matcher.find()) {
                String paramName = matcher.group(1).trim();
                String value = (""+model.get(paramName));
                line = line.replaceAll("\\$\\{ *"+paramName+" *}",Matcher.quoteReplacement(value));
            }
            sb.append(line);
        }
        resp.setCharacterEncoding("utf-8");
        resp.getWriter().write(sb.toString());
    }


}
