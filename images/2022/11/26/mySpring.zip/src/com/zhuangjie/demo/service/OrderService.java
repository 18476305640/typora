package com.zhuangjie.demo.service;

/**
 * 订单服务
 *
 * @author manzhuangjie
 * @date 2022/11/23
 */
public interface OrderService {
}
