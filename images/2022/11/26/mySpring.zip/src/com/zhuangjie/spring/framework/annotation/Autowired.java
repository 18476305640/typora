package com.zhuangjie.spring.framework.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author manzhuangjie
 */
@Target(ElementType.FIELD) //注解用于类上
@Retention(RetentionPolicy.RUNTIME) // 表示注解可以一直保留到运行时，因此可以通过反射获取注解信息
public @interface Autowired {
    String value() default "";
}
