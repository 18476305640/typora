package com.zhuangjie.spring.framework.v3.servlet;

import java.util.Map;

/**
 * 模型和视图
 *
 * @author manzhuangjie
 * @date 2022/11/24
 */
public class ModelAndView {
    private Map<String,?> model;
    private String viewName;

    public ModelAndView(String viewName) {
        this.viewName = viewName;
    }

    public ModelAndView(String viewName, Map<String, Object> model) {
        this.viewName = viewName;
        this.model = model;
    }

    public void setModel(Map<String, ?> model) {
        this.model = model;
    }

    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    public Map<String, ?> getModel() {
        return model;
    }

    public String getViewName() {
        return viewName;
    }
}
