package com.zhuangjie.spring.framework.v3.servlet;

import com.zhuangjie.spring.framework.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * 处理程序适配器
 *
 * @author manzhuangjie
 * @date 2022/11/24
 */
public class HandlerAdapter {

    public ModelAndView handle(HttpServletRequest req, HttpServletResponse resp, HandlerMapping mappingHandler) throws InvocationTargetException, IllegalAccessException {
        Method method = mappingHandler.getMethod();
        // 解析注解的参数
        HashMap<String, Integer> paramIndexMapping = new HashMap<>(8);
        Annotation[][] pa = method.getParameterAnnotations();
        for (int i = 0; i < pa.length; i++) {
            for (Annotation a : pa[i]) {
                if (a instanceof RequestParam) {
                    String paramName = ((RequestParam) a).value();
                    if( !"".equals(paramName.trim())) {
                        paramIndexMapping.put(paramName,i);
                    }
                }
            }
        }
        // 解析形参
        Class<?>[] parameterTypes = method.getParameterTypes();
        for (int i = 0; i < parameterTypes.length; i++) {
            Class<?> type = parameterTypes[i];
            if(type == HttpServletRequest.class || type == HttpServletResponse.class) {
                paramIndexMapping.put(type.getName(),i);
            }
        }
        Map<String, String[]> params = req.getParameterMap();
        // 解析实参
        Object[] paramValues = new Object[parameterTypes.length];
        for (Map.Entry<String, String[]> param : params.entrySet()) {
            String value = Arrays.toString(param.getValue())
                    .replaceAll("\\[|\\]","")
                    .replaceAll("\\s","");
            if (!paramIndexMapping.containsKey(param.getKey())){continue;}
            Integer index = paramIndexMapping.get(param.getKey());
            // 方法参数的类型
            Class<?> parameterType = parameterTypes[index];
            Object _value = value;
            if (parameterType == Integer.class || parameterType == Long.class) {
                _value = Integer.valueOf(value);
            }else if(parameterType == Double.class || parameterType == Float.class ){
                _value = Double.valueOf(value);
            }else if (parameterType == Boolean.class || parameterType == boolean.class ) {
                _value = Boolean.valueOf(value);
            }
            paramValues[index] = _value;
        }

        if (paramIndexMapping.containsKey(HttpServletRequest.class.getName())){
            Integer index = paramIndexMapping.get(HttpServletRequest.class.getName());
            paramValues[index] = req;
        }
        if (paramIndexMapping.containsKey(HttpServletResponse.class.getName())) {
            Integer index = paramIndexMapping.get(HttpServletResponse.class.getName());
            paramValues[index] = resp;
        }
        // 调用赋值
        Object result = method.invoke(mappingHandler.getController(), paramValues);
        if (result == null || result instanceof Void) {return  null;}
        boolean isModelAndView =  (mappingHandler.getMethod().getReturnType() == ModelAndView.class);
        if (isModelAndView) {
            return (ModelAndView) result;
        }
        return null;
    }
}
