package com.zhuangjie.spring.framework.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author manzhuangjie
 */
@Target({ElementType.PARAMETER}) //注解用于方法参数上
@Retention(RetentionPolicy.RUNTIME) // 表示注解可以一直保留到运行时，因此可以通过反射获取注解信息
public @interface RequestParam {
    String value() default "";
}
