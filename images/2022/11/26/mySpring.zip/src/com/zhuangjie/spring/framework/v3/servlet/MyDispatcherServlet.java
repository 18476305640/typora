package com.zhuangjie.spring.framework.v3.servlet;

import com.sun.deploy.net.MessageHeader;
import com.zhuangjie.spring.framework.annotation.Controller;
import com.zhuangjie.spring.framework.annotation.RequestMapper;
import com.zhuangjie.spring.framework.v3.context.ApplicationContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyDispatcherServlet extends HttpServlet {
//    private Map<String,Method> handlerMapping = new HashMap<>();

    private List<HandlerMapping> handlerMappings = new  ArrayList<>();

    private Map<HandlerMapping,HandlerAdapter> handlerAdapter = new HashMap<>();
    private ApplicationContext context;
    private List<View> views = new ArrayList<>();
    private ViewResolver viewResolver = new ViewResolver();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)  {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
        try {
            // 调用主控制程序
            doDispatch(req,resp);
        } catch (Exception e) {
            // 当调用 doDispatch 调用异常时（内部的异常都是往外抛的）
            Map<String,Object> model =new HashMap<>(18);
            model.put("detail","500  "+e.getClass().getSimpleName());
            model.put("stackTrace", Arrays.toString(e.getStackTrace()));
            try {
                processDispatchResult(req,resp,new ModelAndView("500",model));
            } catch(Exception exception) {
                System.out.println("[ERROR] 方法调用出现问题。 InvocationTargetException");
                exception.printStackTrace();
            }
        }
    }


    /**
     * 一个请求的入口与出口
     */
    private void doDispatch(HttpServletRequest req, HttpServletResponse resp) throws InvocationTargetException, IllegalAccessException, IOException {
        //1、根据用户请求的url找到对应的HandlerMapping
        HandlerMapping mappingHandler = getHandler(req);
        //2、如果没有找到对应的HandlerMapping 返回404
        if(mappingHandler == null) {
            processDispatchResult(req,resp,new ModelAndView("404"));
            return;
        }
        //3、根据HandlerMapping找到对应的HandlerAdapter
        HandlerAdapter ha =  getHandlerAdapter(mappingHandler);
        //4、调用HandlerAdapter的handler()方法，完成方法参数的动态匹配
        ModelAndView mv =  ha.handle(req,resp,mappingHandler);
        //5、ModelAndView的内容，决定选择哪种方式给用户返回对应的结果
        processDispatchResult(req,resp,mv);
    }

    private HandlerAdapter getHandlerAdapter(HandlerMapping mappingHandler) {
        if (this.handlerAdapter.isEmpty()) {return null;}
        return this.handlerAdapter.get(mappingHandler);
    }

    /**
     * 进程调度结果
     *
     * @param req  要求事情
     * @param resp 分别地
     * @param mv   mv
     * @throws IOException ioexception
     */
    private void processDispatchResult(HttpServletRequest req, HttpServletResponse resp, ModelAndView mv) throws IOException {
        if (mv == null) {return;}
        String viewName = mv.getViewName().split("\\.")[0];
        for (View view : views) {
            if (view.getViewName().equals(viewName)) {
                // 结合mv,去渲染视图
                view.render(mv.getModel(),req,resp);
            }
        }


    }


    private HandlerMapping getHandler(HttpServletRequest req) {
        String url = req.getRequestURI();
        String contextPath = req.getContextPath();
        url = url.replaceAll(contextPath,"").replaceAll("/+","/");
        for (HandlerMapping handlerMapping : handlerMappings) {
            Matcher matcher = handlerMapping.getPattern().matcher(url);
            if (!matcher.matches()) {continue;}
            return handlerMapping;
        }
        return null;
    }

    /**
     * 初始化
     * @param config 配置
     * @throws ServletException servlet异常
     */
    @Override
    public void init(ServletConfig config) throws ServletException {
        /**
         * v2版本
         * 下面 new ApplicationContext 内部的IOC容器（factoryBeanInstanceCache） 存储的实例还不完全依赖注入成功，
         * 只是容器有了才能注入，但这没关系，在后调用getBean时，此时IOC容器的实例已经全部有了，此时再进行getBean进行依赖注入时
         * 肯定是全部注入的。
         */
        context = new ApplicationContext(config.getInitParameter("contextConfigLocation"));

        initStrategies(context);

        System.out.println("Spring framwork is inited!");
    }

    /**
     * 初始化策略
     * @param context 上下文
     */
    private void initStrategies(ApplicationContext context) {
        //handlerMapping
        initHandlerMappings(context);
        //初始化参数适配器
        initHandlerAdapters(context);
        //初始化视图转换器
        initViewResolvers(context);
    }

    /**
     * 初始化视图解析器
     *
     * @param context 上下文
     */
    private void initViewResolvers(ApplicationContext context) {
        // 得到 layouts 静态文件目录
        String templateRoot = context.getConfig().getProperty("templateRoot");
        // 初始化  viewResolver
        this.viewResolver = new ViewResolver(templateRoot);

        String templateRootPath = this.getClass().getClassLoader().getResource("/").getPath()+templateRoot;
        File templateRootDir = new File(templateRootPath);
        File[] files = templateRootDir.listFiles();
        if (files == null) {return;}
        for (File file : files) {
            this.views.add(new View(file));
        }
    }

    /**
     * 初始化处理程序适配器
     *
     * @param context 上下文
     */
    private void initHandlerAdapters(ApplicationContext context) {
        for (HandlerMapping handlerMapping : handlerMappings) {
            this.handlerAdapter.put(handlerMapping,new HandlerAdapter());
        }
    }

    /**
     * 收集url-method映射
     */
    private void initHandlerMappings(ApplicationContext context) {
        if (this.context.getBeanDefinitionCount() == 0) {return;}
        // 从Controller中获取请求映射信息
        for (String beanName : this.context.getBeanDefinitionNames()) {
            Object instance = this.context.getBean(beanName);
            Class<?> clazz = instance.getClass();
            if(!clazz.isAnnotationPresent(Controller.class)) {continue;}
            // 这里的类上都有@Controller注解
            String baseUrl = "";
            RequestMapper requestMapper = clazz.getAnnotation(RequestMapper.class);
            if (requestMapper != null) {
                baseUrl =  requestMapper.value();
            }
            Method[] methods = clazz.getMethods();
            for (Method method : methods) {
                RequestMapper methodRequestMapper = method.getAnnotation(RequestMapper.class);
                if(methodRequestMapper == null) {continue;}
                // 收集的url 如： /user/hello
                String regex = ("/"+baseUrl+"/"+methodRequestMapper.value())
                        .replaceAll("/+","/")
                        .replaceAll("\\*",".*")
                        .replaceAll("/+","/");
                Pattern pattern = Pattern.compile(regex);
                // "/user/hello" : method 存入handlerMapping

                handlerMappings.add(new HandlerMapping(pattern,instance,method));
                System.out.println(String.format("[HandlerMapping] <- [%s,%s]",pattern,method.getName()));
            }

        }
    }






}
