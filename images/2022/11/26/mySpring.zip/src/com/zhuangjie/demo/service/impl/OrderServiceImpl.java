package com.zhuangjie.demo.service.impl;

import com.zhuangjie.demo.service.OrderService;
import com.zhuangjie.spring.framework.annotation.Service;

/**
 * 订单服务impl
 *
 * @author manzhuangjie
 * @date 2022/11/23
 */
@Service
public class OrderServiceImpl implements OrderService {

}
