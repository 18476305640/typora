package com.zhuangjie.demo.controller;

import com.sun.org.glassfish.gmbal.ParameterNames;
import com.zhuangjie.demo.service.OrderService;
import com.zhuangjie.demo.service.UserService;
import com.zhuangjie.spring.framework.annotation.Autowired;
import com.zhuangjie.spring.framework.annotation.Controller;
import com.zhuangjie.spring.framework.annotation.RequestMapper;
import com.zhuangjie.spring.framework.annotation.RequestParam;
import com.zhuangjie.spring.framework.v3.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

/**
 * @author manzhuangjie
 */
@Controller
@RequestMapper("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    @RequestMapper("/hello")
    public  ModelAndView hello(@RequestParam("uid") Integer uid,@RequestParam("name") String name,@RequestParam("age") Integer age) throws IOException {
        HashMap<String, Object> model = new HashMap<>(8);
        model.put("username",name);
        model.put("info", "用户id是"+uid+"，年龄为"+age);
        return new ModelAndView("profile",model);
    }

}
