package com.zhuangjie.demo.service;

/**
 * @author manzhuangjie
 */
public interface UserService {
    public Integer addition(Integer i,Integer j);

}
