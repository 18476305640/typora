package com.zhuangjie.spring.framework.v1.servlet;

import com.zhuangjie.spring.framework.annotation.Autowired;
import com.zhuangjie.spring.framework.annotation.Controller;
import com.zhuangjie.spring.framework.annotation.RequestMapper;
import com.zhuangjie.spring.framework.annotation.Service;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.*;

public class MyDispatcherServlet extends HttpServlet {
    private Map<String,Object> ioc = new HashMap<>();
    private Map<String,Method> handlerMapping = new HashMap<>();
    private Properties contextConfig = new Properties();
    private List<String> classNames = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            doDispatch(req,resp);
        } catch (Exception e) {
            // 报 500
            resp.getWriter().write("500 Handler error！");
        }
    }

    private void doDispatch(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        String url = req.getRequestURI();
        String contextPath = req.getContextPath();
        url = url.replaceAll(contextPath, "").replaceAll("/+", "/");
        if(!handlerMapping.containsKey(url)) {
            // 报404
            resp.getWriter().write("404 Not found~");
            return;
        }
        // 没什么了
        Map<String, String[]> param = req.getParameterMap();
        Method method = this.handlerMapping.get(url);
        String beanName = toLowerFirstCase(method.getDeclaringClass().getSimpleName());
        String name = param.get("name")[0];
        method.invoke( ioc.get(beanName),new Object[]{req,resp,name });
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        //1、加载配置文件 (这里是先去读取web.xml中 param-name contextConfigLocation 对应的param-value值“application.properties”)
        //   初始化了 contextConfig
        doLoadConfig(config.getInitParameter("contextConfigLocation"));
        //2、 扫描相关的类， 传入了application.properties 中配置扫描包的值“com.zhuangjie.demo”
        //   向“classNames” 加入了所包下所有的 .class 文件路径
        doScanner(contextConfig.getProperty("scanPackage"));
        //3、实例化相关的类，并且缓存到IOC窗口中
        doInstance();
        //4、完成依赖注入，自动赋值
        doAutowrite();
        //5、初始化HandlerMapping
        doInitHandlerMappering();

        System.out.println("Spring framwork is inited!");
    }

    /**
     * 收集url-method映射
     */
    private void doInitHandlerMappering() {
        // 从Controller中获取请求映射信息
        for (Map.Entry<String, Object> entry : ioc.entrySet()) {
            Class<?> clazz = entry.getValue().getClass();
            if(!clazz.isAnnotationPresent(Controller.class)) {continue;}
            // 这里的类上都有@Controller注解
            String baseUrl = "";
            RequestMapper requestMapper = clazz.getAnnotation(RequestMapper.class);
            if (requestMapper != null) {
                baseUrl =  requestMapper.value();
            }
            Method[] methods = clazz.getMethods();
            for (Method method : methods) {
                RequestMapper methodRequestMapper = method.getAnnotation(RequestMapper.class);
                if(methodRequestMapper == null) {continue;}
                // 收集的url 如： /user/hello
                String url = ("/"+baseUrl+"/"+methodRequestMapper.value()).replaceAll("/+","/");
                // "/user/hello" : method 存入handlerMapping
                handlerMapping.put(url,method);
                System.out.println(String.format("[HandlerMapping] <- [%s,%s]",url,method.getName()));
            }

        }
    }

    /**
     * DI操作
     */
    private void doAutowrite() {
        // 自动注入是基于IOC来操作的，所以IOC不能为空
        if (ioc.isEmpty()) {return;}
        for (Map.Entry<String, Object> entry : ioc.entrySet()) {
            Object instance = entry.getValue();
            Field[] fields = instance.getClass().getDeclaredFields();
            for (Field field : fields) {
                // 对实例的所有有@Autowired注解的属性进行自动注入
                Autowired autowired = field.getAnnotation(Autowired.class);
                if (autowired == null) {continue;}
                // 构造从IOC中获取值的beanName
                String beanName = autowired.value();
                if (beanName.isEmpty()) {
                    beanName = toLowerFirstCase(field.getType().getSimpleName());
                }
                field.setAccessible(true);
                try {
                    field.set(instance,ioc.get(beanName));
                } catch (IllegalAccessException e) {
                    System.out.println("[ERROR] 为属性注入失败！");
                }

            }

        }
    }

    /**
     * 从classNames中进行实例化到IOC中
     */
    private void doInstance() {
        if(classNames.isEmpty()) {return;}
        try {
            for (String className : classNames) {
                // 加载类
                Class<?> clazz = Class.forName(className);
                // 判断注解类型
                if(clazz.isAnnotationPresent(Controller.class)) {
                    // 直接以为类名首字母小写为key，实例为value 存入IOC ，即： （userController:实例）-> IOC
                    String beanName = toLowerFirstCase(clazz.getSimpleName());
                    Object instance = clazz.newInstance();
                    ioc.put(beanName,instance);
                }else if(clazz.isAnnotationPresent(Service.class)){
                    // 判断是否有自定义beanName，如果有它就是className （className：实例）-> 再加入IOC容器
                    String beanName = toLowerFirstCase(clazz.getSimpleName());
                    Service serviceAnnotation = clazz.getAnnotation(Service.class);
                    if (!"".equals(serviceAnnotation.value())) {
                        beanName = serviceAnnotation.value();
                    }
                    Object instance = clazz.newInstance();
                    ioc.put(beanName,instance);
                    // 遍历其实现的接口，以接口名首字母小写为key，其实现类实例为value存入IOC, 即: (userController: userControllerImpl实例) -> IOC
                    for (Class<?> aClass : clazz.getInterfaces()) {
                        String interfaceBeanName = toLowerFirstCase(aClass.getSimpleName());
                        if(ioc.containsKey(interfaceBeanName)) {
                            throw new Exception("[ERROR] 已经存在相同BeanName！");
                        }
                        ioc.put(interfaceBeanName,instance);
                    }
                }else {continue; }
            }
        }catch (Exception e) {
            System.out.println("[ERROR] "+e.getMessage());
        }

    }

    private  String toLowerFirstCase(String simpleName) {
        if (simpleName.isEmpty()) {return simpleName;};
        char[] chars = simpleName.toCharArray();
        chars[0] = (chars[0]+"").toLowerCase().toCharArray()[0];
        return new String(chars);
    }


    /**
     * 做扫描: 初始化 classNames 集合，收集的是包下的所有class文件路径  com/zhuangjie/demo/abc.class => com.zhuangjie.demo.abc
     * @param scanPackage 扫描包
     */
    private void doScanner(String scanPackage) {
        // url 是 “/com/zhuangjie/demo”
        URL url = this.getClass().getClassLoader().getResource("/" + scanPackage.replaceAll("\\.", "/"));
        // 获取File对象
        File file = new File(url.getFile());
        for (File packageChildFile : file.listFiles()) {
            if(packageChildFile.isDirectory()) {
                // 如果是文件夹，递归
                this.doScanner(scanPackage+"."+packageChildFile.getName());
            }else {
                // 如果是文件, 且是 .class结尾的 得到 com.zhuangjie.demo.Controller 存到 classNames数组中
                if(!packageChildFile.getName().endsWith(".class")) {continue;}
                String name = packageChildFile.getName();
                String className = scanPackage + "." + name.substring(0, name.lastIndexOf(".class"));
                classNames.add(className);
            }
        }
    }


    /**
     * 加载配置
     * 也就是初始化 contextConfig 成员变量
     * @param contextConfigLocation 上下文配置位置
     */
    private void doLoadConfig(String contextConfigLocation)  {
        // 此时的contextConfigLocation值为“application.properties”，是从web.xml中读取的，转成输入流
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(contextConfigLocation);
        try {
            // 加载了配置文件
            contextConfig.load(is);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("加载配置-加载配置失败！");
        }finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    System.out.println("加载配置-关闭输入流失败！");
                }
            }
        }
    }


}
