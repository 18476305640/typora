package com.zhuangjie.redis;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * redis配置
 *
 * @author manzhuangjie
 * @date 2022/11/27
 */
@Configuration
@EnableConfigurationProperties({RedisConfigProperties.class})
public class RedisConfig {
    @Bean
    public RedissonClient redissonClient(RedisConfigProperties redisConfigProperties ) {
        Config config = new Config();
        String prefix = "redis://";
        if (redisConfigProperties.isSsl()) {
            prefix = "rediss://";
        }
        config.useSingleServer()
                .setAddress(prefix+redisConfigProperties.getHost()+":"+redisConfigProperties.getPort())
                .setTimeout(redisConfigProperties.getTimeout());
        return Redisson.create(config);
    }

}
