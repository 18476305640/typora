package com.zhuangjie.ios._2_NIO;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class _6_拷贝方式4_transferTo {
    public static void main(String[] args) {
        // 1、字节输入管道
        try (
                FileInputStream fis = new FileInputStream("D:\\tmp\\is.txt");
                FileOutputStream fos = new FileOutputStream("D:\\tmp\\os.txt");
        ){
            FileChannel fisChannel = fis.getChannel();
            FileChannel fosChannel = fos.getChannel();
            // 复制-transferForm
//            fosChannel.transferFrom(fisChannel,fisChannel.position(),fisChannel.size());
            fisChannel.transferTo(fisChannel.position(),fisChannel.size(),fosChannel);
            fisChannel.close();
            fosChannel.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
