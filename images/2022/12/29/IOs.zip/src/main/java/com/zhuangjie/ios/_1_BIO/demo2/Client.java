package com.zhuangjie.ios._1_BIO.demo2;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        System.out.println("==客户端的启动中==");
        // 创建一个Socket的通信管道，请求与服务端的端口连接
        Socket socket = new Socket("127.0.0.1", 8888);
        // 从socket通信管理中得到一个字节输出流
        OutputStream os = socket.getOutputStream();
        PrintStream ps = new PrintStream(os);
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("请说：");
            String inputStr = scanner.next();
            ps.println(inputStr);
            ps.flush();
       }

    }
}
