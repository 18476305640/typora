package com.zhuangjie.ios._2_NIO;


import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class _2_使用NIO读取文件 {
    public static void main(String[] args) {
        try {
            // 1、定义一个文件字节输入流与原文件接通
            FileInputStream is = new FileInputStream("D:\\tmp\\NIO写入.txt");
            // 2、需要得到文件字节输入流的文件通道
            FileChannel channel = is.getChannel();
            // 3、定义一个缓冲区
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            // 4、读取数据到缓冲区
            channel.read(buffer);
            buffer.flip();
            // 5、读取出缓冲区中的数据输出即可
            String rs = new String(buffer.array(), 0, buffer.remaining());
            System.out.printf(rs);
        }catch (Exception e) {}
    }
}
