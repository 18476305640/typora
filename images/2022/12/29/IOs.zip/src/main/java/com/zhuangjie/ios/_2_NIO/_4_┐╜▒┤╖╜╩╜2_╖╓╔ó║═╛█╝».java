package com.zhuangjie.ios._2_NIO;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * 分散读取 (Scatter ) :是指把Channel通道的数据读入到多个缓冲区中去
 * 聚集写入 (Gathering )是指将多个 Buffer 中的数据“聚集”到 Channel。
 */
public class _4_拷贝方式2_分散和聚集 {
    public static void main(String[] args) {
        try (
            FileInputStream fis = new FileInputStream("D:\\tmp\\is.txt");
            FileOutputStream fos = new FileOutputStream("D:\\tmp\\os.txt");
        ) {
            // 字节输入管道
            FileChannel isChannel = fis.getChannel();
            // 字节输出管道
            FileChannel osChannel = fos.getChannel();
            // 定义多个缓冲区数据分散
            ByteBuffer buffer1 = ByteBuffer.allocate(4);
            ByteBuffer buffer2 = ByteBuffer.allocate(1024);
            ByteBuffer[] buffers = {buffer1,buffer2};
            // 从通道中读取数据分散到各个缓冲区
            isChannel.read(buffers);
            // 从每个缓冲区中查询是否有数据读取到了
            for (ByteBuffer buffer : buffers) {
                // 切换到读模式：喝一杯，再喝一杯
                buffer.flip();
            }
            osChannel.write(buffers);
            isChannel.close();
            osChannel.close();
            System.out.println("写入完成！");

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
