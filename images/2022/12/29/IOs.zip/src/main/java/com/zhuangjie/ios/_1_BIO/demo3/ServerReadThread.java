package com.zhuangjie.ios._1_BIO.demo3;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class ServerReadThread extends Thread{
    private Socket socket;
    public ServerReadThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            // 从Socket管道中得到一个字节输入流
            InputStream is = socket.getInputStream();
            // 把字节输入流包装成自己需要的流进行数据的读取
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            // 读取数据
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("服务端收到："+line);
            }

        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
