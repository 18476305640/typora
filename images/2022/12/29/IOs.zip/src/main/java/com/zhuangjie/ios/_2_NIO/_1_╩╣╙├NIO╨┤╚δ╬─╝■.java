package com.zhuangjie.ios._2_NIO;

import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class _1_使用NIO写入文件 {
    public static void main(String[] args) {
        try {
            // 1、字节输出流通向目标文件
            FileOutputStream fos = new FileOutputStream("D:\\tmp\\NIO写入.txt");
            // 2、得到字节输出流对应的通道Channel
            FileChannel channel = fos.getChannel();
            // 3、分配缓冲区
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            buffer.put("你好呀，兄弟。我正在学NIO".getBytes());
            // 4、把缓冲区切换成写出模式
            buffer.flip();
            channel.write(buffer);
            channel.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
