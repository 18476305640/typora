package com.zhuangjie.ios._2_NIO;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class _5_拷贝方式3_transferForm从目标通道中去复制原通道数据 {
    public static void main(String[] args) {
        // 1、字节输入管道
        try (
            FileInputStream fis = new FileInputStream("D:\\tmp\\is.txt");
            FileOutputStream fos = new FileOutputStream("D:\\tmp\\os.txt");
        ){
            FileChannel fisChannel = fis.getChannel();
            FileChannel fosChannel = fos.getChannel();
            // 复制-transferForm
            fosChannel.transferFrom(fisChannel,fisChannel.position(),fisChannel.size());
            fisChannel.close();
            fosChannel.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
