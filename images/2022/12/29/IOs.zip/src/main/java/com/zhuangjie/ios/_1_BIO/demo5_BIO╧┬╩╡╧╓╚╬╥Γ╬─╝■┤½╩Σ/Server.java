package com.zhuangjie.ios._1_BIO.demo5_BIO下实现任意文件传输;

import java.io.IOException;
import java.net.ServerSocket;

public class Server {
    public static void main(String[] args) {
        try (
                ServerSocket ss = new ServerSocket(8888);
        ) {
            System.out.println("等待接收文件中...");
            // 交给一个独立的线程来处理与这个客户端的文件通信需求。
            ServerReaderThread thread = new ServerReaderThread(ss.accept());
            thread.start();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
