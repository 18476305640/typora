package com.zhuangjie.ios._1_BIO.demo1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {


        try {
            System.out.println("==服务器启动中==");
            // 注册端口
            ServerSocket serverSocket = new ServerSocket(8888);
            System.out.println("==服务器已启动==");
            // 开始在这里暂停等待接收客户端的连接，得到一个端到端的Socket管道
            Socket  socket = serverSocket.accept();
            // 从Socket管道中得到一个字节输入流
            InputStream is = socket.getInputStream();
            // 把字节输入流包装成自己需要的流进行数据的读取
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            // 读取数据
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("服务端收到："+line);
            }


        } catch (IOException e) {
            System.out.println("服务停止了！");
            throw new RuntimeException(e);
        }
    }
}
