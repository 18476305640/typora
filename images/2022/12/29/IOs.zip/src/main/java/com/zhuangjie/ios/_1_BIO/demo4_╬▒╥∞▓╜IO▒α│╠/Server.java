package com.zhuangjie.ios._1_BIO.demo4_伪异步IO编程;

import com.zhuangjie.ios._1_BIO.demo3.ServerReadThread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {


        try {
            System.out.println("==服务器启动中==");
            // 注册端口
            ServerSocket serverSocket = new ServerSocket(8888);
            System.out.println("==服务器已启动==");
            HandlerSocketThreadPool handlerSocketThreadPool = new HandlerSocketThreadPool(3, 1000);
            while (true) {
                // 开辟一个线程处理一个客户端连接。开始在这里暂停等待接收客户端的连接，得到一个端到端的Socket管道
                Socket socket = serverSocket.accept();
                handlerSocketThreadPool.execute(new ReaderClientRunnable(socket));
            }
        } catch (IOException e) {
            System.out.println("服务停止了！");
            throw new RuntimeException(e);
        }
    }
}
