package com.zhuangjie.ios._1_BIO.demo4_伪异步IO编程;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 处理器插座线程池
 *
 * @author zhuangjie
 * @date 2022/12/21
 */
public class HandlerSocketThreadPool {
    /**
     * 执行器
     */
    private ExecutorService executor;
    /**
     * 核心线程大小
     */
    private Integer coreThreadSize = 3;
    public HandlerSocketThreadPool(int maxPoolSize,int waitQueueSize) {
        this.executor = new ThreadPoolExecutor(
                coreThreadSize,maxPoolSize,
                120L,
                TimeUnit.SECONDS,
                new ArrayBlockingQueue<Runnable>(waitQueueSize)
        );
    }
    public void execute(Runnable task) {
        this.executor.execute(task);
    }
}
