package com.zhuangjie.ios._2_NIO;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class _3_使用NIO拷贝文件 {
    public static void main(String[] args) {
        try (
            FileInputStream is = new FileInputStream("D:\\system\\图片\\美女.jpg");
            FileOutputStream fos = new FileOutputStream("D:\\美女new.jpg");
        ){
            FileChannel readChannel = is.getChannel();
            FileChannel writeChannel = fos.getChannel();
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            while (readChannel.read(buffer) > 0) {
                buffer.flip();
                writeChannel.write(buffer);
                buffer.clear();
            }
            readChannel.close();
            writeChannel.close();
        }catch (Exception e) {}
    }
}
