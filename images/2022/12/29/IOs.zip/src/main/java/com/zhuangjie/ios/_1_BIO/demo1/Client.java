package com.zhuangjie.ios._1_BIO.demo1;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;

public class Client {
    public static void main(String[] args) throws IOException {
        System.out.printf("==客户端的启动中==");
        // 创建一个Socket的通信管道，请求与服务端的端口连接
        Socket socket = new Socket("127.0.0.1", 8888);
        // 从socket通信管理中得到一个字节输出流
        OutputStream os = socket.getOutputStream();
        PrintStream ps = new PrintStream(os);
        ps.println("Hello");
        ps.flush();

    }
}
