package com.zhuangjie.ios._1_BIO.demo5_BIO下实现任意文件传输;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.UUID;

/**
 * 服务器读线程
 *
 * @author zhuangjie
 * @date 2022/12/21
 */
public class ServerReaderThread extends Thread {
    private Socket socket;

    public ServerReaderThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        FileOutputStream os = null;
        try {
            // 1、得到一个数据输入流读取客户端发送过来的数据
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            // 2、读取客户端发送过来的文件类型
            String suffix = dis.readUTF();
            System.out.println("服务端接收的文件类型：" + suffix);
            // 3、定义一个字节输出管道负责把客户端发来的文件数据写出去
            String filename = UUID.randomUUID().toString().replaceAll("[_-]+", "").toUpperCase();
            os = new FileOutputStream("D:\\" + filename + "" + suffix);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = dis.read(buffer)) > 0) {
                os.write(buffer, 0, len);
            }
            os.flush();
            System.out.println("服务端接收文件保存成功！");
        } catch (Exception e) {
            try {
                os.close();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
            e.printStackTrace();
        }
    }
}
