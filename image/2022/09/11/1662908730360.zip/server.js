const express = require('express')
var history = require('connect-history-api-fallback');
const app = express();
app.use(history())
app.use(express.static(__dirname + "/static"))

app.put("/hello", (req, res) => {
    res.send({
        msg: '你好呀！兄弟，欢迎访问！'
    })
})
app.listen(5200, (err) => {
    if (!err) console.log("服务准备就绪！");
})